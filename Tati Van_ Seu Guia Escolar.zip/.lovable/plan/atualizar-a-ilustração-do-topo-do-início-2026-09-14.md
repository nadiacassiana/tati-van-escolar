# Atualizar a ilustração do topo do Início

## Objetivo
Usar a nova arte enviada como fundo do topo da tela inicial, com cores mais vivas e elementos escolares mais visíveis, sem alterar ações ou informações do painel.

## Alterações
- Recortar somente a área limpa da ilustração enviada, removendo as barras da galeria.
- Salvar a nova imagem no fluxo de mídia do projeto e substituir a arte anterior no topo do Início.
- Aumentar a presença visual da marca-d’água e ajustar a camada de contraste para manter saudação, botões e cartões perfeitamente legíveis.
- Preservar integralmente a saudação dinâmica baseada no horário e no nome do usuário conectado.
- Conferir o resultado em tela de celular e validar que a aplicação continua sem erros.

## Detalhes técnicos
- Manter a imagem proporcional, sem esticar, usando enquadramento adaptável ao topo.
- Alterar somente a apresentação da tela inicial; nenhuma regra, ação ou outro módulo será modificado.
