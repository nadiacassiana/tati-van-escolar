# Migrar rastreamento para Leaflet e OpenStreetMap

## Resultado
- Substituir o mapa do rastreio público por Leaflet com mapas do OpenStreetMap.
- Manter van animada, direção do veículo, casa, escola, privacidade e atualização contínua.
- Trocar o traçado de rota por OSRM, sem chave ou faturamento do Google.
- Trocar a geocodificação de casa/escola por Nominatim/Photon, sem chave.
- Remover os tipos e o carregamento da API do Google Maps usados pelo rastreio.
- Alterar o atalho externo do rastreio para abrir a localização no OpenStreetMap.

## Validação
- Verificar tipos, testes e compilação.
- Abrir a página pública em computador e celular para confirmar mapa, marcadores e ausência de erros.

## Detalhes técnicos
- O mapa usará tiles públicos do OpenStreetMap com a atribuição obrigatória.
- O percurso viário usará o serviço público OSRM, com fallback para linha direta se estiver indisponível.
- Login Google e outros recursos sem relação com mapas permanecerão inalterados.
