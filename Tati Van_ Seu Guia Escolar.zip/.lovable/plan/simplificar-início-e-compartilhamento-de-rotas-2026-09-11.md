# Simplificar início e compartilhamento de rotas

## Objetivo
Deixar o início da rota direto e mover o envio individual do rastreio para os cartões dos alunos, mantendo o link geral no painel.

## Alterações
- Simplificar a janela “Iniciar Rota” para mostrar somente 1h, 2h e 3h, com 2h selecionado, e um único botão “Iniciar Rota”.
- Remover o envio em massa, a escolha intermediária de responsáveis e o botão “Compartilhar” do painel azul.
- Adicionar “Enviar Rastreio” em cada cartão, com WhatsApp e link individual do aluno.
- Após voltar do WhatsApp, destacar o próximo aluno ainda não enviado, sem impedir pulos ou outra ordem de envio.
- Manter “Copiar Link Geral”, revogação, encerramento, contador e GPS no painel da rota.
- Atualizar as quatro telas do Guia da Rota para demonstrar exatamente o novo fluxo.

## Validação
- Conferir visualmente o Checklist em celular.
- Validar início com 2h padrão, geração de link individual e destaque da fila.
- Confirmar que o projeto compila sem erros.

## Detalhes técnicos
- A fila será local à rota ativa e avançará a partir do aluno acionado.
- O botão individual ficará disponível somente com rota ativa, link válido e telefone do responsável.
- Nenhuma tabela ou regra de outros módulos será alterada.
