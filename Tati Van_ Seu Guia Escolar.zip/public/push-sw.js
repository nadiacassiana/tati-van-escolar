/*
 * Service Worker de MENSAGERIA (Web Push) da Tati Van Escolar.
 *
 * Escopo intencionalmente mínimo: este worker NÃO faz cache de HTML/assets
 * (não é um app-shell) — ele só recebe notificações push e trata o toque
 * na notificação. Isso evita qualquer risco de conteúdo desatualizado.
 */

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

function parsePayload(event) {
  const fallback = {
    title: "Tati Van Escolar",
    body: "Você tem um novo aviso na Tati.",
    url: "/dashboard",
    tag: "tati-geral",
  };
  if (!event.data) return fallback;
  try {
    const data = event.data.json();
    return {
      title: data.title || fallback.title,
      body: data.body || fallback.body,
      url: data.url || fallback.url,
      tag: data.tag || fallback.tag,
      data: data.data || {},
    };
  } catch {
    return { ...fallback, body: event.data.text() || fallback.body };
  }
}

self.addEventListener("push", (event) => {
  const payload = parsePayload(event);
  event.waitUntil(
    self.registration.showNotification(payload.title, {
      body: payload.body,
      icon: "/icon-192.png",
      badge: "/icon-192.png",
      tag: payload.tag,
      renotify: false,
      data: { url: payload.url, ...(payload.data || {}) },
    }),
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || "/dashboard";
  event.waitUntil(
    (async () => {
      const url = new URL(target, self.location.origin).href;
      const windowClients = await self.clients.matchAll({
        type: "window",
        includeUncontrolled: true,
      });
      for (const client of windowClients) {
        if ("focus" in client) {
          await client.focus();
          if ("navigate" in client) {
            try {
              await client.navigate(url);
            } catch {
              /* alguns navegadores bloqueiam navigate; o foco já basta */
            }
          }
          return;
        }
      }
      if (self.clients.openWindow) await self.clients.openWindow(url);
    })(),
  );
});
