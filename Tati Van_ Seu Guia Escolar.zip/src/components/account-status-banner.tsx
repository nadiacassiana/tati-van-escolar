import { Link } from "@tanstack/react-router";
import { AlertTriangle, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAccountStatus } from "@/hooks/use-account-status";

export function AccountStatusBanner() {
  const status = useAccountStatus();

  if (status.phase === "mensalidade_vencida") {
    const dias = status.graceDaysLeft;
    const texto =
      dias >= 3
        ? "Detectamos uma mensalidade em aberto. Regularize seu pagamento para continuar utilizando todos os benefícios da Tati Van Escolar."
        : dias === 0
        ? "Seu pagamento continua pendente. Regularize sua mensalidade hoje para evitar a pausa das funcionalidades da Tati Van Escolar."
        : dias === 1
        ? "Seu pagamento continua pendente. Regularize sua mensalidade para evitar a pausa do acesso. Você ainda tem 1 dia de tolerância."
        : `Detectamos uma mensalidade em aberto. Regularize seu pagamento para continuar utilizando normalmente a Tati Van Escolar. Você ainda tem ${dias} dias de tolerância.`;

    return (
      <div className="border-b border-accent bg-accent/30">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-accent-foreground" />
            <div className="text-sm">
              <div className="font-bold text-accent-foreground">Mensalidade em aberto</div>
              <p className="text-muted-foreground">{texto}</p>
            </div>
          </div>
          <Link to="/assinatura" className="shrink-0">
            <Button size="sm" className="font-bold">Regularizar pagamento</Button>
          </Link>
        </div>
      </div>
    );
  }

  if (status.phase === "inadimplente") {
    return (
      <div className="border-b border-destructive/40 bg-destructive/10">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-start gap-3">
            <Lock className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
            <div className="text-sm">
              <div className="font-bold text-destructive">
                Sua assinatura está pausada porque identificamos uma mensalidade em aberto.
              </div>
              <p className="text-muted-foreground">
                Regularize seu pagamento para desbloquear novamente todas as funcionalidades da
                Tati Van Escolar. Seus dados continuam preservados e podem ser consultados
                normalmente.
              </p>
            </div>
          </div>
          <Link to="/assinatura" className="shrink-0">
            <Button size="sm" variant="destructive" className="font-bold">
              Regularizar pagamento
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  if (status.phase === "tolerancia") {

    const restante =
      status.graceDaysLeft <= 0
        ? "Hoje é o último dia de tolerância."
        : status.graceDaysLeft === 1
        ? "Você tem mais 1 dia de tolerância."
        : `Você tem mais ${status.graceDaysLeft} dias de tolerância.`;

    return (
      <div className="border-b border-accent bg-accent/30">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-accent-foreground" />
            <div className="text-sm">
              <div className="font-bold text-accent-foreground">
                Seu período de teste terminou.
              </div>
              <p className="text-muted-foreground">
                {restante} Ative sua assinatura para continuar utilizando a plataforma sem
                interrupções.
              </p>
            </div>
          </div>
          <Link to="/assinatura" className="shrink-0">
            <Button size="sm" className="font-bold">Reativar assinatura</Button>
          </Link>
        </div>
      </div>
    );
  }

  if (status.phase === "pausada") {
    return (
      <div className="border-b border-destructive/40 bg-destructive/10">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-start gap-3">
            <Lock className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
            <div className="text-sm">
              <div className="font-bold text-destructive">Sua conta está pausada.</div>
              <p className="text-muted-foreground">
                O período de teste foi encerrado. Para voltar a utilizar todas as
                funcionalidades da Tati Van Escolar, basta ativar sua assinatura. Seus dados
                estão preservados e podem ser consultados normalmente.
              </p>
            </div>
          </div>
          <Link to="/assinatura" className="shrink-0">
            <Button size="sm" variant="destructive" className="font-bold">
              Reativar assinatura
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return null;
}
