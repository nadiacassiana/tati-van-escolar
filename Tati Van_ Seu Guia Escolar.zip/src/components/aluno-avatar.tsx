import { avatarPorSexo, isAvatarUrl, type Sexo } from "@/lib/aluno-avatar";

export type AlunoAvatarProps = {
  nome: string;
  fotoUrl?: string | null;
  foto_url?: string | null;
  avatar?: string | null;
  sexo?: Sexo;
  size?: number;
  className?: string;
};

export function AlunoAvatar({
  nome,
  fotoUrl,
  foto_url,
  avatar,
  sexo,
  size = 40,
  className = "",
}: AlunoAvatarProps) {
  const photo = fotoUrl || foto_url;
  const defaultAvatar = sexo ? avatarPorSexo(sexo) : undefined;
  const fallback = defaultAvatar || avatar;

  const baseClass =
    "inline-flex shrink-0 items-center justify-center rounded-2xl bg-secondary object-cover " + className;

  if (photo) {
    return (
      <img
        src={photo}
        alt={nome}
        className={baseClass}
        style={{ width: size, height: size }}
      />
    );
  }

  if (fallback && isAvatarUrl(fallback)) {
    return (
      <img
        src={fallback}
        alt={nome}
        className={baseClass}
        style={{ width: size, height: size }}
      />
    );
  }

  return (
    <div
      className={baseClass}
      style={{ width: size, height: size, fontSize: size * 0.55 }}
    >
      {fallback || "🧒"}
    </div>
  );
}
