import { useEffect, useMemo, useState } from "react";
import { MessageCircle, Pencil } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { mensagemAniversario } from "@/lib/aniversarios";
import { buildWhatsAppUrl } from "@/lib/whatsapp";

export type ResponsavelContato = { id: string; nome: string; telefone: string };

export function AniversarioWhatsAppDialog({
  open,
  onOpenChange,
  alunoNome,
  responsaveis,
  assinatura,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  alunoNome: string;
  responsaveis: ResponsavelContato[];
  assinatura?: string;
}) {
  const padrao = useMemo(() => mensagemAniversario(alunoNome, assinatura), [alunoNome, assinatura]);
  const [texto, setTexto] = useState(padrao);
  const [editando, setEditando] = useState(false);
  const [destino, setDestino] = useState<string>(responsaveis[0]?.id ?? "");

  useEffect(() => {
    if (open) {
      setTexto(padrao);
      setEditando(false);
      setDestino(responsaveis[0]?.id ?? "");
    }
  }, [open, padrao, responsaveis]);

  const semTelefone = responsaveis.length === 0;
  const escolhido = responsaveis.find((r) => r.id === destino) ?? responsaveis[0];

  function enviar() {
    if (!escolhido) return;
    // A Tati nunca envia sozinha: abrimos o WhatsApp com o texto pronto e a
    // motorista confirma o envio dentro do próprio aplicativo.
    window.open(buildWhatsAppUrl(escolhido.telefone, texto), "_blank", "noopener,noreferrer");
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>🎂 Mensagem de aniversário</DialogTitle>
          <DialogDescription>
            Confira (e edite, se quiser) a mensagem antes de abrir o WhatsApp.
          </DialogDescription>
        </DialogHeader>

        {semTelefone ? (
          <div className="rounded-lg bg-muted p-4 text-sm text-muted-foreground">
            Nenhum responsável com telefone cadastrado para <strong>{alunoNome}</strong>. Cadastre o
            telefone do responsável para enviar a mensagem pelo WhatsApp.
          </div>
        ) : (
          <div className="space-y-4">
            {responsaveis.length > 1 && (
              <div className="space-y-2">
                <Label>Enviar para</Label>
                <div className="flex flex-wrap gap-2">
                  {responsaveis.map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => setDestino(r.id)}
                      className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${
                        r.id === destino
                          ? "border-primary bg-primary/10 text-primary"
                          : "text-muted-foreground"
                      }`}
                    >
                      {r.nome} · {r.telefone}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {editando ? (
              <Textarea
                value={texto}
                onChange={(e) => setTexto(e.target.value)}
                rows={12}
                className="text-sm"
              />
            ) : (
              <div className="whitespace-pre-wrap rounded-xl bg-muted p-4 text-sm">{texto}</div>
            )}
          </div>
        )}

        <DialogFooter className="flex-col gap-2 sm:flex-row">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          {!semTelefone && (
            <>
              <Button variant="outline" onClick={() => setEditando((v) => !v)}>
                <Pencil className="h-4 w-4" /> {editando ? "Concluir edição" : "Editar mensagem"}
              </Button>
              <Button onClick={enviar}>
                <MessageCircle className="h-4 w-4" /> Enviar pelo WhatsApp
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
