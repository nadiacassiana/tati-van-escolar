import { useEffect, useMemo, useState } from "react";
import { CalendarClock, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { formatBRL } from "@/lib/format";
import { trackEvent } from "@/lib/track-event";
import { feedbackSucesso } from "@/lib/sons";
import { ReciboActions } from "@/components/recibo-actions";
import { formatMesReferencia, type Recibo } from "@/lib/recibo";
import type { MotoristaPerfil } from "@/lib/whatsapp";
import {
  competenciasFuturas, formatMesRef, formatDataBR,
  type AlunoMensalidade, type PagamentoMini,
} from "@/lib/mensalidades";

const METODOS = [
  { v: "pix", label: "PIX" },
  { v: "dinheiro", label: "Dinheiro" },
  { v: "transferencia", label: "Transferência" },
  { v: "cartao", label: "Cartão" },
  { v: "outro", label: "Outro" },
];

/**
 * Antecipação de mensalidades (opcional).
 *
 * Registra cada mês futuro escolhido como um pagamento independente, com o
 * recibo correspondente. Não altera nenhuma regra de vencimento, tolerância,
 * inadimplência ou pausa da assinatura.
 */
export function AnteciparMensalidades({
  aluno,
  userId,
  onDone,
  variant = "outline",
  size = "sm",
  maxMesRef,
  motorista,
}: {
  aluno: AlunoMensalidade;
  userId: string;
  onDone?: () => void;
  variant?: "outline" | "default" | "ghost";
  size?: "sm" | "default";
  maxMesRef?: string;
  motorista?: MotoristaPerfil;
}) {
  const [open, setOpen] = useState(false);
  const [pagamentos, setPagamentos] = useState<PagamentoMini[]>([]);
  const [selecionados, setSelecionados] = useState<string[]>([]);
  const [metodo, setMetodo] = useState("pix");
  const [data, setData] = useState(new Date().toISOString().slice(0, 10));
  const [saving, setSaving] = useState(false);
  const [sucessoRecibos, setSucessoRecibos] = useState<Recibo[]>([]);
  const [sucessoOpen, setSucessoOpen] = useState(false);
  const [reciboAtivo, setReciboAtivo] = useState<Recibo | null>(null);
  const [reciboActionsOpen, setReciboActionsOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    setSelecionados([]);
    (async () => {
      const { data: ps } = await supabase
        .from("pagamentos")
        .select("id, aluno_id, mes_referencia, valor, metodo, data_pagamento")
        .eq("aluno_id", aluno.id);
      setPagamentos(((ps as unknown) as PagamentoMini[]) || []);
    })();
  }, [open, aluno.id]);

  const futuras = useMemo(
    () => competenciasFuturas(aluno, pagamentos, 12).filter((c) => !maxMesRef || c.mes <= maxMesRef),
    [aluno, pagamentos, maxMesRef],
  );
  const total = futuras
    .filter((c) => selecionados.includes(c.mes))
    .reduce((s, c) => s + Number(c.valor), 0);

  const alternar = (mes: string) =>
    setSelecionados((atual) =>
      atual.includes(mes) ? atual.filter((m) => m !== mes) : [...atual, mes],
    );

  const confirmar = async () => {
    const escolhidas = futuras
      .filter((c) => selecionados.includes(c.mes))
      .sort((a, b) => a.mes.localeCompare(b.mes));
    if (escolhidas.length === 0) return toast.error("Selecione ao menos um mês.");
    setSaving(true);

    // Trava de segurança: nunca cobrar duas vezes o mesmo mês.
    const { data: jaPagos } = await supabase
      .from("pagamentos")
      .select("mes_referencia")
      .eq("aluno_id", aluno.id)
      .in("mes_referencia", escolhidas.map((c) => c.mes));
    const bloqueados = new Set(
      ((jaPagos as { mes_referencia: string }[] | null) || []).map((p) => p.mes_referencia),
    );
    const pendentes = escolhidas.filter((c) => !bloqueados.has(c.mes));
    if (pendentes.length === 0) {
      setSaving(false);
      return toast.error("Esses meses já estão pagos.");
    }

    let respDados: { nome?: string; cpf?: string; telefone?: string; whatsapp?: string; email?: string } = {};
    if (aluno.responsavel) {
      const { data: resp } = await supabase
        .from("responsaveis")
        .select("nome, cpf, telefone, whatsapp, email")
        .ilike("nome", aluno.responsavel)
        .maybeSingle();
      if (resp) respDados = resp as typeof respDados;
    }

    let ok = 0;
    const gerados: Recibo[] = [];
    for (const c of pendentes) {
      const obs = `Pagamento antecipado da mensalidade de ${formatMesRef(c.mes)}`;
      const { data: pag, error } = await supabase
        .from("pagamentos")
        .insert({
          user_id: userId,
          aluno_id: aluno.id,
          mes_referencia: c.mes,
          valor: Number(c.valor),
          metodo,
          data_pagamento: data,
          observacoes: obs,
        })
        .select()
        .single();
      if (error) continue;
      ok += 1;
      const { data: rec } = await supabase.from("recibos").insert({
        user_id: userId,
        numero: "",
        pagamento_id: pag?.id,
        aluno_id: aluno.id,
        aluno_nome: aluno.nome,
        escola: aluno.escola || null,
        turma: aluno.turma || null,
        periodo: null,
        responsavel_nome: respDados.nome || aluno.responsavel || null,
        responsavel_cpf: respDados.cpf || null,
        responsavel_telefone: respDados.telefone || aluno.whatsapp || null,
        responsavel_whatsapp: respDados.whatsapp || aluno.whatsapp || null,
        responsavel_email: respDados.email || null,
        mes_referencia: c.mes,
        valor: Number(c.valor),
        data_vencimento: c.vencimentoISO,
        data_pagamento: data,
        metodo,
        observacoes: obs,
      }).select().single();
      if (rec) gerados.push(rec as unknown as Recibo);
    }

    setSaving(false);
    if (ok === 0) return toast.error("Não foi possível registrar a antecipação.");
    trackEvent("mensalidade_antecipada", `${aluno.nome} — ${ok} mês(es)`);
    feedbackSucesso();
    setOpen(false);
    // Importante: onDone só é chamado ao FECHAR o pop-up de sucesso. Se fosse
    // chamado aqui, o recarregamento do Financeiro desmontaria este componente
    // (lista vira skeleton) e o pop-up nunca apareceria.

    // Pop-up de sucesso com acesso direto aos recibos (mês atual + antecipados).
    const mesAtual = new Date().toISOString().slice(0, 7);
    const lista: Recibo[] = [];
    if (!gerados.some((r) => r.mes_referencia === mesAtual)) {
      const { data: recAtual } = await supabase
        .from("recibos")
        .select("*")
        .eq("aluno_id", aluno.id)
        .eq("mes_referencia", mesAtual)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (recAtual) lista.push(recAtual as unknown as Recibo);
    }
    lista.push(...gerados);
    setSucessoRecibos(lista);
    setSucessoOpen(true);
  };

  return (
    <>
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={variant} size={size}>
          <CalendarClock className="mr-1 h-3 w-3" /> Antecipar
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-md">
        <DialogHeader>
          <DialogTitle>⏩ Antecipar mensalidades</DialogTitle>
          <DialogDescription>
            {aluno.nome} — escolha os meses ainda não vencidos que o responsável quer
            pagar adiantado. Cada mês é registrado separadamente, com recibo próprio.
          </DialogDescription>
        </DialogHeader>

        {futuras.length === 0 ? (
          <div className="py-6 text-center text-sm text-muted-foreground">
            Não há meses futuros disponíveis para antecipação.
          </div>
        ) : (
          <ul className="divide-y rounded-xl border">
            {futuras.map((c) => (
              <li key={c.mes} className="flex items-center gap-3 px-4 py-3">
                <Checkbox
                  id={`ant-${c.mes}`}
                  checked={selecionados.includes(c.mes)}
                  onCheckedChange={() => alternar(c.mes)}
                />
                <Label htmlFor={`ant-${c.mes}`} className="flex-1 cursor-pointer">
                  <span className="font-semibold">{formatMesRef(c.mes)}</span>
                  <span className="block text-xs font-normal text-muted-foreground">
                    Vencimento {formatDataBR(c.vencimentoISO)}
                  </span>
                </Label>
                <span className="font-bold">R$ {formatBRL(c.valor)}</span>
              </li>
            ))}
          </ul>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Forma de recebimento</Label>
            <Select value={metodo} onValueChange={setMetodo}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {METODOS.map((m) => <SelectItem key={m.v} value={m.v}>{m.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="data-ant">Data do pagamento</Label>
            <Input
              id="data-ant"
              type="date"
              value={data}
              onChange={(e) => setData(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-xl bg-muted px-4 py-3 text-sm">
          <span className="font-semibold">
            {selecionados.length} mês{selecionados.length === 1 ? "" : "es"} selecionado
            {selecionados.length === 1 ? "" : "s"}
          </span>
          <Badge variant="outline" className="font-bold">Total R$ {formatBRL(total)}</Badge>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)} disabled={saving}>
            Cancelar
          </Button>
          <Button onClick={confirmar} disabled={saving || selecionados.length === 0}>
            {saving && <Loader2 className="mr-1 h-4 w-4 animate-spin" />}
            Registrar pagamento antecipado
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>

      {/* Pop-up de sucesso: acesso direto aos recibos gerados na antecipação */}
      <Dialog
        open={sucessoOpen && !reciboActionsOpen}
        onOpenChange={(v) => {
          setSucessoOpen(v);
          if (!v) onDone?.();
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Antecipação realizada com sucesso! 🎉</DialogTitle>
            <DialogDescription>Deseja enviar ou visualizar os recibos agora?</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2">
            {sucessoRecibos.map((r) => (
              <Button
                key={r.id}
                onClick={() => { setReciboAtivo(r); setReciboActionsOpen(true); }}
                className="w-full bg-success font-bold text-success-foreground hover:bg-success/90"
              >
                🟢 Enviar Recibo {formatMesReferencia(r.mes_referencia)}
              </Button>
            ))}
            <Button variant="ghost" onClick={() => setSucessoOpen(false)} className="w-full">
              Continuar no Financeiro
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {motorista && (
        <ReciboActions
          open={reciboActionsOpen}
          onOpenChange={(v) => {
            setReciboActionsOpen(v);
            if (!v) {
              setSucessoOpen(false);
              onDone?.();
            }
          }}
          recibo={reciboAtivo}
          motorista={motorista}
          showSuccessTitle={false}
        />
      )}
    </>
  );
}
