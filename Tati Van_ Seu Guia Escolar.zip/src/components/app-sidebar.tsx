import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { SugerirMelhoriaDialog } from "@/components/sugerir-melhoria-dialog";
import { Home, Users, UsersRound, Bus, Wallet, Fuel, Wrench, Calendar, CheckSquare, Settings, LogOut, FileText, FileSignature, MessageCircle, Receipt, Shield, CreditCard, Ticket, Rocket, Lightbulb, History as HistoryIcon, Sparkles } from "lucide-react";
import { useIsAdmin } from "@/hooks/use-is-admin";
import { useTatiAcesso } from "@/hooks/use-tati-acesso";
import { supabase } from "@/integrations/supabase/client";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

type MenuItem = { title: string; url: string; icon: React.ElementType; highlight?: boolean };

type MenuGroup = { label: string; items: MenuItem[] };

const groups: MenuGroup[] = [
  {
    label: "🚀 COMECE POR AQUI",
    items: [
      { title: "Meus Dados", url: "/comece-aqui", icon: Rocket, highlight: true },
    ],
  },
  {
    label: "👨‍👩‍👧‍👦 MEUS ALUNOS",
    items: [
      { title: "Alunos", url: "/alunos", icon: Users },
      { title: "Responsáveis", url: "/responsaveis", icon: UsersRound },
      { title: "Financeiro", url: "/financeiro", icon: Wallet },
      { title: "Recibos", url: "/recibos", icon: Receipt },
      { title: "Contratos", url: "/contratos", icon: FileSignature },
      { title: "Reserva de Vaga", url: "/garantia-vaga", icon: Ticket },
      { title: "Mensagens", url: "/mensagens", icon: MessageCircle },
    ],
  },
  {
    label: "📊 OPERAÇÃO",
    items: [
      { title: "Painel", url: "/dashboard", icon: Home },
      { title: "Checklist Diário", url: "/checklist", icon: CheckSquare },
      { title: "Histórico de Rotas", url: "/historico-rotas", icon: HistoryIcon },

    ],
  },
  {
    label: "🚐 MINHA VAN",
    items: [
      { title: "Van", url: "/van", icon: Bus },
      { title: "Documentos", url: "/documentos", icon: FileText },
      { title: "Gastos", url: "/gastos", icon: Fuel },
      { title: "Manutenção", url: "/manutencao", icon: Wrench },
      { title: "Agenda", url: "/agenda", icon: Calendar },
    ],
  },
  {
    label: "💡 COLABORE",
    items: [
      { title: "Sugerir Melhoria", url: "#sugerir", icon: Lightbulb },
    ],
  },
  {
    label: "⚙️ CONTA",
    items: [
      { title: "Assinatura", url: "/assinatura", icon: CreditCard },
      { title: "Configurações", url: "/configuracoes", icon: Settings },
    ],
  },
];


export function AppSidebar() {
  const navigate = useNavigate();
  const currentPath = useRouterState({ select: (s) => s.location.pathname });
  const { isMobile, setOpenMobile } = useSidebar();
  const isAdmin = useIsAdmin();
  const temTati = useTatiAcesso();
  const [sugerirOpen, setSugerirOpen] = useState(false);
  const sugerirTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const closeIfMobile = () => {
    if (isMobile) setOpenMobile(false);
  };

  const handleSugerirOpen = (open: boolean) => {
    if (sugerirTimeoutRef.current) {
      clearTimeout(sugerirTimeoutRef.current);
      sugerirTimeoutRef.current = null;
    }
    if (open && isMobile) {
      closeIfMobile();
      sugerirTimeoutRef.current = setTimeout(() => {
        sugerirTimeoutRef.current = null;
        setSugerirOpen(true);
      }, 350);
    } else {
      setSugerirOpen(open);
    }
  };

  useEffect(() => {
    return () => {
      if (sugerirTimeoutRef.current) clearTimeout(sugerirTimeoutRef.current);
    };
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  const renderMenuButton = (item: MenuItem) => {
    const active = currentPath === item.url;
    const isLogout = item.url === "#logout";
    const isSugerir = item.url === "#sugerir";
    const highlightClass = item.highlight && !active ? "text-accent" : "";

    if (isSugerir) {
      return (
        <SidebarMenuItem key={item.title}>
          <SidebarMenuButton tooltip={item.title} onClick={() => handleSugerirOpen(true)}>
            <item.icon className="h-4 w-4" />
            <span>{item.title}</span>
          </SidebarMenuButton>
        </SidebarMenuItem>
      );
    }

    return (
      <SidebarMenuItem key={item.title}>
        <SidebarMenuButton
          asChild={!isLogout}
          isActive={active}
          tooltip={item.title}
          onClick={isLogout ? handleLogout : undefined}
        >
          {isLogout ? (
            <span className={highlightClass}>
              <item.icon className="h-4 w-4" />
              <span>{item.title}</span>
            </span>
          ) : (
            <Link to={item.url} onClick={closeIfMobile} className={highlightClass}>
              <item.icon className="h-4 w-4" />
              <span>{item.title}</span>
            </Link>
          )}
        </SidebarMenuButton>
      </SidebarMenuItem>
    );
  };

  return (
    <>
      <Sidebar collapsible="icon">
        <SidebarHeader className="border-b border-sidebar-border/40">
          <Link to={isAdmin ? "/admin" : "/dashboard"} onClick={closeIfMobile} className="flex items-center gap-2 px-2 py-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-accent text-accent-foreground text-lg">
              🚐
            </div>
            <div className="flex flex-col group-data-[collapsible=icon]:hidden">
              <span className="text-sm font-bold leading-tight text-sidebar-foreground">Tati Van</span>
              <span className="text-[10px] uppercase tracking-wider text-sidebar-foreground/70">Escolar</span>
            </div>
          </Link>
        </SidebarHeader>
        <SidebarContent>
          {!isAdmin &&
            groups.map((group) => (
              <SidebarGroup key={group.label}>
                <SidebarGroupLabel>{group.label}</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {group.items.map(renderMenuButton)}
                    {group.label === "💡 COLABORE" && temTati
                      ? renderMenuButton({ title: "Fale com a Tati", url: "/fale-com-a-tati", icon: Sparkles })
                      : null}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            ))}
          {isAdmin && (
            <SidebarGroup>
              <SidebarGroupLabel>🛡️ ADMIN</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton asChild isActive={currentPath === "/admin"} tooltip="Painel Admin">
                      <Link to="/admin" onClick={closeIfMobile}>
                        <Shield className="h-4 w-4" />
                        <span>Painel Admin</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                      tooltip="Sugestões & Feedbacks"
                      onClick={() => {
                        closeIfMobile();
                        if (currentPath !== "/admin") {
                          window.location.assign("/admin#sugestoes");
                        } else {
                          document.getElementById("sugestoes")?.scrollIntoView({ behavior: "smooth", block: "start" });
                        }
                      }}
                    >
                      <Lightbulb className="h-4 w-4" />
                      <span>Sugestões</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                  <SidebarMenuItem>
                    <SidebarMenuButton tooltip="Sair" onClick={handleLogout}>
                      <LogOut className="h-4 w-4" />
                      <span>Sair</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          )}
        </SidebarContent>
      </Sidebar>
      <SugerirMelhoriaDialog open={sugerirOpen} onOpenChange={handleSugerirOpen}>
        <span className="hidden" />
      </SugerirMelhoriaDialog>
    </>
  );
}
