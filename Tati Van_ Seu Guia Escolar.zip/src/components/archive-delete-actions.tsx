import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Archive, Trash2, ArchiveRestore, AlertTriangle } from "lucide-react";

type Props = {
  isArchived: boolean;
  hasHistory: boolean;
  historyLabel?: string; // e.g. "contratos, recibos e mensalidades"
  entityLabel: string; // e.g. "aluno", "responsável"
  entityName?: string;
  onArchive: () => void | Promise<void>;
  onRestore?: () => void | Promise<void>;
  onDelete: () => void | Promise<void>;
  compact?: boolean;
};

export function ArchiveDeleteActions({
  isArchived,
  hasHistory,
  historyLabel = "contratos, recibos, mensalidades ou documentos",
  entityLabel,
  entityName,
  onArchive,
  onRestore,
  onDelete,
  compact,
}: Props) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [busy, setBusy] = useState(false);

  const run = async (fn: () => void | Promise<void>) => {
    setBusy(true);
    try { await fn(); } finally { setBusy(false); }
  };

  return (
    <>
      <div className={`flex ${compact ? "gap-1" : "gap-2"} items-center flex-wrap`}>
        {isArchived ? (
          <Button
            size={compact ? "sm" : "default"}
            variant="default"
            className="bg-primary text-primary-foreground font-bold"
            disabled={busy}
            onClick={() => onRestore && run(onRestore)}
          >
            <ArchiveRestore className={compact ? "h-3.5 w-3.5" : "h-4 w-4"} />
            {compact ? "Restaurar" : "Restaurar"}
          </Button>
        ) : (
          <Button
            size={compact ? "sm" : "default"}
            variant="default"
            className="bg-primary text-primary-foreground font-bold"
            disabled={busy}
            onClick={() => run(onArchive)}
          >
            <Archive className={compact ? "h-3.5 w-3.5" : "h-4 w-4"} />
            Arquivar
          </Button>
        )}
        <Button
          size={compact ? "sm" : "default"}
          variant="ghost"
          className="text-destructive hover:bg-destructive/10 hover:text-destructive"
          disabled={busy}
          onClick={() => setConfirmDelete(true)}
        >
          <Trash2 className={compact ? "h-3.5 w-3.5" : "h-4 w-4"} />
          Excluir
        </Button>
      </div>

      <Dialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Excluir {entityLabel} definitivamente?
            </DialogTitle>
            <DialogDescription className="space-y-2 pt-2">
              {entityName && (
                <span className="block font-medium text-foreground">{entityName}</span>
              )}
              <span className="block">
                Esta ação é <b>irreversível</b>. Não será possível recuperar depois.
              </span>
              {hasHistory && (
                <span className="mt-3 block rounded-md border border-warning/40 bg-warning/10 p-3 text-sm text-foreground">
                  ⚠️ Este cadastro possui <b>{historyLabel}</b> relacionados.
                  Recomendamos usar <b>Arquivar</b> para preservar o histórico.
                  Você pode restaurar quando quiser.
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setConfirmDelete(false)} disabled={busy}>
              Cancelar
            </Button>
            {hasHistory && !isArchived && (
              <Button
                variant="default"
                className="bg-primary text-primary-foreground font-bold"
                disabled={busy}
                onClick={async () => { setConfirmDelete(false); await run(onArchive); }}
              >
                <Archive className="h-4 w-4" /> Arquivar
              </Button>
            )}
            <Button
              variant="destructive"
              disabled={busy}
              onClick={async () => { setConfirmDelete(false); await run(onDelete); }}
            >
              <Trash2 className="h-4 w-4" /> Excluir definitivamente
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
