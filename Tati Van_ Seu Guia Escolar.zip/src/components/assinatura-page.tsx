import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  Sparkles, RefreshCcw, CreditCard, Calendar, Wallet, Hash, Clock, ExternalLink, ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { getAsaasSubscriptionStatus } from "@/lib/asaas.functions";
import { SubscribeDialog } from "@/components/subscribe-dialog";

const PLAN_NAME = "Tati Van";
const PLAN_PRICE = 29.9;
const TRIAL_DAYS = 10;

function formatDate(v: string | Date | null | undefined) {
  if (!v) return "—";
  if (typeof v === "string") {
    // Date-only strings (YYYY-MM-DD) should be treated as local midnight
    // to avoid timezone shifts showing the previous day in pt-BR.
    if (/^\d{4}-\d{2}-\d{2}$/.test(v)) {
      const [y, m, d] = v.split("-").map(Number);
      const date = new Date(y, m - 1, d);
      if (!Number.isNaN(date.getTime())) {
        return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
      }
    }
  }
  const d = typeof v === "string" ? new Date(v) : v;
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });
}

function formatMoney(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function paymentLabel(method?: string | null) {
  if (!method) return "A escolher (PIX, Boleto ou Cartão)";
  switch (method) {
    case "PIX": return "PIX";
    case "BOLETO": return "Boleto";
    case "CREDIT_CARD": return "Cartão de crédito";
    case "MANUAL": return "A escolher (PIX, Boleto ou Cartão)";
    default: return method;
  }
}

function statusInfo(status?: string | null) {
  const s = (status ?? "").toUpperCase();
  if (s === "ACTIVE") return { label: "Ativa", tone: "success" as const };
  if (s === "OVERDUE") return { label: "Em atraso", tone: "warn" as const };
  if (s === "CANCELED" || s === "INACTIVE") return { label: "Cancelada", tone: "muted" as const };
  return { label: "Em teste gratuito", tone: "info" as const };
}

type StatusData = {
  hasSubscription: boolean;
  isManual?: boolean;
  subscriptionId?: string | null;
  status?: string | null;
  nextDueDate?: string | null;
  trialEndsAt?: string | null;
  trialStartedAt?: string | null;
  subscriptionStartedAt?: string | null;
  paymentMethod?: string | null;
  invoiceUrl?: string | null;
};

const LAST_STATUS_KEY = "tv:assinatura:ultimo-status";

export function AssinaturaPage() {
  const getStatus = useServerFn(getAsaasSubscriptionStatus);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<"trial-early-end" | "manual-migration">("trial-early-end");
  const [data, setData] = useState<StatusData>({ hasSubscription: false });
  const [reativada, setReativada] = useState(false);
  const [profile, setProfile] = useState<{ nome?: string | null; whatsapp?: string | null } | null>(null);

  async function load() {
    try {
      const res = await getStatus();
      setData(res);
      // Detecta reativação: estava em atraso/pausada e voltou a ficar ativa.
      try {
        const atual = (res.status ?? "").toUpperCase();
        const anterior = window.localStorage.getItem(LAST_STATUS_KEY);
        if (atual === "ACTIVE" && (anterior === "OVERDUE" || anterior === "INACTIVE")) {
          setReativada(true);
        }
        if (atual) window.localStorage.setItem(LAST_STATUS_KEY, atual);
      } catch {
        /* localStorage indisponível */
      }
    } catch (e) {
      console.error(e);
    }
  }


  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (u?.user) {
        const { data: p } = await supabase
          .from("profiles")
          .select("nome, whatsapp")
          .eq("user_id", u.user.id)
          .maybeSingle();
        setProfile(p);
      }
      await load();
      setLoading(false);
    })();
  }, []);

  async function handleRefresh() {
    setRefreshing(true);
    try {
      await load();
      toast.success("Status atualizado.");
    } catch {
      toast.error("Não foi possível atualizar.");
    } finally {
      setRefreshing(false);
    }
  }

  const trialStart = data.trialStartedAt ? new Date(data.trialStartedAt) : null;
  const trialEnds = data.trialEndsAt ? new Date(data.trialEndsAt) : null;
  const subscriptionStart = data.subscriptionStartedAt ? new Date(data.subscriptionStartedAt) : null;
  // Mantemos como string (YYYY-MM-DD) para que formatDate trate como data local
  // e evite deslocamento de fuso horário (ex.: 20/08 virar 19/08).
  const nextDue = data.nextDueDate ?? null;
  const now = new Date();
  const daysLeft = trialEnds
    ? Math.max(0, Math.ceil((trialEnds.getTime() - now.getTime()) / 86_400_000))
    : TRIAL_DAYS;
  const inTrial = !!trialEnds && trialEnds.getTime() > now.getTime();
  const info = statusInfo(data.status);
  const isManual = !!data.isManual;
  // Vencimento do pagamento manual: comparamos apenas por dia (YYYY-MM-DD).
  const hojeISO = new Date().toISOString().slice(0, 10);
  const manualDueISO = typeof data.nextDueDate === "string" ? data.nextDueDate.slice(0, 10) : null;
  const manualVencido = isManual && !!manualDueISO && manualDueISO <= hojeISO;
  const manualDiasRestantes = isManual && manualDueISO
    ? Math.ceil((new Date(manualDueISO + "T00:00:00").getTime() - now.getTime()) / 86_400_000)
    : null;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <header className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-primary" /> Assinatura
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Acompanhe o status do seu plano e gerencie o pagamento.
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh} disabled={refreshing || loading}>
          <RefreshCcw className={`h-4 w-4 mr-1.5 ${refreshing ? "animate-spin" : ""}`} />
          Atualizar status
        </Button>
      </header>

      {reativada && (
        <Card className="border-emerald-500/40 bg-emerald-500/10">
          <CardContent className="p-4">
            <p className="font-bold text-emerald-700 dark:text-emerald-300">
              ✅ Assinatura reativada!
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              Seu pagamento foi confirmado e sua Tati Van Escolar está ativa novamente.
            </p>
            {nextDue && (
              <p className="text-sm font-semibold mt-1">
                📅 Próximo vencimento: {formatDate(nextDue)}
              </p>
            )}
          </CardContent>
        </Card>
      )}


      <Card className="overflow-hidden border-primary/20">
        <div className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent p-6 sm:p-8">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">
                Plano atual
              </p>
              <h2 className="text-3xl font-bold mt-1">{PLAN_NAME}</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Tudo o que você precisa para gerenciar a rotina da van escolar.
              </p>
            </div>
            <div className="text-right">
              <p className="text-4xl font-bold text-primary">
                {formatMoney(PLAN_PRICE)}
                <span className="text-sm font-normal text-muted-foreground">/mês</span>
              </p>
            <p className="text-xs text-muted-foreground mt-1">
              {data.hasSubscription
                ? `Status: ${info.label}.`
                : isManual
                ? manualVencido
                  ? "Sua mensalidade venceu. Clique em Pagar para gerar a cobrança."
                  : `Próximo vencimento em ${formatDate(nextDue)}${
                      manualDiasRestantes !== null && manualDiasRestantes > 0
                        ? ` (em ${manualDiasRestantes} dia${manualDiasRestantes === 1 ? "" : "s"})`
                        : ""
                    }.`
                : inTrial
                ? `Você está no período de teste gratuito. Restam ${daysLeft} dias.`
                : "Você está no período de teste gratuito. Restam 10 dias."}
            </p>
            </div>
          </div>
          <div className="mt-6">
            {data.hasSubscription ? (
              <Badge
                variant="outline"
                className={
                  manualVencido
                    ? "bg-orange-500/15 text-orange-700 dark:text-orange-300 border-orange-500/40 px-3 py-1.5 text-sm font-medium"
                    : "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/40 px-3 py-1.5 text-sm font-medium"
                }
              >
                Assinante
              </Badge>
            ) : inTrial || !data.hasSubscription ? (
              <Badge
                variant="outline"
                className="bg-yellow-500/15 text-yellow-700 dark:text-yellow-300 border-yellow-500/40 px-3 py-1.5 text-sm font-medium"
              >
                <Clock className="h-3.5 w-3.5 mr-1.5 inline" />
                Teste grátis ({inTrial ? daysLeft : TRIAL_DAYS} dias)
              </Badge>
            ) : null}
            {(data.hasSubscription || isManual) && nextDue && (
              <p className="mt-3 text-sm font-semibold text-foreground">
                📅 Próximo vencimento: {formatDate(nextDue)}
              </p>
            )}
            {data.hasSubscription && (

              <div className="mt-4 rounded-lg border border-primary/10 bg-primary/5 p-4">
                <p className="text-sm font-medium text-foreground mb-1">
                  💙 Que bom ter você na Tati Van!
                </p>
                <p className="text-sm text-muted-foreground">
                  Agradecemos por confiar em nosso trabalho. Estamos felizes em fazer parte da sua rotina e esperamos tornar a gestão da sua van escolar cada vez mais simples, prática e organizada. Conte sempre conosco!
                </p>
              </div>
            )}
            <p className="text-sm text-muted-foreground mt-2">
              {data.hasSubscription
                ? "Sua assinatura está ativa. Aproveite todos os recursos da Tati Van."
                : "Aproveite o período gratuito para explorar tudo. Sem cobrança até o fim do teste."}
            </p>
          </div>
        </div>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="h-4 w-4 text-primary" /> Informações
            </CardTitle>
            <CardDescription>Detalhes do seu ciclo de cobrança</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            {isManual ? (
              <>
                <InfoRow icon={Clock} label="Próximo vencimento" value={formatDate(nextDue)} />
                <InfoRow icon={Wallet} label="Mensalidade" value={formatMoney(PLAN_PRICE)} />
                <InfoRow icon={CreditCard} label="Forma de pagamento" value={paymentLabel(null)} />
              </>
            ) : data.hasSubscription ? (
              <>
                <InfoRow icon={Calendar} label="Início da assinatura" value={formatDate(subscriptionStart)} />
                <InfoRow icon={Clock} label="Próxima cobrança" value={formatDate(nextDue)} />
                <InfoRow icon={Wallet} label="Mensalidade" value={formatMoney(PLAN_PRICE)} />
                <InfoRow icon={CreditCard} label="Forma de pagamento" value={paymentLabel(data.paymentMethod)} />
              </>
            ) : (
              <>
                <InfoRow icon={Calendar} label="Início do teste" value={formatDate(trialStart)} />
                <InfoRow icon={Clock} label="Fim do período de teste" value={formatDate(trialEnds)} />
                <InfoRow icon={Wallet} label="Após o teste" value={`${formatMoney(PLAN_PRICE)}/mês`} />
                <InfoRow icon={CreditCard} label="Forma de pagamento" value={paymentLabel(data.paymentMethod)} />
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" /> Ações
            </CardTitle>
            <CardDescription>Gerencie sua assinatura</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {!data.hasSubscription ? (
              <Button
                className="w-full"
                onClick={() => { setDialogMode("trial-early-end"); setDialogOpen(true); }}
                disabled={loading}
              >
                <Sparkles className="h-4 w-4 mr-1.5" /> Assinar agora
              </Button>
            ) : (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button className="w-full" disabled={loading}>
                    <CreditCard className="h-4 w-4 mr-1.5" /> Gerenciar assinatura
                    <ChevronDown className="h-4 w-4 ml-1.5 opacity-70" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-64">
                  {isManual ? (
                    <DropdownMenuItem
                      onSelect={() => { setDialogMode("manual-migration"); setDialogOpen(true); }}
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      {manualVencido ? "Pagar mensalidade agora" : "Ativar cobrança automática"}
                    </DropdownMenuItem>
                  ) : data.invoiceUrl ? (
                    <DropdownMenuItem asChild>
                      <a href={data.invoiceUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" /> Visualizar próxima fatura
                      </a>
                    </DropdownMenuItem>
                  ) : (
                    <DropdownMenuItem disabled>
                      <ExternalLink className="h-4 w-4 mr-2" /> Aguardando próxima fatura
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={handleRefresh} disabled={refreshing}>
                    <RefreshCcw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
                    Atualizar status
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
            {isManual && !manualVencido && (
              <p className="text-xs text-muted-foreground rounded-md border bg-muted/40 p-3">
                Sua mensalidade está em dia. A próxima cobrança vence em{" "}
                <strong>{formatDate(nextDue)}</strong>.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <SubscribeDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        defaultName={profile?.nome ?? undefined}
        defaultPhone={profile?.whatsapp ?? undefined}
        startNow={dialogMode === "manual-migration"}
        context={dialogMode}
        onSuccess={load}
      />
    </div>
  );
}

function InfoRow({ icon: Icon, label, value, mono }: {
  icon: React.ComponentType<{ className?: string }>;
  label: string; value: string; mono?: boolean;
}) {
  return (
    <div className="flex items-start justify-between gap-3 py-1">
      <div className="flex items-center gap-2 text-muted-foreground">
        <Icon className="h-4 w-4" />
        <span>{label}</span>
      </div>
      <span className={`text-right font-medium text-foreground ${mono ? "font-mono text-xs" : ""}`}>
        {value}
      </span>
    </div>
  );
}
