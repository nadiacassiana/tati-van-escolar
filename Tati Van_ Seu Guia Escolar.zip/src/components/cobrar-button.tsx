import { useEffect, useState } from "react";
import { MessageCircle, RotateCcw } from "lucide-react";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { buildWhatsAppUrl, getMotoristaFromUser } from "@/lib/whatsapp";
import { buildCobrarMessage } from "@/lib/cobranca";
import { calcularEncargos, type EncargoConfig } from "@/lib/encargos";
import { formatBRL } from "@/lib/format";
import { formatDataBR, formatMesRef, type Competencia } from "@/lib/mensalidades";
import { tocarSucesso } from "@/lib/sons";

/** Botão "Cobrar" com prévia editável da mensagem antes de abrir o WhatsApp. */
export function CobrarButton({
  competencia,
  motorista,
  encargos,
  size = "sm",
  variant = "outline",
}: {
  competencia: Competencia;
  motorista: ReturnType<typeof getMotoristaFromUser>;
  /** Multa/juros configurados no cadastro do aluno (opcionais). */
  encargos?: EncargoConfig | null;
  size?: "sm" | "default";
  variant?: "outline" | "default";
}) {
  const [open, setOpen] = useState(false);
  const c = competencia;
  const enc = calcularEncargos(c.valor, c.diasAtraso, encargos);
  const mensagemPadrao = buildCobrarMessage(c, motorista, encargos);
  const [mensagem, setMensagem] = useState(mensagemPadrao);

  useEffect(() => {
    if (open) setMensagem(mensagemPadrao);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, mensagemPadrao]);

  const url = buildWhatsAppUrl(c.aluno.whatsapp || "", mensagem);


  return (
    <>
      <Button size={size} variant={variant} onClick={() => { tocarSucesso(); setOpen(true); }}>
        <MessageCircle className="mr-1 h-3 w-3" /> Cobrar
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confira antes de enviar 👀</DialogTitle>
            <DialogDescription>
              Revise a mensagem. Ao confirmar, o WhatsApp abre com o texto pronto.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-2 gap-2 rounded-xl border bg-muted/40 p-3 text-sm">
            <div>
              <div className="text-xs text-muted-foreground">Aluno</div>
              <div className="font-semibold">{c.aluno.nome}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Responsável</div>
              <div className="font-semibold">{c.aluno.responsavel || "—"}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Mês de referência</div>
              <div className="font-semibold">{formatMesRef(c.mes)}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Vencimento</div>
              <div className="font-semibold">{formatDataBR(c.vencimentoISO)}</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">
                {enc.encargos > 0 ? "Valor original" : "Valor em aberto"}
              </div>
              <div className="font-bold">R$ {formatBRL(c.valor)}</div>
            </div>
            {enc.encargos > 0 && (
              <div>
                <div className="text-xs text-muted-foreground">Valor atualizado hoje (com juros/multa)</div>
                <div className="font-bold text-destructive">R$ {formatBRL(enc.total)}</div>
              </div>
            )}
            <div>
              <div className="text-xs text-muted-foreground">WhatsApp</div>
              <div className="font-semibold">{c.aluno.whatsapp || "—"}</div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="cobrar-msg">Mensagem (você pode editar)</Label>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                onClick={() => setMensagem(mensagemPadrao)}
                disabled={mensagem === mensagemPadrao}
              >
                <RotateCcw className="mr-1 h-3 w-3" /> Restaurar
              </Button>
            </div>
            <Textarea
              id="cobrar-msg"
              value={mensagem}
              onChange={(e) => setMensagem(e.target.value)}
              rows={10}
              className="text-sm"
            />
          </div>


          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <a href={url} target="_blank" rel="noreferrer" onClick={() => setOpen(false)}>
              <Button className="w-full font-bold">
                <MessageCircle className="mr-1 h-4 w-4" /> Abrir WhatsApp
              </Button>
            </a>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
