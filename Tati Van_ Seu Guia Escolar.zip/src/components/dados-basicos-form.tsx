import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { KeyRound, Save } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { maskPhoneBR, isValidPhoneBR } from "@/lib/phone-mask";

type UserLike = {
  id?: string;
  email?: string;
  user_metadata?: Record<string, unknown>;
} | null | undefined;

export function DadosBasicosForm({ user }: { user: UserLike }) {
  const meta = (user?.user_metadata || {}) as {
    nome_completo?: string; apelido?: string; empresa?: string; telefone?: string;
    whatsapp?: string; email_motorista?: string; pix?: string; banco?: string;
    cidade?: string; estado?: string;
  };

  const [nomeCompleto, setNomeCompleto] = useState(meta.nome_completo || "");
  const [apelido, setApelido] = useState(meta.apelido || "");
  const [empresa, setEmpresa] = useState(meta.empresa || "");
  const [telefone, setTelefone] = useState(maskPhoneBR(meta.telefone || ""));
  const [whatsapp, setWhatsapp] = useState(maskPhoneBR(meta.whatsapp || ""));
  const [whatsConsent, setWhatsConsent] = useState(false);
  const [emailMot, setEmailMot] = useState(meta.email_motorista || user?.email || "");
  const [pix, setPix] = useState(meta.pix || "");
  const [banco, setBanco] = useState(meta.banco || "");
  const [cidade, setCidade] = useState(meta.cidade || "");
  const [estado, setEstado] = useState(meta.estado || "");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user?.id) return;
    supabase
      .from("profiles" as never)
      .select("whatsapp_consent")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        const row = data as { whatsapp_consent?: boolean } | null;
        if (row) setWhatsConsent(!!row.whatsapp_consent);
      });
  }, [user?.id]);

  const handleSave = async () => {
    if (!cidade.trim() || !estado.trim() || !whatsapp.trim()) {
      toast.error("Preencha Cidade, Estado e WhatsApp — são obrigatórios.");
      return;
    }
    if (estado.trim().length !== 2) {
      toast.error("Informe a UF do estado com 2 letras (ex.: SP).");
      return;
    }
    if (!isValidPhoneBR(whatsapp)) {
      toast.error("Informe um WhatsApp válido com DDD.");
      return;
    }
    setSaving(true);
    const { error } = await supabase.auth.updateUser({
      data: { nome_completo: nomeCompleto, apelido, empresa, telefone, whatsapp, email_motorista: emailMot, pix, banco, cidade, estado, whatsapp_consent: whatsConsent },
    });
    if (user?.id) {
      await supabase
        .from("profiles" as never)
        .update({
          nome: nomeCompleto || apelido || null,
          cidade: cidade || null,
          estado: estado || null,
          whatsapp: whatsapp || null,
          whatsapp_consent: whatsConsent,
          whatsapp_consent_at: whatsConsent ? new Date().toISOString() : null,
          email: emailMot || null,
        } as never)
        .eq("user_id", user.id);
    }
    setSaving(false);
    if (error) return toast.error("Erro ao salvar perfil.");
    toast.success("Dados salvos! Suas mensagens e documentos já usam os novos dados.");
  };

  return (
    <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
      <div className="font-bold">Dados básicos</div>
      <p className="text-xs text-muted-foreground">
        Essas informações são usadas automaticamente nos seus documentos e mensagens (variáveis {"{motorista}"}, {"{telefone}"}, {"{pix}"}).
      </p>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div className="space-y-2 sm:col-span-2">
          <Label>🚐 Nome da Van ou Empresa</Label>
          <Input value={empresa} onChange={(e) => setEmpresa(e.target.value)} placeholder="Ex: Lígia Transporte Escolar" />
          <p className="text-[11px] text-muted-foreground">Aparece no cabeçalho dos seus documentos.</p>
        </div>
        <div className="space-y-2 sm:col-span-2">
          <Label>Nome completo</Label>
          <Input value={nomeCompleto} onChange={(e) => setNomeCompleto(e.target.value)} placeholder="Ex: Lígia Aparecida da Silva" />
          <p className="text-[11px] text-muted-foreground">Usado em contratos, recibos e documentos oficiais.</p>
        </div>
        <div className="space-y-2">
          <Label>Como deseja ser chamado(a)?</Label>
          <Input value={apelido} onChange={(e) => setApelido(e.target.value)} placeholder="Ex: Tia Lígia, Tio Carlos, Seu João" />
          <p className="text-[11px] text-muted-foreground">A Tati vai usar esse nome para te saudar no sistema.</p>
        </div>
        <div className="space-y-2">
          <Label>Telefone</Label>
          <Input type="tel" inputMode="numeric" value={telefone} onChange={(e) => setTelefone(maskPhoneBR(e.target.value))} placeholder="(11) 99999-9999" />
        </div>
        <div className="space-y-2 sm:col-span-2">
          <Label>WhatsApp 📱 <span className="text-destructive">*</span></Label>
          <Input required type="tel" inputMode="numeric" value={whatsapp} onChange={(e) => setWhatsapp(maskPhoneBR(e.target.value))} placeholder="(11) 99999-9999" />
          <label className="flex items-start gap-2 rounded-lg bg-muted/40 p-2.5 text-xs text-muted-foreground cursor-pointer">
            <Checkbox checked={whatsConsent} onCheckedChange={(v) => setWhatsConsent(v === true)} className="mt-0.5" />
            <span>
              Autorizo a Tati Assistente Virtual a entrar em contato comigo pelo WhatsApp para
              assuntos relacionados à minha conta, suporte, novidades, atualizações da plataforma,
              lembretes importantes e comunicações sobre minha assinatura. Você pode revogar a
              autorização a qualquer momento desmarcando esta opção.
            </span>
          </label>
        </div>
        <div className="space-y-2">
          <Label>E-mail</Label>
          <Input type="email" value={emailMot} onChange={(e) => setEmailMot(e.target.value)} placeholder="motorista@email.com" />
        </div>
        <div className="space-y-2">
          <Label className="flex items-center gap-1"><KeyRound className="h-3.5 w-3.5" /> Chave PIX</Label>
          <Input value={pix} onChange={(e) => setPix(e.target.value)} placeholder="CPF, telefone, e-mail ou chave aleatória" />
        </div>
        <div className="space-y-2">
          <Label>Banco do Pix (opcional)</Label>
          <Input value={banco} onChange={(e) => setBanco(e.target.value)} placeholder="Ex: Nubank, Caixa..." />
        </div>
        <div className="space-y-2">
          <Label>Cidade <span className="text-destructive">*</span></Label>
          <Input required value={cidade} onChange={(e) => setCidade(e.target.value)} placeholder="Ex: São Paulo" />
        </div>
        <div className="space-y-2">
          <Label>Estado (UF) <span className="text-destructive">*</span></Label>
          <Input required value={estado} onChange={(e) => setEstado(e.target.value.toUpperCase().slice(0, 2))} placeholder="SP" maxLength={2} />
        </div>
      </div>
      <div className="mt-4 flex justify-end">
        <Button onClick={handleSave} disabled={saving} className="bg-primary text-primary-foreground font-bold">
          <Save className="mr-2 h-4 w-4" /> {saving ? "Salvando..." : "Salvar alterações"}
        </Button>
      </div>
    </Card>
  );
}
