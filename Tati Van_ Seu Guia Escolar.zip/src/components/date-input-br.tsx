import * as React from "react";
import { CalendarIcon } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

// Máscara DD/MM/AAAA + calendário opcional.
// value/onChange operam com string ISO "YYYY-MM-DD" (mantém o armazenamento atual).

function maskBR(input: string): string {
  const d = (input || "").replace(/\D/g, "").slice(0, 8);
  if (d.length <= 2) return d;
  if (d.length <= 4) return `${d.slice(0, 2)}/${d.slice(2)}`;
  return `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}`;
}

function isoToBR(iso: string): string {
  if (!iso) return "";
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!m) return "";
  return `${m[3]}/${m[2]}/${m[1]}`;
}

function brToIso(br: string): string | null {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(br);
  if (!m) return null;
  const dd = Number(m[1]);
  const mm = Number(m[2]);
  const yyyy = Number(m[3]);
  if (mm < 1 || mm > 12) return null;
  if (yyyy < 1900 || yyyy > 2100) return null;
  const dt = new Date(yyyy, mm - 1, dd);
  if (dt.getFullYear() !== yyyy || dt.getMonth() !== mm - 1 || dt.getDate() !== dd) return null;
  return `${m[3]}-${m[2]}-${m[1]}`;
}

export interface DateInputBRProps {
  id?: string;
  value: string; // ISO "YYYY-MM-DD" ou ""
  onChange: (iso: string) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  fromYear?: number;
  toYear?: number;
}

export function DateInputBR({ id, value, onChange, placeholder = "DD/MM/AAAA", disabled, className, fromYear = 1950, toYear = new Date().getFullYear() }: DateInputBRProps) {
  const [text, setText] = React.useState<string>(isoToBR(value));
  const [invalid, setInvalid] = React.useState(false);
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    setText(isoToBR(value));
    setInvalid(false);
  }, [value]);

  const handleChange = (raw: string) => {
    const masked = maskBR(raw);
    setText(masked);
    if (masked.length === 10) {
      const iso = brToIso(masked);
      if (iso) {
        setInvalid(false);
        onChange(iso);
      } else {
        setInvalid(true);
      }
    } else {
      setInvalid(false);
      if (masked === "") onChange("");
    }
  };

  const handleBlur = () => {
    if (!text) return;
    if (text.length < 10 || !brToIso(text)) setInvalid(true);
  };

  const selected = value ? (() => {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
    return m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : undefined;
  })() : undefined;

  return (
    <div className={cn("relative", className)}>
      <Input
        id={id}
        inputMode="numeric"
        placeholder={placeholder}
        value={text}
        disabled={disabled}
        onChange={(e) => handleChange(e.target.value)}
        onBlur={handleBlur}
        aria-invalid={invalid}
        className={cn("pr-10", invalid && "border-destructive focus-visible:ring-destructive")}
      />
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            disabled={disabled}
            aria-label="Abrir calendário"
            className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground"
          >
            <CalendarIcon className="h-4 w-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="end">
          <Calendar
            mode="single"
            selected={selected}
            defaultMonth={selected}
            captionLayout="dropdown"
            fromYear={fromYear}
            toYear={toYear}
            onSelect={(d) => {
              if (d) {
                const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
                onChange(iso);
                setText(isoToBR(iso));
                setInvalid(false);
                setOpen(false);
              }
            }}
            initialFocus
            className={cn("p-3 pointer-events-auto")}
          />
        </PopoverContent>
      </Popover>
      {invalid && <p className="mt-1 text-xs text-destructive">Data inválida. Use DD/MM/AAAA.</p>}
    </div>
  );
}
