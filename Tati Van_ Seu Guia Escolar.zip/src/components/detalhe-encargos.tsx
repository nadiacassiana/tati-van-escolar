import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Calculator, CheckCircle2 } from "lucide-react";
import { formatBRL } from "@/lib/format";
import { formatDataBR, formatMesRef, type Competencia } from "@/lib/mensalidades";
import { calcularEncargos, multaLabel, jurosLabel, type EncargoConfig } from "@/lib/encargos";

type Props = {
  competencia: Competencia;
  encargos: EncargoConfig;
  onConfirmar: (c: Competencia) => void;
};

/** Prévia transparente do cálculo de multa e juros de uma parcela em atraso. */
export function DetalheEncargos({ competencia: c, encargos, onConfirmar }: Props) {
  const [open, setOpen] = useState(false);
  const enc = calcularEncargos(c.valor, c.diasAtraso, encargos);
  const mLabel = multaLabel(encargos);
  const jLabel = jurosLabel(encargos);

  const Linha = ({ label, valor, destaque }: { label: string; valor: string; destaque?: boolean }) => (
    <div className={`flex items-center justify-between gap-3 py-1.5 ${destaque ? "font-bold" : ""}`}>
      <span className={destaque ? "" : "text-muted-foreground"}>{label}</span>
      <span className={destaque ? "text-destructive" : ""}>{valor}</span>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" title="Ver detalhamento do cálculo">
          <Calculator className="mr-1 h-3 w-3" /> Ver juros/multa
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Detalhamento do cálculo</DialogTitle>
          <DialogDescription>
            {c.aluno.nome} · mensalidade de {formatMesRef(c.mes)}
          </DialogDescription>
        </DialogHeader>

        <div className="rounded-xl border p-4 text-sm">
          <Linha label="Vencimento original" valor={formatDataBR(c.vencimentoISO)} />
          <Linha label="Dias em atraso" valor={`${c.diasAtraso} dia${c.diasAtraso === 1 ? "" : "s"}`} />
          <div className="my-2 border-t" />
          <Linha label="Valor original da parcela" valor={`R$ ${formatBRL(c.valor)}`} />
          <Linha
            label={mLabel ? `Multa por atraso (${mLabel})` : "Multa por atraso"}
            valor={`R$ ${formatBRL(enc.multa)}`}
          />
          <Linha
            label={jLabel ? `Juros de mora (${jLabel} ao dia × ${c.diasAtraso})` : "Juros de mora"}
            valor={`R$ ${formatBRL(enc.juros)}`}
          />
          <div className="my-2 border-t" />
          <Linha label="Valor final atualizado" valor={`R$ ${formatBRL(enc.total)}`} destaque />
        </div>

        {enc.encargos === 0 && (
          <p className="text-xs text-muted-foreground">
            Nenhuma multa ou juros configurados no cadastro deste aluno.
          </p>
        )}

        <DialogFooter>
          <Button
            className="bg-success text-success-foreground hover:bg-success/90 font-bold"
            onClick={() => { setOpen(false); onConfirmar(c); }}
          >
            <CheckCircle2 className="mr-1 h-4 w-4" /> Confirmar recebimento
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
