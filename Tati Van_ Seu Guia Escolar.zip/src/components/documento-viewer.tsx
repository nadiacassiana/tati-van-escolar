import { type ReactNode } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

/**
 * Leitura do documento na própria tela (contrato / reserva de vaga).
 * Nunca inicia download: o PDF continua disponível pelos botões do rodapé.
 */
export function DocumentoViewerDialog({
  open,
  onOpenChange,
  titulo,
  descricao,
  html,
  loading,
  acoes,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  titulo: string;
  descricao?: string;
  html: string;
  loading?: boolean;
  acoes?: ReactNode;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[95vh] w-[96vw] flex-col overflow-hidden p-0 sm:max-w-3xl">
        <DialogHeader className="px-4 pb-2 pt-4">
          <DialogTitle>{titulo}</DialogTitle>
          <DialogDescription>
            {descricao ||
              "Leia o documento completo na tela. O PDF continua disponível para download."}
          </DialogDescription>
        </DialogHeader>
        <div className="relative min-h-[55vh] flex-1 bg-muted">
          {html ? (
            <iframe
              title={titulo}
              srcDoc={html}
              className="h-full w-full bg-white"
              style={{ minHeight: "55vh", border: 0 }}
            />
          ) : null}
          {(loading || !html) && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-muted/80 text-sm text-muted-foreground">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
              Preparando documento…
            </div>
          )}
        </div>
        {acoes ? <DialogFooter className="gap-2 border-t px-4 py-3">{acoes}</DialogFooter> : null}
      </DialogContent>
    </Dialog>
  );
}
