import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { School, Plus, Trash2, Save, MapPin } from "lucide-react";
import { toast } from "sonner";
import {
  listarEscolas,
  salvarEscola,
  excluirEscola,
  comporEndereco,
  type Escola,
} from "@/lib/escolas";

const vazio = { nome: "", rua: "", numero: "", bairro: "", cidade: "", estado: "", cep: "" };

export function EscolasManager({ userId }: { userId?: string }) {
  const [escolas, setEscolas] = useState<Escola[]>([]);
  const [form, setForm] = useState(vazio);
  const [salvando, setSalvando] = useState(false);
  const [editandoId, setEditandoId] = useState<string | null>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const nomeRef = useRef<HTMLInputElement>(null);

  const carregar = () => listarEscolas().then(setEscolas).catch(() => {});
  useEffect(() => {
    void carregar();
  }, []);

  const set = (k: keyof typeof vazio, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const salvar = async () => {
    if (!userId) return;
    if (!form.nome.trim()) return toast.error("Informe o nome da escola.");
    setSalvando(true);
    try {
      await salvarEscola(userId, form.nome, form);
      await carregar();
      setForm(vazio);
      setEditandoId(null);
      toast.success("Escola salva! 🏫");
    } catch {
      toast.error("Não foi possível salvar a escola.");
    }
    setSalvando(false);
  };

  const editar = (e: Escola) => {
    setEditandoId(e.id);
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      nomeRef.current?.focus();
    }, 50);
    setForm({
      nome: e.nome,
      rua: e.rua || "",
      numero: e.numero || "",
      bairro: e.bairro || "",
      cidade: e.cidade || "",
      estado: e.estado || "",
      cep: e.cep || "",
    });
  };

  const remover = async (e: Escola) => {
    try {
      await excluirEscola(e.id);
      await carregar();
      toast.success(`${e.nome} removida.`);
    } catch {
      toast.error("Não foi possível excluir.");
    }
  };

  return (
    <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
      <div className="flex items-center gap-2 font-bold">
        <School className="h-4 w-4 text-primary" /> Escolas
      </div>
      <p className="text-xs text-muted-foreground">
        Cadastre o endereço completo de cada escola. Ele é usado no pino da escola no rastreamento e na rota do substituto.
      </p>

      {editandoId && (
        <div className="mt-3 rounded-lg bg-primary/10 px-3 py-2 text-xs font-semibold text-primary">
          Editando: {form.nome || "escola selecionada"}
        </div>
      )}

      <div ref={formRef} className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="space-y-1 sm:col-span-2">
          <Label>Nome da escola *</Label>
          <Input ref={nomeRef} value={form.nome} onChange={(e) => set("nome", e.target.value)} placeholder="Ex: Escola Municipal São José" />
        </div>
        <div className="space-y-1">
          <Label>Rua</Label>
          <Input value={form.rua} onChange={(e) => set("rua", e.target.value)} placeholder="Rua das Flores" />
        </div>
        <div className="space-y-1">
          <Label>Número</Label>
          <Input value={form.numero} onChange={(e) => set("numero", e.target.value)} placeholder="123" />
        </div>
        <div className="space-y-1">
          <Label>Bairro</Label>
          <Input value={form.bairro} onChange={(e) => set("bairro", e.target.value)} placeholder="Centro" />
        </div>
        <div className="space-y-1">
          <Label>Cidade</Label>
          <Input value={form.cidade} onChange={(e) => set("cidade", e.target.value)} placeholder="São Paulo" />
        </div>
        <div className="space-y-1">
          <Label>Estado/UF</Label>
          <Input value={form.estado} onChange={(e) => set("estado", e.target.value.toUpperCase())} placeholder="SP" maxLength={2} />
        </div>
        <div className="space-y-1">
          <Label>CEP</Label>
          <Input value={form.cep} onChange={(e) => set("cep", e.target.value)} placeholder="00000-000" />
        </div>
      </div>
      <div className="mt-3 flex justify-end gap-2">
        {editandoId && (
          <Button variant="ghost" onClick={() => { setForm(vazio); setEditandoId(null); }}>
            Cancelar
          </Button>
        )}
        <Button onClick={salvar} disabled={salvando} className="font-bold">
          {editandoId ? <Save className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
          {salvando ? "Salvando..." : editandoId ? "Salvar escola" : "Adicionar escola"}
        </Button>
      </div>

      <div className="mt-4 space-y-2">
        {escolas.length === 0 && (
          <p className="text-xs text-muted-foreground">Nenhuma escola cadastrada ainda.</p>
        )}
        {escolas.map((e) => (
          <div key={e.id} className="flex items-start justify-between gap-2 rounded-xl border p-3">
            <div className="min-w-0">
              <div className="text-sm font-semibold">{e.nome}</div>
              <div className="flex items-start gap-1 text-xs text-muted-foreground">
                <MapPin className="mt-0.5 h-3 w-3 shrink-0" />
                <span>{e.endereco || comporEndereco(e) || "Sem endereço cadastrado"}</span>
              </div>
            </div>
            <div className="flex shrink-0 gap-1">
              <Button size="sm" variant="outline" type="button" onClick={() => editar(e)}>Editar</Button>
              <Button size="sm" variant="ghost" className="text-destructive" onClick={() => void remover(e)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
