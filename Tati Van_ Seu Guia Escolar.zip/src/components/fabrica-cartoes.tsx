import { useCallback, useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Download, FileDown, Sparkles } from "lucide-react";
import { toast } from "sonner";
import vanEscolarSrc from "@/assets/van-escolar-card.png";
import { maskPhoneBR, whatsappLink } from "@/lib/phone-mask";

type ModeloId = "A" | "B" | "C";

type Modelo = {
  id: ModeloId;
  nome: string;
  chamada: string;
  itens: { icone: string; titulo: string; texto: string; cor: string }[];
};

const MODELOS: Record<ModeloId, Modelo> = {
  A: {
    id: "A",
    nome: "Financeiro e Comunicação",
    chamada: "Organização e carinho em cada detalhe",
    itens: [
      { icone: "✓", titulo: "Recibos digitais", texto: "Comprovantes práticos direto no celular", cor: "#0ea5e9" },
      { icone: "✦", titulo: "Contratos digitais", texto: "Documentos organizados e fáceis de consultar", cor: "#f59e0b" },
      { icone: "♥", titulo: "Comunicação simples", texto: "Avisos claros para pais e responsáveis", cor: "#f43f5e" },
    ],
  },
  B: {
    id: "B",
    nome: "Rastreio GPS ao Vivo",
    chamada: "Tranquilidade para acompanhar cada trajeto",
    itens: [
      { icone: "●", titulo: "Rastreio GPS ao vivo", texto: "A localização da van atualizada no mapa", cor: "#0ea5e9" },
      { icone: "⌖", titulo: "Mapa em tempo real", texto: "Acesso individual e seguro para cada família", cor: "#f59e0b" },
      { icone: "✓", titulo: "Avisos do trajeto", texto: "Notificações de embarque e desembarque", cor: "#22c55e" },
    ],
  },
  C: {
    id: "C",
    nome: "Experiência Completa",
    chamada: "Segurança no caminho, organização no dia a dia",
    itens: [
      { icone: "⌖", titulo: "Rastreio ao vivo", texto: "A família acompanha a van durante o trajeto", cor: "#0ea5e9" },
      { icone: "✓", titulo: "Recibos digitais", texto: "Comprovantes práticos enviados pelo celular", cor: "#f59e0b" },
      { icone: "♥", titulo: "Organização completa", texto: "Contratos, cobranças e comunicação em um só lugar", cor: "#f43f5e" },
    ],
  },
};

const W = 1080;
const H = 1350;
const AZUL_NOITE = "#12326b";
const AZUL = "#168eea";
const AZUL_CLARO = "#e8f6ff";
const AMARELO = "#ffd52a";
const AMARELO_CLARO = "#fff7c9";
const BRANCO = "#ffffff";
const TEXTO = "#17325c";
const CINZA = "#58708f";

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
}

function wrap(ctx: CanvasRenderingContext2D, texto: string, max: number): string[] {
  const palavras = texto.trim().split(/\s+/).filter(Boolean);
  const linhas: string[] = [];
  let atual = "";
  for (const palavra of palavras) {
    const teste = atual ? `${atual} ${palavra}` : palavra;
    if (ctx.measureText(teste).width > max && atual) {
      linhas.push(atual);
      atual = palavra;
    } else {
      atual = teste;
    }
  }
  if (atual) linhas.push(atual);
  return linhas;
}

function fitLines(
  ctx: CanvasRenderingContext2D,
  texto: string,
  maxWidth: number,
  maxLines: number,
  startSize: number,
  minSize: number,
  weight = 800,
) {
  for (let size = startSize; size >= minSize; size -= 2) {
    ctx.font = `${weight} ${size}px "Arial Rounded MT Bold", Arial, sans-serif`;
    const lines = wrap(ctx, texto, maxWidth);
    if (lines.length <= maxLines && lines.every((line) => ctx.measureText(line).width <= maxWidth)) {
      return { lines, size };
    }
  }
  ctx.font = `${weight} ${minSize}px "Arial Rounded MT Bold", Arial, sans-serif`;
  return { lines: wrap(ctx, texto, maxWidth), size: minSize };
}

function drawSpark(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, color: string) {
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = color;
  ctx.beginPath();
  for (let i = 0; i < 8; i++) {
    const angle = (Math.PI * i) / 4 - Math.PI / 2;
    const radius = i % 2 === 0 ? size : size * 0.32;
    const px = Math.cos(angle) * radius;
    const py = Math.sin(angle) * radius;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawImageContain(
  ctx: CanvasRenderingContext2D,
  image: HTMLImageElement,
  x: number,
  y: number,
  maxW: number,
  maxH: number,
) {
  const scale = Math.min(maxW / image.naturalWidth, maxH / image.naturalHeight);
  const width = image.naturalWidth * scale;
  const height = image.naturalHeight * scale;
  ctx.drawImage(image, x + (maxW - width) / 2, y + (maxH - height) / 2, width, height);
}

function desenhar(
  canvas: HTMLCanvasElement,
  vanImage: HTMLImageElement | null,
  dados: { nome: string; telefone: string; regiao: string; modelo: ModeloId },
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const modelo = MODELOS[dados.modelo];
  canvas.width = W;
  canvas.height = H;

  ctx.fillStyle = BRANCO;
  ctx.fillRect(0, 0, W, H);

  // Área principal viva, com formas orgânicas e a van como protagonista.
  const hero = ctx.createLinearGradient(0, 0, W, 610);
  hero.addColorStop(0, "#0d6fd1");
  hero.addColorStop(1, "#22a9ef");
  ctx.fillStyle = hero;
  ctx.fillRect(0, 0, W, 610);
  ctx.fillStyle = AMARELO;
  ctx.beginPath();
  ctx.arc(860, 310, 285, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.14)";
  ctx.beginPath();
  ctx.arc(55, 510, 190, 0, Math.PI * 2);
  ctx.fill();
  drawSpark(ctx, 948, 80, 22, BRANCO);
  drawSpark(ctx, 994, 135, 11, AMARELO_CLARO);
  drawSpark(ctx, 65, 420, 13, AMARELO);

  ctx.fillStyle = AMARELO;
  roundRect(ctx, 66, 52, 280, 44, 22);
  ctx.fill();
  ctx.fillStyle = AZUL_NOITE;
  ctx.font = "800 19px Arial, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("TRANSPORTE ESCOLAR", 206, 75);

  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  const nome = dados.nome.trim().toLocaleUpperCase("pt-BR");
  const title = fitLines(ctx, nome, 620, 3, 66, 42);
  ctx.fillStyle = BRANCO;
  let titleY = 170;
  for (const line of title.lines.slice(0, 3)) {
    ctx.fillText(line, 66, titleY);
    titleY += title.size * 1.02;
  }
  ctx.fillStyle = AMARELO_CLARO;
  ctx.font = "700 27px Arial, sans-serif";
  const subtitleLines = wrap(ctx, "Transporte Escolar com Amor e Segurança", 380);
  subtitleLines.forEach((line, index) => ctx.fillText(line, 66, titleY + 18 + index * 38));

  if (vanImage?.complete && vanImage.naturalWidth > 0) {
    ctx.save();
    ctx.shadowColor = "rgba(13,50,107,0.28)";
    ctx.shadowBlur = 28;
    ctx.shadowOffsetY = 16;
    drawImageContain(ctx, vanImage, 470, 160, 575, 420);
    ctx.restore();
  }

  // Contato sempre ganha uma área própria; se vazio, o bloco se adapta.
  const telefone = dados.telefone.trim();
  if (telefone) {
    const numeroFormatado = maskPhoneBR(telefone);
    const boxX = 66;
    const boxW = 405;
    const boxH = 96;
    const boxY = 522;
    const centerX = boxX + boxW / 2;

    ctx.fillStyle = AZUL_NOITE;
    roundRect(ctx, boxX, boxY, boxW, boxH, 26);
    ctx.fill();

    ctx.fillStyle = AMARELO;
    ctx.beginPath();
    ctx.arc(112, boxY + boxH / 2, 22, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = AZUL_NOITE;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = "800 22px Arial, sans-serif";
    ctx.fillText("💬", 112, boxY + boxH / 2);

    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.font = "700 17px Arial, sans-serif";
    ctx.fillText("WhatsApp", centerX, boxY + 34);

    ctx.fillStyle = BRANCO;
    ctx.font = "800 34px Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(numeroFormatado, centerX, boxY + boxH / 2 + 10);
  }

  // Caixa expansível para escolas e bairros, sem truncar palavras.
  const regiao = dados.regiao.trim();
  let benefitStart = 690;
  if (regiao) {
    ctx.font = "700 28px Arial, sans-serif";
    let regionLines = wrap(ctx, regiao, 790);
    let regionSize = 28;
    while ((regionLines.length > 3 || regionLines.some((line) => ctx.measureText(line).width > 790)) && regionSize > 12) {
      regionSize -= 1;
      ctx.font = `700 ${regionSize}px Arial, sans-serif`;
      regionLines = wrap(ctx, regiao, 790);
    }
    const regionHeight = 88 + regionLines.length * (regionSize + 8);
    ctx.fillStyle = AMARELO_CLARO;
    roundRect(ctx, 60, 636, 960, regionHeight, 28);
    ctx.fill();
    ctx.fillStyle = "#f2ae00";
    roundRect(ctx, 82, 660, 66, 66, 19);
    ctx.fill();
    ctx.fillStyle = AZUL_NOITE;
    ctx.font = "800 30px Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("⌖", 115, 692);
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = CINZA;
    ctx.font = "800 16px Arial, sans-serif";
    ctx.fillText("ESCOLAS E BAIRROS QUE ATENDEMOS", 174, 680);
    ctx.fillStyle = TEXTO;
    ctx.font = `700 ${regionSize}px Arial, sans-serif`;
    regionLines.forEach((line, index) => ctx.fillText(line, 174, 716 + index * (regionSize + 8)));
    benefitStart = 636 + regionHeight + 34;
  }

  ctx.fillStyle = TEXTO;
  ctx.font = "800 25px Arial, sans-serif";
  ctx.fillText(modelo.chamada, 66, benefitStart);
  ctx.fillStyle = AZUL;
  ctx.fillRect(66, benefitStart + 18, 86, 6);

  const availableBottom = 1218;
  const itemGap = 14;
  const itemHeight = Math.max(86, Math.min(136, (availableBottom - (benefitStart + 48) - itemGap * 2) / 3));
  const compactItems = itemHeight < 112;
  let itemY = benefitStart + 48;
  for (const item of modelo.itens) {
    ctx.save();
    ctx.shadowColor = "rgba(23,50,92,0.10)";
    ctx.shadowBlur = 16;
    ctx.shadowOffsetY = 7;
    ctx.fillStyle = BRANCO;
    roundRect(ctx, 60, itemY, 960, itemHeight, 24);
    ctx.fill();
    ctx.restore();
    ctx.fillStyle = AZUL_CLARO;
    roundRect(ctx, 78, itemY + 17, 84, itemHeight - 34, 20);
    ctx.fill();
    ctx.fillStyle = item.cor;
    ctx.beginPath();
    ctx.arc(120, itemY + itemHeight / 2, 27, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = BRANCO;
    ctx.font = "800 28px Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(item.icone, 120, itemY + itemHeight / 2 + 1);
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = TEXTO;
    ctx.font = `800 ${compactItems ? 22 : 28}px Arial, sans-serif`;
    ctx.fillText(item.titulo, 190, itemY + (compactItems ? 38 : 49));
    ctx.fillStyle = CINZA;
    ctx.font = `500 ${compactItems ? 17 : 22}px Arial, sans-serif`;
    wrap(ctx, item.texto, 770).slice(0, 2).forEach((line, index) => {
      ctx.fillText(line, 190, itemY + (compactItems ? 64 : 82) + index * (compactItems ? 20 : 27));
    });
    itemY += itemHeight + itemGap;
  }

  // Selo de confiança: presente, mas claramente subordinado à identidade da van.
  ctx.fillStyle = AZUL_NOITE;
  ctx.fillRect(0, 1240, W, 110);
  ctx.fillStyle = AMARELO;
  ctx.beginPath();
  ctx.arc(105, 1295, 31, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = AZUL_NOITE;
  drawSpark(ctx, 105, 1295, 16, AZUL_NOITE);
  ctx.fillStyle = BRANCO;
  ctx.font = "700 19px Arial, sans-serif";
  ctx.fillText("SELO DE SEGURANÇA & TECNOLOGIA", 158, 1286);
  ctx.fillStyle = AMARELO;
  ctx.font = "800 27px Arial, sans-serif";
  ctx.fillText("Tati Van Escolar", 158, 1321);
  ctx.textAlign = "right";
  ctx.fillStyle = "rgba(255,255,255,0.78)";
  ctx.font = "600 19px Arial, sans-serif";
  ctx.fillText("Cuidado que acompanha cada trajeto", 1012, 1305);
  ctx.textAlign = "left";
}

export function FabricaCartoes() {
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");
  const [regiao, setRegiao] = useState("");
  const [modelo, setModelo] = useState<ModeloId>("A");
  const [vanImage, setVanImage] = useState<HTMLImageElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const image = new Image();
    image.onload = () => setVanImage(image);
    image.src = vanEscolarSrc;
  }, []);

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    desenhar(canvas, vanImage, {
      nome: nome.trim() || "Van da Tia Nadia",
      telefone,
      regiao,
      modelo,
    });
  }, [nome, telefone, regiao, modelo, vanImage]);

  useEffect(() => {
    render();
  }, [render]);

  const baixar = () => {
    if (!nome.trim()) {
      toast.error("Informe o nome do motorista ou da van.");
      return;
    }
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.toBlob((blob) => {
      if (!blob) {
        toast.error("Não foi possível gerar a imagem.");
        return;
      }
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `cartao-${nome.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-")}.png`;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 3000);
      toast.success("Imagem baixada! Já pode enviar no WhatsApp. 💛");
    }, "image/png");
  };

  const baixarPdf = async () => {
    if (!nome.trim()) {
      toast.error("Informe o nome do motorista ou da van.");
      return;
    }
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      const { default: jsPDF } = await import("jspdf");
      const escala = 0.1; // 1080x1350 px -> 108x135 mm
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: [W * escala, H * escala] });
      pdf.addImage(canvas.toDataURL("image/png"), "PNG", 0, 0, W * escala, H * escala, undefined, "FAST");
      if (telefone.trim()) {
        // Área do WhatsApp clicável (mesmas coordenadas do desenho no canvas).
        pdf.link(66 * escala, 522 * escala, 405 * escala, 96 * escala, {
          url: whatsappLink(telefone),
        });
      }
      pdf.save(`cartao-${nome.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-")}.pdf`);
      toast.success("PDF gerado! Pronto para impressão. 💛");
    } catch {
      toast.error("Não foi possível gerar o PDF.");
    }
  };

  return (
    <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
      <div className="flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-accent-foreground" />
        <h2 className="text-lg font-bold">Fábrica de Cartões de Venda</h2>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        Crie um panfleto profissional da sua van, pronto para WhatsApp e redes sociais.
      </p>

      <div className="mt-4 grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="fc-nome">Nome do motorista / van *</Label>
            <Input id="fc-nome" value={nome} onChange={(event) => setNome(event.target.value)} placeholder="Ex.: Van da Tia Nadia" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="fc-tel">Telefone / WhatsApp (opcional)</Label>
            <Input id="fc-tel" value={telefone} onChange={(event) => setTelefone(event.target.value)} placeholder="(11) 90000-0000" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="fc-regiao">Bairros e escolas atendidos (opcional)</Label>
            <Input
              id="fc-regiao"
              value={regiao}
              onChange={(event) => setRegiao(event.target.value)}
              placeholder="Ex.: Pq. Fernanda • Escola Beatriz de Quadros Leme"
            />
          </div>

          <div className="space-y-2">
            <Label>Modelo de apresentação</Label>
            <div className="grid gap-2">
              {(Object.keys(MODELOS) as ModeloId[]).map((id) => (
                <Button
                  key={id}
                  type="button"
                  variant="outline"
                  onClick={() => setModelo(id)}
                  className={`h-auto justify-start rounded-xl p-3 text-left text-sm whitespace-normal ${
                    modelo === id ? "border-primary bg-primary/5 font-semibold" : "hover:bg-muted"
                  }`}
                >
                  <span className="mr-2 font-bold">Opção {id}</span>
                  {MODELOS[id].nome}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid gap-2">
            <Button onClick={baixar} className="w-full">
              <Download className="mr-2 h-4 w-4" /> Baixar Imagem (PNG)
            </Button>
            <Button onClick={baixarPdf} variant="outline" className="w-full">
              <FileDown className="mr-2 h-4 w-4" /> Baixar em PDF (Impressão)
            </Button>
          </div>
        </div>

        <div className="flex justify-center">
          <canvas
            ref={canvasRef}
            className="h-auto w-full max-w-[360px] rounded-2xl border shadow-sm"
            aria-label="Prévia do cartão de divulgação"
          />
        </div>
      </div>
    </Card>
  );
}