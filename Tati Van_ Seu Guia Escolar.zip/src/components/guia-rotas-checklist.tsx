import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft, ArrowRight, Bus, CheckCircle2, Hand, Home, MapPin, Play,
  MessageCircle, School, Square, Sun, Sunrise, Sunset, Timer, UserX,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Dados 100% fictícios — apenas para simulação didática               */
/* ------------------------------------------------------------------ */
const DEMO = {
  motorista: "Tia Carol",
  escola: "Escola Pequeno Príncipe",
  endereco: "Rua das Flores, 100 - Bairro Sol",
  alunos: [
    { nome: "Lucas Silva", avatar: "🧒" },
    { nome: "Sofia Santos", avatar: "👧" },
    { nome: "Gabriel Lima", avatar: "👦" },
  ],
};

type Passo = {
  titulo: string;
  subtitulo: string;
  ilustracao: React.ComponentType;
  explicacao: string;
  dica: string;
};

/* ------------------------- Ilustrações ------------------------------ */

function IlustraPasso1() {
  return (
    <div className="space-y-3">
      <div className="text-center text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
        1️⃣ Escolha o turno
      </div>
      <div className="grid grid-cols-3 gap-1.5 rounded-xl border bg-muted/40 p-1.5">
        <div className="relative flex flex-col items-center gap-0.5 rounded-lg bg-background py-2 text-[11px] font-bold shadow-sm ring-2 ring-primary">
          <Sunrise className="h-4 w-4 text-primary" /> Manhã
          <Hand className="absolute -right-2 -top-3 h-5 w-5 animate-bounce text-primary" />
        </div>
        <div className="flex flex-col items-center gap-0.5 rounded-lg py-2 text-[11px] font-semibold text-muted-foreground">
          <Sunset className="h-4 w-4" /> Tarde
        </div>
        <div className="flex flex-col items-center gap-0.5 rounded-lg py-2 text-[11px] font-semibold text-muted-foreground">
          <Sun className="h-4 w-4" /> Integral
        </div>
      </div>

      <div className="flex justify-center text-lg leading-none">⬇️</div>

      <div className="text-center text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
        2️⃣ Escolha o sentido do trajeto
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="relative rounded-xl border-2 border-primary bg-primary/10 p-2.5 text-center">
          <Bus className="mx-auto h-5 w-5 text-primary" />
          <div className="mt-1 text-[11px] font-extrabold">Ida para a Escola</div>
          <div className="text-[10px] text-muted-foreground">🏠 Casa → 🏫 Escola</div>
          <Hand className="absolute -right-1.5 -top-3 h-5 w-5 animate-bounce text-primary" />
        </div>
        <div className="rounded-xl border-2 border-dashed p-2.5 text-center opacity-70">
          <Home className="mx-auto h-5 w-5 text-muted-foreground" />
          <div className="mt-1 text-[11px] font-extrabold">Volta para Casa</div>
          <div className="text-[10px] text-muted-foreground">🏫 Escola → 🏠 Casa</div>
        </div>
      </div>
    </div>
  );
}

function IlustraPasso2() {
  return (
    <div className="space-y-3">
      <div className="rounded-xl border bg-secondary/50 p-3">
        <div className="flex items-center gap-1.5 text-[11px] font-bold">
          <Timer className="h-4 w-4 text-primary" /> Por quanto tempo o link ficará ativo?
        </div>
        <div className="mt-2 grid grid-cols-3 gap-2">
          <div className="rounded-lg border bg-background py-2 text-center text-xs font-bold">1h</div>
          <div className="relative rounded-lg bg-primary py-2 text-center text-xs font-extrabold text-primary-foreground ring-2 ring-primary/40">
            2h
            <Hand className="absolute -right-2 -top-3 h-5 w-5 animate-bounce text-primary" />
          </div>
          <div className="rounded-lg border bg-background py-2 text-center text-xs font-bold">3h</div>
        </div>
        <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">O GPS desliga automaticamente ao fim do tempo escolhido.</p>
      </div>

      <div className="relative">
        <div className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-sm font-extrabold text-primary-foreground shadow-md">
          <Play className="h-5 w-5" /> Iniciar Rota
        </div>
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xl">👆</div>
        <Hand className="absolute -right-2 -top-3 h-6 w-6 animate-bounce text-primary" />
      </div>
    </div>
  );
}

function IlustraPasso3() {
  return (
    <div className="space-y-2">
      {DEMO.alunos.map((a, i) => (
        <div key={a.nome} className={cn("rounded-xl border bg-background p-2.5", i === 1 && "ring-2 ring-success ring-offset-1")}>
          {i === 1 && (
            <div className="mb-2 flex items-center gap-1 rounded-md bg-success/10 px-2 py-1 text-[10px] font-extrabold text-success">
              <MessageCircle className="h-3 w-3" /> Próximo envio sugerido
            </div>
          )}
          <div className="flex items-center gap-2">
            <span className="text-lg">{a.avatar}</span>
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-bold">{a.nome}</div>
              <div className="truncate text-[10px] text-muted-foreground">{DEMO.endereco}</div>
            </div>
          </div>
          <div className={cn(
            "relative mt-1.5 flex h-8 items-center justify-center gap-1 rounded-lg text-[10px] font-extrabold",
            i === 0 ? "bg-success text-success-foreground" : "border border-success/40 text-success",
          )}>
            {i === 0 && <Hand className="absolute -right-1.5 -top-2.5 h-4 w-4 animate-bounce text-success" />}
            <MessageCircle className="h-3 w-3" /> {i === 0 ? "Rastreio enviado — enviar novamente" : "Enviar Rastreio"}
          </div>
          <div className="mt-2 grid grid-cols-3 gap-1.5">
            <div
              className={cn(
                "relative flex h-8 items-center justify-center gap-1 rounded-lg text-[10px] font-extrabold",
                i === 0
                  ? "bg-primary text-primary-foreground ring-2 ring-primary/60"
                  : "border text-muted-foreground",
              )}
            >
              {i === 0 && <Hand className="absolute -right-1.5 -top-2.5 h-4 w-4 animate-bounce text-primary" />}
              <CheckCircle2 className="h-3 w-3" /> Embarcou
            </div>
            <div
              className={cn(
                "relative flex h-8 items-center justify-center gap-1 rounded-lg text-[10px] font-extrabold",
                i === 1
                  ? "bg-success text-success-foreground ring-2 ring-success/60"
                  : "border text-muted-foreground",
              )}
            >
              {i === 1 && <Hand className="absolute -right-1.5 -top-2.5 h-4 w-4 animate-bounce text-success" />}
              <School className="h-3 w-3" /> Desembarcou
            </div>
            <div
              className={cn(
                "relative flex h-8 items-center justify-center gap-1 rounded-lg text-[10px] font-extrabold",
                i === 2
                  ? "bg-destructive text-destructive-foreground ring-2 ring-destructive/60"
                  : "border text-muted-foreground",
              )}
            >
              {i === 2 && <Hand className="absolute -right-1.5 -top-2.5 h-4 w-4 animate-bounce text-destructive" />}
              <UserX className="h-3 w-3" /> Ausente
            </div>
          </div>
          {i === 0 && (
            <div className="mt-1.5 rounded-md bg-primary/10 px-2 py-1 text-center text-[10px] font-bold text-primary">
              📲 Pais notificados: "{a.nome.split(" ")[0]} embarcou na van!"
            </div>
          )}
          {i === 1 && (
            <div className="mt-1.5 rounded-md bg-success/10 px-2 py-1 text-center text-[10px] font-bold text-success">
              📲 Pais notificados: "{a.nome.split(" ")[0]} chegou na escola!" ✅
            </div>
          )}
          {i === 2 && (
            <div className="mt-1.5 rounded-md bg-destructive/10 px-2 py-1 text-center text-[10px] font-bold text-destructive">
              🚫 Não vai hoje — a rota ajusta as paradas sozinha
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function IlustraPasso4() {
  return (
    <div className="space-y-3">
      <div className="rounded-xl border-2 border-primary bg-primary p-3 text-primary-foreground">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-extrabold">🟢 Rota em andamento</div>
            <div className="text-[10px] opacity-90">📍 Rastreamento ativo</div>
          </div>
          <div className="text-right text-[10px]">Link expira em<br/><b className="text-sm">01h 58min</b></div>
        </div>
        <div className="relative mt-3 flex h-9 items-center justify-center gap-1.5 rounded-lg bg-background text-xs font-extrabold text-primary">
          <MapPin className="h-3.5 w-3.5" /> Copiar Link Geral
          <Hand className="absolute -right-2 -top-3 h-5 w-5 animate-bounce text-primary" />
        </div>
      </div>
      <div className="relative">
        <div className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-destructive text-sm font-extrabold text-destructive-foreground">
          <Square className="h-4 w-4" /> Encerrar Rota
        </div>
        <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xl">👆</div>
        <Hand className="absolute -right-2 -top-3 h-6 w-6 animate-bounce text-destructive" />
      </div>
      <div className="rounded-xl border bg-muted/50 p-3 text-[11px] leading-relaxed text-muted-foreground">
        🔒 <span className="font-bold text-foreground">Privacidade garantida:</span> ao encerrar, o link dos pais
        expira na hora e o GPS para de enviar a localização da van.
      </div>
    </div>
  );
}

/* ------------------------- Definição dos passos --------------------- */

const PASSOS: Passo[] = [
  {
    titulo: "Escolha o turno e o sentido",
    subtitulo: "Passo 1 de 4",
    ilustracao: IlustraPasso1,
    explicacao:
      "No topo da tela do Checklist Diário, toque no turno que você vai rodar agora: Manhã, Tarde ou Integral. " +
      "Logo abaixo, escolha o sentido: Ida para a Escola (buscar as crianças em casa) ou Volta para Casa (levar de volta).",
    dica: "💡 O aplicativo já organiza automaticamente os alunos de cada turno para você.",
  },
  {
    titulo: "Escolha o tempo e inicie",
    subtitulo: "Passo 2 de 4",
    ilustracao: IlustraPasso2,
    explicacao:
      "Escolha obrigatoriamente 1h, 2h ou 3h — 2h já vem selecionado. Depois toque apenas em 'Iniciar Rota' para ligar o GPS e ativar o painel.",
    dica: "💡 Não existe mais envio em massa nem uma tela intermediária de seleção.",
  },
  {
    titulo: "Envie o rastreio pelo card",
    subtitulo: "Passo 3 de 4",
    ilustracao: IlustraPasso3,
    explicacao:
      "Em cada aluno, toque no botão verde 'Enviar Rastreio'. O WhatsApp do responsável abre com a mensagem e o link individual. Ao voltar, o próximo aluno fica destacado.",
    dica: "💡 A sugestão é livre: você pode pular alunos ou enviar em qualquer ordem.",
  },
  {
    titulo: "Use o painel da rota",
    subtitulo: "Passo 4 de 4",
    ilustracao: IlustraPasso4,
    explicacao:
      "No painel azul, use 'Copiar Link Geral' se preferir colar um único link no grupo da van. Ao terminar, toque em 'Encerrar Rota' para desligar o GPS e os links.",
    dica: "💡 Se esquecer de encerrar, o link e o GPS expiram sozinhos no tempo escolhido.",
  },
];

/* ------------------------- Componente principal --------------------- */

export function GuiaRotasChecklist({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [passo, setPasso] = useState(0);
  const atual = PASSOS[passo];
  const Ilustracao = atual.ilustracao;

  function ir(delta: number) {
    setPasso((p) => Math.min(Math.max(p + delta, 0), PASSOS.length - 1));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[90vh] max-w-md flex-col overflow-y-auto p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-base leading-snug">
            📖 Guia Prático do Compartilhamento de Rotas e Checklist
          </DialogTitle>
          <DialogDescription className="text-xs">
            Simulação com dados fictícios: van da <span className="font-bold">{DEMO.motorista}</span> •{" "}
            {DEMO.escola}
          </DialogDescription>
        </DialogHeader>

        {/* Progresso */}
        <div className="flex items-center gap-1.5">
          {PASSOS.map((_, i) => (
            <button
              key={i}
              onClick={() => setPasso(i)}
              aria-label={`Ir para o passo ${i + 1}`}
              className={cn(
                "h-1.5 flex-1 rounded-full transition-colors",
                i === passo ? "bg-primary" : i < passo ? "bg-primary/40" : "bg-muted",
              )}
            />
          ))}
        </div>

        <div className="animate-fade-in" key={passo}>
          <div className="rounded-2xl border-2 border-primary/20 bg-gradient-to-b from-secondary/40 to-background p-3">
            <div className="mb-2 text-center">
              <span className="rounded-full bg-primary/10 px-3 py-1 text-[10px] font-extrabold uppercase tracking-wide text-primary">
                {atual.subtitulo}
              </span>
              <h3 className="mt-2 text-lg font-extrabold leading-tight">{atual.titulo}</h3>
            </div>

            <Ilustracao />
          </div>

          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{atual.explicacao}</p>
          <p className="mt-2 rounded-xl bg-accent/20 p-2.5 text-xs font-medium leading-relaxed">{atual.dica}</p>
        </div>

        {/* Navegação */}
        <div className="mt-4 grid grid-cols-2 gap-2 pb-1">
          <Button variant="outline" onClick={() => ir(-1)} disabled={passo === 0} className="font-bold">
            <ArrowLeft className="mr-1 h-4 w-4" /> Voltar
          </Button>
          {passo < PASSOS.length - 1 ? (
            <Button onClick={() => ir(1)} className="font-bold">
              Próximo <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          ) : (
            <Button onClick={() => onOpenChange(false)} className="font-bold">
              Entendi! 🚐
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** Botão pronto para abrir o guia (usa estado interno). */
export function GuiaRotasChecklistButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen(true)}
        className="gap-1.5 border-primary/40 font-bold text-primary hover:bg-primary/10"
      >
        📖 Guia da Rota
      </Button>
      <GuiaRotasChecklist open={open} onOpenChange={setOpen} />
    </>
  );
}
