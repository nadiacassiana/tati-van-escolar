import { MessageCircle } from "lucide-react";
import { suporteWhatsAppLink } from "@/lib/suporte";

// Botão flutuante de ajuda exibido em todas as telas autenticadas.
export function HelpFab() {
  return (
    <a
      href={suporteWhatsAppLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Precisa de ajuda? Falar com o suporte no WhatsApp"
      className="fixed bottom-4 right-4 z-40 flex items-center gap-2 rounded-full bg-primary px-4 py-3 text-sm font-bold text-primary-foreground shadow-lg transition-transform hover:scale-105 active:scale-95"
    >
      <MessageCircle className="h-4 w-4" />
      <span className="sm:hidden">Ajuda</span>
      <span className="hidden sm:inline">Precisa de ajuda?</span>
    </a>
  );
}

