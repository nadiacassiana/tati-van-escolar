import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { formatBRL } from "@/lib/format";
import { getMotoristaFromUser } from "@/lib/whatsapp";
import { CobrarButton } from "@/components/cobrar-button";
import { AnteciparMensalidades } from "@/components/antecipar-mensalidades";
import {
  buildCompetencias, formatMesRef, formatDataBR, STATUS_UI,
  type AlunoMensalidade, type PagamentoMini,
} from "@/lib/mensalidades";

export function HistoricoMensalidades({
  aluno,
  open,
  onOpenChange,
  user,
}: {
  aluno: AlunoMensalidade | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  user?: Parameters<typeof getMotoristaFromUser>[0];
}) {
  const motorista = getMotoristaFromUser(user ?? null);
  const [pagamentos, setPagamentos] = useState<PagamentoMini[]>([]);
  const [estornos, setEstornos] = useState<{ mes_referencia: string; estornado_em: string }[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !aluno) return;
    let active = true;
    setLoading(true);
    (async () => {
      const [{ data }, { data: est }] = await Promise.all([
        supabase
          .from("pagamentos")
          .select("id, aluno_id, mes_referencia, valor, metodo, data_pagamento")
          .eq("aluno_id", aluno.id),
        supabase
          .from("recibos")
          .select("mes_referencia, estornado_em")
          .eq("aluno_id", aluno.id)
          .not("estornado_em", "is", null),
      ]);
      if (!active) return;
      setPagamentos(((data as unknown) as PagamentoMini[]) || []);
      setEstornos(((est as unknown) as { mes_referencia: string; estornado_em: string }[]) || []);
      setLoading(false);
    })();
    return () => { active = false; };
  }, [open, aluno]);

  const competencias = aluno
    ? buildCompetencias([aluno], pagamentos).sort((a, b) => b.mes.localeCompare(a.mes))
    : [];
  const emAberto = competencias.filter((c) => c.status !== "pago" && Number(c.valor) > 0);
  const totalAberto = emAberto.reduce((s, c) => s + Number(c.valor), 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-md">
        <DialogHeader>
          <DialogTitle>💰 Histórico de mensalidades</DialogTitle>
          <DialogDescription>
            {aluno?.nome}
            {aluno?.responsavel && aluno.responsavel !== "—" ? ` — responsável: ${aluno.responsavel}` : ""}
          </DialogDescription>
        </DialogHeader>

        {emAberto.length > 0 && totalAberto > 0 && (
          <div className="rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm font-semibold text-destructive">
            {emAberto.length} mensalidade{emAberto.length === 1 ? "" : "s"} em aberto · R$ {formatBRL(totalAberto)}
          </div>
        )}

        {loading ? (
          <div className="py-6 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : competencias.length === 0 ? (
          <div className="py-6 text-center text-sm text-muted-foreground">Nenhuma mensalidade registrada ainda.</div>
        ) : (
          <ul className="divide-y rounded-xl border">
            {competencias.map((c) => {
              const s = STATUS_UI[c.status];
              const estorno = c.status !== "pago" ? estornos.find((e) => e.mes_referencia === c.mes) : undefined;
              return (
                <li key={c.key} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <div className="font-semibold">{formatMesRef(c.mes)}</div>
                    <div className="text-xs text-muted-foreground">
                      Referente à mensalidade de {formatMesRef(c.mes).replace(" de ", "/")}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {c.status === "pago" && c.pagamento?.data_pagamento
                        ? `Pago em ${formatDataBR(c.pagamento.data_pagamento)}`
                        : `Vencimento ${formatDataBR(c.vencimentoISO)}`}
                    </div>
                    {estorno && (
                      <div className="text-xs font-semibold text-destructive">
                        ↩️ Recebimento desfeito em {formatDataBR(estorno.estornado_em.slice(0, 10))}
                      </div>
                    )}
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <span className="font-bold">R$ {formatBRL(c.valor)}</span>
                    <Badge variant="outline" className={s.className}>
                      {s.emoji} {c.antecipada ? "Pago antecipadamente" : s.label}
                      {c.status === "vencido" ? ` há ${c.diasAtraso} dia${c.diasAtraso === 1 ? "" : "s"}` : ""}
                    </Badge>
                    {c.status === "vencido" && Number(c.valor) > 0 && c.aluno.whatsapp && (
                      <CobrarButton competencia={c} motorista={motorista} encargos={aluno as unknown as import("@/lib/encargos").EncargoConfig} />
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </DialogContent>
    </Dialog>
  );
}
