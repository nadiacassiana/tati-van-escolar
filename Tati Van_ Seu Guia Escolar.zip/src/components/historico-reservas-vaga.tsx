import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { getMotoristaFromUser } from "@/lib/whatsapp";
import { useVanLogo } from "@/lib/logo-store";
import { downloadBlob, openBlobInNewTab } from "@/lib/contrato-pdf";
import { garantiaFilename, garantiaToPdfBlob } from "@/lib/garantia-pdf";
import {
  STATUS_LABEL, formatDataHora, tipoLabel, valorLabel,
  type GarantiaStatus, type GarantiaVaga,
} from "@/lib/garantia-vaga";

const STATUS_CLASS: Record<GarantiaStatus, string> = {
  pendente: "bg-warning/20 text-warning-foreground border-warning/40",
  confirmado: "bg-success/15 text-success border-success/30",
  recusado: "bg-destructive/15 text-destructive border-destructive/30",
};

export function HistoricoReservasVaga({
  aluno,
  open,
  onOpenChange,
  user,
}: {
  aluno: { id: string; nome: string } | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  user?: Parameters<typeof getMotoristaFromUser>[0];
}) {
  const logo = useVanLogo();
  const motorista = getMotoristaFromUser(user ?? null);
  const [itens, setItens] = useState<GarantiaVaga[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !aluno) return;
    let active = true;
    setLoading(true);
    (async () => {
      const { data } = await supabase
        .from("garantias_vaga")
        .select("*")
        .or(`aluno_id.eq.${aluno.id},aluno_nome.eq.${aluno.nome}`)
        .order("ano_referencia", { ascending: false });
      if (!active) return;
      setItens(((data as unknown) as GarantiaVaga[]) || []);
      setLoading(false);
    })();
    return () => { active = false; };
  }, [open, aluno]);

  const run = (g: GarantiaVaga, action: "ver" | "baixar") => {
    try {
      const blob = garantiaToPdfBlob(g, { ...motorista, logo: logo || motorista.logo });
      if (action === "ver") openBlobInNewTab(blob);
      else downloadBlob(blob, garantiaFilename(g));
    } catch (e) {
      console.error("[historico-reservas] falha ao gerar PDF", e);
      toast.error("Não foi possível abrir o documento.");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-md">
        <DialogHeader>
          <DialogTitle>🎟️ Histórico de reservas de vaga</DialogTitle>
          <DialogDescription>{aluno?.nome}</DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="py-6 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : itens.length === 0 ? (
          <div className="py-6 text-center text-sm text-muted-foreground">
            Nenhuma reserva de vaga registrada para este aluno.
          </div>
        ) : (
          <ul className="divide-y rounded-xl border">
            {itens.map((g) => {
              const status = (g.status as GarantiaStatus) || "pendente";
              return (
                <li key={g.id} className="space-y-2 px-4 py-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-semibold">{g.ano_referencia} — {tipoLabel(g)}</div>
                      <div className="text-xs text-muted-foreground">{valorLabel(g)}</div>
                      <div className="text-xs text-muted-foreground">
                        {status === "confirmado" && g.confirmado_em
                          ? `Confirmada em ${formatDataHora(g.confirmado_em)}`
                          : status === "recusado" && g.recusado_em
                            ? `Recusada em ${formatDataHora(g.recusado_em)}`
                            : `Criada em ${formatDataHora(g.created_at)}`}
                      </div>
                    </div>
                    <Badge variant="outline" className={STATUS_CLASS[status]}>
                      {STATUS_LABEL[status]}
                    </Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => run(g, "ver")}>
                      👁️ Visualizar
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => run(g, "baixar")}>
                      ⬇️ Baixar
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </DialogContent>
    </Dialog>
  );
}
