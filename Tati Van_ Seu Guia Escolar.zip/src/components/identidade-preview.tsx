import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { VanLogo } from "@/components/van-logo";


type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  nome: string;
  logo?: string;
};

function Cabecalho({ nome, logo }: { nome: string; logo?: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b-4 pb-3" style={{ borderColor: "#1e40af" }}>
      <div className="flex items-center gap-3">
        <VanLogo
          logo={logo}
          className="object-contain"
          fallbackClassName="flex h-11 w-11 items-center justify-center rounded-xl text-2xl"
        />

        <div className="text-base font-extrabold" style={{ color: "#1e3a8a" }}>
          {nome}
        </div>
      </div>
      <div className="text-[10px] uppercase tracking-wider text-slate-500">Documento oficial</div>
    </div>
  );
}

function Folha({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-xl border bg-white p-5 text-slate-900 shadow-sm" style={{ fontFamily: "system-ui, sans-serif" }}>
      {children}
    </div>
  );
}

export function IdentidadePreviewDialog({ open, onOpenChange, nome, logo }: Props) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>👁️ Como seus documentos ficam</DialogTitle>
          <DialogDescription>
            Exemplos com a identidade visual da sua van. Os dados abaixo são apenas ilustrativos.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="recibo">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="recibo">Recibo</TabsTrigger>
            <TabsTrigger value="contrato">Contrato</TabsTrigger>
            <TabsTrigger value="reserva">Reserva de vaga</TabsTrigger>
          </TabsList>

          <TabsContent value="recibo" className="mt-3">
            <Folha>
              <Cabecalho nome={nome} logo={logo} />
              <div className="mt-4 rounded-xl p-4 text-center" style={{ background: "#eff6ff" }}>
                <div className="text-[10px] uppercase tracking-wider text-slate-600">Valor recebido</div>
                <div className="text-2xl font-extrabold" style={{ color: "#1e3a8a" }}>R$ 450,00</div>
              </div>
              <p className="mt-4 text-justify text-xs leading-relaxed">
                Declaro ter recebido de Maria Souza a importância de R$ 450,00 referente ao serviço de transporte
                escolar prestado ao aluno(a) Pedro Souza, correspondente ao mês de Março/2026.
              </p>
              <div className="mt-6 text-center text-[10px] uppercase tracking-wider text-slate-400">{nome} • REC-000123</div>
            </Folha>
          </TabsContent>

          <TabsContent value="contrato" className="mt-3">
            <Folha>
              <Cabecalho nome={nome} logo={logo} />
              <div className="mt-4 text-center text-sm font-bold uppercase tracking-wide">
                Contrato de Prestação de Serviço — Transporte Escolar
              </div>
              <div className="mt-3 text-[11px] font-bold uppercase" style={{ color: "#2563eb" }}>Dados do aluno</div>
              <div className="text-xs">Pedro Souza • Escola Municipal Aurora • Turno: Manhã</div>
              <div className="mt-3 text-[11px] font-bold uppercase" style={{ color: "#2563eb" }}>Cláusulas</div>
              <p className="text-justify text-xs leading-relaxed">
                <b>1. Pontualidade.</b> O responsável compromete-se a estar presente no horário combinado...
              </p>
              <div className="mt-6 text-center text-[10px] text-slate-400">{nome} • {new Date().toLocaleDateString("pt-BR")}</div>
            </Folha>
          </TabsContent>

          <TabsContent value="reserva" className="mt-3">
            <Folha>
              <Cabecalho nome={nome} logo={logo} />
              <div className="mt-4 text-center text-sm font-bold uppercase tracking-wide">Reserva de vaga</div>
              <p className="mt-3 text-justify text-xs leading-relaxed">
                Confirmamos a reserva de 1 (uma) vaga no transporte escolar para o(a) aluno(a) Pedro Souza,
                referente ao ano letivo de {new Date().getFullYear()}, mediante as condições combinadas com o responsável.
              </p>
              <div className="mt-8 border-t pt-2 text-center text-xs font-semibold">Assinatura do responsável</div>
              <div className="mt-6 text-center text-[10px] text-slate-400">{nome}</div>
            </Folha>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
