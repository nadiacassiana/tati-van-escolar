import { useEffect, useState } from "react";
import { Smartphone, X, Apple, Chrome, MonitorSmartphone } from "lucide-react";

const STORAGE_KEY = "tati_install_hint_seen";

type Platform = "ios" | "android" | "other";

function detectPlatform(): Platform {
  if (typeof navigator === "undefined") return "other";
  const ua = navigator.userAgent.toLowerCase();
  if (/iphone|ipad|ipod/.test(ua)) return "ios";
  if (/android/.test(ua)) return "android";
  return "other";
}

const messages: Record<Platform, { title: string; steps: string[]; icon: React.ReactNode }> = {
  ios: {
    title: "Instale diretamente pelo iPhone",
    steps: [
      "A Tati Van Escolar não está na App Store.",
      "Toque no botão amarelo para começar.",
      "No Safari, use Compartilhar → Adicionar à Tela de Início.",
    ],
    icon: <Apple className="h-4 w-4 sm:h-5 sm:w-5" />,
  },
  android: {
    title: "Instale diretamente pelo Android",
    steps: [
      "A Tati Van Escolar não está na Play Store.",
      "Toque no botão amarelo para começar.",
      "No Chrome, toque em Adicionar à tela inicial.",
    ],
    icon: <Chrome className="h-4 w-4 sm:h-5 sm:w-5" />,
  },
  other: {
    title: "Aplicativo web, sem loja",
    steps: [
      "A Tati Van Escolar não está na Play Store nem na App Store.",
      "No celular, instale diretamente pelo site.",
      "É rápido, leve e sempre atualizado.",
    ],
    icon: <MonitorSmartphone className="h-4 w-4 sm:h-5 sm:w-5" />,
  },
};

export function InstallHint() {
  const [platform, setPlatform] = useState<Platform>("other");
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setPlatform(detectPlatform());
    try {
      const seen = localStorage.getItem(STORAGE_KEY);
      if (!seen) setVisible(true);
    } catch {
      setVisible(true);
    }
  }, []);

  if (!visible) return null;

  const { title, steps, icon } = messages[platform];

  const dismiss = () => {
    setVisible(false);
    try {
      localStorage.setItem(STORAGE_KEY, "1");
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="relative mt-5 w-full max-w-xl rounded-2xl border border-white/30 bg-white/15 p-3 pr-9 backdrop-blur transition-all sm:p-4 sm:pr-10">
      <button
        onClick={dismiss}
        className="absolute right-2 top-2 inline-flex h-6 w-6 items-center justify-center rounded-full text-primary-foreground/80 transition-colors hover:bg-white/20 hover:text-primary-foreground sm:h-7 sm:w-7"
        aria-label="Fechar orientação"
      >
        <X className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
      </button>
      <div className="flex items-start gap-2.5 sm:gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-foreground shadow-sm sm:h-10 sm:w-10">
          <Smartphone className="h-4 w-4 sm:h-5 sm:w-5" />
        </div>
        <div className="min-w-0">
          <h3 className="flex items-center gap-1.5 text-xs font-bold text-primary-foreground sm:text-sm">
            {icon}
            <span className="truncate">{title}</span>
          </h3>
          <ol className="mt-1.5 space-y-0.5 text-xs text-primary-foreground/90 sm:mt-2 sm:space-y-1 sm:text-sm">
            {steps.map((step, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-accent sm:mt-1.5 sm:h-1.5 sm:w-1.5" />
                <span className="break-words leading-relaxed">{step}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
}
