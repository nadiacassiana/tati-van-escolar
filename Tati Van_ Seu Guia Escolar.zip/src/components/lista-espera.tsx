import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, ArrowRightCircle, Link2, Copy } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { maskPhoneBR } from "@/lib/phone-mask";
import { formatDataHora } from "@/lib/garantia-vaga";
import { getDisplayName, getMotoristaFromUser, type MotoristaPerfil } from "@/lib/whatsapp";

export type ListaEsperaItem = Tables<"lista_espera">;

export const PERIODO_OPCOES = [
  { value: "manha", label: "Manhã" },
  { value: "tarde", label: "Tarde" },
  { value: "integral", label: "Integral" },
] as const;

export function periodoLabel(v?: string | null): string {
  return PERIODO_OPCOES.find((p) => p.value === v)?.label ?? "";
}

type Form = {
  aluno_nome: string;
  responsavel_nome: string;
  responsavel_whatsapp: string;
  escola: string;
  periodo: string;
  endereco: string;
  numero: string;
  observacoes: string;
};

const emptyForm = (): Form => ({
  aluno_nome: "",
  responsavel_nome: "",
  responsavel_whatsapp: "",
  escola: "",
  periodo: "",
  endereco: "",
  numero: "",
  observacoes: "",
});

export function ListaEsperaTab({
  userId,
  onMoverParaReserva,
  reloadKey,
}: {
  userId: string;
  onMoverParaReserva: (item: ListaEsperaItem) => void;
  reloadKey?: number;
}) {
  const [itens, setItens] = useState<ListaEsperaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ListaEsperaItem | null>(null);
  const [form, setForm] = useState<Form>(emptyForm());
  const [saving, setSaving] = useState(false);
  const [linkOpen, setLinkOpen] = useState(false);
  const [motorista, setMotorista] = useState<MotoristaPerfil | null>(null);

  const link = typeof window !== "undefined" ? `${window.location.origin}/espera/${userId}` : "";
  const nomeMotorista = getDisplayName(motorista ?? {});
  const mensagemPadrao =
    `Olá! 🚐 Estamos com a lista de espera aberta para o transporte escolar da ${nomeMotorista}. ` +
    `Se tiver interesse em uma vaga, é só preencher seus dados neste formulário: ${link}\n\n` +
    "Assim que abrir vaga, entraremos em contato. 💛";

  const copiarMensagem = async () => {
    try {
      await navigator.clipboard.writeText(mensagemPadrao);
      toast.success("Mensagem copiada! Agora é só enviar para os pais. 💙");
    } catch {
      toast.error("Não consegui copiar. Mensagem: " + mensagemPadrao);
    }
  };

  const enviarWhatsApp = () => {
    window.open(`https://wa.me/?text=${encodeURIComponent(mensagemPadrao)}`, "_blank", "noopener");
  };

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("lista_espera")
      .select("*")
      .is("convertido_em", null)
      .order("created_at", { ascending: true });
    setItens((data as ListaEsperaItem[]) || []);
    setLoading(false);
  };

  const loadMotorista = async () => {
    const { data } = await supabase.auth.getUser();
    if (data?.user) setMotorista(getMotoristaFromUser(data.user));
  };

  useEffect(() => {
    void load();
    void loadMotorista();
  }, [reloadKey]);

  const openNovo = () => {
    setEditing(null);
    setForm(emptyForm());
    setOpen(true);
  };

  const openEditar = (i: ListaEsperaItem) => {
    setEditing(i);
    setForm({
      aluno_nome: i.aluno_nome,
      responsavel_nome: i.responsavel_nome,
      responsavel_whatsapp: i.responsavel_whatsapp,
      escola: i.escola || "",
      periodo: i.periodo || "",
      endereco: i.endereco || "",
      numero: i.numero || "",
      observacoes: i.observacoes || "",
    });
    setOpen(true);
  };

  const salvar = async () => {
    if (!form.aluno_nome.trim()) return toast.error("Informe o nome do aluno.");
    if (!form.responsavel_nome.trim()) return toast.error("Informe o nome do responsável.");
    if (!form.responsavel_whatsapp.trim()) return toast.error("Informe o WhatsApp do responsável.");

    const payload = {
      aluno_nome: form.aluno_nome.trim(),
      responsavel_nome: form.responsavel_nome.trim(),
      responsavel_whatsapp: form.responsavel_whatsapp.trim(),
      escola: form.escola.trim(),
      periodo: form.periodo,
      endereco: form.endereco.trim(),
      numero: form.numero.trim(),
      observacoes: form.observacoes.trim(),
    };

    setSaving(true);
    const { error } = editing
      ? await supabase.from("lista_espera").update(payload).eq("id", editing.id)
      : await supabase.from("lista_espera").insert({ ...payload, user_id: userId });
    setSaving(false);
    if (error) return toast.error("Não foi possível salvar.");
    toast.success(editing ? "Cadastro atualizado." : "Adicionado à lista de espera.");
    setOpen(false);
    void load();
  };

  const excluir = async (i: ListaEsperaItem) => {
    if (!confirm(`Remover ${i.aluno_nome} da lista de espera?`)) return;
    const { error } = await supabase.from("lista_espera").delete().eq("id", i.id);
    if (error) return toast.error("Não foi possível excluir.");
    toast.success("Removido da lista de espera.");
    void load();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Interessados aguardando uma vaga. Quando abrir vaga, mova para a reserva em um clique.
        </p>
        <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row">
          <Button variant="outline" className="font-bold" onClick={() => setLinkOpen(true)}>
            <Link2 className="mr-1 h-4 w-4" /> 🔗 Enviar Link para o Pai
          </Button>
          <Button className="font-bold" onClick={openNovo}>
            <Plus className="mr-1 h-4 w-4" /> Adicionar à Lista de Espera
          </Button>
        </div>
      </div>

      <Dialog open={linkOpen} onOpenChange={setLinkOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>🔗 Link da lista de espera</DialogTitle>
            <DialogDescription>
              Envie para o responsável preencher os dados. O cadastro entra direto na sua lista de espera.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="break-all rounded-lg border bg-muted/40 p-3 text-xs">{link}</div>
            <div className="rounded-lg border bg-card p-3 text-xs text-muted-foreground whitespace-pre-line">
              {mensagemPadrao}
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              <Button variant="outline" onClick={copiarMensagem}>
                <Copy className="mr-1 h-4 w-4" /> Copiar mensagem
              </Button>
              <Button className="font-bold" onClick={enviarWhatsApp}>
                📱 Enviar por WhatsApp
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {loading ? (
        <Card className="p-6 text-center text-sm text-muted-foreground">Carregando...</Card>
      ) : itens.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">
          Ninguém na lista de espera ainda. Clique em{" "}
          <strong>Adicionar à Lista de Espera</strong> para começar.
        </Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {itens.map((i, idx) => (
            <Card key={i.id} className="space-y-3 p-4" style={{ boxShadow: "var(--shadow-card)" }}>
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline" className="bg-primary/10 text-primary">#{idx + 1}</Badge>
                <span className="font-bold">{i.aluno_nome}</span>
                {i.periodo && <Badge variant="outline">{periodoLabel(i.periodo)}</Badge>}
              </div>
              <div className="space-y-0.5 text-xs text-muted-foreground">
                <div>👤 {i.responsavel_nome} • 📱 {i.responsavel_whatsapp}</div>
                {i.escola && <div>🏫 {i.escola}</div>}
                {(i.endereco || i.numero) && (
                  <div>📍 {[i.endereco, i.numero].filter(Boolean).join(", ")}</div>
                )}
                {i.observacoes && <div>📝 {i.observacoes}</div>}
                <div>🗓️ Cadastrado em {formatDataHora(i.created_at)}</div>
              </div>
              <Button className="w-full font-bold" onClick={() => onMoverParaReserva(i)}>
                <ArrowRightCircle className="mr-1 h-4 w-4" /> Mover para Reserva
              </Button>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="flex-1" onClick={() => openEditar(i)}>
                  <Pencil className="mr-1 h-3 w-3" /> Editar
                </Button>
                <Button size="sm" variant="outline" className="flex-1" onClick={() => excluir(i)}>
                  <Trash2 className="mr-1 h-3 w-3 text-destructive" /> Excluir
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar interessado" : "Adicionar à lista de espera"}</DialogTitle>
            <DialogDescription>
              Cadastro rápido para não perder o contato de quem procurou a van.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="le-aluno">Nome do aluno *</Label>
              <Input
                id="le-aluno"
                value={form.aluno_nome}
                onChange={(e) => setForm({ ...form, aluno_nome: e.target.value })}
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="le-resp">Nome do responsável *</Label>
                <Input
                  id="le-resp"
                  value={form.responsavel_nome}
                  onChange={(e) => setForm({ ...form, responsavel_nome: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="le-zap">WhatsApp do responsável *</Label>
                <Input
                  id="le-zap"
                  inputMode="numeric"
                  placeholder="(11) 99999-9999"
                  value={form.responsavel_whatsapp}
                  onChange={(e) =>
                    setForm({ ...form, responsavel_whatsapp: maskPhoneBR(e.target.value) })
                  }
                />
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="le-escola">Escola</Label>
                <Input
                  id="le-escola"
                  value={form.escola}
                  onChange={(e) => setForm({ ...form, escola: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Período</Label>
                <Select value={form.periodo} onValueChange={(v) => setForm({ ...form, periodo: v })}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    {PERIODO_OPCOES.map((p) => (
                      <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-[1fr_120px]">
              <div className="space-y-1.5">
                <Label htmlFor="le-end">Endereço (rua e bairro)</Label>
                <Input
                  id="le-end"
                  value={form.endereco}
                  onChange={(e) => setForm({ ...form, endereco: e.target.value })}
                  placeholder="Rua das Flores, Centro"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="le-num">Número</Label>
                <Input
                  id="le-num"
                  value={form.numero}
                  onChange={(e) => setForm({ ...form, numero: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="le-obs">Observações da rota (opcional)</Label>
              <Textarea
                id="le-obs"
                rows={2}
                value={form.observacoes}
                onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
                placeholder="Ex.: perto da casa do Pedro, ponto de referência: padaria."
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button className="font-bold" onClick={salvar} disabled={saving}>
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
