import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Search, Send, Pencil, Star, Megaphone, Copy, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { applyVariables, getMotoristaFromUser, MENSAGENS_PADRAO, VARIAVEIS_DISPONIVEIS, type VarContext } from "@/lib/whatsapp";
import { WhatsAppBatchRunner, type BatchTarget } from "@/components/whatsapp-batch-runner";
import { useIsMobile } from "@/hooks/use-mobile";

import { getRotaAtiva, linkAtivo, trackingUrl, type RotaAtiva } from "@/lib/rota-ativa";
import { MapPin } from "lucide-react";
import { toast } from "sonner";
import type { User } from "@supabase/supabase-js";

export type MassResponsavel = {
  id: string;
  nome: string;
  whatsapp: string;
  telefone?: string;
  alunos_ids?: string[];
};

export type MassAluno = {
  id: string;
  nome: string;
  escola?: string;
  mensalidade?: number;
  vencimento?: number;
  horario_ida?: string;
  status_mensalidade?: string;
};

type Mensagem = { id: string; nome: string; emoji: string; texto: string; favorito: boolean; ordem: number };

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  user: User;
  responsaveis: MassResponsavel[];
  alunos: MassAluno[];
};

// Sugestões rápidas (procuradas na biblioteca por palavra-chave)
const QUICK = [
  { emoji: "🚐", label: "Estou saindo para a rota", keywords: ["sair", "saindo", "saída", "buscar", "rota"] },
  { emoji: "🏫", label: "Cheguei à escola", keywords: ["escola", "embarcou", "chegou", "chegada"] },
  { emoji: "🏠", label: "Estamos iniciando o retorno", keywords: ["casa", "retorno", "voltando", "chegando em casa"] },
  { emoji: "🚦", label: "Hoje haverá atraso", keywords: ["atraso", "trânsito", "transito"] },
  { emoji: "🌧", label: "Atenção: chuva forte", keywords: ["chuva", "tempo"] },
  { emoji: "❌", label: "Hoje não haverá transporte", keywords: ["não haverá", "sem transporte", "cancelad"] },
  { emoji: "📅", label: "Amanhã não haverá aula", keywords: ["amanhã", "feriado", "aula"] },
];

type Step = "msg" | "dest" | "confirm" | "run";

function VariablesPanel({ onInsert }: { onInsert: (v: string) => void }) {
  const [copied, setCopied] = useState<string | null>(null);

  async function copy(key: string) {
    try {
      await navigator.clipboard.writeText(key);
      setCopied(key);
      setTimeout(() => setCopied(null), 1500);
    } catch {
      // ignore
    }
  }

  return (
    <div className="rounded-lg border bg-card p-3">
      <p className="text-xs font-semibold text-muted-foreground mb-2">Variáveis disponíveis — clique para copiar e cole na mensagem:</p>
      <div className="flex flex-wrap gap-2">
        {VARIAVEIS_DISPONIVEIS.map((v) => (
          <button
            key={v.key}
            type="button"
            onClick={() => { void copy(v.key); onInsert(v.key); }}
            title={v.label}
            className="inline-flex items-center gap-1.5 rounded-md border bg-background px-2 py-1 text-xs font-medium transition-colors hover:bg-accent/30"
          >
            <span className="font-mono text-primary">{v.key}</span>
            {copied === v.key ? <Check className="h-3 w-3 text-success" /> : <Copy className="h-3 w-3 text-muted-foreground" />}
          </button>
        ))}
      </div>
    </div>
  );
}

export function MassCommDialog({ open, onOpenChange, user, responsaveis, alunos }: Props) {
  const motorista = useMemo(() => getMotoristaFromUser(user), [user]);
  const isMobile = useIsMobile();

  const [step, setStep] = useState<Step>("msg");
  const [msgs, setMsgs] = useState<Mensagem[]>([]);
  const [busca, setBusca] = useState("");
  const [escolhida, setEscolhida] = useState<Mensagem | null>(null);
  const [textoCustom, setTextoCustom] = useState("");
  const [filtro, setFiltro] = useState<"todos" | "manha" | "tarde" | "escola" | "inadimplentes" | "manual">("todos");
  const [escola, setEscola] = useState<string>("");
  const [selManual, setSelManual] = useState<Set<string>>(new Set());
  const [enviando, setEnviando] = useState(false);
  const [rotas, setRotas] = useState<{ manha: RotaAtiva | null; tarde: RotaAtiva | null }>({ manha: null, tarde: null });

  const BOAS_VINDAS_PADRAO = useMemo(() => MENSAGENS_PADRAO.find((m) => m.nome === "Boas-vindas às Famílias"), []);

  useEffect(() => {
    if (!open) return;
    setStep("msg");
    setEscolhida(null);
    setTextoCustom("");
    setBusca("");
    setFiltro("todos");
    setEscola("");
    setSelManual(new Set());
    void load();
    void loadRotas();
  }, [open]);

  async function loadRotas() {
    const [m, t] = await Promise.all([getRotaAtiva(user.id, "manha"), getRotaAtiva(user.id, "tarde")]);
    setRotas({ manha: m, tarde: t });
  }

  async function load() {
    const { data } = await supabase
      .from("mensagens").select("*")
      .order("favorito", { ascending: false }).order("ordem", { ascending: true });
    let list = (data as Mensagem[]) || [];
    if (list.length === 0) {
      const rows = MENSAGENS_PADRAO.map((m, i) => ({ ...m, ordem: i, user_id: user.id }));
      const { data: inserted } = await supabase.from("mensagens").insert(rows).select("*");
      list = (inserted as Mensagem[]) || [];
    }
    setMsgs(list);
  }

  function escolherBoasVindas() {
    const found = msgs.find((m) => m.nome === "Boas-vindas às Famílias");
    if (found) {
      setEscolhida(found);
      setTextoCustom("");
    } else if (BOAS_VINDAS_PADRAO) {
      setEscolhida({ ...BOAS_VINDAS_PADRAO, id: "quick-boas-vindas", favorito: false, ordem: 999 });
      setTextoCustom("");
    } else {
      toast.error("Modelo de boas-vindas não encontrado.");
      return;
    }
    setStep("dest");
  }

  const escolas = useMemo(() => {
    const s = new Set<string>();
    alunos.forEach((a) => { if (a.escola) s.add(a.escola); });
    return Array.from(s).sort();
  }, [alunos]);

  const destinatarios = useMemo(() => {
    if (filtro === "todos") return responsaveis;
    if (filtro === "manual") return responsaveis.filter((r) => selManual.has(r.id));
    if (filtro === "manha") {
      const ids = alunos.filter((a) => a.horario_ida && parseInt(a.horario_ida) < 12).map((a) => a.id);
      return responsaveis.filter((r) => (r.alunos_ids || []).some((id) => ids.includes(id)));
    }
    if (filtro === "tarde") {
      const ids = alunos.filter((a) => a.horario_ida && parseInt(a.horario_ida) >= 12).map((a) => a.id);
      return responsaveis.filter((r) => (r.alunos_ids || []).some((id) => ids.includes(id)));
    }
    if (filtro === "escola") {
      if (!escola) return [];
      const ids = alunos.filter((a) => a.escola === escola).map((a) => a.id);
      return responsaveis.filter((r) => (r.alunos_ids || []).some((id) => ids.includes(id)));
    }
    if (filtro === "inadimplentes") {
      const ids = alunos.filter((a) => a.status_mensalidade === "atrasado" || a.status_mensalidade === "pendente").map((a) => a.id);
      return responsaveis.filter((r) => (r.alunos_ids || []).some((id) => ids.includes(id)));
    }
    return [];
  }, [filtro, escola, selManual, responsaveis, alunos]);

  const filtradas = msgs.filter((m) =>
    !busca || m.nome.toLowerCase().includes(busca.toLowerCase()) || m.texto.toLowerCase().includes(busca.toLowerCase())
  );

  function matchLibrary(label: string, keywords: string[]): Mensagem | undefined {
    const all = label.toLowerCase() + " " + keywords.join(" ").toLowerCase();
    return msgs.find((m) => {
      const hay = (m.nome + " " + m.texto).toLowerCase();
      return keywords.some((k) => hay.includes(k.toLowerCase())) || hay.includes(label.toLowerCase()) || all.includes(m.nome.toLowerCase());
    });
  }

  function escolherQuick(q: typeof QUICK[number]) {
    const found = matchLibrary(q.label, q.keywords);
    if (found) {
      setEscolhida(found);
      setTextoCustom("");
    } else {
      // Sem correspondência: usa um modelo simples e orienta o usuário a editar depois nas Configurações.
      const tmp: Mensagem = { id: "quick-" + q.label, nome: q.label, emoji: q.emoji, texto: `${q.emoji} ${q.label}.`, favorito: false, ordem: 999 };
      setEscolhida(tmp);
      setTextoCustom("");
      toast.message("Dica: cadastre essa mensagem na Biblioteca para personalizar.", { duration: 4000 });
    }
    setStep("dest");
  }

  function escolherDaBiblioteca(m: Mensagem) {
    setEscolhida(m);
    setTextoCustom("");
    setStep("dest");
  }

  function escolherPersonalizada() {
    setEscolhida({ id: "custom", nome: "Mensagem personalizada", emoji: "✏️", texto: "", favorito: false, ordem: 999 });
    setTextoCustom("");
    setStep("dest");
  }

  const rotaCandidata: RotaAtiva | null =
    filtro === "manha" ? rotas.manha : filtro === "tarde" ? rotas.tarde : null;
  const rotaAtivaDoFiltro: RotaAtiva | null = linkAtivo(rotaCandidata) ? rotaCandidata : null;

  function previewTextoPara(r: MassResponsavel | undefined): string {
    if (!escolhida) return "";
    const base = escolhida.id === "custom" ? textoCustom : escolhida.texto;
    const seuAluno = r ? alunos.find((a) => (r.alunos_ids || []).includes(a.id)) : alunos[0];
    const ctx: VarContext = {
      responsavel: r?.nome,
      aluno: seuAluno?.nome,
      escola: seuAluno?.escola,
      mensalidade: seuAluno?.mensalidade,
      vencimento: seuAluno?.vencimento,
    };
    let texto = applyVariables(base, ctx, motorista);
    if (rotaAtivaDoFiltro && !texto.includes("/rastrear/")) {
      texto = `${texto}\n\n📍 Acompanhe minha localização em tempo real:\n${trackingUrl(rotaAtivaDoFiltro.id)}`;
    }
    return texto;
  }

  const exemploDestinatario = useMemo(
    () => destinatarios.find((r) => (r.alunos_ids || []).length > 0) || destinatarios[0],
    [destinatarios]
  );

  const targets: BatchTarget[] = useMemo(
    () =>
      destinatarios
        .filter((r) => !!r.whatsapp)
        .map((r) => ({ id: r.id, nome: r.nome, telefone: r.whatsapp, texto: previewTextoPara(r) })),
    [destinatarios, escolhida, textoCustom, rotaAtivaDoFiltro]
  );

  function iniciarEnvio() {
    if (!escolhida) return;
    if (escolhida.id === "custom" && !textoCustom.trim()) { toast.error("Escreva a mensagem."); return; }
    if (targets.length === 0) { toast.error("Nenhum destinatário com WhatsApp."); return; }
    setStep("run");
  }

  async function registrarEnvio(t: BatchTarget) {
    if (!escolhida) return;
    const r = destinatarios.find((d) => d.id === t.id);
    const seuAluno = r ? alunos.find((a) => (r.alunos_ids || []).includes(a.id)) : undefined;
    await supabase.from("mensagens_historico").insert({
      user_id: user.id,
      mensagem_nome: escolhida.nome,
      emoji: escolhida.emoji,
      texto: t.texto,
      destinatario: t.nome,
      telefone: t.telefone,
      responsavel_id: t.id,
      aluno_id: seuAluno?.id ?? null,
    });
  }


  const labelFiltro: Record<string, string> = {
    todos: "Todos os responsáveis",
    manha: "Alunos da manhã",
    tarde: "Alunos da tarde",
    escola: escola ? `Escola: ${escola}` : "Escola específica",
    inadimplentes: "Responsáveis com mensalidade em atraso",
    manual: "Seleção manual",
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Megaphone className="h-5 w-5 text-primary" />
            {step === "msg" && "Comunicação em Massa — escolha a mensagem"}
            {step === "dest" && "Para quem enviar?"}
            {step === "confirm" && "Confirme o envio"}
            {step === "run" && "Enviando mensagens"}
          </DialogTitle>
          <DialogDescription>
            {step === "msg" && "Usa as mensagens da sua Biblioteca. Cada responsável recebe com o nome do filho dele."}
            {step === "dest" && "Selecione o grupo de responsáveis."}
            {step === "confirm" && "Veja um exemplo da mensagem antes de abrir o WhatsApp."}
            {step === "run" && (isMobile ? "Uma conversa por vez no aplicativo do WhatsApp." : "Abrindo as conversas no WhatsApp Web.")}
          </DialogDescription>
        </DialogHeader>


        {step === "msg" && (
          <div className="space-y-4">
            <div>
              <p className="text-xs font-semibold mb-2 text-primary">Atalho</p>
              <button type="button" onClick={escolherBoasVindas}
                className="flex w-full items-center gap-3 rounded-xl border border-primary/30 bg-primary/5 p-3 text-left transition-colors hover:bg-primary/10">
                <div className="text-2xl">🚌</div>
                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-sm">Boas-vindas às Famílias</div>
                  <div className="line-clamp-1 text-xs text-muted-foreground">Envie a mensagem de apresentação do Tati Van</div>
                </div>
              </button>
            </div>

            <div>
              <p className="text-xs font-semibold mb-2 text-muted-foreground">Sugestões rápidas</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {QUICK.map((q) => (
                  <button key={q.label} type="button" onClick={() => escolherQuick(q)}
                    className="flex items-center gap-3 rounded-xl border bg-card p-3 text-left transition-colors hover:bg-accent/30">
                    <div className="text-2xl">{q.emoji}</div>
                    <div className="text-sm font-semibold">{q.label}</div>
                  </button>
                ))}
                <button type="button" onClick={escolherPersonalizada}
                  className="flex items-center gap-3 rounded-xl border border-dashed bg-card p-3 text-left transition-colors hover:bg-accent/30">
                  <div className="text-2xl">✏️</div>
                  <div className="text-sm font-semibold">Mensagem personalizada</div>
                </button>
              </div>
            </div>

            <div>
              <p className="text-xs font-semibold mb-2 text-muted-foreground">Ou escolha da Biblioteca</p>
              <div className="relative mb-2">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input className="pl-9" placeholder="Buscar mensagem..." value={busca} onChange={(e) => setBusca(e.target.value)} />
              </div>
              <div className="grid gap-2 max-h-[35vh] overflow-y-auto pr-1">
                {filtradas.map((m) => (
                  <button key={m.id} type="button" onClick={() => escolherDaBiblioteca(m)}
                    className="flex items-start gap-3 rounded-xl border bg-card p-3 text-left transition-colors hover:bg-accent/30">
                    <div className="text-2xl">{m.emoji}</div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 font-semibold text-sm">
                        {m.nome}
                        {m.favorito && <Star className="h-3.5 w-3.5 fill-accent text-accent" />}
                      </div>
                      <div className="line-clamp-2 text-xs text-muted-foreground">{m.texto}</div>
                    </div>
                  </button>
                ))}
                {filtradas.length === 0 && (
                  <div className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">Nenhuma mensagem na biblioteca.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {step === "dest" && escolhida && (
          <div className="space-y-4">
            <div className="rounded-lg bg-accent/20 p-2 text-xs">
              {escolhida.emoji} <span className="font-semibold">{escolhida.nome}</span>
            </div>

            {escolhida.id === "custom" && (
              <div className="space-y-2">
                <Label>Escreva sua mensagem</Label>
                <Textarea rows={5} value={textoCustom} onChange={(e) => setTextoCustom(e.target.value)}
                  placeholder="Use {responsavel} e {aluno} para personalizar." />
                <VariablesPanel onInsert={(v) => setTextoCustom((p) => p + v)} />
              </div>
            )}

            <RadioGroup value={filtro} onValueChange={(v) => setFiltro(v as typeof filtro)} className="grid gap-2">
              {[
                { v: "todos", label: `📢 Todos os responsáveis (${responsaveis.length})` },
                { v: "manha", label: "🌅 Apenas alunos da manhã" },
                { v: "tarde", label: "🌇 Apenas alunos da tarde" },
                { v: "escola", label: "🏫 Apenas de uma escola específica" },
                { v: "inadimplentes", label: "💰 Apenas com mensalidade em atraso" },
                { v: "manual", label: "👆 Selecionar manualmente" },
              ].map((opt) => (
                <label key={opt.v} className="flex items-center gap-2 rounded-lg border p-3 cursor-pointer hover:bg-accent/30">
                  <RadioGroupItem value={opt.v} id={`f-${opt.v}`} />
                  <span className="text-sm">{opt.label}</span>
                </label>
              ))}
            </RadioGroup>

            {filtro === "escola" && (
              <div>
                <Label>Selecione a escola</Label>
                <Select value={escola} onValueChange={setEscola}>
                  <SelectTrigger><SelectValue placeholder="Escolha uma escola..." /></SelectTrigger>
                  <SelectContent>
                    {escolas.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}

            {filtro === "manual" && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Marque quem deve receber ({selManual.size})</Label>
                  <div className="flex gap-2">
                    <Button type="button" variant="outline" size="sm" onClick={() => setSelManual(new Set(responsaveis.map((r) => r.id)))}>Todos</Button>
                    <Button type="button" variant="outline" size="sm" onClick={() => setSelManual(new Set())}>Limpar</Button>
                  </div>
                </div>
                <div className="grid gap-1 max-h-[35vh] overflow-y-auto rounded-lg border p-2">
                  {responsaveis.map((r) => (
                    <label key={r.id} className="flex items-center gap-2 rounded p-2 cursor-pointer hover:bg-accent/30">
                      <Checkbox
                        checked={selManual.has(r.id)}
                        onCheckedChange={(c) => {
                          setSelManual((p) => {
                            const next = new Set(p);
                            if (c) next.add(r.id); else next.delete(r.id);
                            return next;
                          });
                        }}
                      />
                      <span className="text-sm font-medium">{r.nome}</span>
                      {!r.whatsapp && <span className="text-[10px] text-destructive">(sem WhatsApp)</span>}
                    </label>
                  ))}
                </div>
              </div>
            )}

            <div className="rounded-lg bg-primary/5 border border-primary/20 p-3 text-sm">
              <span className="font-semibold">{destinatarios.length}</span> responsável(eis) receberá(ão) esta mensagem.
              <div className="mt-1 text-xs text-muted-foreground">
                {isMobile
                  ? "📱 As conversas serão abertas uma por vez no aplicativo do WhatsApp."
                  : `💻 Serão abertas ${destinatarios.filter((r) => r.whatsapp).length} conversas no WhatsApp Web.`}
              </div>

            </div>

            {(filtro === "manha" || filtro === "tarde") && (
              rotaAtivaDoFiltro ? (
                <div className="rounded-lg border border-success/40 bg-success/5 p-3 text-xs">
                  <div className="flex items-center gap-2 font-semibold text-success">
                    <MapPin className="h-4 w-4" /> Rastreio em tempo real ativo — será incluído automaticamente
                  </div>
                  <div className="mt-1 truncate text-muted-foreground">{trackingUrl(rotaAtivaDoFiltro.id)}</div>
                </div>
              ) : (
                <div className="rounded-lg border border-dashed p-3 text-xs text-muted-foreground">
                  💡 Rastreio deste turno não iniciado. Vá em <b>Checklist</b> e clique em <b>Iniciar rota</b> da {filtro === "manha" ? "manhã" : "tarde"} para incluir o link automaticamente.
                </div>
              )
            )}

            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setStep("msg")}><ArrowLeft className="mr-2 h-4 w-4" /> Voltar</Button>
              <Button onClick={() => setStep("confirm")} disabled={destinatarios.length === 0} className="bg-primary font-bold">
                Continuar
              </Button>
            </DialogFooter>
          </div>
        )}

        {step === "confirm" && escolhida && (
          <div className="space-y-3">
            <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-900">
              Você está prestes a enviar esta mensagem para <span className="font-bold">{destinatarios.length}</span> responsável(eis).
              <div className="mt-1 text-xs">Grupo: {labelFiltro[filtro]}</div>
            </div>

            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-1">Pré-visualização (exemplo para {exemploDestinatario?.nome}):</p>
              <div className="rounded-lg border bg-card p-3 text-sm whitespace-pre-wrap">
                {previewTextoPara(exemploDestinatario)}
              </div>
              <p className="mt-1 text-[11px] text-muted-foreground">Cada responsável recebe a versão com o nome do próprio filho.</p>
            </div>

            <p className="rounded-lg border border-dashed p-3 text-xs text-muted-foreground">
              {isMobile
                ? "📱 As conversas serão abertas uma por vez no aplicativo do WhatsApp. Após enviar cada mensagem, volte ao Tati Van e toque em “Próxima conversa”."
                : `💻 Serão abertas ${targets.length} conversas do WhatsApp Web (uma aba por responsável). Se o navegador bloquear, permita pop-ups para este site.`}
            </p>

            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setStep("dest")} disabled={enviando}>
                <ArrowLeft className="mr-2 h-4 w-4" /> Cancelar
              </Button>
              <Button onClick={iniciarEnvio} disabled={enviando} className="bg-success text-success-foreground hover:bg-success/90 font-bold">
                <Send className="mr-2 h-4 w-4" /> Iniciar envio
              </Button>
            </DialogFooter>
          </div>
        )}

        {step === "run" && (
          <WhatsAppBatchRunner
            targets={targets}
            onSent={registrarEnvio}
            onFinish={(enviados, cancelado) => {
              if (cancelado && enviados > 0) toast.message(`Envio interrompido. ${enviados} conversa(s) aberta(s).`);
              onOpenChange(false);
            }}
          />
        )}

      </DialogContent>
    </Dialog>
  );
}
