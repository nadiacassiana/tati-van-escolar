import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Bell, BellRing, Cake, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { supabase } from "@/integrations/supabase/client";
import { emojiDoTipo, type Notificacao } from "@/lib/notificacoes-tipos";
import {
  enviarNotificacaoTeste,
  simularAniversarioAgora,
  sincronizarNotificacoes,
} from "@/lib/notificacoes.functions";


function tempoRelativo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.round(diff / 60000);
  if (min < 1) return "agora";
  if (min < 60) return `há ${min} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `há ${h}h`;
  return new Date(iso).toLocaleDateString("pt-BR");
}

export function NotificacoesBell() {
  const navigate = useNavigate();
  const [itens, setItens] = useState<Notificacao[]>([]);
  const [open, setOpen] = useState(false);
  const [testando, setTestando] = useState(false);
  const [simulando, setSimulando] = useState(false);

  const carregar = useCallback(async () => {
    const { data } = await supabase
      .from("notificacoes")
      .select("id, tipo, titulo, corpo, url, dados, lida_em, created_at")
      .order("created_at", { ascending: false })
      .limit(20);
    setItens(((data as unknown) as Notificacao[]) ?? []);
  }, []);

  useEffect(() => {
    (async () => {
      try {
        // Gera as notificações do dia (aniversários etc.) mesmo sem cron.
        await sincronizarNotificacoes();
      } catch (e) {
        console.error("[notificacoes] sincronização falhou", e);
      }
      await carregar();
    })();
  }, [carregar]);

  const naoLidas = itens.filter((n) => !n.lida_em).length;

  async function marcarLida(n: Notificacao) {
    if (!n.lida_em) {
      await supabase
        .from("notificacoes")
        .update({ lida_em: new Date().toISOString() })
        .eq("id", n.id);
      setItens((prev) =>
        prev.map((i) => (i.id === n.id ? { ...i, lida_em: new Date().toISOString() } : i)),
      );
    }
  }

  async function marcarTodas() {
    const ids = itens.filter((n) => !n.lida_em).map((n) => n.id);
    if (ids.length === 0) return;
    await supabase.from("notificacoes").update({ lida_em: new Date().toISOString() }).in("id", ids);
    setItens((prev) => prev.map((i) => ({ ...i, lida_em: i.lida_em ?? new Date().toISOString() })));
  }

  async function abrir(n: Notificacao) {
    await marcarLida(n);
    setOpen(false);
    const url = n.url || "/dashboard";
    const [path, hash] = url.split("#");
    navigate({ to: path, hash: hash || undefined } as never);
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Notificações">
          <Bell className="h-5 w-5" />
          {naoLidas > 0 && (
            <span className="absolute right-1 top-1 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
              {naoLidas > 9 ? "9+" : naoLidas}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[min(22rem,calc(100vw-2rem))] p-0">
        <div className="flex items-center justify-between border-b px-4 py-3">
          <span className="text-sm font-bold">🔔 Notificações</span>
          {naoLidas > 0 && (
            <button
              onClick={marcarTodas}
              className="inline-flex items-center gap-1 text-xs font-semibold text-primary"
            >
              <Check className="h-3 w-3" /> Marcar todas
            </button>
          )}
        </div>
        <div className="max-h-80 overflow-y-auto">
          {itens.length === 0 ? (
            <div className="p-6 text-center text-sm text-muted-foreground">
              Nenhuma notificação por enquanto.
            </div>
          ) : (
            itens.map((n) => (
              <button
                key={n.id}
                onClick={() => abrir(n)}
                className={`flex w-full gap-3 border-b px-4 py-3 text-left last:border-b-0 hover:bg-muted/60 ${
                  n.lida_em ? "opacity-70" : ""
                }`}
              >
                <span className="text-lg leading-none">{emojiDoTipo(n.tipo)}</span>
                <span className="flex-1">
                  <span className="block text-sm font-semibold">{n.titulo}</span>
                  <span className="block text-xs text-muted-foreground">{n.corpo}</span>
                  <span className="mt-1 block text-[10px] uppercase tracking-wide text-muted-foreground">
                    {tempoRelativo(n.created_at)}
                  </span>
                </span>
                {!n.lida_em && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary" />}
              </button>
            ))
          )}
        </div>
        <div className="border-t p-3">
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            disabled={testando}
            onClick={async () => {
              setTestando(true);
              try {
                const res = await enviarNotificacaoTeste({ data: undefined as never });
                if (res.enviados > 0) {
                  toast.success(
                    "Notificação de teste enviada! Confira a área de notificações do celular.",
                  );
                } else {
                  toast.error(
                    "Nenhum aparelho recebeu. Ative as notificações em Configurações e tente de novo.",
                  );
                }
              } catch {
                toast.error("Não foi possível enviar a notificação de teste agora.");
              } finally {
                setTestando(false);
              }
            }}
          >
            {testando ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <BellRing className="h-4 w-4" />
            )}
            Enviar notificação de teste
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="mt-2 w-full"
            disabled={simulando}
            onClick={async () => {
              setSimulando(true);
              try {
                const res = await simularAniversarioAgora({
                  data: { nome: "Ana Beatriz Souza" },
                });
                await carregar();
                if (res.enviados > 0) {
                  toast.success(
                    `Aniversário de ${res.aluno} simulado! Veja a notificação no celular.`,
                  );
                } else {
                  toast.error(
                    "A notificação foi criada aqui, mas nenhum aparelho recebeu o push. Ative as notificações em Configurações.",
                  );
                }
              } catch {
                toast.error("Não foi possível simular o aniversário agora.");
              } finally {
                setSimulando(false);
              }
            }}
          >
            {simulando ? <Loader2 className="h-4 w-4 animate-spin" /> : <Cake className="h-4 w-4" />}
            🎂 Simular aniversário agora
          </Button>
          <p className="mt-2 text-center text-[11px] text-muted-foreground">
            Ao tocar na notificação, a Tati abre no Painel. A simulação não altera a data de
            nascimento de nenhum aluno.
          </p>

        </div>
      </PopoverContent>
    </Popover>
  );
}
