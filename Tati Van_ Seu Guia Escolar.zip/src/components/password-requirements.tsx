import { Check, X } from "lucide-react";
import { checkPassword } from "@/lib/password-policy";

/** Lista visual dos requisitos da nova senha. */
export function PasswordRequirements({ value }: { value: string }) {
  const itens = checkPassword(value);
  return (
    <ul className="space-y-1 rounded-lg bg-muted/40 p-2.5 text-xs" aria-live="polite">
      <li className="mb-1 font-medium text-muted-foreground">Sua senha precisa ter:</li>
      {itens.map((i) => (
        <li
          key={i.id}
          className={`flex items-center gap-2 ${i.ok ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"}`}
        >
          {i.ok ? <Check className="h-3.5 w-3.5 shrink-0" /> : <X className="h-3.5 w-3.5 shrink-0 opacity-50" />}
          <span>{i.label}</span>
        </li>
      ))}
    </ul>
  );
}
