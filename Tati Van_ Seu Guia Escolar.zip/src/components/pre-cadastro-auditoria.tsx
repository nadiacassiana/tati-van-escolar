import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { FileDown } from "lucide-react";
import { toast } from "sonner";
import {
  dataHoraBR,
  gerarComprovantePreCadastroPDF,
  usoImagemLabel,
  type PreCadastroRow,
} from "@/lib/pre-cadastro-pdf";

/** Carrega as fichas de auto-cadastro (link público) da motorista logada. */
export function usePreCadastrosAprovados() {
  const [fichas, setFichas] = useState<PreCadastroRow[]>([]);

  useEffect(() => {
    let ativo = true;
    (async () => {
      const { data } = await supabase
        .from("pre_cadastros")
        .select("*")
        .order("created_at", { ascending: false });
      if (ativo) setFichas((data as PreCadastroRow[]) || []);
    })();
    return () => {
      ativo = false;
    };
  }, []);

  return fichas;
}

export function onlyDigitsPhone(s: string | null | undefined) {
  return (s || "").replace(/\D/g, "");
}

/** Card/selo de trilha de auditoria do auto-cadastro público. */
export function PreCadastroAuditoria({
  ficha,
  marca,
}: {
  ficha: PreCadastroRow | undefined;
  marca?: string;
}) {
  if (!ficha) return null;

  const imagem = usoImagemLabel(ficha.autoriza_imagem);

  return (
    <div className="mt-3 rounded-lg border border-success/30 bg-success/10 p-3 text-xs">
      <div className="font-semibold">✅ Cadastro realizado pelo responsável via link público</div>
      <div className="mt-1 flex justify-between gap-2">
        <span className="text-muted-foreground">Preenchido em</span>
        <span className="font-medium">{dataHoraBR(ficha.created_at)}</span>
      </div>
      {ficha.status === "aprovado" && (
        <div className="mt-0.5 flex justify-between gap-2">
          <span className="text-muted-foreground">Aprovado em</span>
          <span className="font-medium">{dataHoraBR(ficha.updated_at)}</span>
        </div>
      )}
      <div className="mt-0.5 flex justify-between gap-2">
        <span className="text-muted-foreground">Uso de imagem</span>
        <span className="font-medium">
          {ficha.autoriza_imagem === true ? "✅ " : ficha.autoriza_imagem === false ? "❌ " : "❔ "}
          {imagem}
        </span>
      </div>

      <Button
        variant="outline"
        size="sm"
        className="mt-3 w-full font-semibold"
        onClick={() => {
          try {
            gerarComprovantePreCadastroPDF(ficha, marca);
            toast.success("Comprovante do cadastro gerado. 📄");
          } catch {
            toast.error("Não consegui gerar o comprovante.");
          }
        }}
      >
        <FileDown className="mr-1 h-4 w-4" /> 📄 Exportar Comprovante do Cadastro
      </Button>
    </div>
  );
}
