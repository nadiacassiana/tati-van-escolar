import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Link2, Inbox, Check, X } from "lucide-react";
import { toast } from "sonner";
import { avatarPorSexo } from "@/lib/aluno-avatar";
import { comporEndereco } from "@/lib/escolas";
import type { Tables } from "@/integrations/supabase/types";

type PreCadastro = Tables<"pre_cadastros">;

function dataBR(iso: string | null) {
  if (!iso) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso;
}

function enderecoCompleto(p: PreCadastro) {
  const base = comporEndereco({
    rua: p.rua,
    numero: p.numero,
    bairro: p.bairro,
    cidade: p.cidade,
    estado: p.estado,
    cep: p.cep,
  });
  return p.referencia ? `${base} (ref.: ${p.referencia})` : base || "—";
}

export function PreCadastros({ userId, onAprovado }: { userId: string; onAprovado: () => void }) {
  const [lista, setLista] = useState<PreCadastro[]>([]);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);

  const carregar = useCallback(async () => {
    const { data } = await supabase
      .from("pre_cadastros")
      .select("*")
      .eq("status", "pendente")
      .order("created_at", { ascending: false });
    setLista((data as PreCadastro[]) || []);
  }, []);

  useEffect(() => {
    void carregar();
  }, [carregar]);

  const link = typeof window !== "undefined" ? `${window.location.origin}/cadastro/${userId}` : "";

  const copiarLink = async () => {
    try {
      await navigator.clipboard.writeText(link);
      toast.success("Link copiado! Envie para os pais pelo WhatsApp. 💙");
    } catch {
      toast.error("Não consegui copiar. Link: " + link);
    }
  };

  const aprovar = async (p: PreCadastro) => {
    setBusy(p.id);

    const { data: novo, error } = await supabase
      .from("alunos")
      .insert({
        user_id: userId,
        nome: p.aluno_nome,
        escola: p.escola || "—",
        turma: p.serie || "",
        endereco: enderecoCompleto(p),
        rua: p.rua || "",
        numero: p.numero || "",
        bairro: p.bairro || "",
        cidade: p.cidade || "",
        estado: (p.estado || "").toUpperCase().slice(0, 2),
        cep: p.cep || "",
        responsavel: p.responsavel_nome || "—",
        telefone: p.responsavel_whatsapp || "—",
        whatsapp: (p.responsavel_whatsapp || "").replace(/\D/g, ""),
        mensalidade: 0,
        vencimento: 5,
        horario_ida: "—",
        horario_volta: "—",
        aniversario: dataBR(p.data_nascimento) === "—" ? "" : dataBR(p.data_nascimento),
        observacoes: (p.observacoes || "").trim(),
        pode_buscar: p.pessoas_autorizadas || "",
        nao_pode_buscar: "",
        restricoes: "",
        avatar: avatarPorSexo(null),
        foto_url: "",
        tipo_cobranca: "mensal",
        status_mensalidade: "pendente",
        autoriza_imagem: p.autoriza_imagem,
      })
      .select("id")
      .single();

    if (error || !novo) {
      setBusy(null);
      toast.error("Não consegui aprovar esse pré-cadastro.");
      return;
    }

    // Cadastra o responsável com e-mail e telefone de emergência nos campos próprios.
    const nomeResp = (p.responsavel_nome || "").trim();
    if (nomeResp) {
      const wpp = (p.responsavel_whatsapp || "").replace(/\D/g, "");
      const { data: existente } = await supabase
        .from("responsaveis")
        .select("id, alunos_ids")
        .eq("user_id", userId)
        .ilike("nome", nomeResp)
        .limit(1)
        .maybeSingle();

      if (existente) {
        const ids = Array.isArray(existente.alunos_ids) ? existente.alunos_ids : [];
        await supabase
          .from("responsaveis")
          .update({
            email: p.responsavel_email || null,
            telefone_emergencia: p.telefone_emergencia || null,
            pessoas_autorizadas: p.pessoas_autorizadas || null,
            alunos_ids: ids.includes(novo.id) ? ids : [...ids, novo.id],
          })
          .eq("id", existente.id);
      } else {
        await supabase.from("responsaveis").insert({
          user_id: userId,
          nome: nomeResp,
          telefone: p.responsavel_whatsapp || "",
          whatsapp: wpp,
          pix: "",
          endereco: enderecoCompleto(p),
          observacoes: p.responsavel_cpf ? `CPF: ${p.responsavel_cpf}` : "",
          email: p.responsavel_email || null,
          telefone_emergencia: p.telefone_emergencia || null,
          pessoas_autorizadas: p.pessoas_autorizadas || null,
          alunos_ids: [novo.id],
        });
      }
    }

    await supabase
      .from("pre_cadastros")
      .update({ status: "aprovado", aluno_id: novo.id })
      .eq("id", p.id);

    setBusy(null);
    setLista((l) => l.filter((x) => x.id !== p.id));
    toast.success(`${p.aluno_nome} foi cadastrado! Complete mensalidade e horários. ✅`);
    onAprovado();
  };

  const recusar = async (p: PreCadastro) => {
    setBusy(p.id);
    const { error } = await supabase.from("pre_cadastros").delete().eq("id", p.id);
    setBusy(null);
    if (error) {
      toast.error("Não consegui excluir esse pré-cadastro.");
      return;
    }
    setLista((l) => l.filter((x) => x.id !== p.id));
    toast.success("Pré-cadastro removido.");
  };

  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" onClick={copiarLink} className="font-semibold">
          <Link2 className="mr-2 h-4 w-4" /> Copiar link de cadastro para pais
        </Button>
        <Button
          variant={lista.length > 0 ? "default" : "outline"}
          onClick={() => {
            void carregar();
            setOpen(true);
          }}
          className="font-semibold"
        >
          <Inbox className="mr-2 h-4 w-4" /> Pré-cadastros
          {lista.length > 0 && (
            <Badge className="ml-2 bg-warning text-warning-foreground">{lista.length}</Badge>
          )}
        </Button>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Pré-cadastros pendentes 📥</DialogTitle>
            <DialogDescription>
              Fichas enviadas pelos responsáveis pelo link público. Revise e aprove.
            </DialogDescription>
          </DialogHeader>

          {lista.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              Nenhuma ficha pendente no momento.
            </p>
          ) : (
            <div className="space-y-3">
              {lista.map((p) => (
                <Card key={p.id} className="space-y-1 p-4 text-sm">
                  <div className="font-bold">{p.aluno_nome}</div>
                  <div className="text-muted-foreground">Nascimento: {dataBR(p.data_nascimento)}</div>
                  <div className="text-muted-foreground">Escola: {p.escola} — {p.serie}</div>
                  <div className="text-muted-foreground">Endereço: {enderecoCompleto(p)}</div>
                  <div className="text-muted-foreground">
                    Responsável: {p.responsavel_nome} — {p.responsavel_whatsapp}
                  </div>
                  {p.responsavel_cpf && <div className="text-muted-foreground">CPF: {p.responsavel_cpf}</div>}
                  {p.responsavel_email && <div className="text-muted-foreground">E-mail: {p.responsavel_email}</div>}
                  {p.telefone_emergencia && (
                    <div className="text-muted-foreground">Emergência: {p.telefone_emergencia}</div>
                  )}
                  {p.pessoas_autorizadas && (
                    <div className="text-muted-foreground">Autorizados: {p.pessoas_autorizadas}</div>
                  )}
                  {p.observacoes && (
                    <div className="text-muted-foreground">Observações: {p.observacoes}</div>
                  )}
                  {p.autoriza_imagem !== null && (
                    <div className="text-muted-foreground">
                      Uso de imagem: {p.autoriza_imagem ? "Autorizado ✅" : "Não autorizado ❌"}
                    </div>
                  )}
                  <div className="flex gap-2 pt-2">
                    <Button size="sm" className="flex-1 font-semibold" disabled={busy === p.id} onClick={() => aprovar(p)}>
                      <Check className="mr-1 h-4 w-4" /> Aprovar aluno
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1 font-semibold text-destructive"
                      disabled={busy === p.id}
                      onClick={() => recusar(p)}
                    >
                      <X className="mr-1 h-4 w-4" /> Recusar
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
