import { Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserCog } from "lucide-react";
import type { User } from "@supabase/supabase-js";

type Meta = { cidade?: string; estado?: string; whatsapp?: string };

export function getMissingProfileFields(user: User | null | undefined): Array<"cidade" | "estado" | "whatsapp"> {
  const meta = ((user?.user_metadata as Meta) || {});
  const missing: Array<"cidade" | "estado" | "whatsapp"> = [];
  if (!meta.cidade?.trim()) missing.push("cidade");
  if (!meta.estado?.trim()) missing.push("estado");
  if (!meta.whatsapp?.trim()) missing.push("whatsapp");
  return missing;
}

export function ProfileCompletionPrompt({ user, firstAccess }: { user: User | null | undefined; firstAccess: boolean }) {
  const missing = getMissingProfileFields(user);
  if (missing.length === 0) return null;

  const labels: Record<string, string> = { cidade: "Cidade", estado: "Estado (UF)", whatsapp: "WhatsApp" };
  const faltando = missing.map((m) => labels[m]).join(", ");

  if (firstAccess) {
    return (
      <Card className="relative z-10 rounded-md border border-slate-200 bg-white p-5 text-slate-800 shadow-sm">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary/15 text-2xl">👋</div>
          <div className="flex-1 space-y-2">
            <div className="text-base font-extrabold text-slate-800">Bem-vindo(a)! Antes de começar, complete seu perfil.</div>
            <p className="text-sm text-slate-800">
              Precisamos de <strong>{faltando}</strong>. Essas informações ajudam na organização da plataforma e no suporte.
            </p>
            <div className="pt-1">
              <Link to="/comece-aqui">
                <Button className="bg-primary text-primary-foreground font-bold">
                  <UserCog className="mr-2 h-4 w-4" /> Começar — Meus Dados
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Link to="/comece-aqui">
      <Card className="relative z-10 flex items-center justify-between gap-3 rounded-md border border-slate-200 bg-white p-4 text-slate-800 shadow-sm transition-shadow hover:shadow-md">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-warning/30 text-xl">📝</div>
          <div>
            <div className="font-bold text-slate-800">Complete seu perfil</div>
            <div className="text-xs text-slate-800">Faltam: {faltando}. Leva menos de 1 minuto.</div>
          </div>
        </div>
        <Button size="sm" variant="outline">Atualizar</Button>
      </Card>
    </Link>
  );
}
