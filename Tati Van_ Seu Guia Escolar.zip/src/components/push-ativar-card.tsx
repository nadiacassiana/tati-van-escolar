import { useEffect, useState } from "react";
import { Bell, BellOff, BellRing, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ativarNotificacoes,
  assinaturaAtual,
  desativarNotificacoes,
  permissaoAtual,
  registrarServiceWorker,
  verificarSuporte,
} from "@/lib/push-client";
import {
  agendarTesteEmSegundoPlano,
  enviarNotificacaoTeste,
  getVapidPublicKey,
  removerPushSubscription,
  salvarPushSubscription,
} from "@/lib/notificacoes.functions";

type Estado = "carregando" | "indisponivel" | "desativado" | "negado" | "ativo";

export function PushAtivarCard({ compacto = false }: { compacto?: boolean }) {
  const [estado, setEstado] = useState<Estado>("carregando");
  const [motivo, setMotivo] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      const suporte = verificarSuporte();
      if (!suporte.ok) {
        setMotivo(suporte.motivo);
        setEstado("indisponivel");
        return;
      }
      await registrarServiceWorker();
      const perm = permissaoAtual();
      if (perm === "denied") {
        setEstado("negado");
        return;
      }
      const sub = await assinaturaAtual();
      setEstado(sub && perm === "granted" ? "ativo" : "desativado");
    })();
  }, []);

  async function ativar() {
    setBusy(true);
    try {
      const { publicKey } = await getVapidPublicKey();
      if (!publicKey) {
        toast.error("Notificações indisponíveis no momento.");
        return;
      }
      const res = await ativarNotificacoes(publicKey);
      if (!res.ok) {
        setMotivo(res.motivo);
        setEstado(permissaoAtual() === "denied" ? "negado" : "indisponivel");
        toast.error(res.motivo);
        return;
      }
      await salvarPushSubscription({ data: res.assinatura });
      setEstado("ativo");
      toast.success("Notificações ativadas! 🔔");
    } catch (e) {
      console.error(e);
      toast.error("Não foi possível ativar as notificações agora.");
    } finally {
      setBusy(false);
    }
  }

  async function desativar() {
    setBusy(true);
    try {
      const endpoint = await desativarNotificacoes();
      if (endpoint) await removerPushSubscription({ data: { endpoint } });
      setEstado("desativado");
      toast.success("Notificações desativadas. Você pode ativar novamente quando quiser.");
    } finally {
      setBusy(false);
    }
  }

  async function testar() {
    setBusy(true);
    try {
      const res = await enviarNotificacaoTeste({ data: undefined as never });
      if (res.enviados > 0) toast.success("Notificação de teste enviada para o seu aparelho.");
      else toast.error("Nenhum aparelho recebeu. Ative as notificações novamente.");
    } catch {
      toast.error("Falha ao enviar a notificação de teste.");
    } finally {
      setBusy(false);
    }
  }

  async function testarFechado() {
    setBusy(true);
    try {
      const res = await agendarTesteEmSegundoPlano({ data: { minutos: 2 } });
      toast.success(
        `Teste agendado! Feche a Tati agora — a notificação deve chegar em cerca de ${res.minutos} minutos.`,
      );
    } catch {
      toast.error("Não foi possível agendar o teste agora.");
    } finally {
      setBusy(false);
    }
  }

  if (estado === "carregando") return null;
  if (estado === "ativo" && compacto) return null;
  if (estado === "indisponivel" && compacto) return null;

  return (
    <Card className="relative z-10 rounded-md border border-slate-200 bg-white p-5 text-slate-800 shadow-sm">
      <div className="flex items-start gap-3">
        <div className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          {estado === "ativo" ? <BellRing className="h-5 w-5" /> : <Bell className="h-5 w-5" />}
        </div>
        <div className="flex-1">
          <div className="font-bold text-slate-800">🔔 Ative as notificações da Tati</div>
          <p className="mt-1 text-sm text-slate-800">
            Receba lembretes importantes da sua van, como aniversários dos alunos e outros avisos.
          </p>

          {estado === "indisponivel" && (
            <p className="mt-2 rounded-lg bg-slate-100 p-3 text-xs text-slate-800">{motivo}</p>
          )}
          {estado === "negado" && (
            <p className="mt-2 rounded-lg bg-slate-100 p-3 text-xs text-slate-800">
              A permissão está bloqueada neste navegador. Libere as notificações da Tati nas
              configurações do site/app e volte aqui para ativar. A Tati continua funcionando
              normalmente sem elas.
            </p>
          )}

          <div className="mt-3 flex flex-wrap gap-2">
            {estado === "desativado" && (
              <Button onClick={ativar} disabled={busy}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bell className="h-4 w-4" />}
                Ativar notificações
              </Button>
            )}
            {estado === "negado" && (
              <Button onClick={ativar} disabled={busy} variant="outline">
                Tentar novamente
              </Button>
            )}
            {estado === "ativo" && (
              <>
                <Button onClick={testar} disabled={busy} variant="outline">
                  {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <BellRing className="h-4 w-4" />}
                  Enviar notificação de teste
                </Button>
                <Button onClick={testarFechado} disabled={busy} variant="outline">
                  {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <BellRing className="h-4 w-4" />}
                  Testar com o app fechado (2 min)
                </Button>
                <Button onClick={desativar} disabled={busy} variant="ghost">
                  <BellOff className="h-4 w-4" /> Desativar
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}
