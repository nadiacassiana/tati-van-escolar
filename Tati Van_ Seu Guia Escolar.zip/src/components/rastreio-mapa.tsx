import { useEffect, useRef, useState } from "react";
import L, { type Map as LeafletMap, type Marker, type Polyline } from "leaflet";

export type LatLng = { lat: number; lng: number };

type Props = {
  van: LatLng | null;
  heading: number;
  casa: LatLng | null;
  escola: LatLng | null;
  /** Para onde a van está indo agora (define o traçado da rota). */
  destino: LatLng | null;
};

type OsrmResposta = {
  routes?: Array<{ geometry?: { coordinates?: [number, number][] } }>;
};

function vanIcon(rot: number): L.DivIcon {
  return L.divIcon({
    className: "tati-map-marker",
    html: `<div style="width:56px;height:56px;transform:rotate(${Math.round(rot)}deg);transition:transform .35s ease">
      <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" viewBox="0 0 64 64" aria-hidden="true">
        <circle cx="32" cy="32" r="21" fill="#1d4ed8" opacity="0.14"/>
        <g transform="translate(32 32)">
          <rect x="-11" y="-16" width="22" height="32" rx="7" fill="#facc15" stroke="#1f2937" stroke-width="2.5"/>
          <path d="M-8 -11 h16 v8 h-16 z" fill="#bfdbfe" stroke="#1f2937" stroke-width="1.6"/>
          <rect x="-8" y="1" width="6" height="6" rx="1.6" fill="#bfdbfe" stroke="#1f2937" stroke-width="1.4"/>
          <rect x="2" y="1" width="6" height="6" rx="1.6" fill="#bfdbfe" stroke="#1f2937" stroke-width="1.4"/>
          <rect x="-6" y="11" width="12" height="3" rx="1.5" fill="#1f2937"/>
        </g>
      </svg>
    </div>`,
    iconSize: [56, 56],
    iconAnchor: [28, 28],
  });
}

function pinIcon(tipo: "casa" | "escola"): L.DivIcon {
  const corpo = tipo === "casa"
    ? `<path d="M8 20 L20 9 L32 20 V33 H8 Z" fill="#22c55e" stroke="#14532d" stroke-width="2.2"/><rect x="16" y="24" width="8" height="9" fill="#14532d"/>`
    : `<rect x="7" y="16" width="26" height="17" rx="2" fill="#2563eb" stroke="#1e3a8a" stroke-width="2.2"/><path d="M20 6 L34 15 H6 Z" fill="#1d4ed8" stroke="#1e3a8a" stroke-width="2"/><rect x="17" y="24" width="6" height="9" fill="#dbeafe"/>`;
  return L.divIcon({
    className: "tati-map-marker",
    html: `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" aria-hidden="true">${corpo}</svg>`,
    iconSize: [40, 40],
    iconAnchor: [20, 34],
  });
}

export default function RastreioMapa({ van, heading, casa, escola, destino }: Props) {
  const divRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const vanRef = useRef<Marker | null>(null);
  const casaRef = useRef<Marker | null>(null);
  const escolaRef = useRef<Marker | null>(null);
  const rotaRef = useRef<Polyline | null>(null);
  const animRef = useRef<number | null>(null);
  const requisicaoRef = useRef<AbortController | null>(null);
  const ultimaRota = useRef(0);
  const [erro, setErro] = useState<string | null>(null);
  const [pronto, setPronto] = useState(false);

  useEffect(() => {
    if (!divRef.current || mapRef.current) return;
    try {
      const centro = van || casa || escola || { lat: -23.55, lng: -46.63 };
      const map = L.map(divRef.current, {
        center: [centro.lat, centro.lng],
        zoom: 15,
        zoomControl: true,
        attributionControl: true,
      });
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      }).addTo(map);
      mapRef.current = map;
      setPronto(true);
      requestAnimationFrame(() => map.invalidateSize());
    } catch {
      setErro("Falha ao iniciar o OpenStreetMap.");
    }
    return () => {
      if (animRef.current != null) cancelAnimationFrame(animRef.current);
      requisicaoRef.current?.abort();
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!pronto || !map) return;
    if (casa) {
      if (!casaRef.current) casaRef.current = L.marker([casa.lat, casa.lng], { icon: pinIcon("casa"), title: "Seu endereço", zIndexOffset: 20 }).addTo(map);
      else casaRef.current.setLatLng([casa.lat, casa.lng]).addTo(map);
    } else if (casaRef.current) {
      casaRef.current.removeFrom(map);
    }
    if (escola) {
      if (!escolaRef.current) escolaRef.current = L.marker([escola.lat, escola.lng], { icon: pinIcon("escola"), title: "Escola", zIndexOffset: 20 }).addTo(map);
      else escolaRef.current.setLatLng([escola.lat, escola.lng]).addTo(map);
    } else if (escolaRef.current) {
      escolaRef.current.removeFrom(map);
    }
  }, [pronto, casa, escola]);

  useEffect(() => {
    const map = mapRef.current;
    if (!pronto || !map || !van) return;
    if (!vanRef.current) {
      vanRef.current = L.marker([van.lat, van.lng], { icon: vanIcon(heading), title: "Van", zIndexOffset: 100 }).addTo(map);
      map.panTo([van.lat, van.lng]);
      return;
    }
    vanRef.current.setIcon(vanIcon(heading));
    const atual = vanRef.current.getLatLng();
    const inicio = { lat: atual.lat, lng: atual.lng };
    const t0 = performance.now();
    const duracao = 1200;
    if (animRef.current != null) cancelAnimationFrame(animRef.current);
    const animar = (tempo: number) => {
      const k = Math.min(1, (tempo - t0) / duracao);
      const suave = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      vanRef.current?.setLatLng([
        inicio.lat + (van.lat - inicio.lat) * suave,
        inicio.lng + (van.lng - inicio.lng) * suave,
      ]);
      if (k < 1) animRef.current = requestAnimationFrame(animar);
      else map.panTo([van.lat, van.lng], { animate: true, duration: 0.5 });
    };
    animRef.current = requestAnimationFrame(animar);
  }, [pronto, van, heading]);

  useEffect(() => {
    const map = mapRef.current;
    if (!pronto || !map || !van || !destino) return;
    const agora = Date.now();
    if (agora - ultimaRota.current < 25_000) return;
    ultimaRota.current = agora;
    requisicaoRef.current?.abort();
    const controller = new AbortController();
    requisicaoRef.current = controller;
    const url = `https://router.project-osrm.org/route/v1/driving/${van.lng},${van.lat};${destino.lng},${destino.lat}?overview=full&geometries=geojson`;
    fetch(url, { signal: controller.signal, headers: { Accept: "application/json" } })
      .then((res) => res.ok ? res.json() as Promise<OsrmResposta> : Promise.reject(new Error("rota indisponível")))
      .then((json) => {
        const coords = json.routes?.[0]?.geometry?.coordinates;
        const pontos: L.LatLngExpression[] = coords?.length
          ? coords.map(([lng, lat]) => [lat, lng])
          : [[van.lat, van.lng], [destino.lat, destino.lng]];
        if (!rotaRef.current) rotaRef.current = L.polyline(pontos, { color: "#2563eb", opacity: 0.85, weight: 6 }).addTo(map);
        else rotaRef.current.setLatLngs(pontos);
      })
      .catch((e: unknown) => {
        if (e instanceof DOMException && e.name === "AbortError") return;
        const pontos: L.LatLngExpression[] = [[van.lat, van.lng], [destino.lat, destino.lng]];
        if (!rotaRef.current) rotaRef.current = L.polyline(pontos, { color: "#2563eb", opacity: 0.65, weight: 5, dashArray: "8 8" }).addTo(map);
        else rotaRef.current.setLatLngs(pontos);
      });
    return () => controller.abort();
  }, [pronto, van, destino]);

  if (erro) {
    return <div className="flex h-full items-center justify-center p-6 text-center text-sm text-muted-foreground">Não foi possível carregar o mapa. {erro}</div>;
  }
  return <div ref={divRef} className="h-full w-full" aria-label="Mapa de rastreamento da van" />;
}