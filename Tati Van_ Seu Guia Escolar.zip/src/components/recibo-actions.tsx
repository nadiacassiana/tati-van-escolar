import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Mail, Clock, Share2, Star, Download, Undo2, Copy, Briefcase } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { type Recibo, reciboWhatsAppMessage, reciboEmailSubject, reciboEmailBody, reciboMensagemCompartilhamento } from "@/lib/recibo";
import { reciboToImageBlob, reciboImageFilename, shareImageFile } from "@/lib/recibo-image";
import { buildWhatsAppUrl, toWhatsAppE164, type MotoristaPerfil } from "@/lib/whatsapp";
import { reciboToPdfBlob, reciboToPdfBlobFromImage, reciboFilename } from "@/lib/recibo-pdf";
import { downloadBlob, sharePdfFile } from "@/lib/contrato-pdf";
import { estornarRecebimento } from "@/lib/estorno";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  recibo: Recibo | null;
  motorista: MotoristaPerfil;
  showSuccessTitle?: boolean;
  onChanged?: () => void;
};

export function ReciboActions({ open, onOpenChange, recibo, motorista, showSuccessTitle, onChanged }: Props) {
  const [busy, setBusy] = useState<string | null>(null);
  const [sharePreview, setSharePreview] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [shareBlob, setShareBlob] = useState<Blob | null>(null);
  const [shareText, setShareText] = useState("");

  if (!recibo) return null;

  const buildPdf = () => {
    try {
      return reciboToPdfBlob(recibo, motorista);
    } catch (e) {
      console.error("Erro ao gerar PDF do recibo:", e);
      toast.error("Não foi possível gerar o PDF. Tente novamente.");
      return null;
    }
  };

  const logEnvio = async (canal: string) => {
    const envios = [...(recibo.envios || []), { canal, data: new Date().toISOString() }];
    await supabase.from("recibos").update({ envios }).eq("id", recibo.id);
    onChanged?.();
  };

  const handleDownload = async () => {
    setBusy("download");
    try {
      const blob = await reciboToPdfBlobFromImage(recibo, motorista);
      if (blob) {
        downloadBlob(blob, reciboFilename(recibo));
        toast.success("✅ PDF gerado com sucesso.");
        setBusy(null);
        return;
      }
    } catch (e) {
      console.error("Erro ao gerar PDF do recibo:", e);
    }
    const fallback = buildPdf();
    if (fallback) {
      downloadBlob(fallback, reciboFilename(recibo));
      toast.success("✅ PDF gerado com sucesso.");
    }
    setBusy(null);
  };


  // Mesma estratégia do botão "Cobrar" do Financeiro: link direto wa.me,
  // aberto no próprio gesto do usuário (sem await antes) → abre o app do WhatsApp.
  const waText = reciboWhatsAppMessage(recibo, motorista);
  const waPhone = recibo.responsavel_whatsapp || recibo.responsavel_telefone || "";

  // Envia a IMAGEM do recibo + mensagem. Como wa.me/whatsapp:// não aceitam
  // anexos, usamos o compartilhamento nativo com arquivo (que lista o WhatsApp
  // e o WhatsApp Business) e, se indisponível, baixamos a imagem e abrimos o chat.
  const enviarComImagem = async (canal: "whatsapp" | "whatsapp-business") => {
    if (!shareBlob) return;
    setBusy(canal);
    const result = await shareImageFile(shareBlob, reciboImageFilename(recibo), {
      title: `Recibo ${recibo.numero}`,
      text: shareText,
    });
    setBusy(null);
    if (result === "cancelled") return;
    if (result === "downloaded") {
      toast.success("🖼️ Imagem baixada. Anexe na conversa do WhatsApp que vamos abrir.");
      const url =
        canal === "whatsapp"
          ? buildWhatsAppUrl(waPhone, shareText)
          : `whatsapp://send?phone=${toWhatsAppE164(waPhone)}&text=${encodeURIComponent(shareText)}`;
      window.open(url, "_blank");
    } else {
      toast.success("✅ Recibo enviado com a imagem!");
    }
    await logEnvio(canal);
  };



  const handleEmail = async () => {
    if (!recibo.responsavel_email) return toast.error("Responsável sem e-mail cadastrado.");
    setBusy("email");
    const blob = buildPdf();
    if (blob) {
      downloadBlob(blob, reciboFilename(recibo));
      toast.success("📎 PDF baixado. Anexe ao e-mail.");
    }
    const subject = encodeURIComponent(reciboEmailSubject(recibo));
    const body = encodeURIComponent(reciboEmailBody(recibo, motorista));
    window.open(`mailto:${recibo.responsavel_email}?subject=${subject}&body=${body}`, "_blank");
    await logEnvio("email");
    setBusy(null);
  };

  // Abre a pré-visualização (imagem + mensagem) antes de compartilhar.
  const handleAbrirPreviaCompartilhar = async () => {
    setBusy("share");
    const text = reciboMensagemCompartilhamento(recibo, motorista);
    setShareText(text);
    try {
      const img = await reciboToImageBlob(recibo, motorista);
      if (img) {
        if (shareUrl) URL.revokeObjectURL(shareUrl);
        setShareBlob(img);
        setShareUrl(URL.createObjectURL(img));
        setSharePreview(true);
        setBusy(null);
        return;
      }
    } catch (e) {
      console.error("Erro ao gerar imagem do recibo:", e);
    }

    // Fallback: se a imagem falhar, mantém o compartilhamento em PDF.
    const blob = buildPdf();
    if (blob) {
      const result = await sharePdfFile(blob, reciboFilename(recibo), { title: `Recibo ${recibo.numero}`, text });
      if (result === "shared") {
        await logEnvio("compartilhar");
        toast.success("✅ Recibo compartilhado!");
      } else if (result === "downloaded") {
        toast.success("📎 PDF baixado.");
      }
    }
    setBusy(null);
  };

  const fecharPrevia = () => {
    setSharePreview(false);
    if (shareUrl) URL.revokeObjectURL(shareUrl);
    setShareUrl(null);
    setShareBlob(null);
  };

  const handleConfirmarCompartilhar = async () => {
    if (!shareBlob) return;
    setBusy("share-confirm");
    const result = await shareImageFile(shareBlob, reciboImageFilename(recibo), {
      title: `Recibo ${recibo.numero}`,
      text: shareText,
    });
    setBusy(null);
    if (result === "shared") {
      await logEnvio("compartilhar");
      toast.success("✅ Recibo compartilhado!");
      fecharPrevia();
    } else if (result === "downloaded") {
      toast.success("🖼️ Imagem do recibo baixada.");
      fecharPrevia();
    }
  };

  const handleBaixarImagem = () => {
    if (!shareBlob) return;
    downloadBlob(shareBlob, reciboImageFilename(recibo));
    toast.success("🖼️ Imagem do recibo baixada.");
  };

  const handleCopiarMensagem = async () => {
    try {
      await navigator.clipboard.writeText(shareText);
      toast.success("✅ Mensagem copiada.");
    } catch {
      toast.error("Não foi possível copiar a mensagem.");
    }
  };

  const handleEstorno = async () => {
    if (!confirm("Deseja realmente desfazer este recebimento? A cobrança voltará para em aberto.")) return;
    setBusy("estorno");
    const res = await estornarRecebimento(recibo);
    setBusy(null);
    if (!res.ok) return toast.error(res.erro || "Não foi possível desfazer.");
    toast.success("Recebimento desfeito. A cobrança voltou para em aberto. ↩️");
    onChanged?.();
    onOpenChange(false);
  };

  const toggleFavorito = async () => {
    await supabase.from("recibos").update({ favorito: !recibo.favorito }).eq("id", recibo.id);
    toast.success(!recibo.favorito ? "⭐ Adicionado aos favoritos" : "Removido dos favoritos");
    onChanged?.();
    onOpenChange(false);
  };

  return (
    <>
      <Dialog open={open && !sharePreview} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{showSuccessTitle ? "✅ Pagamento registrado com sucesso!" : `Recibo ${recibo.numero}`}</DialogTitle>
            <DialogDescription>O que deseja fazer agora?</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={handleDownload} disabled={busy === "download"} className="h-auto flex-col gap-1 py-3">
              <Download className="h-5 w-5" />
              <span className="text-xs font-bold">{busy === "download" ? "Gerando..." : "⬇️ Baixar PDF"}</span>
            </Button>

            <Button variant="outline" onClick={handleEmail} disabled={!recibo.responsavel_email || busy === "email"} className="h-auto flex-col gap-1 py-3">
              <Mail className="h-5 w-5" />
              <span className="text-xs font-bold">📧 E-mail</span>
            </Button>
            <Button variant="outline" onClick={handleAbrirPreviaCompartilhar} disabled={busy === "share"} className="h-auto flex-col gap-1 py-3">
              <Share2 className="h-5 w-5" />
              <span className="text-xs font-bold">{busy === "share" ? "Gerando..." : "📤 Compartilhar recibo"}</span>
            </Button>
            <Button variant="outline" onClick={toggleFavorito} className="col-span-2 h-auto flex-col gap-1 py-3">
              <Star className={`h-5 w-5 ${recibo.favorito ? "fill-warning text-warning" : ""}`} />
              <span className="text-xs font-bold">⭐ {recibo.favorito ? "Remover favorito" : "Favoritar"}</span>
            </Button>
          </div>
          {recibo.estornado_em ? (
            <div className="rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs font-semibold text-destructive">
              ↩️ Recebimento desfeito — este recibo não vale mais como pagamento.
            </div>
          ) : (
            <Button variant="outline" onClick={handleEstorno} disabled={busy === "estorno"} className="w-full border-destructive/40 text-destructive hover:bg-destructive/10">
              <Undo2 className="mr-2 h-4 w-4" />
              {busy === "estorno" ? "Desfazendo..." : "↩️ Desfazer recebimento"}
            </Button>
          )}
          <p className="text-[11px] leading-snug text-muted-foreground">
            💡 Toque em <strong>Compartilhar recibo</strong> para enviar a imagem do recibo junto com a mensagem pelo WhatsApp. Se preferir o documento em PDF, use <strong>Baixar PDF</strong>.
          </p>

          <DialogFooter>
            <Button variant="ghost" onClick={() => onOpenChange(false)} className="w-full">
              <Clock className="mr-2 h-4 w-4" /> Fazer depois
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>




      <Dialog open={sharePreview} onOpenChange={(v) => { if (!v) fecharPrevia(); }}>
        <DialogContent className="max-h-[92vh] overflow-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>👀 Confira antes de enviar</DialogTitle>
            <DialogDescription>Veja como o recibo e a mensagem chegarão ao responsável.</DialogDescription>
          </DialogHeader>

          {shareUrl && (
            <div className="overflow-hidden rounded-xl border bg-muted/30 p-2">
              <img src={shareUrl} alt={`Pré-visualização do recibo ${recibo.numero}`} className="w-full rounded-lg" />
            </div>
          )}

          <div className="space-y-1">
            <label htmlFor="msg-recibo" className="text-xs font-bold text-muted-foreground">Mensagem que acompanha a imagem</label>
            <Textarea id="msg-recibo" value={shareText} onChange={(e) => setShareText(e.target.value)} rows={7} className="text-sm" />
            <p className="text-[11px] text-muted-foreground">Você pode editar a mensagem antes de enviar.</p>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Button
              onClick={() => void enviarComImagem("whatsapp")}
              disabled={busy === "whatsapp"}
              className="h-auto w-full flex-col gap-1 bg-success py-3 text-success-foreground hover:bg-success/90"
            >
              <MessageCircle className="h-5 w-5" />
              <span className="text-xs font-bold">{busy === "whatsapp" ? "Abrindo..." : "📱 WhatsApp"}</span>
            </Button>
            <Button
              onClick={() => void enviarComImagem("whatsapp-business")}
              disabled={busy === "whatsapp-business"}
              className="h-auto w-full flex-col gap-1 bg-primary py-3 text-primary-foreground hover:bg-primary/90"
            >
              <Briefcase className="h-5 w-5" />
              <span className="text-xs font-bold">{busy === "whatsapp-business" ? "Abrindo..." : "💼 WhatsApp Business"}</span>
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={handleBaixarImagem}>
              <Download className="mr-1 h-4 w-4" /> Baixar imagem
            </Button>
            <Button variant="outline" onClick={handleCopiarMensagem}>
              <Copy className="mr-1 h-4 w-4" /> Copiar mensagem
            </Button>
          </div>

          <Button onClick={handleConfirmarCompartilhar} disabled={busy === "share-confirm"} className="w-full bg-success text-success-foreground hover:bg-success/90">
            <Share2 className="mr-2 h-4 w-4" />
            {busy === "share-confirm" ? "Abrindo..." : "📤 Compartilhar agora"}
          </Button>

          <DialogFooter>
            <Button variant="ghost" onClick={fecharPrevia} className="w-full">Cancelar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
