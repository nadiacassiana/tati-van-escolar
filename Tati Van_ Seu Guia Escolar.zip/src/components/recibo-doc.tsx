import { formatBRL } from "@/lib/format";
import { METODO_LABEL, formatDateBR, formatMesReferencia, reciboTextoOficial, type Recibo } from "@/lib/recibo";
import type { MotoristaPerfil } from "@/lib/whatsapp";

export function ReciboDoc({ recibo, motorista }: { recibo: Recibo; motorista: MotoristaPerfil }) {
  const nomeOficial = motorista.nome_completo || "Motorista";
  const empresa = motorista.empresa;
  const apelido = motorista.apelido;

  return (
    <div
      id="recibo-print"
      className="mx-auto bg-white text-slate-900"
      style={{
        width: "100%",
        maxWidth: "780px",
        padding: "40px 48px",
        fontFamily: "system-ui, -apple-system, sans-serif",
        boxShadow: "0 2px 16px rgba(0,0,0,0.08)",
        borderRadius: "12px",
      }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-4 border-b-4 pb-5" style={{ borderColor: "#1e40af" }}>
        <div className="flex items-center gap-3">
          {motorista.logo ? (
            <img
              src={motorista.logo}
              alt={empresa || "Logotipo da van"}
              style={{ maxHeight: "64px", maxWidth: "130px", objectFit: "contain" }}
            />
          ) : (
            <div
              className="flex h-14 w-14 items-center justify-center rounded-2xl text-3xl"
              style={{ background: "#fde68a" }}
            >
              🚐
            </div>
          )}
          <div>
            <div className="text-xl font-extrabold" style={{ color: "#1e3a8a" }}>
              {empresa || "Transporte Escolar"}
            </div>
            <div className="text-xs text-slate-600">
              {apelido ? `${apelido} • ` : ""}{nomeOficial}
            </div>
            {motorista.telefone && <div className="text-xs text-slate-600">📞 {motorista.telefone}</div>}
            {motorista.email && <div className="text-xs text-slate-600">✉️ {motorista.email}</div>}
          </div>
        </div>
        <div className="text-right">
          <div className="rounded-lg px-3 py-1 text-xs font-bold uppercase tracking-wider" style={{ background: "#1e40af", color: "#fff" }}>
            Recibo
          </div>
          <div className="mt-2 text-lg font-extrabold" style={{ color: "#1e3a8a" }}>
            {recibo.numero}
          </div>
          <div className="text-xs text-slate-600">Emitido em {formatDateBR(recibo.created_at.slice(0, 10))}</div>
        </div>
      </div>

      {/* Valor destacado */}
      <div className="mt-6 rounded-2xl p-5 text-center" style={{ background: "#eff6ff" }}>
        <div className="text-xs uppercase tracking-wider text-slate-600">Valor recebido</div>
        <div className="text-4xl font-extrabold" style={{ color: "#1e3a8a" }}>
          R$ {formatBRL(Number(recibo.valor))}
        </div>
        <div className="mt-1 text-sm font-semibold text-slate-700">
          Referente a {formatMesReferencia(recibo.mes_referencia)}
        </div>
      </div>

      {/* Texto oficial */}
      <p className="mt-6 text-justify text-sm leading-relaxed text-slate-800">
        {reciboTextoOficial(recibo)}
      </p>

      {/* Dados */}
      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="rounded-xl border p-4">
          <div className="mb-2 text-xs font-bold uppercase tracking-wider" style={{ color: "#1e40af" }}>👨‍👩‍👧 Responsável</div>
          <div className="text-sm font-semibold">{recibo.responsavel_nome || "—"}</div>
          {recibo.responsavel_cpf && <div className="text-xs text-slate-600">CPF: {recibo.responsavel_cpf}</div>}
          {recibo.responsavel_telefone && <div className="text-xs text-slate-600">📞 {recibo.responsavel_telefone}</div>}
          {recibo.responsavel_email && <div className="text-xs text-slate-600">✉️ {recibo.responsavel_email}</div>}
        </div>
        <div className="rounded-xl border p-4">
          <div className="mb-2 text-xs font-bold uppercase tracking-wider" style={{ color: "#1e40af" }}>🎒 Aluno(a)</div>
          <div className="text-sm font-semibold">{recibo.aluno_nome}</div>
          {recibo.escola && <div className="text-xs text-slate-600">Escola: {recibo.escola}</div>}
          {recibo.turma && <div className="text-xs text-slate-600">Turma: {recibo.turma}</div>}
          {recibo.periodo && <div className="text-xs text-slate-600">Período: {recibo.periodo}</div>}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Info label="Vencimento" value={formatDateBR(recibo.data_vencimento)} />
        <Info label="Pagamento" value={formatDateBR(recibo.data_pagamento)} />
        <Info label="Forma" value={METODO_LABEL[recibo.metodo || ""] || recibo.metodo || "—"} />
        <Info label="Mês ref." value={formatMesReferencia(recibo.mes_referencia)} />
      </div>

      {recibo.observacoes && (
        <div className="mt-4 rounded-xl border-l-4 p-3 text-sm text-slate-700" style={{ borderColor: "#fbbf24", background: "#fffbeb" }}>
          <span className="font-bold">Observações: </span>
          {recibo.observacoes}
        </div>
      )}

      {/* Assinatura */}
      <div className="mt-10 text-center">
        <div className="mx-auto w-2/3 border-t pt-2 text-sm font-semibold">{nomeOficial}</div>
        <div className="text-xs text-slate-600">Recebido por</div>
        {empresa && <div className="mt-1 text-xs text-slate-500">{empresa}</div>}
      </div>

      <div className="mt-8 border-t pt-3 text-center text-[10px] uppercase tracking-wider text-slate-400">
        {empresa || nomeOficial} • {recibo.numero}
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border p-3">
      <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
      <div className="text-sm font-semibold text-slate-800">{value}</div>
    </div>
  );
}
