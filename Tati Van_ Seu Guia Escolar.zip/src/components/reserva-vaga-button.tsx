import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { downloadBlob, openBlobInNewTab, printBlob } from "@/lib/contrato-pdf";
import { reservaFilename, reservaToPdfBlob, type ReservaVaga } from "@/lib/reserva-pdf";
import { getMarca } from "@/lib/marca";
import { useVanLogo } from "@/lib/logo-store";
import { getMotoristaFromUser } from "@/lib/whatsapp";

type UserLike = { email?: string; user_metadata?: Record<string, unknown> } | null;

type AlunoLike = {
  nome: string;
  escola?: string;
  turma?: string;
  responsavel?: string;
  telefone?: string;
  endereco?: string;
  horarioIda?: string;
  horarioVolta?: string;
  mensalidade?: number;
  vencimento?: number;
};

export function ReservaVagaButton({ user, aluno }: { user: UserLike; aluno: AlunoLike }) {
  const logo = useVanLogo();
  const motorista = getMotoristaFromUser(user);
  const marca = getMarca({ ...motorista, logo: logo || motorista.logo });

  const [open, setOpen] = useState(false);
  const [ano, setAno] = useState(String(new Date().getFullYear()));
  const [turno, setTurno] = useState("");
  const [obs, setObs] = useState("");

  const build = (): { blob: Blob; nome: string } => {
    const reserva: ReservaVaga = {
      alunoNome: aluno.nome,
      escola: aluno.escola,
      turma: aluno.turma,
      responsavel: aluno.responsavel,
      telefone: aluno.telefone,
      endereco: aluno.endereco,
      turno,
      horarioIda: aluno.horarioIda,
      horarioVolta: aluno.horarioVolta,
      mensalidade: aluno.mensalidade,
      vencimento: aluno.vencimento,
      anoLetivo: ano.trim() || String(new Date().getFullYear()),
      observacoes: obs.trim(),
    };
    return {
      blob: reservaToPdfBlob(reserva, { ...motorista, logo: logo || motorista.logo }),
      nome: reservaFilename(reserva),
    };
  };

  const run = (action: "ver" | "baixar" | "imprimir") => {
    try {
      const { blob, nome } = build();
      if (action === "ver") openBlobInNewTab(blob);
      else if (action === "baixar") downloadBlob(blob, nome);
      else printBlob(blob);
    } catch (e) {
      console.error("[reserva-vaga] falha ao gerar PDF", e);
      toast.error("Não foi possível gerar a reserva de vaga.");
    }
  };

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="mt-2 w-full font-semibold"
        onClick={() => setOpen(true)}
      >
        🎟️ Reserva de vaga
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-md">
          <DialogHeader>
            <DialogTitle>🎟️ Reserva de vaga</DialogTitle>
            <DialogDescription>
              O documento sai com a identidade da sua van no cabeçalho e no rodapé.
            </DialogDescription>
          </DialogHeader>

          {/* Prévia do cabeçalho — mesma identidade do PDF */}
          <div className="rounded-xl border bg-card p-3">
            <div className="flex items-center gap-3 border-b-4 border-primary pb-2">
              {marca.logo ? (
                <img
                  src={marca.logo}
                  alt={`Logotipo de ${marca.nome}`}
                  className="h-10 w-auto max-w-[110px] object-contain"
                />
              ) : (
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-xl">🚐</div>
              )}
              <div className="min-w-0">
                <div className="truncate text-sm font-extrabold text-primary">{marca.nome}</div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Reserva de vaga
                </div>
              </div>
            </div>
            <div className="pt-2 text-xs text-muted-foreground">
              Vaga de <strong className="text-foreground">{aluno.nome}</strong>
              {aluno.escola ? ` • ${aluno.escola}` : ""}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="reserva-ano">Ano letivo</Label>
              <Input
                id="reserva-ano"
                inputMode="numeric"
                value={ano}
                onChange={(e) => setAno(e.target.value.replace(/\D/g, "").slice(0, 4))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="reserva-turno">Turno (opcional)</Label>
              <Input
                id="reserva-turno"
                value={turno}
                onChange={(e) => setTurno(e.target.value)}
                placeholder="Manhã, Tarde..."
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="reserva-obs">Observações (opcional)</Label>
            <Textarea
              id="reserva-obs"
              rows={2}
              value={obs}
              onChange={(e) => setObs(e.target.value)}
              placeholder="Ex.: vaga garantida mediante pagamento da primeira mensalidade."
            />
          </div>

          <div className="grid gap-2 sm:grid-cols-3">
            <Button variant="outline" onClick={() => run("ver")}>👁️ Visualizar</Button>
            <Button variant="outline" onClick={() => run("imprimir")}>🖨️ Imprimir</Button>
            <Button className="font-bold" onClick={() => run("baixar")}>⬇️ Baixar PDF</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
