import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Heart, Loader2 } from "lucide-react";
import { toast } from "sonner";

export const RETENTION_MOTIVOS: { value: string; label: string }[] = [
  { value: "facilidade_uso", label: "Facilidade de uso" },
  { value: "organizacao_alunos", label: "Organização dos alunos" },
  { value: "controle_financeiro", label: "Controle financeiro" },
  { value: "contratos", label: "Contratos" },
  { value: "recibos", label: "Recibos" },
  { value: "checklist_diario", label: "Checklist diário" },
  { value: "rastreamento_rota", label: "Rastreamento da rota" },
  { value: "compartilhamento_responsaveis", label: "Compartilhamento com os responsáveis" },
  { value: "controle_documentos", label: "Controle de documentos" },
  { value: "economia_tempo", label: "Economia de tempo" },
  { value: "atendimento_suporte", label: "Atendimento e suporte" },
  { value: "outro", label: "Outro motivo" },
];

const MIN_DIAS_USO = 30;

type Props = { user: User | null | undefined };

export function RetentionSurveyPrompt({ user }: Props) {
  const [visible, setVisible] = useState(false);
  const [motivos, setMotivos] = useState<Set<string>>(new Set());
  const [outroTexto, setOutroTexto] = useState("");
  const [comentario, setComentario] = useState("");
  const [enviando, setEnviando] = useState(false);

  const dismissKey = `tati:retention-survey-dismissed:${user?.id ?? "anon"}`;

  useEffect(() => {
    if (!user?.id || !user?.created_at) return;
    const diasUso = Math.floor((Date.now() - new Date(user.created_at).getTime()) / 86_400_000);
    if (diasUso < MIN_DIAS_USO) return;
    if (typeof window !== "undefined" && window.localStorage.getItem(dismissKey)) return;

    let cancelled = false;
    supabase
      .from("retention_surveys" as never)
      .select("id")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (!cancelled && !data) setVisible(true);
      });
    return () => { cancelled = true; };
  }, [user?.id, user?.created_at, dismissKey]);

  const toggleMotivo = (v: string) => {
    setMotivos((prev) => {
      const next = new Set(prev);
      if (next.has(v)) next.delete(v);
      else next.add(v);
      return next;
    });
  };

  const dispensar = () => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(dismissKey, new Date().toISOString());
    }
    setVisible(false);
  };

  const enviar = async () => {
    if (!user?.id) return;
    if (motivos.size === 0) {
      toast.error("Selecione ao menos um motivo — ou clique em 'Agora não'.");
      return;
    }
    setEnviando(true);
    const lista = Array.from(motivos);
    const comentarioFinal = [
      motivos.has("outro") && outroTexto.trim() ? `Outro: ${outroTexto.trim()}` : "",
      comentario.trim(),
    ].filter(Boolean).join("\n\n") || null;

    const { error } = await supabase.from("retention_surveys" as never).insert({
      user_id: user.id,
      motivos: lista,
      comentario: comentarioFinal,
    } as never);
    setEnviando(false);
    if (error) {
      toast.error("Não foi possível enviar. Tente de novo.", { description: error.message });
      return;
    }
    toast.success("Obrigada pelo carinho! 💙 Sua resposta foi enviada.");
    if (typeof window !== "undefined") {
      window.localStorage.setItem(dismissKey, new Date().toISOString());
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <Card className="relative z-10 rounded-md border border-slate-200 bg-white p-5 text-slate-800 shadow-sm">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary">
          <Heart className="h-5 w-5" />
        </div>
        <div className="flex-1 space-y-3">
          <div>
            <div className="font-bold text-slate-800">Uma perguntinha rápida 💙</div>
            <p className="text-sm text-slate-800">
              O que fez você continuar utilizando a Tati Van Escolar? Marque o que mais te ajudou —
              sua resposta é opcional e ajuda a Tati a evoluir.
            </p>
          </div>
          <div className="grid gap-1.5 sm:grid-cols-2">
            {RETENTION_MOTIVOS.map((m) => (
              <label
                key={m.value}
                htmlFor={`retm-${m.value}`}
                className="flex cursor-pointer items-start gap-2 rounded-md border border-slate-200 bg-white px-2 py-1.5 text-sm text-slate-800 hover:bg-slate-50"
              >
                <Checkbox
                  id={`retm-${m.value}`}
                  checked={motivos.has(m.value)}
                  onCheckedChange={() => toggleMotivo(m.value)}
                  className="mt-0.5"
                />
                <span>{m.label}</span>
              </label>
            ))}
          </div>
          {motivos.has("outro") && (
            <div>
              <Textarea
                value={outroTexto}
                onChange={(e) => setOutroTexto(e.target.value.slice(0, 500))}
                placeholder="Conte com suas palavras o que mais te ajudou."
                rows={2}
              />
            </div>
          )}
          <div>
            <label className="mb-1 block text-xs text-slate-800">
              Gostaria de deixar algum comentário ou sugestão? (opcional)
            </label>
            <Textarea
              value={comentario}
              onChange={(e) => setComentario(e.target.value.slice(0, 1000))}
              placeholder="Estamos ouvindo com carinho..."
              rows={3}
            />
          </div>
          <div className="flex flex-wrap justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={dispensar} disabled={enviando}>
              Agora não
            </Button>
            <Button size="sm" onClick={enviar} disabled={enviando}>
              {enviando ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Enviando...</> : "Enviar resposta"}
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
