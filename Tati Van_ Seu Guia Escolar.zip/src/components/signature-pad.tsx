import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { PAPEL_LABEL, type PapelAssinatura } from "@/lib/assinatura";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  papel: PapelAssinatura;
  /** Nome sugerido de quem vai assinar (editável). */
  nomePadrao?: string;
  documentoLabel?: string;
  saving?: boolean;
  onAceitar: (dados: { imagem: string; nome: string }) => void | Promise<void>;
};

/**
 * Área única de assinatura visual (dedo, caneta ou mouse) usada por Contratos
 * e por Reserva/Reserva de Vaga. Fluxo: Desenhe → Confira → Refazer ou Aceitar.
 */
export function SignaturePadDialog({
  open,
  onOpenChange,
  papel,
  nomePadrao = "",
  documentoLabel,
  saving = false,
  onAceitar,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const desenhando = useRef(false);
  const temTraco = useRef(false);

  const [preview, setPreview] = useState<string | null>(null);
  const [vazio, setVazio] = useState(true);
  const [nome, setNome] = useState(nomePadrao);

  useEffect(() => {
    if (open) {
      setNome(nomePadrao);
      setPreview(null);
      setVazio(true);
      temTraco.current = false;
    }
  }, [open, nomePadrao]);

  const prepararCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const w = wrap.clientWidth;
    const h = 240;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = "#1e3a8a";
    ctx.lineWidth = 2.6;
    ctx.clearRect(0, 0, w, h);
    temTraco.current = false;
    setVazio(true);
  }, []);

  useEffect(() => {
    if (!open || preview) return;
    const id = window.setTimeout(prepararCanvas, 40);
    window.addEventListener("resize", prepararCanvas);
    return () => {
      window.clearTimeout(id);
      window.removeEventListener("resize", prepararCanvas);
    };
  }, [open, preview, prepararCanvas]);

  const pos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const onDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    desenhando.current = true;
    const { x, y } = pos(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + 0.1, y + 0.1);
    ctx.stroke();
    temTraco.current = true;
    setVazio(false);
  };

  const onMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!desenhando.current) return;
    e.preventDefault();
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const { x, y } = pos(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const onUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    desenhando.current = false;
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };

  /** Recorta o espaço vazio ao redor do traço e devolve um PNG transparente. */
  const exportarPng = (): string | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    const { width, height } = canvas;
    const { data } = ctx.getImageData(0, 0, width, height);
    let minX = width;
    let minY = height;
    let maxX = -1;
    let maxY = -1;
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        if (data[(y * width + x) * 4 + 3] > 8) {
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }
    if (maxX < minX || maxY < minY) return null;
    const pad = Math.round(Math.max(width, height) * 0.02);
    const sx = Math.max(0, minX - pad);
    const sy = Math.max(0, minY - pad);
    const sw = Math.min(width - sx, maxX - minX + 1 + pad * 2);
    const sh = Math.min(height - sy, maxY - minY + 1 + pad * 2);
    const out = document.createElement("canvas");
    out.width = sw;
    out.height = sh;
    const octx = out.getContext("2d");
    if (!octx) return null;
    octx.drawImage(canvas, sx, sy, sw, sh, 0, 0, sw, sh);
    return out.toDataURL("image/png");
  };

  const conferir = () => {
    if (!temTraco.current) return;
    const png = exportarPng();
    if (!png) return;
    setPreview(png);
  };

  const refazer = () => {
    setPreview(null);
    setVazio(true);
    temTraco.current = false;
  };

  const aceitar = async () => {
    if (!preview) return;
    if (nome.trim().length < 3) return;
    await onAceitar({ imagem: preview, nome: nome.trim() });
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !saving && onOpenChange(v)}>
      <DialogContent className="max-h-[95vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>✍️ Assinar documento</DialogTitle>
          <DialogDescription>
            {documentoLabel ? `${documentoLabel} — ` : ""}
            {PAPEL_LABEL[papel]}. Desenhe sua assinatura com o dedo, confira e aceite.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-1.5">
          <Label htmlFor="assinatura-nome">Nome de quem está assinando</Label>
          <Input
            id="assinatura-nome"
            value={nome}
            maxLength={120}
            onChange={(e) => setNome(e.target.value)}
            placeholder="Nome completo"
          />
        </div>

        {!preview ? (
          <>
            <div ref={wrapRef} className="rounded-2xl border-2 border-dashed border-primary/40 bg-card p-1">
              <canvas
                ref={canvasRef}
                onPointerDown={onDown}
                onPointerMove={onMove}
                onPointerUp={onUp}
                onPointerLeave={onUp}
                onPointerCancel={onUp}
                className="block w-full rounded-xl bg-background"
                style={{ touchAction: "none", height: 240 }}
              />
              <div className="px-3 pb-2 text-center text-xs text-muted-foreground">
                {vazio ? "Desenhe aqui com o dedo ou a caneta" : "Pronto? Toque em Conferir assinatura"}
              </div>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              <Button variant="outline" onClick={prepararCanvas} disabled={vazio}>
                🧽 Apagar
              </Button>
              <Button className="font-bold" onClick={conferir} disabled={vazio}>
                👁️ Conferir assinatura
              </Button>
            </div>
          </>
        ) : (
          <>
            <div className="rounded-2xl border bg-card p-4 text-center">
              <img
                src={preview}
                alt={`Assinatura de ${nome || "quem assina"}`}
                className="mx-auto max-h-32 w-auto object-contain"
              />
              <div className="mt-2 border-t pt-2 text-sm font-semibold">{nome || "—"}</div>
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">
                {PAPEL_LABEL[papel]}
              </div>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              <Button variant="outline" onClick={refazer} disabled={saving}>
                🔄 Refazer assinatura
              </Button>
              <Button
                className="font-bold"
                onClick={aceitar}
                disabled={saving || nome.trim().length < 3}
              >
                {saving ? "Salvando..." : "✅ Aceitar assinatura"}
              </Button>
            </div>
            {nome.trim().length < 3 && (
              <p className="text-center text-xs text-destructive">Informe o nome de quem está assinando.</p>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
