import { useEffect, useState } from "react";
import { Bus } from "lucide-react";

function getGreeting() {
  const h = new Date().getHours();
  if (h >= 5 && h < 12) return { icon: "🌅", text: "Bom dia! Preparando sua rota..." };
  if (h >= 12 && h < 18) return { icon: "☀️", text: "Boa tarde! Preparando sua rota..." };
  return { icon: "🌙", text: "Boa noite! Preparando sua rota..." };
}

export function SplashScreen() {
  const [visible, setVisible] = useState(true);
  const [fading, setFading] = useState(false);
  const greeting = getGreeting();

  useEffect(() => {
    const t1 = setTimeout(() => setFading(true), 1800);
    const t2 = setTimeout(() => setVisible(false), 2300);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  if (!visible) return null;

  return (
    <div
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-between py-16 px-6 transition-opacity duration-500 ${
        fading ? "opacity-0" : "opacity-100"
      }`}
      style={{
        background:
          "linear-gradient(160deg, oklch(0.55 0.18 250) 0%, oklch(0.45 0.16 255) 60%, oklch(0.38 0.14 260) 100%)",
      }}
      aria-hidden={fading}
    >
      <div className="flex-1" />

      <div className="flex flex-col items-center animate-fade-in">
        <div className="relative mb-6">
          <div className="absolute inset-0 rounded-full bg-accent/30 blur-2xl animate-pulse" />
          <div className="relative flex h-28 w-28 items-center justify-center rounded-3xl bg-white shadow-2xl">
            <Bus className="h-14 w-14" style={{ color: "oklch(0.55 0.18 250)" }} strokeWidth={2.2} />
          </div>
        </div>

        <h1 className="text-3xl font-bold text-white tracking-tight">Tati Van Escolar</h1>
        <p className="mt-2 text-sm font-medium text-white/80">Assistente do Motorista</p>

        <div className="mt-10 flex items-center gap-1.5" aria-label="Carregando">
          <span className="h-2.5 w-2.5 rounded-full bg-accent animate-bounce" style={{ animationDelay: "0ms" }} />
          <span className="h-2.5 w-2.5 rounded-full bg-accent animate-bounce" style={{ animationDelay: "150ms" }} />
          <span className="h-2.5 w-2.5 rounded-full bg-accent animate-bounce" style={{ animationDelay: "300ms" }} />
        </div>
      </div>

      <div className="flex-1" />

      <p className="text-center text-sm text-white/90 font-medium animate-fade-in">
        <span className="mr-1">{greeting.icon}</span>
        {greeting.text}
      </p>
    </div>
  );
}
