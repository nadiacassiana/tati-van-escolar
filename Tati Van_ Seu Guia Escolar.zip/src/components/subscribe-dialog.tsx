import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { createAsaasSubscription } from "@/lib/asaas.functions";
import { isValidCPF, isValidCNPJ, maskCPF, maskCNPJ, onlyDigits } from "@/lib/cpf-cnpj";
import { maskPhoneBR, isValidPhoneBR } from "@/lib/phone-mask";

type DialogContext = "trial" | "trial-early-end" | "manual-migration";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  defaultName?: string;
  defaultPhone?: string;
  startNow?: boolean;
  context?: DialogContext;
  onSuccess?: () => void;
};

export function SubscribeDialog({ open, onOpenChange, defaultName, defaultPhone, startNow, context, onSuccess }: Props) {
  const dialogContext: DialogContext =
    context ?? (startNow ? "manual-migration" : "trial");
  const isEarlyEnd = dialogContext === "trial-early-end";
  const isManualMigration = dialogContext === "manual-migration";
  const subscribe = useServerFn(createAsaasSubscription);
  const [personType, setPersonType] = useState<"PF" | "PJ">("PF");
  const [name, setName] = useState(defaultName ?? "");
  const [cpfCnpj, setCpfCnpj] = useState("");
  const [phone, setPhone] = useState(defaultPhone ?? "");
  const [loading, setLoading] = useState(false);
  const needsExplanation = isEarlyEnd || isManualMigration;
  const [showExplanation, setShowExplanation] = useState(needsExplanation);

  useEffect(() => {
    if (open) {
      setShowExplanation(needsExplanation);
      setName(defaultName ?? "");
      setPhone(defaultPhone ?? "");
      setCpfCnpj("");
      setPersonType("PF");
    }
  }, [open, needsExplanation, defaultName, defaultPhone]);

  const docValid = personType === "PF" ? isValidCPF(cpfCnpj) : isValidCNPJ(cpfCnpj);
  const canSubmit = name.trim().length >= 3 && docValid && (!phone || isValidPhoneBR(phone));

  async function handleSubmit() {
    if (!docValid) {
      toast.error(
        personType === "PF"
          ? "CPF inválido. Verifique os números informados e tente novamente."
          : "CNPJ inválido. Verifique os números informados e tente novamente.",
      );
      return;
    }
    if (!canSubmit) return;
    setLoading(true);
    try {
      const res = await subscribe({
        data: {
          personType,
          cpfCnpj: onlyDigits(cpfCnpj),
          name: name.trim(),
          phone: onlyDigits(phone),
          startNow: !!startNow || isEarlyEnd,
        },
      });
      toast.success(
        res.alreadySubscribed
          ? "Você já possui uma assinatura."
          : isEarlyEnd
          ? "Assinatura ativada! Escolha PIX, Boleto ou Cartão na fatura."
          : startNow
          ? "Cobrança gerada! Escolha PIX, Boleto ou Cartão na fatura."
          : "Assinatura criada! Aproveite os 10 dias gratuitos.",
      );
      onSuccess?.();
      onOpenChange(false);
      if (res.invoiceUrl) {
        window.open(res.invoiceUrl, "_blank", "noopener,noreferrer");
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Erro ao criar assinatura.";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            {showExplanation
              ? isEarlyEnd
                ? "Encerrar teste e assinar agora"
                : "Complete seu cadastro de pagamento"
              : isEarlyEnd
              ? "Assinar Tati Van agora"
              : startNow
              ? "Pagar mensalidade Tati Van"
              : "Assinar Tati Van"}
          </DialogTitle>
          <DialogDescription>
            {showExplanation
              ? isEarlyEnd
                ? "Você está optando por encerrar o período de teste antes do prazo."
                : "Finalize seu cadastro para ativar a cobrança automática da mensalidade."
              : isEarlyEnd
              ? "Informe seus dados para gerar a cobrança de R$ 29,90 agora."
              : startNow
              ? "Informe seus dados para gerar a cobrança de R$ 29,90 agora."
              : "R$ 29,90/mês com 10 dias grátis. Sem cobrança durante o teste."}
          </DialogDescription>
        </DialogHeader>

        {showExplanation ? (
          <div className="space-y-4">
            {isEarlyEnd ? (
              <>
                <p className="text-sm text-foreground">
                  Ao continuar, seu <strong>período de teste gratuito será encerrado</strong> e sua assinatura da Tati Van será ativada imediatamente.
                </p>
                <p className="text-sm text-foreground">
                  Precisamos apenas confirmar alguns dados (como CPF) para criar seu cadastro na nossa plataforma de pagamentos (Asaas), gerar a primeira cobrança de <strong>R$ 29,90</strong> e liberar sua fatura para pagamento via PIX, Boleto ou Cartão.
                </p>
                <p className="text-sm text-muted-foreground">
                  Após a confirmação do pagamento, seu status será alterado automaticamente para <strong>Assinante</strong>.
                </p>
              </>
            ) : (
              <>
                <p className="text-sm text-foreground">
                  Para gerar suas cobranças mensais e ativar sua assinatura automática, precisamos concluir seu cadastro junto à nossa plataforma de pagamentos (Asaas).
                </p>
                <p className="text-sm text-foreground">
                  Seus dados serão utilizados apenas para emissão das cobranças e gerenciamento da sua assinatura, sendo enviados com segurança diretamente para o Asaas.
                </p>
                <p className="text-sm text-foreground">
                  Após concluir esse cadastro, seus próximos pagamentos poderão ser realizados normalmente pela plataforma.
                </p>
              </>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Tipo de pessoa</Label>
              <RadioGroup
                value={personType}
                onValueChange={(v) => { setPersonType(v as "PF" | "PJ"); setCpfCnpj(""); }}
                className="flex gap-4"
              >
                <label className="flex items-center gap-2 cursor-pointer">
                  <RadioGroupItem value="PF" /> Pessoa Física
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <RadioGroupItem value="PJ" /> Pessoa Jurídica
                </label>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label htmlFor="sub-name">
                {personType === "PF" ? "Nome completo" : "Razão social"}
              </Label>
              <Input id="sub-name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sub-doc">{personType === "PF" ? "CPF" : "CNPJ"}</Label>
              <Input
                id="sub-doc"
                inputMode="numeric"
                value={cpfCnpj}
                onChange={(e) =>
                  setCpfCnpj(personType === "PF" ? maskCPF(e.target.value) : maskCNPJ(e.target.value))
                }
                placeholder={personType === "PF" ? "000.000.000-00" : "00.000.000/0000-00"}
              />
              {cpfCnpj && !docValid && (
                <p className="text-xs text-destructive">
                  {personType === "PF" ? "CPF inválido" : "CNPJ inválido"}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="sub-phone">Telefone / WhatsApp (opcional)</Label>
              <Input
                id="sub-phone"
                inputMode="tel"
                value={phone}
                onChange={(e) => setPhone(maskPhoneBR(e.target.value))}
                placeholder="(11) 99999-9999"
              />
            </div>

            <p className="text-xs text-muted-foreground">
              Você poderá escolher <strong>PIX, Boleto ou Cartão</strong> na página de pagamento após
              o período de teste.
            </p>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancelar
          </Button>
          {showExplanation ? (
            <Button onClick={() => setShowExplanation(false)}>
              Continuar
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={!canSubmit || loading}>
              {loading ? (
                <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Processando...</>
              ) : (
                <><Sparkles className="h-4 w-4 mr-1.5" /> Confirmar assinatura</>
              )}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
