import { useCallback, useState } from "react";
import { Lightbulb, Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useSidebar } from "@/components/ui/sidebar";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface SugerirMelhoriaDialogProps {
  children: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export function SugerirMelhoriaDialog({
  children,
  open: openProp,
  onOpenChange,
}: SugerirMelhoriaDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const isControlled = openProp !== undefined;
  const open = isControlled ? openProp : internalOpen;
  const { isMobile } = useSidebar();

  const setOpen = useCallback(
    (value: boolean) => {
      if (!isControlled) setInternalOpen(value);
      onOpenChange?.(value);
    },
    [isControlled, onOpenChange],
  );

  const [sugestao, setSugestao] = useState("");
  const [enviando, setEnviando] = useState(false);

  const enviar = async () => {
    const texto = sugestao.trim();
    if (!texto || enviando) return;

    const { data, error: userError } = await supabase.auth.getUser();
    if (userError || !data.user) {
      toast.error("Faça login novamente para enviar sua sugestão.");
      return;
    }

    setEnviando(true);
    const { error } = await supabase
      .from("feedbacks" as never)
      .insert({ user_id: data.user.id, mensagem: texto } as never);
    setEnviando(false);

    if (error) {
      toast.error("Não foi possível enviar sua sugestão. Tente novamente.");
      return;
    }

    setSugestao("");
    setOpen(false);
    toast.success("Sua sugestão foi enviada com sucesso para a nossa equipe! Obrigado por contribuir. 💛");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {!isControlled ? <DialogTrigger asChild>{children}</DialogTrigger> : children}
      <DialogContent
        className="sm:max-w-md"
        onPointerDownOutside={(e) => {
          if (isMobile) e.preventDefault();
        }}
        onInteractOutside={(e) => {
          if (isMobile) e.preventDefault();
        }}
        onEscapeKeyDown={(e) => {
          if (isMobile) e.preventDefault();
        }}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Lightbulb className="h-5 w-5 text-warning" />
            Tem uma ideia para melhorar o Tati Van Escolar?
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <p className="text-sm text-muted-foreground">
            Conta pra gente o que poderia facilitar seu dia a dia. Sua sugestão é lida pela nossa equipe.
          </p>
          <Textarea
            value={sugestao}
            onChange={(e) => setSugestao(e.target.value.slice(0, 2000))}
            placeholder="Escreva aqui sua sugestão de melhoria..."
            rows={4}
            autoFocus
          />
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)} disabled={enviando}>
              Cancelar
            </Button>
            <Button onClick={enviar} disabled={!sugestao.trim() || enviando}>
              {enviando ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Send className="mr-2 h-4 w-4" />
              )}
              Enviar para a Equipe
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
