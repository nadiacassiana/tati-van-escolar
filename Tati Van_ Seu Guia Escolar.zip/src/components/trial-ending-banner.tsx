import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Clock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getAsaasSubscriptionStatus } from "@/lib/asaas.functions";

function startOfDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

export function TrialEndingBanner() {
  const getStatus = useServerFn(getAsaasSubscriptionStatus);
  const [daysLeft, setDaysLeft] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const res = await getStatus();
        if (res?.hasSubscription) return;
        if (!res?.trialEndsAt) return;
        const end = new Date(res.trialEndsAt);
        if (Number.isNaN(end.getTime())) return;
        const diff = Math.round((startOfDay(end) - startOfDay(new Date())) / 86_400_000);
        if (diff >= 0 && diff <= 2) setDaysLeft(diff);
      } catch {
        // silencioso: o banner é apenas um lembrete
      }
    })();
  }, []);

  if (daysLeft === null) return null;

  const titulo =
    daysLeft === 2
      ? "Seu período de teste termina em 2 dias."
      : daysLeft === 1
      ? "Seu período de teste termina amanhã."
      : "Seu período de teste termina hoje.";

  const texto =
    daysLeft === 2
      ? "Você ainda pode aproveitar todos os recursos do Tati Van Escolar normalmente. Para continuar utilizando o sistema após o término do teste, conheça a assinatura do Tati Van Escolar."
      : daysLeft === 1
      ? "Para continuar utilizando todos os recursos do Tati Van Escolar após o período de teste, conheça a assinatura do Tati Van Escolar."
      : "Para continuar utilizando o sistema sem interrupções, conheça a assinatura do Tati Van Escolar.";

  return (
    <Card className="relative z-10 flex flex-wrap items-center justify-between gap-4 rounded-md border border-slate-200 bg-white p-4 text-slate-800 shadow-sm">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent/50 text-accent-foreground">
          <Clock className="h-5 w-5" />
        </div>
        <div>
          <div className="font-bold text-slate-800">{titulo}</div>
          <p className="mt-0.5 text-sm text-slate-800">{texto}</p>
        </div>
      </div>
      <Link to="/assinatura" className="shrink-0">
        <Button size="sm" className="font-bold">Conhecer a assinatura</Button>
      </Link>
    </Card>
  );
}
