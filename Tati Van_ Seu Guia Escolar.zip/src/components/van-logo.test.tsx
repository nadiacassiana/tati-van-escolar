import { describe, expect, it } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { VanLogo, isLogoUsavel } from "./van-logo";

const PNG_1PX =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";

describe("isLogoUsavel", () => {
  it("recusa logotipo ausente ou vazio", () => {
    expect(isLogoUsavel(undefined)).toBe(false);
    expect(isLogoUsavel(null)).toBe(false);
    expect(isLogoUsavel("   ")).toBe(false);
  });

  it("recusa conteúdo corrompido/inválido", () => {
    expect(isLogoUsavel("lixo-corrompido")).toBe(false);
    expect(isLogoUsavel("javascript:alert(1)")).toBe(false);
    expect(isLogoUsavel("data:text/html,<b>x</b>")).toBe(false);
  });

  it("recusa imagem grande demais", () => {
    expect(isLogoUsavel("data:image/png;base64," + "A".repeat(1_000_000))).toBe(false);
  });

  it("aceita data URL de imagem e URL http(s)", () => {
    expect(isLogoUsavel(PNG_1PX)).toBe(true);
    expect(isLogoUsavel("https://exemplo.com/logo.png")).toBe(true);
  });
});

describe("<VanLogo />", () => {
  it("mostra o ícone padrão quando não há logotipo", () => {
    render(<VanLogo logo="" />);
    expect(screen.getByText("🚐")).toBeInTheDocument();
    expect(screen.queryByRole("img")).toBeNull();
  });

  it("mostra o ícone padrão quando o logotipo está corrompido", () => {
    render(<VanLogo logo="????nao-e-imagem????" />);
    expect(screen.getByText("🚐")).toBeInTheDocument();
  });

  it("cai no ícone padrão se a imagem falhar ao carregar", () => {
    render(<VanLogo logo="https://exemplo.com/quebrado.png" />);
    const img = screen.getByRole("img");
    fireEvent.error(img);
    expect(screen.getByText("🚐")).toBeInTheDocument();
    expect(screen.queryByRole("img")).toBeNull();
  });

  it("renderiza o logotipo válido", () => {
    render(<VanLogo logo={PNG_1PX} alt="Logotipo da van" />);
    expect(screen.getByAltText("Logotipo da van")).toBeInTheDocument();
  });
});
