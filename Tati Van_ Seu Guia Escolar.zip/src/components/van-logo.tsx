import { useEffect, useState } from "react";

/**
 * Logotipo da van à prova de falhas.
 * Se a imagem estiver ausente, inválida, corrompida ou grande demais,
 * mostramos o ícone padrão — nunca quebramos a tela por causa disso.
 */
const MAX_LOGO_CHARS = 900_000;

export function isLogoUsavel(logo?: string | null): boolean {
  const v = (logo || "").trim();
  if (!v) return false;
  if (v.length > MAX_LOGO_CHARS) return false;
  return v.startsWith("data:image/") || /^https?:\/\//i.test(v);
}

type Props = {
  logo?: string | null;
  alt?: string;
  className?: string;
  fallbackClassName?: string;
  emoji?: string;
};

export function VanLogo({
  logo,
  alt = "Logotipo da van",
  className = "h-12 w-12 shrink-0 rounded-xl border bg-background object-contain p-1 sm:h-14 sm:w-14",
  fallbackClassName = "flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-accent text-2xl sm:h-14 sm:w-14",
  emoji = "🚐",
}: Props) {
  const [broken, setBroken] = useState(false);

  useEffect(() => {
    setBroken(false);
  }, [logo]);

  if (!isLogoUsavel(logo) || broken) {
    return (
      <div className={fallbackClassName} aria-hidden="true">
        {emoji}
      </div>
    );
  }

  return (
    <img
      src={(logo || "").trim()}
      alt={alt}
      className={className}
      onError={() => setBroken(true)}
    />
  );
}
