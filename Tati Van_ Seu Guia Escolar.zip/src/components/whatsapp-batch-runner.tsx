import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, CheckCircle2, MessageCircle, X } from "lucide-react";
import { buildWhatsAppUrl } from "@/lib/whatsapp";
import { useIsMobile } from "@/hooks/use-mobile";

export type BatchTarget = {
  id: string;
  nome: string;
  telefone: string;
  texto: string;
};

type Props = {
  targets: BatchTarget[];
  /** Chamado a cada conversa aberta (para registrar no histórico). */
  onSent: (t: BatchTarget) => void | Promise<void>;
  /** Chamado quando o usuário finaliza ou cancela o processo. */
  onFinish: (enviados: number, cancelado: boolean) => void;
};

const STORAGE_PREFIX = "tativan:wa-batch:";

function makeKey(targets: BatchTarget[]) {
  const ids = targets.map((t) => t.id).join("|");
  let h = 0;
  for (let i = 0; i < ids.length; i++) h = (h * 31 + ids.charCodeAt(i)) | 0;
  return `${STORAGE_PREFIX}${targets.length}:${h}`;
}

function readProgress(key: string): { indice: number; concluido: boolean } | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return null;
    const p = JSON.parse(raw) as { indice?: number; concluido?: boolean };
    return { indice: Number(p.indice) || 0, concluido: !!p.concluido };
  } catch {
    return null;
  }
}

export function WhatsAppBatchRunner({ targets, onSent, onFinish }: Props) {
  const isMobile = useIsMobile();
  const total = targets.length;
  const storageKey = useMemo(() => makeKey(targets), [targets]);
  const [indice, setIndice] = useState(0);
  const [concluido, setConcluido] = useState(false);
  const [bloqueado, setBloqueado] = useState(false);
  const [rodandoDesktop, setRodandoDesktop] = useState(false);
  const [retomado, setRetomado] = useState(false);
  const [hidratado, setHidratado] = useState(false);

  // Retoma o progresso salvo (volta do WhatsApp / recarrega a página)
  useEffect(() => {
    const saved = readProgress(storageKey);
    if (saved && saved.indice > 0 && saved.indice < total) {
      setIndice(saved.indice);
      setRetomado(true);
    } else if (saved?.concluido) {
      setIndice(saved.indice);
      setConcluido(true);
    }
    setHidratado(true);
  }, [storageKey, total]);

  // Persiste a cada mudança
  useEffect(() => {
    if (!hidratado || typeof window === "undefined") return;
    try {
      window.localStorage.setItem(storageKey, JSON.stringify({ indice, concluido, ts: Date.now() }));
    } catch {
      /* ignora */
    }
  }, [hidratado, storageKey, indice, concluido]);

  function limparProgresso() {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.removeItem(storageKey);
    } catch {
      /* ignora */
    }
  }

  // Desktop: abre todas as abas de uma vez (já confirmado na etapa anterior)
  useEffect(() => {
    if (!hidratado || isMobile || rodandoDesktop || concluido) return;
    setRodandoDesktop(true);
    void (async () => {
      let abertos = 0;
      let bloqueios = 0;
      for (const t of targets) {
        const win = window.open(buildWhatsAppUrl(t.telefone, t.texto), "_blank", "noopener");
        if (!win) {
          bloqueios++;
        } else {
          abertos++;
          await onSent(t);
        }
      }
      setIndice(abertos);
      setBloqueado(bloqueios > 0);
      setConcluido(bloqueios === 0);
    })();
  }, [hidratado, isMobile, rodandoDesktop, concluido, targets]);

  async function abrirAtual() {
    const t = targets[indice];
    if (!t) return;
    const prox = indice + 1;
    // Salva ANTES de sair para o WhatsApp: ao voltar, continua de onde parou.
    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem(
          storageKey,
          JSON.stringify({ indice: prox, concluido: prox >= total, ts: Date.now() }),
        );
      } catch {
        /* ignora */
      }
    }
    setIndice(prox);
    setRetomado(false);
    if (prox >= total) setConcluido(true);
    void onSent(t);
    window.location.href = buildWhatsAppUrl(t.telefone, t.texto);
  }

  function finalizar(enviados: number, cancelado: boolean) {
    limparProgresso();
    onFinish(enviados, cancelado);
  }

  if (concluido) {
    return (
      <div className="space-y-4">
        <div className="flex items-start gap-3 rounded-xl border border-success/40 bg-success/5 p-4">
          <CheckCircle2 className="mt-0.5 h-5 w-5 text-success" />
          <div className="text-sm font-semibold text-success">
            Todas as mensagens foram preparadas para envio com sucesso.
          </div>
        </div>
        <Button className="w-full font-bold" onClick={() => finalizar(indice, false)}>Concluir</Button>
      </div>
    );
  }


  if (!isMobile) {
    return (
      <div className="space-y-4">
        {bloqueado ? (
          <div className="flex items-start gap-3 rounded-xl border border-destructive/40 bg-destructive/5 p-4 text-sm">
            <AlertTriangle className="mt-0.5 h-5 w-5 text-destructive" />
            <div>
              <p className="font-semibold text-destructive">Seu navegador bloqueou as janelas do WhatsApp Web.</p>
              <p className="mt-1 text-muted-foreground">
                Permita pop-ups para este site (ícone de bloqueio na barra de endereço) e tente novamente.
              </p>
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">Abrindo as conversas no WhatsApp Web...</p>
        )}
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={() => finalizar(indice, true)}>Fechar</Button>
          {bloqueado && (
            <Button className="flex-1 font-bold" onClick={() => { setBloqueado(false); setRodandoDesktop(false); }}>
              Tentar novamente
            </Button>
          )}
        </div>
      </div>
    );
  }

  const atual = targets[indice];
  return (
    <div className="space-y-4">
      {retomado && (
        <div className="rounded-xl border border-accent/40 bg-accent/10 p-3 text-xs">
          Continuando de onde você parou: <b>{indice}</b> de <b>{total}</b> conversa(s) já abertas.
        </div>
      )}
      <div>
        <div className="mb-1 flex items-center justify-between text-sm font-semibold">
          <span>Enviando {Math.min(indice + 1, total)} de {total}</span>
          <span className="text-muted-foreground">{Math.round((indice / total) * 100)}%</span>
        </div>
        <Progress value={(indice / total) * 100} />
      </div>

      <div className="rounded-xl border bg-card p-3">
        <p className="text-xs text-muted-foreground">Próxima conversa</p>
        <p className="font-semibold">{atual?.nome}</p>
      </div>

      <p className="text-xs text-muted-foreground">
        O WhatsApp abrirá com a mensagem pronta. Depois de enviar, volte ao Tati Van e toque em <b>Próxima conversa</b>.
      </p>

      <div className="grid gap-2">
        <Button className="w-full bg-success font-bold text-success-foreground hover:bg-success/90" onClick={abrirAtual}>
          <MessageCircle className="mr-2 h-4 w-4" />
          {indice === 0 ? "Abrir primeira conversa" : "Próxima conversa"}
        </Button>
        <Button variant="outline" className="w-full" onClick={() => finalizar(indice, true)}>
          <X className="mr-2 h-4 w-4" /> Cancelar envio
        </Button>
      </div>
    </div>
  );
}
