import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Star, ArrowLeft, Send, Pencil, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { applyVariables, buildWhatsAppUrl, getMotoristaFromUser, MENSAGENS_PADRAO, type VarContext } from "@/lib/whatsapp";
import { WhatsAppBatchRunner, type BatchTarget } from "@/components/whatsapp-batch-runner";
import { useIsMobile } from "@/hooks/use-mobile";

import { toast } from "sonner";
import type { User } from "@supabase/supabase-js";

export type SenderResponsavel = {
  id: string;
  nome: string;
  whatsapp: string;
  telefone?: string;
  alunos_ids?: string[];
};

export type SenderAluno = {
  id: string;
  nome: string;
  escola?: string;
  mensalidade?: number;
  vencimento?: number;
};

type Mensagem = { id: string; nome: string; emoji: string; texto: string; favorito: boolean; ordem: number };

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  user: User;
  responsaveis: SenderResponsavel[];   // 1 ou vários (modo grupo)
  alunos: SenderAluno[];                // todos os alunos relevantes (para resolver {aluno})
  grupo?: boolean;                      // se true, envia para todos os responsaveis em sequência
  grupoLabel?: string;
};

export function WhatsAppSender({ open, onOpenChange, user, responsaveis, alunos, grupo, grupoLabel }: Props) {
  const [mensagens, setMensagens] = useState<Mensagem[]>([]);
  const [busca, setBusca] = useState("");
  const [step, setStep] = useState<"escolher" | "aluno" | "preview" | "envio">("escolher");
  const [escolhida, setEscolhida] = useState<Mensagem | null>(null);
  const [alunoId, setAlunoId] = useState<string>("");
  const [texto, setTexto] = useState("");
  const [enviando, setEnviando] = useState(false);

  const motorista = useMemo(() => getMotoristaFromUser(user), [user]);
  const isMobile = useIsMobile();


  useEffect(() => {
    if (!open) return;
    setStep("escolher");
    setEscolhida(null);
    setAlunoId("");
    setBusca("");
    void loadMensagens();
  }, [open]);

  async function loadMensagens() {
    const { data } = await supabase
      .from("mensagens")
      .select("*")
      .order("favorito", { ascending: false })
      .order("ordem", { ascending: true })
      .order("created_at", { ascending: true });
    let list = (data as Mensagem[]) || [];
    if (list.length === 0) {
      // seed defaults
      const rows = MENSAGENS_PADRAO.map((m, i) => ({ ...m, ordem: i, user_id: user.id }));
      const { data: inserted } = await supabase.from("mensagens").insert(rows).select("*");
      list = ((inserted as Mensagem[]) || []).sort((a, b) => Number(b.favorito) - Number(a.favorito) || a.ordem - b.ordem);
    }
    setMensagens(list);
  }

  const principal = responsaveis[0];
  const alunosDoResp = useMemo(() => {
    if (grupo || !principal) return [];
    const ids = principal.alunos_ids || [];
    return alunos.filter((a) => ids.includes(a.id));
  }, [grupo, principal, alunos]);

  function escolherMensagem(m: Mensagem) {
    setEscolhida(m);
    const precisaAluno = /\{aluno\}|\{escola\}|\{mensalidade\}|\{vencimento\}/.test(m.texto);
    if (!grupo && precisaAluno && alunosDoResp.length > 1) {
      setAlunoId(alunosDoResp[0].id);
      setStep("aluno");
    } else {
      gerarPreview(m, alunosDoResp[0]?.id || "");
      setStep("preview");
    }
  }

  function personalizada() {
    const m: Mensagem = { id: "custom", nome: "Mensagem personalizada", emoji: "✏️", texto: "", favorito: false, ordem: 999 };
    setEscolhida(m);
    setTexto("");
    setStep("preview");
  }

  function gerarPreview(m: Mensagem, alId: string) {
    const al = alunos.find((a) => a.id === alId) || alunosDoResp[0];
    const ctx: VarContext = {
      responsavel: principal?.nome,
      aluno: al?.nome,
      escola: al?.escola,
      mensalidade: al?.mensalidade,
      vencimento: al?.vencimento,
    };
    setTexto(applyVariables(m.texto, ctx, motorista));
    setAlunoId(alId);
  }

  const gruposTargets: BatchTarget[] = useMemo(() => {
    if (!grupo || !escolhida) return [];
    return responsaveis
      .filter((r) => !!r.whatsapp)
      .map((r) => {
        const seuAluno = alunos.find((a) => (r.alunos_ids || []).includes(a.id));
        const ctx: VarContext = {
          responsavel: r.nome,
          aluno: seuAluno?.nome,
          escola: seuAluno?.escola,
          mensalidade: seuAluno?.mensalidade,
          vencimento: seuAluno?.vencimento,
        };
        return { id: r.id, nome: r.nome, telefone: r.whatsapp, texto: applyVariables(escolhida.texto || texto, ctx, motorista) };
      });
  }, [grupo, escolhida, responsaveis, alunos, texto, motorista]);

  async function registrarEnvio(t: BatchTarget) {
    if (!escolhida) return;
    const r = responsaveis.find((x) => x.id === t.id);
    const seuAluno = r ? alunos.find((a) => (r.alunos_ids || []).includes(a.id)) : undefined;
    await supabase.from("mensagens_historico").insert({
      user_id: user.id,
      mensagem_nome: escolhida.nome,
      emoji: escolhida.emoji,
      texto: t.texto,
      destinatario: t.nome,
      telefone: t.telefone,
      responsavel_id: t.id,
      aluno_id: seuAluno?.id ?? null,
    });
  }

  async function enviar() {
    if (!escolhida) return;
    if (!texto.trim()) { toast.error("Mensagem vazia."); return; }
    if (grupo) {
      if (gruposTargets.length === 0) { toast.error("Nenhum responsável com WhatsApp."); return; }
      setStep("envio");
      return;
    }
    setEnviando(true);
    try {
      if (!principal?.whatsapp) { toast.error("Responsável sem WhatsApp."); setEnviando(false); return; }
      const url = buildWhatsAppUrl(principal.whatsapp, texto);
      window.open(url, "_blank", "noopener");
      await supabase.from("mensagens_historico").insert({
        user_id: user.id,
        mensagem_nome: escolhida.nome,
        emoji: escolhida.emoji,
        texto,
        destinatario: principal.nome,
        telefone: principal.whatsapp,
        responsavel_id: principal.id,
        aluno_id: alunoId || null,
      });
      toast.success("WhatsApp aberto!");
      onOpenChange(false);
    } finally {
      setEnviando(false);
    }
  }


  const filtradas = mensagens.filter((m) =>
    !busca || m.nome.toLowerCase().includes(busca.toLowerCase()) || m.texto.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {step === "escolher" && "Escolha uma mensagem"}
            {step === "aluno" && "Qual aluno?"}
            {step === "preview" && "Confira e envie"}
            {step === "envio" && "Enviando mensagens"}

          </DialogTitle>
          <DialogDescription>
            {grupo
              ? `Envio em grupo${grupoLabel ? ` — ${grupoLabel}` : ""}: ${responsaveis.length} responsável(eis).`
              : principal
                ? `Para: ${principal.nome}`
                : "Selecione um destinatário."}
          </DialogDescription>
        </DialogHeader>

        {step === "escolher" && (
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input className="pl-9" placeholder="Buscar mensagem..." value={busca} onChange={(e) => setBusca(e.target.value)} />
            </div>
            <div className="grid gap-2 max-h-[50vh] overflow-y-auto pr-1">
              {filtradas.map((m) => (
                <button key={m.id} type="button" onClick={() => escolherMensagem(m)}
                  className="flex items-start gap-3 rounded-xl border bg-card p-3 text-left transition-colors hover:bg-accent/30">
                  <div className="text-2xl">{m.emoji}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 font-semibold text-sm">
                      {m.nome}
                      {m.favorito && <Star className="h-3.5 w-3.5 fill-accent text-accent" />}
                    </div>
                    <div className="line-clamp-2 text-xs text-muted-foreground">{m.texto}</div>
                  </div>
                </button>
              ))}
              {filtradas.length === 0 && (
                <div className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">Nenhuma mensagem encontrada.</div>
              )}
            </div>
            <Button type="button" variant="outline" className="w-full" onClick={personalizada}>
              <Pencil className="mr-2 h-4 w-4" /> Escrever mensagem personalizada
            </Button>
          </div>
        )}

        {step === "aluno" && escolhida && (
          <div className="space-y-3">
            <Label>Selecione o aluno para personalizar a mensagem:</Label>
            <RadioGroup value={alunoId} onValueChange={setAlunoId}>
              {alunosDoResp.map((a) => (
                <label key={a.id} className="flex items-center gap-2 rounded-lg border p-3 cursor-pointer hover:bg-accent/30">
                  <RadioGroupItem value={a.id} id={`al-${a.id}`} />
                  <span className="font-medium">{a.nome}</span>
                  {a.escola && <span className="text-xs text-muted-foreground">— {a.escola}</span>}
                </label>
              ))}
            </RadioGroup>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setStep("escolher")}><ArrowLeft className="mr-2 h-4 w-4" /> Voltar</Button>
              <Button onClick={() => { gerarPreview(escolhida, alunoId); setStep("preview"); }} disabled={!alunoId} className="bg-primary font-bold">Continuar</Button>
            </DialogFooter>
          </div>
        )}

        {step === "preview" && escolhida && (
          <div className="space-y-3">
            <div className="rounded-lg bg-accent/20 p-2 text-xs text-muted-foreground">
              {escolhida.emoji} <span className="font-semibold">{escolhida.nome}</span>
            </div>
            <Label>Mensagem (você pode editar):</Label>
            <Textarea rows={8} value={texto} onChange={(e) => setTexto(e.target.value)} />
            {grupo && (
              <>
                <p className="text-xs text-muted-foreground">
                  As variáveis serão substituídas por responsável. O texto acima é apenas pré-visualização do modelo.
                </p>
                <p className="rounded-lg border border-dashed p-3 text-xs text-muted-foreground">
                  {isMobile
                    ? "📱 As conversas serão abertas uma por vez no aplicativo do WhatsApp."
                    : `💻 Serão abertas ${gruposTargets.length} conversas do WhatsApp Web. Se o navegador bloquear, permita pop-ups para este site.`}
                </p>
              </>
            )}
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setStep("escolher")}><ArrowLeft className="mr-2 h-4 w-4" /> Trocar</Button>
              <Button onClick={enviar} disabled={enviando} className="bg-success text-success-foreground hover:bg-success/90 font-bold">
                <Send className="mr-2 h-4 w-4" /> {enviando ? "Abrindo..." : grupo ? "Iniciar envio" : "Abrir WhatsApp"}
              </Button>
            </DialogFooter>
          </div>
        )}

        {step === "envio" && (
          <WhatsAppBatchRunner
            targets={gruposTargets}
            onSent={registrarEnvio}
            onFinish={(enviados, cancelado) => {
              if (cancelado && enviados > 0) toast.message(`Envio interrompido. ${enviados} conversa(s) aberta(s).`);
              onOpenChange(false);
            }}
          />
        )}

      </DialogContent>
    </Dialog>
  );
}
