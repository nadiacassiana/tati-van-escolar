import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { computeAccountStatus, type AccountStatus } from "@/lib/account-status";
import { setReadOnlyMode } from "@/lib/readonly-guard";

const defaultStatus: AccountStatus = {
  phase: "ativo",
  trialEndsAt: null,
  graceEndsAt: null,
  graceDaysLeft: 0,
  isReadOnly: false,
};

const AccountStatusContext = createContext<AccountStatus>(defaultStatus);

export function AccountStatusProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<AccountStatus>(defaultStatus);

  useEffect(() => {
    let alive = true;

    async function load() {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user?.id;
      if (!uid) return;
      const { data: profile } = await supabase
        .from("profiles")
        .select(
          "plan_status, subscription_status, asaas_subscription_id, asaas_next_due_date, next_due_date, payment_method, trial_started_at, trial_ends_at, trial_days_bonus, created_at",
        )

        .eq("user_id", uid)
        .maybeSingle();
      const next = computeAccountStatus(
        profile ?? { created_at: userData.user?.created_at ?? null },
      );
      if (!alive) return;
      setStatus(next);
      setReadOnlyMode(next.isReadOnly);
    }

    load();
    // Reavalia periodicamente para que a pausa/liberação seja automática
    const timer = window.setInterval(load, 5 * 60 * 1000);
    const onFocus = () => load();
    window.addEventListener("focus", onFocus);
    return () => {
      alive = false;
      window.clearInterval(timer);
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  return (
    <AccountStatusContext.Provider value={status}>{children}</AccountStatusContext.Provider>
  );
}

export function useAccountStatus() {
  return useContext(AccountStatusContext);
}
