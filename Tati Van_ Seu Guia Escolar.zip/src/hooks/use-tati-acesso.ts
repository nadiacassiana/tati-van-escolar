import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { TATI_EMAIL_TESTE } from "@/lib/tati-conhecimento";

/** Modo de teste restrito: só o e-mail de teste enxerga a assistente. */
export function useTatiAcesso() {
  const [liberado, setLiberado] = useState(false);

  useEffect(() => {
    let alive = true;
    void (async () => {
      const { data } = await supabase.auth.getUser();
      const email = (data.user?.email ?? "").toLowerCase();
      if (alive) setLiberado(email === TATI_EMAIL_TESTE);
    })();
    return () => {
      alive = false;
    };
  }, []);

  return liberado;
}
