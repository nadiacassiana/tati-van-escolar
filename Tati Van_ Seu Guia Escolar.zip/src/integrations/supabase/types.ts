export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      alunos: {
        Row: {
          aniversario: string
          arquivado_em: string | null
          autoriza_imagem: boolean | null
          avatar: string
          bairro: string
          cep: string
          cidade: string
          created_at: string
          endereco: string
          escola: string
          estado: string
          foto_url: string
          horario_ida: string
          horario_volta: string
          id: string
          juros_dia: number
          juros_tipo: string
          mensalidade: number
          multa_atraso: number
          multa_tipo: string
          nao_pode_buscar: string
          nome: string
          numero: string
          observacoes: string
          ordem_rota: number | null
          pode_buscar: string
          responsavel: string
          restricoes: string
          rua: string
          sexo: string | null
          status_mensalidade: string
          telefone: string
          tipo_cobranca: string
          turma: string
          turno: string | null
          updated_at: string
          user_id: string
          vencimento: number
          whatsapp: string
        }
        Insert: {
          aniversario?: string
          arquivado_em?: string | null
          autoriza_imagem?: boolean | null
          avatar?: string
          bairro?: string
          cep?: string
          cidade?: string
          created_at?: string
          endereco?: string
          escola?: string
          estado?: string
          foto_url?: string
          horario_ida?: string
          horario_volta?: string
          id?: string
          juros_dia?: number
          juros_tipo?: string
          mensalidade?: number
          multa_atraso?: number
          multa_tipo?: string
          nao_pode_buscar?: string
          nome: string
          numero?: string
          observacoes?: string
          ordem_rota?: number | null
          pode_buscar?: string
          responsavel?: string
          restricoes?: string
          rua?: string
          sexo?: string | null
          status_mensalidade?: string
          telefone?: string
          tipo_cobranca?: string
          turma?: string
          turno?: string | null
          updated_at?: string
          user_id: string
          vencimento?: number
          whatsapp?: string
        }
        Update: {
          aniversario?: string
          arquivado_em?: string | null
          autoriza_imagem?: boolean | null
          avatar?: string
          bairro?: string
          cep?: string
          cidade?: string
          created_at?: string
          endereco?: string
          escola?: string
          estado?: string
          foto_url?: string
          horario_ida?: string
          horario_volta?: string
          id?: string
          juros_dia?: number
          juros_tipo?: string
          mensalidade?: number
          multa_atraso?: number
          multa_tipo?: string
          nao_pode_buscar?: string
          nome?: string
          numero?: string
          observacoes?: string
          ordem_rota?: number | null
          pode_buscar?: string
          responsavel?: string
          restricoes?: string
          rua?: string
          sexo?: string | null
          status_mensalidade?: string
          telefone?: string
          tipo_cobranca?: string
          turma?: string
          turno?: string | null
          updated_at?: string
          user_id?: string
          vencimento?: number
          whatsapp?: string
        }
        Relationships: []
      }
      contratos: {
        Row: {
          aluno_id: string | null
          aluno_nome: string
          arquivado_em: string | null
          assinado_em: string | null
          assinatura_motorista: Json | null
          assinatura_responsavel: Json | null
          autoriza_imagem: boolean | null
          clausulas_adicionais: string
          clausulas_custom: Json | null
          created_at: string
          data_inicio: string | null
          data_termino: string | null
          dia_vencimento: number
          email_responsavel: string | null
          endereco: string
          enviado_email_em: string | null
          enviado_whatsapp_em: string | null
          escola: string
          forma_pagamento: string | null
          historico: Json
          horario_ida: string | null
          horario_volta: string | null
          id: string
          juros_dia: number
          juros_tipo: string
          mensalidade: number
          multa_atraso: number
          multa_tipo: string
          observacoes: string
          observacoes_importantes: string | null
          pessoas_autorizadas: string | null
          pix_motorista: string | null
          responsavel: string
          status: string
          telefone: string
          telefone_emergencia: string | null
          turno: string
          updated_at: string
          user_id: string
        }
        Insert: {
          aluno_id?: string | null
          aluno_nome?: string
          arquivado_em?: string | null
          assinado_em?: string | null
          assinatura_motorista?: Json | null
          assinatura_responsavel?: Json | null
          autoriza_imagem?: boolean | null
          clausulas_adicionais?: string
          clausulas_custom?: Json | null
          created_at?: string
          data_inicio?: string | null
          data_termino?: string | null
          dia_vencimento?: number
          email_responsavel?: string | null
          endereco?: string
          enviado_email_em?: string | null
          enviado_whatsapp_em?: string | null
          escola?: string
          forma_pagamento?: string | null
          historico?: Json
          horario_ida?: string | null
          horario_volta?: string | null
          id?: string
          juros_dia?: number
          juros_tipo?: string
          mensalidade?: number
          multa_atraso?: number
          multa_tipo?: string
          observacoes?: string
          observacoes_importantes?: string | null
          pessoas_autorizadas?: string | null
          pix_motorista?: string | null
          responsavel?: string
          status?: string
          telefone?: string
          telefone_emergencia?: string | null
          turno?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          aluno_id?: string | null
          aluno_nome?: string
          arquivado_em?: string | null
          assinado_em?: string | null
          assinatura_motorista?: Json | null
          assinatura_responsavel?: Json | null
          autoriza_imagem?: boolean | null
          clausulas_adicionais?: string
          clausulas_custom?: Json | null
          created_at?: string
          data_inicio?: string | null
          data_termino?: string | null
          dia_vencimento?: number
          email_responsavel?: string | null
          endereco?: string
          enviado_email_em?: string | null
          enviado_whatsapp_em?: string | null
          escola?: string
          forma_pagamento?: string | null
          historico?: Json
          horario_ida?: string | null
          horario_volta?: string | null
          id?: string
          juros_dia?: number
          juros_tipo?: string
          mensalidade?: number
          multa_atraso?: number
          multa_tipo?: string
          observacoes?: string
          observacoes_importantes?: string | null
          pessoas_autorizadas?: string | null
          pix_motorista?: string | null
          responsavel?: string
          status?: string
          telefone?: string
          telefone_emergencia?: string | null
          turno?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "contratos_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "alunos"
            referencedColumns: ["id"]
          },
        ]
      }
      deleted_accounts: {
        Row: {
          cadastro_em: string | null
          cidade: string | null
          created_at: string
          dias_permanencia: number | null
          email: string | null
          estado: string | null
          excluido_em: string
          id: string
          motivo: string | null
          motivo_texto: string | null
          nome: string | null
          status_no_momento: string | null
          user_id: string
          whatsapp: string | null
        }
        Insert: {
          cadastro_em?: string | null
          cidade?: string | null
          created_at?: string
          dias_permanencia?: number | null
          email?: string | null
          estado?: string | null
          excluido_em?: string
          id?: string
          motivo?: string | null
          motivo_texto?: string | null
          nome?: string | null
          status_no_momento?: string | null
          user_id: string
          whatsapp?: string | null
        }
        Update: {
          cadastro_em?: string | null
          cidade?: string | null
          created_at?: string
          dias_permanencia?: number | null
          email?: string | null
          estado?: string | null
          excluido_em?: string
          id?: string
          motivo?: string | null
          motivo_texto?: string | null
          nome?: string | null
          status_no_momento?: string | null
          user_id?: string
          whatsapp?: string | null
        }
        Relationships: []
      }
      documentos: {
        Row: {
          arquivo: string | null
          arquivo_nome: string | null
          arquivo_tipo: string | null
          categoria: string
          created_at: string
          historico: Json
          id: string
          nome: string
          numero: string
          observacoes: string
          seguro_info: Json | null
          updated_at: string
          user_id: string
          vencimento: string | null
          vistoria_checklist: Json
          vistoria_concluida_em: string | null
          vistoria_parabens_exibido: boolean
        }
        Insert: {
          arquivo?: string | null
          arquivo_nome?: string | null
          arquivo_tipo?: string | null
          categoria?: string
          created_at?: string
          historico?: Json
          id?: string
          nome: string
          numero?: string
          observacoes?: string
          seguro_info?: Json | null
          updated_at?: string
          user_id: string
          vencimento?: string | null
          vistoria_checklist?: Json
          vistoria_concluida_em?: string | null
          vistoria_parabens_exibido?: boolean
        }
        Update: {
          arquivo?: string | null
          arquivo_nome?: string | null
          arquivo_tipo?: string | null
          categoria?: string
          created_at?: string
          historico?: Json
          id?: string
          nome?: string
          numero?: string
          observacoes?: string
          seguro_info?: Json | null
          updated_at?: string
          user_id?: string
          vencimento?: string | null
          vistoria_checklist?: Json
          vistoria_concluida_em?: string | null
          vistoria_parabens_exibido?: boolean
        }
        Relationships: []
      }
      escolas: {
        Row: {
          bairro: string
          cep: string
          cidade: string
          created_at: string
          endereco: string
          estado: string
          id: string
          nome: string
          numero: string
          rua: string
          updated_at: string
          user_id: string
        }
        Insert: {
          bairro?: string
          cep?: string
          cidade?: string
          created_at?: string
          endereco?: string
          estado?: string
          id?: string
          nome: string
          numero?: string
          rua?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          bairro?: string
          cep?: string
          cidade?: string
          created_at?: string
          endereco?: string
          estado?: string
          id?: string
          nome?: string
          numero?: string
          rua?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      feedbacks: {
        Row: {
          created_at: string
          id: string
          mensagem: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          mensagem: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          mensagem?: string
          user_id?: string
        }
        Relationships: []
      }
      garantias_vaga: {
        Row: {
          abater: boolean
          abater_em: string
          abater_outro: string
          aluno_id: string | null
          aluno_nome: string
          ano_referencia: number
          assinatura_motorista: Json | null
          assinatura_responsavel: Json | null
          cobrar: boolean
          confirmacao_nome: string | null
          confirmado_em: string | null
          created_at: string
          enviado_em: string | null
          escola: string
          historico: Json
          id: string
          mensalidade_prevista: number
          observacoes: string
          prazo_resposta: string | null
          recusado_em: string | null
          responsavel_nome: string
          responsavel_whatsapp: string
          status: string
          tipo: string
          tipo_outro: string
          updated_at: string
          user_id: string
          valor: number
        }
        Insert: {
          abater?: boolean
          abater_em?: string
          abater_outro?: string
          aluno_id?: string | null
          aluno_nome?: string
          ano_referencia: number
          assinatura_motorista?: Json | null
          assinatura_responsavel?: Json | null
          cobrar?: boolean
          confirmacao_nome?: string | null
          confirmado_em?: string | null
          created_at?: string
          enviado_em?: string | null
          escola?: string
          historico?: Json
          id?: string
          mensalidade_prevista?: number
          observacoes?: string
          prazo_resposta?: string | null
          recusado_em?: string | null
          responsavel_nome?: string
          responsavel_whatsapp?: string
          status?: string
          tipo?: string
          tipo_outro?: string
          updated_at?: string
          user_id: string
          valor?: number
        }
        Update: {
          abater?: boolean
          abater_em?: string
          abater_outro?: string
          aluno_id?: string | null
          aluno_nome?: string
          ano_referencia?: number
          assinatura_motorista?: Json | null
          assinatura_responsavel?: Json | null
          cobrar?: boolean
          confirmacao_nome?: string | null
          confirmado_em?: string | null
          created_at?: string
          enviado_em?: string | null
          escola?: string
          historico?: Json
          id?: string
          mensalidade_prevista?: number
          observacoes?: string
          prazo_resposta?: string | null
          recusado_em?: string | null
          responsavel_nome?: string
          responsavel_whatsapp?: string
          status?: string
          tipo?: string
          tipo_outro?: string
          updated_at?: string
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "garantias_vaga_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "alunos"
            referencedColumns: ["id"]
          },
        ]
      }
      gastos: {
        Row: {
          categoria: string
          created_at: string
          data: string
          descricao: string
          id: string
          km: number | null
          observacoes: string
          updated_at: string
          user_id: string
          valor: number
        }
        Insert: {
          categoria?: string
          created_at?: string
          data?: string
          descricao?: string
          id?: string
          km?: number | null
          observacoes?: string
          updated_at?: string
          user_id: string
          valor?: number
        }
        Update: {
          categoria?: string
          created_at?: string
          data?: string
          descricao?: string
          id?: string
          km?: number | null
          observacoes?: string
          updated_at?: string
          user_id?: string
          valor?: number
        }
        Relationships: []
      }
      lancamentos_financeiros: {
        Row: {
          aluno_id: string | null
          aluno_nome: string
          ano_referencia: number | null
          competencia: string | null
          created_at: string
          data_recebimento: string | null
          descricao: string
          garantia_id: string | null
          historico: Json
          id: string
          origem: string
          regra_abatimento: string | null
          saldo_restante: number
          status: string
          tipo: string
          updated_at: string
          user_id: string
          valor: number
        }
        Insert: {
          aluno_id?: string | null
          aluno_nome?: string
          ano_referencia?: number | null
          competencia?: string | null
          created_at?: string
          data_recebimento?: string | null
          descricao?: string
          garantia_id?: string | null
          historico?: Json
          id?: string
          origem?: string
          regra_abatimento?: string | null
          saldo_restante?: number
          status?: string
          tipo?: string
          updated_at?: string
          user_id: string
          valor?: number
        }
        Update: {
          aluno_id?: string | null
          aluno_nome?: string
          ano_referencia?: number | null
          competencia?: string | null
          created_at?: string
          data_recebimento?: string | null
          descricao?: string
          garantia_id?: string | null
          historico?: Json
          id?: string
          origem?: string
          regra_abatimento?: string | null
          saldo_restante?: number
          status?: string
          tipo?: string
          updated_at?: string
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "lancamentos_financeiros_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "alunos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lancamentos_financeiros_garantia_id_fkey"
            columns: ["garantia_id"]
            isOneToOne: false
            referencedRelation: "garantias_vaga"
            referencedColumns: ["id"]
          },
        ]
      }
      lista_espera: {
        Row: {
          aluno_nome: string
          convertido_em: string | null
          created_at: string
          endereco: string
          escola: string
          id: string
          numero: string
          observacoes: string
          periodo: string
          responsavel_nome: string
          responsavel_whatsapp: string
          updated_at: string
          user_id: string
        }
        Insert: {
          aluno_nome: string
          convertido_em?: string | null
          created_at?: string
          endereco?: string
          escola?: string
          id?: string
          numero?: string
          observacoes?: string
          periodo?: string
          responsavel_nome: string
          responsavel_whatsapp: string
          updated_at?: string
          user_id: string
        }
        Update: {
          aluno_nome?: string
          convertido_em?: string | null
          created_at?: string
          endereco?: string
          escola?: string
          id?: string
          numero?: string
          observacoes?: string
          periodo?: string
          responsavel_nome?: string
          responsavel_whatsapp?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      mensagens: {
        Row: {
          categoria: string
          created_at: string
          emoji: string
          favorito: boolean
          id: string
          nome: string
          ordem: number
          texto: string
          updated_at: string
          user_id: string
        }
        Insert: {
          categoria?: string
          created_at?: string
          emoji?: string
          favorito?: boolean
          id?: string
          nome: string
          ordem?: number
          texto: string
          updated_at?: string
          user_id: string
        }
        Update: {
          categoria?: string
          created_at?: string
          emoji?: string
          favorito?: boolean
          id?: string
          nome?: string
          ordem?: number
          texto?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      mensagens_historico: {
        Row: {
          aluno_id: string | null
          canal: string
          created_at: string
          destinatario: string
          emoji: string
          id: string
          mensagem_nome: string
          responsavel_id: string | null
          status: string
          telefone: string
          texto: string
          user_id: string
        }
        Insert: {
          aluno_id?: string | null
          canal?: string
          created_at?: string
          destinatario?: string
          emoji?: string
          id?: string
          mensagem_nome?: string
          responsavel_id?: string | null
          status?: string
          telefone?: string
          texto: string
          user_id: string
        }
        Update: {
          aluno_id?: string | null
          canal?: string
          created_at?: string
          destinatario?: string
          emoji?: string
          id?: string
          mensagem_nome?: string
          responsavel_id?: string | null
          status?: string
          telefone?: string
          texto?: string
          user_id?: string
        }
        Relationships: []
      }
      notificacoes: {
        Row: {
          corpo: string
          created_at: string
          dados: Json
          dedupe_key: string | null
          id: string
          lida_em: string | null
          push_enviado_em: string | null
          tipo: string
          titulo: string
          updated_at: string
          url: string | null
          user_id: string
        }
        Insert: {
          corpo?: string
          created_at?: string
          dados?: Json
          dedupe_key?: string | null
          id?: string
          lida_em?: string | null
          push_enviado_em?: string | null
          tipo: string
          titulo: string
          updated_at?: string
          url?: string | null
          user_id: string
        }
        Update: {
          corpo?: string
          created_at?: string
          dados?: Json
          dedupe_key?: string | null
          id?: string
          lida_em?: string | null
          push_enviado_em?: string | null
          tipo?: string
          titulo?: string
          updated_at?: string
          url?: string | null
          user_id?: string
        }
        Relationships: []
      }
      notificacoes_agendadas: {
        Row: {
          agendada_para: string
          corpo: string
          created_at: string
          enviada_em: string | null
          id: string
          tipo: string
          titulo: string
          url: string | null
          user_id: string
        }
        Insert: {
          agendada_para: string
          corpo: string
          created_at?: string
          enviada_em?: string | null
          id?: string
          tipo?: string
          titulo: string
          url?: string | null
          user_id: string
        }
        Update: {
          agendada_para?: string
          corpo?: string
          created_at?: string
          enviada_em?: string | null
          id?: string
          tipo?: string
          titulo?: string
          url?: string | null
          user_id?: string
        }
        Relationships: []
      }
      pagamentos: {
        Row: {
          aluno_id: string
          created_at: string
          data_pagamento: string
          id: string
          mes_referencia: string
          metodo: string
          observacoes: string
          updated_at: string
          user_id: string
          valor: number
        }
        Insert: {
          aluno_id: string
          created_at?: string
          data_pagamento?: string
          id?: string
          mes_referencia: string
          metodo?: string
          observacoes?: string
          updated_at?: string
          user_id: string
          valor?: number
        }
        Update: {
          aluno_id?: string
          created_at?: string
          data_pagamento?: string
          id?: string
          mes_referencia?: string
          metodo?: string
          observacoes?: string
          updated_at?: string
          user_id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "pagamentos_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "alunos"
            referencedColumns: ["id"]
          },
        ]
      }
      pre_cadastros: {
        Row: {
          aluno_id: string | null
          aluno_nome: string
          autoriza_imagem: boolean | null
          bairro: string
          cep: string
          cidade: string
          created_at: string
          data_nascimento: string | null
          escola: string
          estado: string
          id: string
          numero: string
          observacoes: string
          pessoas_autorizadas: string | null
          referencia: string
          responsavel_cpf: string | null
          responsavel_email: string | null
          responsavel_nome: string
          responsavel_whatsapp: string
          rua: string
          serie: string
          status: string
          telefone_emergencia: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          aluno_id?: string | null
          aluno_nome: string
          autoriza_imagem?: boolean | null
          bairro?: string
          cep?: string
          cidade?: string
          created_at?: string
          data_nascimento?: string | null
          escola?: string
          estado?: string
          id?: string
          numero?: string
          observacoes?: string
          pessoas_autorizadas?: string | null
          referencia?: string
          responsavel_cpf?: string | null
          responsavel_email?: string | null
          responsavel_nome?: string
          responsavel_whatsapp?: string
          rua?: string
          serie?: string
          status?: string
          telefone_emergencia?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          aluno_id?: string | null
          aluno_nome?: string
          autoriza_imagem?: boolean | null
          bairro?: string
          cep?: string
          cidade?: string
          created_at?: string
          data_nascimento?: string | null
          escola?: string
          estado?: string
          id?: string
          numero?: string
          observacoes?: string
          pessoas_autorizadas?: string | null
          referencia?: string
          responsavel_cpf?: string | null
          responsavel_email?: string | null
          responsavel_nome?: string
          responsavel_whatsapp?: string
          rua?: string
          serie?: string
          status?: string
          telefone_emergencia?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pre_cadastros_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "alunos"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          asaas_customer_id: string | null
          asaas_next_due_date: string | null
          asaas_subscription_id: string | null
          assinante_desde: string | null
          blocked_at: string | null
          cancelado_em: string | null
          cidade: string | null
          created_at: string
          email: string | null
          estado: string | null
          last_invoice_url: string | null
          logo: string | null
          next_due_date: string | null
          nome: string | null
          payment_method: string | null
          plan_price: number
          plan_status: string
          subscription_ends_at: string | null
          subscription_started_at: string | null
          subscription_status: string
          subscription_updated_at: string | null
          trial_days_bonus: number
          trial_ends_at: string | null
          trial_started_at: string | null
          ultimo_acesso: string | null
          updated_at: string
          user_id: string
          whatsapp: string | null
          whatsapp_consent: boolean
          whatsapp_consent_at: string | null
        }
        Insert: {
          asaas_customer_id?: string | null
          asaas_next_due_date?: string | null
          asaas_subscription_id?: string | null
          assinante_desde?: string | null
          blocked_at?: string | null
          cancelado_em?: string | null
          cidade?: string | null
          created_at?: string
          email?: string | null
          estado?: string | null
          last_invoice_url?: string | null
          logo?: string | null
          next_due_date?: string | null
          nome?: string | null
          payment_method?: string | null
          plan_price?: number
          plan_status?: string
          subscription_ends_at?: string | null
          subscription_started_at?: string | null
          subscription_status?: string
          subscription_updated_at?: string | null
          trial_days_bonus?: number
          trial_ends_at?: string | null
          trial_started_at?: string | null
          ultimo_acesso?: string | null
          updated_at?: string
          user_id: string
          whatsapp?: string | null
          whatsapp_consent?: boolean
          whatsapp_consent_at?: string | null
        }
        Update: {
          asaas_customer_id?: string | null
          asaas_next_due_date?: string | null
          asaas_subscription_id?: string | null
          assinante_desde?: string | null
          blocked_at?: string | null
          cancelado_em?: string | null
          cidade?: string | null
          created_at?: string
          email?: string | null
          estado?: string | null
          last_invoice_url?: string | null
          logo?: string | null
          next_due_date?: string | null
          nome?: string | null
          payment_method?: string | null
          plan_price?: number
          plan_status?: string
          subscription_ends_at?: string | null
          subscription_started_at?: string | null
          subscription_status?: string
          subscription_updated_at?: string | null
          trial_days_bonus?: number
          trial_ends_at?: string | null
          trial_started_at?: string | null
          ultimo_acesso?: string | null
          updated_at?: string
          user_id?: string
          whatsapp?: string | null
          whatsapp_consent?: boolean
          whatsapp_consent_at?: string | null
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          ativo: boolean
          auth: string
          created_at: string
          endpoint: string
          id: string
          p256dh: string
          ultimo_erro: string | null
          updated_at: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          ativo?: boolean
          auth: string
          created_at?: string
          endpoint: string
          id?: string
          p256dh: string
          ultimo_erro?: string | null
          updated_at?: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          ativo?: boolean
          auth?: string
          created_at?: string
          endpoint?: string
          id?: string
          p256dh?: string
          ultimo_erro?: string | null
          updated_at?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      recibos: {
        Row: {
          aluno_id: string | null
          aluno_nome: string
          created_at: string
          data_pagamento: string
          data_vencimento: string | null
          envios: Json
          escola: string | null
          estornado_em: string | null
          estorno_motivo: string | null
          favorito: boolean
          historico: Json
          id: string
          mes_referencia: string
          metodo: string | null
          numero: string
          observacoes: string | null
          pagamento_id: string | null
          periodo: string | null
          responsavel_cpf: string | null
          responsavel_email: string | null
          responsavel_nome: string | null
          responsavel_telefone: string | null
          responsavel_whatsapp: string | null
          turma: string | null
          updated_at: string
          user_id: string
          valor: number
        }
        Insert: {
          aluno_id?: string | null
          aluno_nome: string
          created_at?: string
          data_pagamento?: string
          data_vencimento?: string | null
          envios?: Json
          escola?: string | null
          estornado_em?: string | null
          estorno_motivo?: string | null
          favorito?: boolean
          historico?: Json
          id?: string
          mes_referencia: string
          metodo?: string | null
          numero: string
          observacoes?: string | null
          pagamento_id?: string | null
          periodo?: string | null
          responsavel_cpf?: string | null
          responsavel_email?: string | null
          responsavel_nome?: string | null
          responsavel_telefone?: string | null
          responsavel_whatsapp?: string | null
          turma?: string | null
          updated_at?: string
          user_id: string
          valor?: number
        }
        Update: {
          aluno_id?: string | null
          aluno_nome?: string
          created_at?: string
          data_pagamento?: string
          data_vencimento?: string | null
          envios?: Json
          escola?: string | null
          estornado_em?: string | null
          estorno_motivo?: string | null
          favorito?: boolean
          historico?: Json
          id?: string
          mes_referencia?: string
          metodo?: string | null
          numero?: string
          observacoes?: string | null
          pagamento_id?: string | null
          periodo?: string | null
          responsavel_cpf?: string | null
          responsavel_email?: string | null
          responsavel_nome?: string | null
          responsavel_telefone?: string | null
          responsavel_whatsapp?: string | null
          turma?: string | null
          updated_at?: string
          user_id?: string
          valor?: number
        }
        Relationships: []
      }
      responsaveis: {
        Row: {
          alunos_ids: string[]
          arquivado_em: string | null
          created_at: string
          email: string | null
          endereco: string
          id: string
          nome: string
          observacoes: string
          pessoas_autorizadas: string | null
          pix: string
          telefone: string
          telefone_emergencia: string | null
          updated_at: string
          user_id: string
          whatsapp: string
        }
        Insert: {
          alunos_ids?: string[]
          arquivado_em?: string | null
          created_at?: string
          email?: string | null
          endereco?: string
          id?: string
          nome: string
          observacoes?: string
          pessoas_autorizadas?: string | null
          pix?: string
          telefone?: string
          telefone_emergencia?: string | null
          updated_at?: string
          user_id: string
          whatsapp?: string
        }
        Update: {
          alunos_ids?: string[]
          arquivado_em?: string | null
          created_at?: string
          email?: string | null
          endereco?: string
          id?: string
          nome?: string
          observacoes?: string
          pessoas_autorizadas?: string | null
          pix?: string
          telefone?: string
          telefone_emergencia?: string | null
          updated_at?: string
          user_id?: string
          whatsapp?: string
        }
        Relationships: []
      }
      retention_surveys: {
        Row: {
          comentario: string | null
          created_at: string
          id: string
          motivos: string[]
          user_id: string
        }
        Insert: {
          comentario?: string | null
          created_at?: string
          id?: string
          motivos?: string[]
          user_id: string
        }
        Update: {
          comentario?: string | null
          created_at?: string
          id?: string
          motivos?: string[]
          user_id?: string
        }
        Relationships: []
      }
      rota_paradas: {
        Row: {
          aluno_id: string | null
          aluno_nome: string
          created_at: string
          desembarcado_em: string | null
          embarcado_em: string | null
          id: string
          ordem: number
          rota_id: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          aluno_id?: string | null
          aluno_nome: string
          created_at?: string
          desembarcado_em?: string | null
          embarcado_em?: string | null
          id?: string
          ordem?: number
          rota_id: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          aluno_id?: string | null
          aluno_nome?: string
          created_at?: string
          desembarcado_em?: string | null
          embarcado_em?: string | null
          id?: string
          ordem?: number
          rota_id?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "rota_paradas_rota_id_fkey"
            columns: ["rota_id"]
            isOneToOne: false
            referencedRelation: "rotas_ativas"
            referencedColumns: ["id"]
          },
        ]
      }
      rotas_ativas: {
        Row: {
          created_at: string
          encerrada_em: string | null
          expira_em: string | null
          id: string
          iniciada_em: string
          motorista_nome: string | null
          revogada_em: string | null
          sentido: string
          turno: string
          ultima_atualizacao: string | null
          ultima_lat: number | null
          ultima_lng: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          encerrada_em?: string | null
          expira_em?: string | null
          id?: string
          iniciada_em?: string
          motorista_nome?: string | null
          revogada_em?: string | null
          sentido?: string
          turno: string
          ultima_atualizacao?: string | null
          ultima_lat?: number | null
          ultima_lng?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          encerrada_em?: string | null
          expira_em?: string | null
          id?: string
          iniciada_em?: string
          motorista_nome?: string | null
          revogada_em?: string | null
          sentido?: string
          turno?: string
          ultima_atualizacao?: string | null
          ultima_lat?: number | null
          ultima_lng?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      rotas_substituto: {
        Row: {
          created_at: string
          expira_em: string
          id: string
          paradas: Json
          revogada_em: string | null
          titular_nome: string | null
          turno: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          expira_em?: string
          id?: string
          paradas?: Json
          revogada_em?: string | null
          titular_nome?: string | null
          turno: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          expira_em?: string
          id?: string
          paradas?: Json
          revogada_em?: string | null
          titular_nome?: string | null
          turno?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      saude_van_snapshots: {
        Row: {
          created_at: string
          id: string
          mes_referencia: string
          score: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          mes_referencia: string
          score: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          mes_referencia?: string
          score?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_events: {
        Row: {
          created_at: string
          descricao: string | null
          id: string
          metadata: Json | null
          tipo: string
          user_id: string
        }
        Insert: {
          created_at?: string
          descricao?: string | null
          id?: string
          metadata?: Json | null
          tipo: string
          user_id: string
        }
        Update: {
          created_at?: string
          descricao?: string | null
          id?: string
          metadata?: Json | null
          tipo?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      assinar_documento_responsavel: {
        Args: { _id: string; _imagem: string; _nome: string; _tipo: string }
        Returns: Json
      }
      get_documento_assinatura: {
        Args: { _id: string; _tipo: string }
        Returns: Json
      }
      get_escolas_publicas: {
        Args: { _user_id: string }
        Returns: {
          nome: string
        }[]
      }
      get_rota_publica: {
        Args: { _id: string }
        Returns: {
          encerrada_em: string
          expira_em: string
          id: string
          iniciada_em: string
          motorista_nome: string
          revogada_em: string
          turno: string
          ultima_atualizacao: string
          ultima_lat: number
          ultima_lng: number
        }[]
      }
      get_rota_status: {
        Args: { _parada?: string; _rota: string }
        Returns: Json
      }
      get_rota_substituto: { Args: { _id: string }; Returns: Json }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "motorista"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "motorista"],
    },
  },
} as const
