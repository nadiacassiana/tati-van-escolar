import { describe, expect, it } from "vitest";
import { computeAccountStatus } from "./account-status";

const iso = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

function due(offsetDays: number) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return iso(d);
}

const assinante = (nextDue: string | null) => ({
  plan_status: "ativo",
  asaas_subscription_id: "sub_1",
  next_due_date: nextDue,
  created_at: "2025-01-01T00:00:00Z",
});

describe("fluxo de mensalidade do assinante", () => {
  it("pagamento em dia: acesso liberado, sem aviso", () => {
    const s = computeAccountStatus(assinante(due(10)));
    expect(s.phase).toBe("ativo");
    expect(s.isReadOnly).toBe(false);
  });

  it("vence hoje: aviso com acesso liberado", () => {
    const s = computeAccountStatus(assinante(due(0)));
    expect(s.phase).toBe("mensalidade_vencida");
    expect(s.graceDaysLeft).toBe(3);
    expect(s.isReadOnly).toBe(false);
  });

  it.each([
    [1, 2],
    [2, 1],
    [3, 0],
  ])("dia %i de atraso mantém acesso com %i dias de tolerância", (atraso, restantes) => {
    const s = computeAccountStatus(assinante(due(-atraso)));
    expect(s.phase).toBe("mensalidade_vencida");
    expect(s.graceDaysLeft).toBe(restantes);
    expect(s.isReadOnly).toBe(false);
  });

  it("após a tolerância: pausada por inadimplência (somente leitura)", () => {
    const s = computeAccountStatus(assinante(due(-4)));
    expect(s.phase).toBe("inadimplente");
    expect(s.isReadOnly).toBe(true);
  });

  it("pagamento confirmado libera a conta novamente", () => {
    const s = computeAccountStatus(assinante(due(27)));
    expect(s.phase).toBe("ativo");
    expect(s.isReadOnly).toBe(false);
  });

  it("assinante sem vencimento registrado nunca é bloqueado", () => {
    const s = computeAccountStatus(assinante(null));
    expect(s.phase).toBe("ativo");
  });

  it("não altera o fluxo do teste gratuito", () => {
    const s = computeAccountStatus({ created_at: new Date().toISOString() });
    expect(s.phase).toBe("trial");
    expect(s.isReadOnly).toBe(false);
  });
});
