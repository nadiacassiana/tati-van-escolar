// Regras do período de teste da Tati Van Escolar
// - 10 dias de teste a partir da ativação da conta (+ bônus concedido pelo admin)
// - 3 dias corridos de tolerância após o fim do teste (uso normal + aviso)
// - Depois disso a conta entra em modo "Conta pausada" (somente leitura)
// Assinantes ativos não são afetados por estas regras.

export const TRIAL_DAYS = 10;
export const GRACE_DAYS = 3;
/** Dias de tolerância após o vencimento da mensalidade do assinante */
export const PAYMENT_GRACE_DAYS = 3;

export type AccountPhase =
  | "ativo"
  | "trial"
  | "tolerancia"
  | "pausada"
  /** Assinante com mensalidade vencida, dentro da tolerância (uso liberado) */
  | "mensalidade_vencida"
  /** Assinante inadimplente após a tolerância (somente leitura) */
  | "inadimplente";

export type AccountProfile = {
  plan_status?: string | null;
  subscription_status?: string | null;
  asaas_subscription_id?: string | null;
  asaas_next_due_date?: string | null;
  next_due_date?: string | null;
  payment_method?: string | null;
  trial_started_at?: string | null;
  trial_ends_at?: string | null;
  trial_days_bonus?: number | null;
  created_at?: string | null;
};

export type AccountStatus = {
  phase: AccountPhase;
  /** Fim do período de teste (10 dias + bônus) */
  trialEndsAt: Date | null;
  /** Fim da tolerância de 3 dias */
  graceEndsAt: Date | null;
  /** Dias restantes de tolerância (0 = último dia) */
  graceDaysLeft: number;
  /** Somente leitura: nenhuma alteração de dados é permitida */
  isReadOnly: boolean;
  /** Vencimento da mensalidade do assinante (quando houver) */
  dueDate?: Date | null;
  /** Dias de atraso da mensalidade (0 = vence hoje) */
  overdueDays?: number;
};


function startOfDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

/** Último instante do dia (23:59:59.999) — a tolerância vale o dia inteiro. */
function endOfDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);
}

/** Converte "YYYY-MM-DD" (ou ISO) em data local, sem deslocamento de fuso. */
function parseDate(value?: string | null): Date | null {
  if (!value) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (m) return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}

/**
 * Fluxo do assinante: mensalidade vence → avisos → 3 dias de tolerância →
 * pausa por inadimplência. Independente do fluxo do período de teste.
 */
function computeAssinanteStatus(
  profile: AccountProfile,
  now: Date,
  base: AccountStatus,
): AccountStatus {
  const cancelado = profile.plan_status === "cancelado";
  const dueDate = parseDate(profile.asaas_next_due_date || profile.next_due_date);

  // Sem vencimento registrado: nada a cobrar (nunca bloquear por engano).
  if (!dueDate || cancelado) return { ...base, phase: "ativo", dueDate };

  const overdueDays = Math.floor((startOfDay(now) - startOfDay(dueDate)) / 86_400_000);
  if (overdueDays < 0) return { ...base, phase: "ativo", dueDate, overdueDays: 0 };

  const graceRef = new Date(dueDate);
  graceRef.setDate(graceRef.getDate() + PAYMENT_GRACE_DAYS);
  const graceEndsAt = endOfDay(graceRef);

  if (now.getTime() <= graceEndsAt.getTime()) {
    return {
      ...base,
      phase: "mensalidade_vencida",
      graceEndsAt,
      graceDaysLeft: Math.max(0, PAYMENT_GRACE_DAYS - overdueDays),
      dueDate,
      overdueDays,
    };
  }

  return {
    ...base,
    phase: "inadimplente",
    graceEndsAt,
    graceDaysLeft: 0,
    isReadOnly: true,
    dueDate,
    overdueDays,
  };
}

export function computeAccountStatus(

  profile: AccountProfile | null | undefined,
  now: Date = new Date(),
): AccountStatus {
  const base: AccountStatus = {
    phase: "trial",
    trialEndsAt: null,
    graceEndsAt: null,
    graceDaysLeft: GRACE_DAYS,
    isReadOnly: false,
  };

  if (!profile) return { ...base, phase: "ativo" };

  // Assinantes (inclusive pagamento manual registrado pela administração)
  const assinante =
    profile.plan_status === "ativo" ||
    !!profile.asaas_subscription_id ||
    profile.payment_method === "MANUAL";
  if (assinante) return computeAssinanteStatus(profile, now, base);


  const startISO = profile.trial_started_at || profile.created_at;
  if (!startISO) return { ...base, phase: "trial" };

  let trialEndsAt: Date;
  if (profile.trial_ends_at) {
    trialEndsAt = new Date(profile.trial_ends_at);
  } else {
    trialEndsAt = new Date(startISO);
    trialEndsAt.setDate(trialEndsAt.getDate() + TRIAL_DAYS);
  }
  const bonus = Number(profile.trial_days_bonus || 0);
  if (bonus > 0) trialEndsAt.setDate(trialEndsAt.getDate() + bonus);

  // A tolerância vale por 3 dias corridos completos: se o teste terminou em 31/07,
  // os dias 01/08, 02/08 e 03/08 são de tolerância e a pausa ocorre só em 04/08 00:00.
  const graceRef = new Date(trialEndsAt);
  graceRef.setDate(graceRef.getDate() + GRACE_DAYS);
  const graceEndsAt = endOfDay(graceRef);

  if (now.getTime() < trialEndsAt.getTime()) {
    return { ...base, phase: "trial", trialEndsAt, graceEndsAt };
  }

  if (now.getTime() <= graceEndsAt.getTime()) {
    // Inclui o dia atual: no último dia de tolerância resta 1 dia.
    const graceDaysLeft = Math.min(
      GRACE_DAYS,
      Math.max(1, Math.round((startOfDay(graceEndsAt) - startOfDay(now)) / 86_400_000) + 1),
    );
    return { phase: "tolerancia", trialEndsAt, graceEndsAt, graceDaysLeft, isReadOnly: false };
  }

  return { phase: "pausada", trialEndsAt, graceEndsAt, graceDaysLeft: 0, isReadOnly: true };
}
