import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (error) throw new Error(`Falha ao validar papel: ${error.message}`);
  if (!data) throw new Error("Forbidden: acesso restrito a administradores.");
}

export const adminExtendTrial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { user_id: string; days: number }) => ({
    user_id: String(d.user_id),
    days: Math.max(1, Math.min(365, Math.floor(Number(d.days) || 0))),
  }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: p, error: e1 } = await (supabaseAdmin as any)
      .from("profiles").select("trial_days_bonus").eq("user_id", data.user_id).maybeSingle();
    if (e1) throw new Error(e1.message);
    const atual = Number(p?.trial_days_bonus ?? 0);
    const { error } = await (supabaseAdmin as any).from("profiles")
      .update({ trial_days_bonus: atual + data.days, plan_status: "trial" })
      .eq("user_id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true, novo_bonus: atual + data.days };
  });

export const adminResetTrial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { user_id: string }) => ({ user_id: String(d.user_id) }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any).from("profiles").update({
      trial_started_at: new Date().toISOString(),
      trial_days_bonus: 0,
      plan_status: "trial",
      cancelado_em: null,
    }).eq("user_id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const ASAAS_BASE_URL = "https://api.asaas.com/v3";
const PLAN_PRICE = 29.9;

function asaasHeaders() {
  const key = process.env.ASAAS_API_KEY;
  if (!key) throw new Error("ASAAS_API_KEY não configurada.");
  return {
    "Content-Type": "application/json",
    access_token: key,
    "User-Agent": "TatiVanEscolar/1.0 (admin)",
  } as Record<string, string>;
}

async function asaasFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${ASAAS_BASE_URL}${path}`, {
    ...init,
    headers: { ...asaasHeaders(), ...(init?.headers as Record<string, string> | undefined) },
  });
  const text = await res.text();
  if (!res.ok) {
    console.error(`[asaas-admin] ${res.status} ${path}: ${text}`);
    throw new Error(`Asaas API ${res.status}: ${text.slice(0, 300)}`);
  }
  return JSON.parse(text) as T;
}

export const adminMarkManualPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { user_id: string; next_due_date: string }) => {
    const nextDueDate = String(d.next_due_date || "").trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(nextDueDate)) {
      throw new Error("Data do próximo vencimento inválida (use AAAA-MM-DD).");
    }
    return { user_id: String(d.user_id), next_due_date: nextDueDate };
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const now = new Date().toISOString();
    const { error } = await (supabaseAdmin as any).from("profiles").update({
      plan_status: "ativo",
      assinante_desde: now,
      cancelado_em: null,
      payment_method: "MANUAL",
      subscription_status: "ACTIVE",
      next_due_date: data.next_due_date,
      subscription_updated_at: now,
    }).eq("user_id", data.user_id);
    if (error) throw new Error(error.message);

    await (supabaseAdmin as any).from("user_events").insert({
      user_id: data.user_id,
      tipo: "admin_pagamento_manual",
      descricao: `Pagamento manual registrado. Próximo vencimento ${data.next_due_date}`,
    });
    return { ok: true, next_due_date: data.next_due_date };
  });

export const adminConvertToSubscriber = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: {
    user_id: string;
    next_due_date: string; // yyyy-mm-dd
    cpf_cnpj?: string;
    person_type?: "PF" | "PJ";
  }) => {
    const nextDueDate = String(d.next_due_date || "").trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(nextDueDate)) {
      throw new Error("Data da primeira cobrança inválida (use AAAA-MM-DD).");
    }
    // Não permite data no passado (comparação por dia UTC).
    const hoje = new Date().toISOString().slice(0, 10);
    if (nextDueDate < hoje) {
      throw new Error("A data da primeira cobrança não pode estar no passado.");
    }
    return {
      user_id: String(d.user_id),
      next_due_date: nextDueDate,
      cpf_cnpj: d.cpf_cnpj ? String(d.cpf_cnpj).replace(/\D/g, "") : "",
      person_type: d.person_type === "PJ" ? ("PJ" as const) : ("PF" as const),
    };
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Carrega perfil-alvo
    const { data: perfil, error: pErr } = await (supabaseAdmin as any)
      .from("profiles")
      .select("nome, email, whatsapp, asaas_customer_id, asaas_subscription_id")
      .eq("user_id", data.user_id)
      .maybeSingle();
    if (pErr) throw new Error(`Falha ao carregar perfil: ${pErr.message}`);
    if (!perfil) throw new Error("Perfil não encontrado.");

    // Impede duplicidade — se já houver assinatura, apenas atualiza status local.
    let subscriptionId: string | null = perfil.asaas_subscription_id ?? null;
    let customerId: string | null = perfil.asaas_customer_id ?? null;

    if (!subscriptionId) {
      // Cria cliente no Asaas se ainda não existir
      if (!customerId) {
        if (!data.cpf_cnpj || data.cpf_cnpj.length < 11) {
          throw new Error("CPF/CNPJ é obrigatório para criar a cliente no Asaas.");
        }
        const nome = perfil.nome || perfil.email || "Assinante Tati Van";
        const phone = (perfil.whatsapp || "").replace(/\D/g, "");
        const customer = await asaasFetch<{ id: string }>("/customers", {
          method: "POST",
          body: JSON.stringify({
            name: nome,
            email: perfil.email || undefined,
            cpfCnpj: data.cpf_cnpj,
            mobilePhone: phone || undefined,
            personType: data.person_type === "PJ" ? "JURIDICA" : "FISICA",
            notificationDisabled: false,
            externalReference: data.user_id,
          }),
        });
        customerId = customer.id;
      }

      // Cria assinatura com a data informada como primeira cobrança
      const sub = await asaasFetch<{ id: string; status: string; nextDueDate: string }>(
        "/subscriptions",
        {
          method: "POST",
          body: JSON.stringify({
            customer: customerId,
            billingType: "UNDEFINED",
            value: PLAN_PRICE,
            nextDueDate: data.next_due_date,
            cycle: "MONTHLY",
            description: "Assinatura Tati Van Escolar (conversão administrativa)",
            externalReference: data.user_id,
          }),
        },
      );
      subscriptionId = sub.id;
    }

    // Atualiza perfil local
    const { error: upErr } = await (supabaseAdmin as any).from("profiles").update({
      plan_status: "ativo",
      assinante_desde: new Date().toISOString(),
      cancelado_em: null,
      asaas_customer_id: customerId,
      asaas_subscription_id: subscriptionId,
      subscription_status: "ACTIVE",
      next_due_date: data.next_due_date,
      subscription_updated_at: new Date().toISOString(),
    }).eq("user_id", data.user_id);
    if (upErr) throw new Error(upErr.message);

    // Log administrativo
    await (supabaseAdmin as any).from("user_events").insert({
      user_id: data.user_id,
      tipo: "admin_converteu_assinante",
      descricao: `Conversão administrativa. Assinatura ${subscriptionId} · 1ª cobrança ${data.next_due_date}`,
    });

    return { ok: true, subscription_id: subscriptionId, customer_id: customerId };
  });

export const adminSetBlocked = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { user_id: string; blocked: boolean }) => ({
    user_id: String(d.user_id),
    blocked: !!d.blocked,
  }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await (supabaseAdmin as any).from("profiles")
      .update({ blocked_at: data.blocked ? new Date().toISOString() : null })
      .eq("user_id", data.user_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/**
 * Concede cortesia (liberação manual): ativa a conta por +30 dias a partir
 * de hoje, sem criar/alterar nada no Asaas. Apenas banco local.
 */
export const adminGiveCourtesy = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { user_id: string }) => ({ user_id: String(d.user_id) }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const base = new Date();
    base.setUTCDate(base.getUTCDate() + 30);
    const nextDue = base.toISOString().slice(0, 10);
    const now = new Date().toISOString();

    const { error } = await (supabaseAdmin as any).from("profiles").update({
      plan_status: "ativo",
      assinante_desde: now,
      cancelado_em: null,
      blocked_at: null,
      payment_method: "CORTESIA",
      subscription_status: "ACTIVE",
      next_due_date: nextDue,
      asaas_next_due_date: nextDue,
      subscription_updated_at: now,
    }).eq("user_id", data.user_id);
    if (error) throw new Error(error.message);

    await (supabaseAdmin as any).from("user_events").insert({
      user_id: data.user_id,
      tipo: "admin_cortesia",
      descricao: `Cortesia concedida pelo administrador. Acesso liberado até ${nextDue}.`,
    });
    return { ok: true, next_due_date: nextDue };
  });

export const adminDeleteUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { user_id: string }) => ({ user_id: String(d.user_id) }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    if (data.user_id === context.userId) {
      throw new Error("Você não pode excluir a própria conta pelo painel administrativo.");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Snapshot do perfil para o histórico
    const { data: perfil } = await (supabaseAdmin as any)
      .from("profiles")
      .select("nome, email, whatsapp, cidade, estado, plan_status, created_at")
      .eq("user_id", data.user_id).maybeSingle();

    const cadastroEm: string | null = perfil?.created_at ?? null;
    const diasPermanencia = cadastroEm
      ? Math.max(0, Math.floor((Date.now() - new Date(cadastroEm).getTime()) / 86_400_000))
      : null;

    await (supabaseAdmin as any).from("deleted_accounts").insert({
      user_id: data.user_id,
      nome: perfil?.nome ?? null,
      email: perfil?.email ?? null,
      whatsapp: perfil?.whatsapp ?? null,
      cidade: perfil?.cidade ?? null,
      estado: perfil?.estado ?? null,
      cadastro_em: cadastroEm,
      dias_permanencia: diasPermanencia,
      status_no_momento: perfil?.plan_status ?? null,
      motivo: "admin",
      motivo_texto: "Excluído pelo painel administrativo",
    });

    const tables = [
      "recibos", "pagamentos", "gastos", "documentos", "contratos",
      "mensagens_historico", "mensagens", "rotas_ativas",
      "saude_van_snapshots", "responsaveis", "alunos",
    ];
    for (const t of tables) {
      const { error } = await (supabaseAdmin as any).from(t).delete().eq("user_id", data.user_id);
      if (error) throw new Error(`Falha ao remover ${t}: ${(error as any).message}`);
    }
    const { error: delErr } = await supabaseAdmin.auth.admin.deleteUser(data.user_id);
    if (delErr) throw new Error(`Falha ao remover conta: ${delErr.message}`);
    return { ok: true };
  });

/**
 * Sincroniza a coluna "Próx. cobrança" com o Asaas.
 * A data exibida é sempre a PRIMEIRA cobrança em aberto da assinatura.
 * Nunca calcular a data manualmente.
 */
export const adminSyncAsaasDueDates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { getFirstOpenPayment } = await import("@/lib/asaas-due.server");

    const { data: perfis, error } = await (supabaseAdmin as any)
      .from("profiles")
      .select("user_id, asaas_subscription_id")
      .not("asaas_subscription_id", "is", null);
    if (error) throw new Error(error.message);

    const result: Record<string, string | null> = {};
    for (const p of (perfis ?? []) as { user_id: string; asaas_subscription_id: string }[]) {
      try {
        const pay = await getFirstOpenPayment(p.asaas_subscription_id);
        result[p.user_id] = pay?.dueDate ?? null;
        await (supabaseAdmin as any)
          .from("profiles")
          .update({
            asaas_next_due_date: pay?.dueDate ?? null,
            next_due_date: pay?.dueDate ?? null,
            last_invoice_url: pay?.invoiceUrl ?? null,
            subscription_updated_at: new Date().toISOString(),
          })
          .eq("user_id", p.user_id);
      } catch (e) {
        console.error(`[asaas-due] falha ao sincronizar ${p.user_id}:`, e);
      }
    }
    return { ok: true, due_dates: result };
  });
