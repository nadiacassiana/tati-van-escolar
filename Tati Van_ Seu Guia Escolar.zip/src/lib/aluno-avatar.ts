// Avatar padrão inteligente por sexo do aluno.
// Usado sempre que o aluno ainda não tem foto cadastrada.
export type Sexo = "masculino" | "feminino" | null | undefined;

export const AVATAR_MENINO = "/avatars/avatar-menino.svg";
export const AVATAR_MENINA = "/avatars/avatar-menina.svg";

export function avatarPorSexo(sexo: Sexo): string | undefined {
  if (sexo === "masculino") return AVATAR_MENINO;
  if (sexo === "feminino") return AVATAR_MENINA;
  return undefined;
}

export function isAvatarUrl(value: string): boolean {
  return value.startsWith("/") || value.startsWith("http://") || value.startsWith("https://");
}

