/**
 * Simulação de aniversário (server-only) — APENAS TESTE.
 *
 * Não altera nenhum dado de aluno: apenas dispara o mesmo fluxo
 * (notificação interna + push real) que aconteceria no dia do aniversário.
 */
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { criarNotificacao } from "./push.server";

type AlunoRow = { id: string; nome: string };

export async function simularAniversario(
  userId: string,
  nomeBusca?: string,
): Promise<{ ok: boolean; aluno: string | null; enviados: number; falhas: number }> {
  let aluno: AlunoRow | null = null;

  if (nomeBusca && nomeBusca.trim()) {
    const { data } = await supabaseAdmin
      .from("alunos")
      .select("id, nome")
      .eq("user_id", userId)
      .ilike("nome", `%${nomeBusca.trim()}%`)
      .limit(1);
    aluno = ((data ?? []) as AlunoRow[])[0] ?? null;
  }

  if (!aluno) {
    const { data } = await supabaseAdmin
      .from("alunos")
      .select("id, nome")
      .eq("user_id", userId)
      .is("arquivado_em", null)
      .order("nome")
      .limit(1);
    aluno = ((data ?? []) as AlunoRow[])[0] ?? null;
  }

  const nome = aluno?.nome ?? "Ana Beatriz Souza";
  const carimbo = new Date().toISOString().slice(0, 16); // evita duplicidade no mesmo minuto

  const res = await criarNotificacao({
    userId,
    tipo: "aniversario_aluno",
    titulo: "Hoje é aniversário!",
    corpo: `Hoje é aniversário da aluna ${nome}! 🎉 Que tal enviar uma mensagem de felicitações?`,
    url: "/dashboard#aniversariantes",
    dados: { simulacao: true, aluno_id: aluno?.id ?? null, aluno_nome: nome },
    dedupeKey: `simulacao-aniversario:${aluno?.id ?? "demo"}:${carimbo}`,
  });

  return {
    ok: true,
    aluno: nome,
    enviados: res.push?.enviados ?? 0,
    falhas: res.push?.falhas ?? 0,
  };
}
