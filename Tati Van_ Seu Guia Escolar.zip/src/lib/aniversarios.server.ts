/** Geração das notificações de aniversário (server-only). */
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { criarNotificacao } from "./push.server";
import { hojeBrasil, parseAniversario } from "./aniversarios";

type AlunoRow = { id: string; user_id: string; nome: string; aniversario: string | null; arquivado_em: string | null };

function tituloEcorpo(nome: string) {
  return {
    titulo: "Hoje é aniversário!",
    corpo: `${nome} faz aniversário hoje. Que tal enviar uma mensagem de felicitações? 🎉`,
  };
}

/** Cria as notificações de aniversário de HOJE para um motorista específico. */
export async function sincronizarAniversariosDoUsuario(userId: string): Promise<number> {
  const hoje = hojeBrasil();
  const { data } = await supabaseAdmin
    .from("alunos")
    .select("id, user_id, nome, aniversario, arquivado_em")
    .eq("user_id", userId);

  const alunos = ((data ?? []) as AlunoRow[]).filter((a) => {
    if (a.arquivado_em) return false;
    const dm = parseAniversario(a.aniversario);
    return !!dm && dm.dia === hoje.dia && dm.mes === hoje.mes;
  });

  let criadas = 0;
  for (const aluno of alunos) {
    const { titulo, corpo } = tituloEcorpo(aluno.nome);
    const res = await criarNotificacao({
      userId,
      tipo: "aniversario_aluno",
      titulo,
      corpo,
      url: "/dashboard#aniversariantes",
      dados: { aluno_id: aluno.id, aluno_nome: aluno.nome },
      dedupeKey: `aniversario:${aluno.id}:${hoje.iso}`,
    });
    if (res.criada) criadas += 1;
  }
  return criadas;
}

/** Varredura diária: todos os motoristas com aniversariante hoje. */
export async function sincronizarAniversariosDeTodos(): Promise<{ usuarios: number; notificacoes: number }> {
  const hoje = hojeBrasil();
  const { data } = await supabaseAdmin
    .from("alunos")
    .select("id, user_id, nome, aniversario, arquivado_em");

  const alunos = ((data ?? []) as AlunoRow[]).filter((a) => {
    if (a.arquivado_em) return false;
    const dm = parseAniversario(a.aniversario);
    return !!dm && dm.dia === hoje.dia && dm.mes === hoje.mes;
  });

  let notificacoes = 0;
  const usuarios = new Set<string>();
  for (const aluno of alunos) {
    usuarios.add(aluno.user_id);
    const { titulo, corpo } = tituloEcorpo(aluno.nome);
    const res = await criarNotificacao({
      userId: aluno.user_id,
      tipo: "aniversario_aluno",
      titulo,
      corpo,
      url: "/dashboard#aniversariantes",
      dados: { aluno_id: aluno.id, aluno_nome: aluno.nome },
      dedupeKey: `aniversario:${aluno.id}:${hoje.iso}`,
    });
    if (res.criada) notificacoes += 1;
  }
  return { usuarios: usuarios.size, notificacoes };
}
