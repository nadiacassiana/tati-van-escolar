/** Utilidades de aniversário (puras — usadas no cliente e no servidor). */

export type DiaMes = { dia: number; mes: number };

/**
 * Aceita "DD/MM/AAAA", "DD/MM" ou "AAAA-MM-DD" e devolve apenas dia/mês.
 * O ano de nascimento nunca impede o aniversário anual.
 */
export function parseAniversario(valor: string | null | undefined): DiaMes | null {
  if (!valor) return null;
  const iso = valor.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (iso) return { dia: Number(iso[3]), mes: Number(iso[2]) };
  const br = valor.match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?$/);
  if (br) return { dia: Number(br[1]), mes: Number(br[2]) };
  return null;
}

/** Data "de hoje" no fuso de São Paulo (o app é 100% Brasil). */
export function hojeBrasil(agora: Date = new Date()): DiaMes & { iso: string } {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  const iso = fmt.format(agora); // AAAA-MM-DD
  const [, m, d] = iso.split("-");
  return { dia: Number(d), mes: Number(m), iso };
}

export function formatDiaMes(dm: DiaMes): string {
  return `${String(dm.dia).padStart(2, "0")}/${String(dm.mes).padStart(2, "0")}`;
}

export function ehAniversarioHoje(valor: string | null | undefined, agora?: Date): boolean {
  const dm = parseAniversario(valor);
  if (!dm) return false;
  const hoje = hojeBrasil(agora);
  return dm.dia === hoje.dia && dm.mes === hoje.mes;
}

/** Mensagem padrão (editável pela motorista antes de abrir o WhatsApp). */
export function mensagemAniversario(nomeAluno: string, assinatura = "Tia da Van 🚐💙"): string {
  const primeiro = (nomeAluno || "").trim().split(/\s+/).slice(0, 2).join(" ") || "aluno(a)";
  return [
    `🎉🎂 Feliz aniversário, ${primeiro}! 🎂🎉`,
    "",
    "Hoje é um dia muito especial e queremos desejar a você um aniversário cheio de alegria, carinho, saúde e muitos momentos felizes! 🥳🎈💖",
    "",
    "Que seu novo ano seja repleto de coisas boas, muitos sorrisos, sonhos realizados e muitas bênçãos! ✨🎁🌸",
    "",
    `Parabéns, ${primeiro}! Aproveite muito o seu dia! 🎉🎂🎈💕`,
    "",
    "Com carinho,",
    assinatura,
  ].join("\n");
}
