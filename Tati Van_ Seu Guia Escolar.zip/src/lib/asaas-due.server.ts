// Regra de negócio: a próxima cobrança SEMPRE vem do Asaas.
// Nunca calcular a data manualmente.
//
// Buscamos a primeira cobrança em aberto (OVERDUE ou PENDING) da assinatura,
// ordenada pelo vencimento mais antigo. O campo `nextDueDate` da assinatura
// aponta para a PRÓXIMA fatura a ser gerada (a seguinte), por isso não é usado.

const ASAAS_BASE_URL = "https://api.asaas.com/v3";

export type AsaasOpenPayment = {
  id: string;
  status: string;
  billingType?: string;
  invoiceUrl?: string;
  dueDate: string; // yyyy-mm-dd
};

async function fetchPayments(path: string): Promise<AsaasOpenPayment[]> {
  const key = process.env.ASAAS_API_KEY;
  if (!key) throw new Error("ASAAS_API_KEY não configurada.");
  const res = await fetch(`${ASAAS_BASE_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      access_token: key,
      "User-Agent": "TatiVanEscolar/1.0",
    },
  });
  const text = await res.text();
  if (!res.ok) {
    console.error(`[asaas-due] ${res.status} ${path}: ${text}`);
    throw new Error(`Asaas API ${res.status}: ${text.slice(0, 300)}`);
  }
  const json = JSON.parse(text) as { data?: AsaasOpenPayment[] };
  return json.data ?? [];
}

/**
 * Retorna a primeira cobrança pendente/vencida da assinatura (a mais antiga em aberto).
 * Retorna null quando não há nenhuma cobrança em aberto.
 */
export async function getFirstOpenPayment(
  subscriptionId: string,
): Promise<AsaasOpenPayment | null> {
  const [overdue, pending] = await Promise.all([
    fetchPayments(
      `/payments?subscription=${encodeURIComponent(subscriptionId)}&status=OVERDUE&limit=100`,
    ).catch(() => [] as AsaasOpenPayment[]),
    fetchPayments(
      `/payments?subscription=${encodeURIComponent(subscriptionId)}&status=PENDING&limit=100`,
    ).catch(() => [] as AsaasOpenPayment[]),
  ]);
  const abertas = [...overdue, ...pending].filter((p) => !!p.dueDate);
  if (abertas.length === 0) return null;
  abertas.sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  return abertas[0] ?? null;
}
