// Ajuste do próximo vencimento da assinatura no Asaas após reativação.
// Usado apenas quando a conta estava pausada por falta de pagamento e o
// pagamento foi confirmado — inicia um novo ciclo de 30 dias.

const ASAAS_BASE_URL = "https://api.asaas.com/v3";

export async function atualizarNextDueDateAsaas(
  subscriptionId: string,
  nextDueDate: string,
): Promise<boolean> {
  const key = process.env.ASAAS_API_KEY;
  if (!key) return false;
  try {
    const res = await fetch(`${ASAAS_BASE_URL}/subscriptions/${subscriptionId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        access_token: key,
        "User-Agent": "TatiVanEscolar/1.0",
      },
      body: JSON.stringify({ nextDueDate, updatePendingPayments: true }),
    });
    if (!res.ok) {
      console.error(`[asaas-renovacao] ${res.status}: ${(await res.text()).slice(0, 200)}`);
      return false;
    }
    return true;
  } catch (e) {
    console.error("[asaas-renovacao] falha ao atualizar vencimento:", e);
    return false;
  }
}
