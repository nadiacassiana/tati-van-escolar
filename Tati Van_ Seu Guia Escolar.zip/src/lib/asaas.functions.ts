import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { isValidCPF, isValidCNPJ } from "@/lib/cpf-cnpj";

// Integração Asaas — Produção (https://api.asaas.com/v3)
// Plano Tati Van: R$ 29,90/mês, 10 dias de teste gratuito.
// billingType = "UNDEFINED" → o Asaas gera a fatura com PIX, Boleto e Cartão
// e o assinante escolhe a forma na página de pagamento hospedada.

const ASAAS_BASE_URL = "https://api.asaas.com/v3";
const PLAN_PRICE = 29.9;
const TRIAL_DAYS = 10;

type AsaasCustomer = { id: string; name: string; email: string };
type AsaasSubscription = {
  id: string;
  status: string;
  nextDueDate: string;
  billingType: string;
  value: number;
};
type AsaasPayment = {
  id: string;
  status: string;
  billingType: string;
  invoiceUrl?: string;
  dueDate?: string;
};

function apiHeaders() {
  const key = process.env.ASAAS_API_KEY;
  if (!key) throw new Error("ASAAS_API_KEY não configurada.");
  return {
    "Content-Type": "application/json",
    access_token: key,
    "User-Agent": "TatiVanEscolar/1.0",
  } as Record<string, string>;
}

async function asaasFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${ASAAS_BASE_URL}${path}`, {
    ...init,
    headers: { ...apiHeaders(), ...(init?.headers as Record<string, string> | undefined) },
  });
  const text = await res.text();
  if (!res.ok) {
    console.error(`[asaas] ${res.status} ${path}: ${text}`);
    throw new Error(`Asaas API ${res.status}: ${text.slice(0, 300)}`);
  }
  return JSON.parse(text) as T;
}

function addDaysISO(days: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10); // yyyy-mm-dd
}

export const createAsaasSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: {
    personType: "PF" | "PJ";
    cpfCnpj: string;
    name: string;
    phone?: string;
    startNow?: boolean;
  }) => input)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const cpfCnpj = (data.cpfCnpj || "").replace(/\D/g, "");
    if (data.personType === "PF" && !isValidCPF(cpfCnpj)) {
      throw new Error("CPF inválido. Verifique os números informados e tente novamente.");
    }
    if (data.personType === "PJ" && !isValidCNPJ(cpfCnpj)) {
      throw new Error("CNPJ inválido. Verifique os números informados e tente novamente.");
    }

    // Carrega perfil
    const { data: profile, error: profErr } = await supabase
      .from("profiles")
      .select("email, nome, whatsapp, asaas_customer_id, asaas_subscription_id")
      .eq("user_id", userId)
      .maybeSingle();
    if (profErr) throw new Error(`Falha ao carregar perfil: ${profErr.message}`);
    if (!profile) throw new Error("Perfil não encontrado.");

    // Se já existe assinatura ativa, retorna dados atuais
    if (profile.asaas_subscription_id) {
      const sub = await asaasFetch<AsaasSubscription>(
        `/subscriptions/${profile.asaas_subscription_id}`,
      );
      return {
        alreadySubscribed: true,
        subscriptionId: sub.id,
        status: sub.status,
        nextDueDate: sub.nextDueDate,
        invoiceUrl: null as string | null,
      };
    }

    const email = profile.email ?? "";
    const phone = (data.phone ?? profile.whatsapp ?? "").replace(/\D/g, "");

    // 1) Cria ou reaproveita customer
    let customerId = profile.asaas_customer_id;
    if (!customerId) {
      const customer = await asaasFetch<AsaasCustomer>("/customers", {
        method: "POST",
        body: JSON.stringify({
          name: data.name,
          email,
          cpfCnpj,
          mobilePhone: phone || undefined,
          personType: data.personType === "PJ" ? "JURIDICA" : "FISICA",
          notificationDisabled: false,
        }),
      });
      customerId = customer.id;
    }

    // 2) Cria a assinatura (primeira cobrança hoje quando startNow=true — usado após
    // pagamento manual registrado pela administradora; caso contrário, após o trial de 10 dias)
    const nextDueDate = data.startNow ? addDaysISO(0) : addDaysISO(TRIAL_DAYS);
    const subscription = await asaasFetch<AsaasSubscription>("/subscriptions", {
      method: "POST",
      body: JSON.stringify({
        customer: customerId,
        billingType: "UNDEFINED", // cliente escolhe PIX/Boleto/Cartão na fatura
        value: PLAN_PRICE,
        nextDueDate,
        cycle: "MONTHLY",
        description: "Assinatura Tati Van Escolar",
        externalReference: userId,
      }),
    });

    // 3) Tenta obter a URL da primeira fatura para exibir "Pagar agora"
    let invoiceUrl: string | null = null;
    try {
      const payments = await asaasFetch<{ data: AsaasPayment[] }>(
        `/subscriptions/${subscription.id}/payments?limit=1`,
      );
      invoiceUrl = payments.data?.[0]?.invoiceUrl ?? null;
    } catch (e) {
      console.warn("[asaas] falha ao buscar invoiceUrl inicial:", e);
    }

    // 4) Persiste no perfil
    const trialEndsAt = new Date();
    trialEndsAt.setUTCDate(trialEndsAt.getUTCDate() + TRIAL_DAYS);

    const { error: upErr } = await supabase
      .from("profiles")
      .update({
        asaas_customer_id: customerId,
        asaas_subscription_id: subscription.id,
        subscription_status: subscription.status,
        trial_ends_at: trialEndsAt.toISOString(),
        next_due_date: subscription.nextDueDate,
        last_invoice_url: invoiceUrl,
        subscription_updated_at: new Date().toISOString(),
      })
      .eq("user_id", userId);
    if (upErr) throw new Error(`Falha ao salvar assinatura: ${upErr.message}`);

    return {
      alreadySubscribed: false,
      subscriptionId: subscription.id,
      status: subscription.status,
      nextDueDate: subscription.nextDueDate,
      invoiceUrl,
    };
  });

export const getAsaasSubscriptionStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: profile } = await supabase
      .from("profiles")
      .select(
        "asaas_subscription_id, subscription_status, trial_ends_at, next_due_date, payment_method, last_invoice_url, plan_status, created_at, trial_started_at, subscription_started_at",
      )
      .eq("user_id", userId)
      .maybeSingle();

    const trialStartedAt = profile?.trial_started_at ?? profile?.created_at ?? null;
    const trialEndsAt = profile?.trial_ends_at
      ? profile.trial_ends_at
      : profile?.created_at
      ? new Date(new Date(profile.created_at).getTime() + TRIAL_DAYS * 86_400_000).toISOString()
      : null;

    // Pagamento manual registrado pela administradora: não há assinatura no Asaas,
    // apenas o próximo vencimento salvo internamente.
    if (!profile?.asaas_subscription_id && profile?.payment_method === "MANUAL") {
      return {
        hasSubscription: true as const,
        isManual: true as const,
        subscriptionId: null,
        status: profile.subscription_status ?? "ACTIVE",
        nextDueDate: profile.next_due_date,
        trialEndsAt,
        trialStartedAt,
        paymentMethod: "MANUAL",
        invoiceUrl: null,
      };
    }

    if (!profile?.asaas_subscription_id) {
      return {
        hasSubscription: false as const,
        trialEndsAt,
        trialStartedAt,
        paymentMethod: null as string | null,
      };
    }

    // Sincroniza com o Asaas
    try {
      const sub = await asaasFetch<AsaasSubscription>(
        `/subscriptions/${profile.asaas_subscription_id}`,
      );
      let invoiceUrl: string | null = profile.last_invoice_url ?? null;
      let paymentMethod: string | null = profile.payment_method ?? null;
      // A próxima cobrança é sempre a PRIMEIRA fatura em aberto no Asaas.
      // Nunca calcular a data manualmente.
      let nextDueDate: string | null = profile.next_due_date ?? null;
      try {
        const { getFirstOpenPayment } = await import("@/lib/asaas-due.server");
        const p = await getFirstOpenPayment(sub.id);
        if (p) {
          nextDueDate = p.dueDate;
          invoiceUrl = p.invoiceUrl ?? invoiceUrl;
          if (p.billingType && p.billingType !== "UNDEFINED") paymentMethod = p.billingType;
        } else {
          // Sem cobrança em aberto: preserva o vencimento do ciclo vigente
          // (ex.: novo ciclo de 30 dias após reativação) quando ainda é futuro.
          const hojeISO = new Date().toISOString().slice(0, 10);
          nextDueDate = nextDueDate && nextDueDate.slice(0, 10) >= hojeISO ? nextDueDate : null;
        }

      } catch {
        /* ignore */
      }
      await supabase
        .from("profiles")
        .update({
          subscription_status: sub.status,
          next_due_date: nextDueDate,
          last_invoice_url: invoiceUrl,
          payment_method: paymentMethod,
          subscription_updated_at: new Date().toISOString(),
        })
        .eq("user_id", userId);
      return {
        hasSubscription: true as const,
        subscriptionId: sub.id,
        status: sub.status,
        nextDueDate,
        trialEndsAt: profile.trial_ends_at,
        trialStartedAt,
        subscriptionStartedAt: profile.subscription_started_at ?? trialStartedAt,
        paymentMethod,
        invoiceUrl,
      };

    } catch (e) {
      console.error("[asaas] status sync falhou:", e);
      return {
        hasSubscription: true as const,
        subscriptionId: profile.asaas_subscription_id,
        status: profile.subscription_status ?? "UNKNOWN",
        nextDueDate: profile.next_due_date,
        trialEndsAt: profile.trial_ends_at,
        trialStartedAt,
        subscriptionStartedAt: profile.subscription_started_at ?? trialStartedAt,
        paymentMethod: profile.payment_method,
        invoiceUrl: profile.last_invoice_url,
      };
    }
  });
