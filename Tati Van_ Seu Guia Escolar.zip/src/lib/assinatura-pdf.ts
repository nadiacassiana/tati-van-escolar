import type jsPDF from "jspdf";
import { formatAssinaturaData, type Assinatura } from "./assinatura";

export type CampoAssinatura = {
  /** Rótulo abaixo da linha (ex.: "Transportador(a)"). */
  papelLabel: string;
  /** Nome exibido quando ainda não houver assinatura. */
  nomePadrao?: string;
  assinatura?: Assinatura | null;
};

/** Altura total (mm) ocupada pelo bloco de assinaturas. */
export const ALTURA_BLOCO_ASSINATURA = 34;

/**
 * Desenha lado a lado as duas assinaturas visuais (imagem realmente desenhada
 * pela pessoa), com nome, papel e data/hora do aceite abaixo da linha.
 * Retorna a posição Y final.
 */
export function desenharAssinaturas(
  pdf: jsPDF,
  opts: { x: number; largura: number; y: number; esquerda: CampoAssinatura; direita: CampoAssinatura },
): number {
  const { x, largura, y, esquerda, direita } = opts;
  const gap = 16;
  const colW = (largura - gap) / 2;

  const coluna = (cx: number, campo: CampoAssinatura) => {
    const a = campo.assinatura;
    if (a?.imagem) {
      try {
        const props = pdf.getImageProperties(a.imagem);
        const maxH = 16;
        const maxW = colW - 8;
        const ratio = props.width / props.height || 1;
        let h = maxH;
        let w = h * ratio;
        if (w > maxW) {
          w = maxW;
          h = w / ratio;
        }
        pdf.addImage(a.imagem, props.fileType || "PNG", cx + (colW - w) / 2, y - h - 1, w, h, undefined, "FAST");
      } catch {
        /* imagem inválida — mantém apenas a linha */
      }
    }

    pdf.setDrawColor(26, 26, 46);
    pdf.setLineWidth(0.4);
    pdf.line(cx, y, cx + colW, y);

    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(9);
    pdf.setTextColor(26, 26, 46);
    const nome = (a?.nome || campo.nomePadrao || "—").slice(0, 60);
    pdf.text(nome, cx + colW / 2, y + 5, { align: "center" });

    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(8);
    pdf.setTextColor(107, 114, 128);
    pdf.text(campo.papelLabel, cx + colW / 2, y + 9.5, { align: "center" });

    if (a) {
      pdf.setFontSize(7);
      pdf.setTextColor(82, 82, 91);
      pdf.text(`Assinado digitalmente em ${formatAssinaturaData(a.em)}`, cx + colW / 2, y + 14, {
        align: "center",
      });
    }
  };

  coluna(x, esquerda);
  coluna(x + colW + gap, direita);
  return y + 18;
}
