/**
 * Assinatura digital visual — modelo único reutilizado por Contratos e
 * Reserva/Reserva de Vaga. A assinatura é sempre a imagem realmente
 * desenhada na tela pela pessoa (nunca uma fonte cursiva do nome digitado).
 */

export type PapelAssinatura = "motorista" | "responsavel";

export type Assinatura = {
  /** PNG (data URL) do traço desenhado na tela. */
  imagem: string;
  /** Nome de quem assinou, usado para identificação abaixo da assinatura. */
  nome: string;
  papel: PapelAssinatura;
  /** ISO com data e hora do aceite. */
  em: string;
};

export type DocumentoAssinavel = "contrato" | "garantia";

export function parseAssinatura(raw: unknown): Assinatura | null {
  if (!raw || typeof raw !== "object") return null;
  const a = raw as Partial<Assinatura>;
  if (typeof a.imagem !== "string" || !a.imagem.startsWith("data:image/")) return null;
  return {
    imagem: a.imagem,
    nome: typeof a.nome === "string" ? a.nome : "",
    papel: a.papel === "responsavel" ? "responsavel" : "motorista",
    em: typeof a.em === "string" ? a.em : new Date().toISOString(),
  };
}

export function novaAssinatura(imagem: string, nome: string, papel: PapelAssinatura): Assinatura {
  return { imagem, nome: nome.trim(), papel, em: new Date().toISOString() };
}

export const PAPEL_LABEL: Record<PapelAssinatura, string> = {
  motorista: "Assinatura da Contratada / Responsável pelo Transporte",
  responsavel: "Assinatura do Responsável",
};

export type StatusAssinaturas =
  | "aguardando_motorista"
  | "assinado_motorista"
  | "assinado_ambos";

export function statusAssinaturas(
  motorista: unknown,
  responsavel: unknown,
): StatusAssinaturas {
  const m = parseAssinatura(motorista);
  const r = parseAssinatura(responsavel);
  if (m && r) return "assinado_ambos";
  if (m) return "assinado_motorista";
  return "aguardando_motorista";
}

export const STATUS_ASSINATURA_LABEL: Record<StatusAssinaturas, string> = {
  aguardando_motorista: "✍️ Aguardando sua assinatura",
  assinado_motorista: "📩 Aguardando assinatura do responsável",
  assinado_ambos: "✅ Assinado pelas duas partes",
};

/** Link público que o responsável abre pelo WhatsApp para ler e assinar. */
export function linkAssinatura(tipo: DocumentoAssinavel, id: string): string {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  return `${origin}/assinar/${tipo}/${id}`;
}

export function formatAssinaturaData(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return `${d.toLocaleDateString("pt-BR")} às ${d.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}
