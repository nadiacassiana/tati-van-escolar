import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Descobre se um e-mail pertence a uma conta criada SOMENTE via Google
 * (sem senha cadastrada). Usado apenas para melhorar a mensagem de erro
 * do login — não altera nenhuma conta.
 */
export const isGoogleOnlyAccount = createServerFn({ method: "POST" })
  .inputValidator((data) => z.object({ email: z.string().email() }).parse(data))
  .handler(async ({ data }) => {
    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_SERVICE_ROLE_KEY"];
    if (!url || !key) return { googleOnly: false };

    try {
      const res = await fetch(
        `${url}/auth/v1/admin/users?filter=${encodeURIComponent(data.email)}&per_page=5`,
        { headers: { apikey: key, Authorization: `Bearer ${key}` } },
      );
      if (!res.ok) return { googleOnly: false };
      const json = (await res.json()) as {
        users?: Array<{
          email?: string | null;
          identities?: Array<{ provider?: string }> | null;
          app_metadata?: { provider?: string; providers?: string[] } | null;
        }>;
      };
      const alvo = data.email.trim().toLowerCase();
      const user = (json.users ?? []).find((u) => (u.email ?? "").toLowerCase() === alvo);
      if (!user) return { googleOnly: false };
      const listaIdentidades = (user.identities ?? []).map((i) => (i.provider ?? "").toLowerCase());
      const listaMeta = (user.app_metadata?.providers ?? [])
        .concat(user.app_metadata?.provider ? [user.app_metadata.provider] : [])
        .map((p) => p.toLowerCase());
      const providers = listaIdentidades.length > 0 ? listaIdentidades : listaMeta;
      const googleOnly = providers.length > 0 && providers.every((p) => p === "google");
      return { googleOnly };
    } catch {
      return { googleOnly: false };
    }
  });
