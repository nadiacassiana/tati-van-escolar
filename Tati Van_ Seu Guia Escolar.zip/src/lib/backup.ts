import { supabase } from "@/integrations/supabase/client";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { downloadBlob } from "@/lib/contrato-pdf";

const TABLES = [
  { key: "alunos", label: "Alunos" },
  { key: "responsaveis", label: "Responsáveis" },
  { key: "gastos", label: "Gastos" },
  { key: "pagamentos", label: "Pagamentos" },
  { key: "documentos", label: "Documentos" },
  { key: "contratos", label: "Contratos" },
  { key: "recibos", label: "Recibos" },
] as const;

export function backupFilename(ext: "pdf" | "xlsx"): string {
  const d = new Date();
  const date = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  return `Backup_Tati_Van_${date}.${ext}`;
}

async function fetchAll(userId: string) {
  const out: Record<string, Record<string, unknown>[]> = {};
  for (const t of TABLES) {
    const { data, error } = await supabase
      .from(t.key)
      .select("*")
      .eq("user_id", userId);
    if (error && error.code !== "PGRST116" && !/relation .* does not exist/i.test(error.message)) {
      // Ignore missing tables silently; rethrow real errors
      throw new Error(`Erro ao ler ${t.label}: ${error.message}`);
    }
    out[t.key] = data || [];
  }
  return out;
}

function flatten(row: Record<string, unknown>): Record<string, string> {
  const r: Record<string, string> = {};
  for (const [k, v] of Object.entries(row)) {
    if (v == null) r[k] = "";
    else if (typeof v === "object") r[k] = JSON.stringify(v);
    else r[k] = String(v);
  }
  return r;
}

export async function generateBackupXlsx(userId: string): Promise<Blob> {
  const data = await fetchAll(userId);
  const wb = XLSX.utils.book_new();
  for (const t of TABLES) {
    const rows = (data[t.key] || []).map(flatten);
    const ws = XLSX.utils.json_to_sheet(rows.length ? rows : [{ info: "Sem registros" }]);
    XLSX.utils.book_append_sheet(wb, ws, t.label.slice(0, 31));
  }
  const arr = XLSX.write(wb, { bookType: "xlsx", type: "array" }) as ArrayBuffer;
  return new Blob([arr], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
}

export async function generateBackupPdf(userId: string): Promise<Blob> {
  const data = await fetchAll(userId);
  const pdf = new jsPDF("p", "mm", "a4");
  const pageW = pdf.internal.pageSize.getWidth();

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(18);
  pdf.setTextColor(37, 99, 235);
  pdf.text("Tati", 16, 18);
  pdf.setTextColor(245, 158, 11);
  pdf.text("Van Escolar", 33, 18);
  pdf.setFontSize(11);
  pdf.setTextColor(26, 26, 46);
  pdf.text("Backup completo dos seus dados", 16, 26);
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  pdf.setTextColor(107, 114, 128);
  pdf.text(`Gerado em ${new Date().toLocaleString("pt-BR")}`, 16, 32);

  let startY = 40;
  for (const t of TABLES) {
    const rows = data[t.key] || [];
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(12);
    pdf.setTextColor(37, 99, 235);
    if (startY > 260) { pdf.addPage(); startY = 20; }
    pdf.text(`${t.label} (${rows.length})`, 16, startY);
    startY += 4;

    if (!rows.length) {
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(9);
      pdf.setTextColor(107, 114, 128);
      pdf.text("Sem registros.", 16, startY + 4);
      startY += 10;
      continue;
    }

    // pick first ~5 most useful columns
    const ignore = new Set(["user_id", "id", "created_at", "updated_at", "historico"]);
    const cols = Object.keys(rows[0]).filter((k) => !ignore.has(k)).slice(0, 5);
    const body = rows.map((r) => cols.map((c) => {
      const v = (r as Record<string, unknown>)[c];
      if (v == null) return "";
      if (typeof v === "object") return JSON.stringify(v).slice(0, 40);
      return String(v).slice(0, 60);
    }));

    autoTable(pdf, {
      head: [cols],
      body,
      startY: startY + 2,
      styles: { fontSize: 8, cellPadding: 1.5, textColor: [26, 26, 46] },
      headStyles: { fillColor: [37, 99, 235], textColor: [255, 255, 255] },
      margin: { left: 16, right: 16 },
    });
    // @ts-expect-error autotable attaches lastAutoTable
    startY = (pdf.lastAutoTable?.finalY || startY) + 8;
  }

  // page numbers
  const pageCount = pdf.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    pdf.setPage(i);
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(8);
    pdf.setTextColor(107, 114, 128);
    pdf.text(`Página ${i}/${pageCount}`, pageW - 16, 290, { align: "right" });
  }

  return pdf.output("blob");
}

export async function downloadBackup(userId: string, format: "pdf" | "xlsx") {
  const blob = format === "pdf" ? await generateBackupPdf(userId) : await generateBackupXlsx(userId);
  downloadBlob(blob, backupFilename(format));
}
