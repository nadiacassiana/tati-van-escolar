import { applyVariables, getMotoristaFromUser } from "@/lib/whatsapp";
import { formatBRL } from "@/lib/format";
import { formatDataBR, formatMesRef, type Competencia } from "@/lib/mensalidades";
import { calcularEncargos, type EncargoConfig } from "@/lib/encargos";

export const COBRAR_TEMPLATE = `Olá, {responsavel}! 😊

Esperamos que esteja tudo bem com você.

Passamos para lembrar que a mensalidade do transporte escolar de {aluno} está pendente.

Quando puder, pedimos a gentileza de realizar a regularização.

PIX: {pix}

Caso o pagamento já tenha sido realizado, desconsidere esta mensagem.

Agradecemos a atenção! 💙`;

/** Mensagem de cobrança de uma competência específica (mês + valor em aberto). */
export function buildCobrarMessage(
  c: Competencia,
  motorista: ReturnType<typeof getMotoristaFromUser>,
  encargos?: EncargoConfig | null,
) {
  const base = applyVariables(
    COBRAR_TEMPLATE,
    {
      responsavel: c.aluno.responsavel,
      aluno: c.aluno.nome,
      escola: c.aluno.escola,
      mensalidade: c.valor,
      vencimento: c.aluno.vencimento,
      pix: motorista.pix,
      telefone: motorista.whatsapp,
    },
    motorista,
  );
  const enc = calcularEncargos(c.valor, c.diasAtraso, encargos);
  const trechoValor =
    enc.encargos > 0
      ? `referente a ${formatMesRef(c.mes)} (vencimento em ${formatDataBR(c.vencimentoISO)}) está em aberto. O valor original é de R$ ${formatBRL(c.valor)} e o valor atualizado hoje (com juros/multa) é de R$ ${formatBRL(enc.total)}.`
      : `referente a ${formatMesRef(c.mes)} (vencimento em ${formatDataBR(c.vencimentoISO)}) está em aberto, no valor de R$ ${formatBRL(c.valor)}.`;
  return base.replace("está pendente.", trechoValor);
}
