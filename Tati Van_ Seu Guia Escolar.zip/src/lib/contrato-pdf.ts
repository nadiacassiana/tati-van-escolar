import jsPDF from "jspdf";
import { parseAssinatura, type Assinatura } from "./assinatura";
import { desenharAssinaturas } from "./assinatura-pdf";
import { buildWhatsAppUrl } from "./whatsapp";


export type ContratoLike = {
  id: string;
  aluno_nome: string;
};

/**
 * Renders an HTML string into a Blob PDF (A4, multi-page).
 *
 * Strategy: parse the same contract HTML used by the preview and draw the
 * content directly with jsPDF. This avoids the blank-PDF issue caused by
 * browser canvas capture in hidden iframes and keeps pagination under our
 * control line by line.
 */
export async function htmlToPdfBlob(html: string): Promise<Blob> {
  const parsed = new DOMParser().parseFromString(html, "text/html");
  const body = parsed.body;
  const pdf = new jsPDF("p", "mm", "a4");

  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const marginX = 16;
  const marginTop = 14;
  const marginBottom = 20;
  const contentW = pageW - marginX * 2;
  const safeBottom = pageH - marginBottom;
  const lineGap = 6.2;
  let cursorY = marginTop;
  let currentSectionTitle = "";

  const clean = (text: string) => text.replace(/🚐/g, "").replace(/\s+/g, " ").trim();
  const headerEl = body.querySelector(".header");
  const headerNumber = clean(headerEl?.querySelector("div:last-child")?.textContent || "");
  const brandName = (headerEl?.getAttribute("data-brand-name") || "").trim() || "Transporte Escolar";
  const brandLogo = (headerEl?.getAttribute("data-brand-logo") || "").trim();
  const title = clean(body.querySelector("h1")?.textContent || "Contrato de Prestação de Serviço — Transporte Escolar");

  // Dimensões do logotipo da motorista (identidade visual dos documentos).
  let logoW = 0;
  let logoH = 0;
  let logoType = "PNG";
  if (brandLogo) {
    try {
      const props = pdf.getImageProperties(brandLogo);
      logoType = props.fileType || "PNG";
      const maxH = 14;
      const maxW = 42;
      const ratio = props.width / props.height;
      logoH = maxH;
      logoW = logoH * ratio;
      if (logoW > maxW) { logoW = maxW; logoH = logoW / ratio; }
    } catch {
      logoW = 0;
      logoH = 0;
    }
  }

  const setText = (size: number, style: "normal" | "bold" = "normal", color: [number, number, number] = [26, 26, 46]) => {
    pdf.setFont("helvetica", style);
    pdf.setFontSize(size);
    pdf.setTextColor(color[0], color[1], color[2]);
  };

  const drawHeader = () => {
    cursorY = marginTop;
    let nameX = marginX;
    if (logoW > 0) {
      try {
        pdf.addImage(brandLogo, logoType, marginX, cursorY - 2, logoW, logoH, undefined, "FAST");
        nameX = marginX + logoW + 5;
      } catch {
        nameX = marginX;
      }
    }
    setText(16, "bold", [30, 58, 138]);
    const nameLines = pdf.splitTextToSize(brandName, pageW - nameX - marginX - 45) as string[];
    pdf.text(nameLines[0] || brandName, nameX, cursorY + 5);
    if (headerNumber) {
      setText(8, "normal", [107, 114, 128]);
      pdf.text(headerNumber, pageW - marginX, cursorY + 4, { align: "right" });
    }
    const lineY = cursorY + Math.max(11, logoH + 1);
    pdf.setDrawColor(37, 99, 235);
    pdf.setLineWidth(1.1);
    pdf.line(marginX, lineY, pageW - marginX, lineY);
    cursorY = lineY + 9;
  };

  const addContinuationTitle = () => {
    if (!currentSectionTitle) return;
    cursorY += 2;
    setText(9, "bold", [37, 99, 235]);
    pdf.text(`${clean(currentSectionTitle).toUpperCase()} (CONTINUAÇÃO)`, marginX, cursorY);
    pdf.setDrawColor(229, 231, 235);
    pdf.setLineWidth(0.3);
    pdf.line(marginX, cursorY + 2.5, pageW - marginX, cursorY + 2.5);
    cursorY += 8;
  };

  const startNewPage = (withContinuation = false) => {
    pdf.addPage();
    drawHeader();
    if (withContinuation) addContinuationTitle();
  };

  const ensureSpace = (height: number) => {
    if (cursorY + height <= safeBottom) return;
    startNewPage();
  };

  const addTitle = (text: string) => {
    const lines = pdf.splitTextToSize(clean(text), contentW) as string[];
    ensureSpace(lines.length * 7 + 8);
    setText(14, "bold", [26, 26, 46]);
    lines.forEach((line) => {
      pdf.text(line, pageW / 2, cursorY, { align: "center" });
      cursorY += 7;
    });
    cursorY += 5;
  };

  const addSectionTitle = (text: string) => {
    currentSectionTitle = clean(text);
    // Keep the section title with at least ~2 lines of the following paragraph
    // to avoid orphaned headings at the bottom of a page.
    ensureSpace(13 + lineGap * 2);
    cursorY += 2;
    setText(10, "bold", [37, 99, 235]);
    pdf.text(clean(text).toUpperCase(), marginX, cursorY);
    pdf.setDrawColor(229, 231, 235);
    pdf.setLineWidth(0.3);
    pdf.line(marginX, cursorY + 2.5, pageW - marginX, cursorY + 2.5);
    cursorY += 8;
  };

  // Given the number of lines that fit before a page break, adjust the split
  // to avoid orphans (1 line alone at bottom) and widows (1 line alone at top).
  const adjustSplit = (fits: number, total: number): number => {
    if (fits >= total) return total;
    if (fits <= 0) return 0;
    // Orphan: only the first line fits here — push whole paragraph to next page.
    if (fits === 1 && total >= 2) return 0;
    // Widow: leaving a single line for the next page — pull one line down.
    if (total - fits === 1 && fits >= 2) return fits - 1;
    return fits;
  };

  const addParagraph = (text: string, extraAfter = 2) => {
    const lines = pdf.splitTextToSize(clean(text), contentW) as string[];
    setText(9.5, "normal", [26, 26, 46]);
    let i = 0;
    while (i < lines.length) {
      const remaining = lines.length - i;
      const available = Math.max(0, Math.floor((safeBottom - cursorY) / lineGap));
      let take = Math.min(available, remaining);
      take = adjustSplit(take, remaining);
      if (take <= 0) {
        startNewPage(true);
        setText(9.5, "normal", [26, 26, 46]);
        continue;
      }
      for (let k = 0; k < take; k++) {
        setText(9.5, "normal", [26, 26, 46]);
        pdf.text(lines[i + k], marginX, cursorY);
        cursorY += lineGap;
      }
      i += take;
      if (i < lines.length) {
        startNewPage(true);
        setText(9.5, "normal", [26, 26, 46]);
      }
    }
    cursorY += extraAfter;
  };

  // Renders a paragraph made of inline runs (text + optional bold), wrapping
  // across lines while preserving bold segments. Used for clause paragraphs
  // so every "N. Título." prefix renders in bold uniformly.
  const addRichParagraph = (source: HTMLElement, extraAfter = 2, options: { keepTogether?: boolean } = {}) => {
    type Run = { text: string; bold: boolean };
    const runs: Run[] = [];
    const walk = (node: Node, bold: boolean) => {
      if (node.nodeType === Node.TEXT_NODE) {
        const t = (node.textContent || "").replace(/\s+/g, " ");
        if (t) runs.push({ text: t, bold });
        return;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      const el = node as HTMLElement;
      const tag = el.tagName.toLowerCase();
      const isBold = bold || tag === "b" || tag === "strong";
      el.childNodes.forEach((child) => walk(child, isBold));
    };
    source.childNodes.forEach((child) => walk(child, false));

    // Tokenize into words while keeping bold flag per token
    type Token = { text: string; bold: boolean; space: boolean };
    const tokens: Token[] = [];
    for (const run of runs) {
      const parts = run.text.split(/(\s+)/);
      for (const part of parts) {
        if (!part) continue;
        if (/^\s+$/.test(part)) tokens.push({ text: " ", bold: run.bold, space: true });
        else tokens.push({ text: part, bold: run.bold, space: false });
      }
    }

    // First pass: break tokens into rendered lines without emitting them,
    // so we can paginate the paragraph as a whole and apply orphan/widow rules.
    setText(9.5, "normal", [26, 26, 46]);
    const builtLines: Token[][] = [];
    let line: Token[] = [];
    let lineWidth = 0;
    const closeLine = () => {
      while (line.length && line[0].space) line.shift();
      while (line.length && line[line.length - 1].space) line.pop();
      if (line.length) builtLines.push(line);
      line = [];
      lineWidth = 0;
    };
    for (const tok of tokens) {
      pdf.setFont("helvetica", tok.bold ? "bold" : "normal");
      const w = pdf.getTextWidth(tok.text);
      if (!tok.space && lineWidth + w > contentW && line.length) {
        closeLine();
      }
      line.push(tok);
      lineWidth += w;
    }
    closeLine();

    const paragraphHeight = builtLines.length * lineGap + extraAfter;
    const freshPageContentHeight = safeBottom - (marginTop + 20);

    // Contract clauses are short and should read as complete visual blocks.
    // If the whole block fits on a clean page, move it before rendering instead
    // of splitting the title/prefix from its remaining text.
    if (options.keepTogether && paragraphHeight <= freshPageContentHeight && cursorY + paragraphHeight > safeBottom) {
      startNewPage(true);
      setText(9.5, "normal", [26, 26, 46]);
    }

    // Second pass: render with pagination that avoids orphans and widows.
    let i = 0;
    while (i < builtLines.length) {
      const remaining = builtLines.length - i;
      const available = Math.max(0, Math.floor((safeBottom - cursorY) / lineGap));
      let take = Math.min(available, remaining);
      take = adjustSplit(take, remaining);
      if (take <= 0) {
        startNewPage(true);
        setText(9.5, "normal", [26, 26, 46]);
        continue;
      }
      for (let k = 0; k < take; k++) {
        const ln = builtLines[i + k];
        let x = marginX;
        for (const tok of ln) {
          pdf.setFontSize(9.5);
          pdf.setTextColor(26, 26, 46);
          pdf.setFont("helvetica", tok.bold ? "bold" : "normal");
          pdf.text(tok.text, x, cursorY);
          x += pdf.getTextWidth(tok.text);
        }
        cursorY += lineGap;
      }
      i += take;
      if (i < builtLines.length) {
        startNewPage(true);
        setText(9.5, "normal", [26, 26, 46]);
      }
    }
    cursorY += extraAfter;
  };

  const addGrid = (el: HTMLElement) => {
    const rows = Array.from(el.querySelectorAll<HTMLElement>(".row"));
    const gap = 8;
    const colW = (contentW - gap) / 2;
    for (let i = 0; i < rows.length; i += 2) {
      const pair = rows.slice(i, i + 2);
      const prepared = pair.map((row) => {
        const label = clean(row.querySelector(".label")?.textContent || "");
        const value = clean(row.querySelector(".value")?.textContent || "—") || "—";
        const lines = pdf.splitTextToSize(value, colW) as string[];
        return { label, lines };
      });
      const rowH = 5 + Math.max(...prepared.map((p) => p.lines.length || 1)) * 5.6 + 4;
      ensureSpace(rowH);
      prepared.forEach((item, idx) => {
        const x = marginX + idx * (colW + gap);
        setText(7.5, "bold", [107, 114, 128]);
        pdf.text(item.label.toUpperCase(), x, cursorY);
        setText(9.5, "normal", [26, 26, 46]);
        item.lines.forEach((line, lineIdx) => pdf.text(line, x, cursorY + 5 + lineIdx * 5.6));
      });
      cursorY += rowH;
    }
    cursorY += 1;
  };

  const addSignatures = (el?: HTMLElement) => {
    ensureSpace(46);
    cursorY += 20;
    const parse = (raw: string | null): Assinatura | null => {
      if (!raw) return null;
      try {
        return parseAssinatura(JSON.parse(raw));
      } catch {
        return null;
      }
    };
    cursorY = desenharAssinaturas(pdf, {
      x: marginX,
      largura: contentW,
      y: cursorY,
      esquerda: {
        papelLabel: "Responsável pelo(a) aluno(a)",
        nomePadrao: (el?.getAttribute("data-resp-nome") || "").trim() || "Responsável",
        assinatura: parse(el?.getAttribute("data-sig-responsavel") || null),
      },
      direita: {
        papelLabel: "Transportador(a)",
        nomePadrao: brandName,
        assinatura: parse(el?.getAttribute("data-sig-motorista") || null),
      },
    });
  };


  const addFooter = (text: string) => {
    ensureSpace(18);
    pdf.setDrawColor(229, 231, 235);
    pdf.line(marginX, cursorY, pageW - marginX, cursorY);
    cursorY += 6;
    setText(8, "normal", [107, 114, 128]);
    pdf.text(clean(text), pageW / 2, cursorY, { align: "center" });
  };

  drawHeader();
  addTitle(title);

  const children = Array.from(body.children).filter((el): el is HTMLElement => el instanceof HTMLElement);
  for (const el of children) {
    if (el.classList.contains("header") || el.tagName.toLowerCase() === "h1") continue;
    if (el.tagName.toLowerCase() === "h2") addSectionTitle(el.textContent || "");
    else if (el.classList.contains("grid")) addGrid(el);
    else if (el.classList.contains("sign")) addSignatures(el);
    else if (el.classList.contains("footer")) addFooter(el.textContent || "");
    else if (el.tagName.toLowerCase() === "p") addRichParagraph(el, 2, { keepTogether: el.classList.contains("clausula") });
    else addParagraph(el.textContent || "");
  }

  return pdf.output("blob");
}

export function pdfFilename(c: ContratoLike): string {
  const safe = (c.aluno_nome || "contrato").replace(/[^\p{L}\p{N}\s-]/gu, "").replace(/\s+/g, "_");
  return `Contrato_${safe}.pdf`;
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  a.target = "_self";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  // iOS Safari ignora o atributo `download` para Blob URLs — abre em nova aba como fallback
  const ua = navigator.userAgent || "";
  const isIOS = /iPad|iPhone|iPod/.test(ua) && !("MSStream" in window);
  if (isIOS) {
    setTimeout(() => window.open(url, "_blank"), 100);
  }
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}


export function openBlobInNewTab(blob: Blob): Window | null {
  const url = URL.createObjectURL(blob);
  const win = window.open(url, "_blank");
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
  return win;
}

export function printBlob(blob: Blob, targetWindow?: Window | null) {
  const url = URL.createObjectURL(blob);

  if (targetWindow && !targetWindow.closed) {
    targetWindow.location.href = url;
    setTimeout(() => {
      try {
        targetWindow.focus();
        targetWindow.print();
      } catch {/* ignore */}
    }, 900);
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    return;
  }

  if (isMobile()) {
    const win = window.open(url, "_blank");
    setTimeout(() => {
      try {
        win?.focus();
        win?.print();
      } catch {/* ignore */}
    }, 900);
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    return;
  }

  const iframe = document.createElement("iframe");
  iframe.style.position = "fixed";
  iframe.style.right = "0";
  iframe.style.bottom = "0";
  iframe.style.width = "0";
  iframe.style.height = "0";
  iframe.style.border = "0";
  iframe.src = url;
  iframe.onload = () => {
    setTimeout(() => {
      try {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
      } catch {/* ignore */}
    }, 200);
  };
  document.body.appendChild(iframe);
  setTimeout(() => {
    document.body.removeChild(iframe);
    URL.revokeObjectURL(url);
  }, 60_000);
}

export async function sharePdfFile(
  blob: Blob,
  filename: string,
  opts: { title: string; text: string; whatsappPhone?: string },
): Promise<"shared" | "downloaded" | "whatsapp" | "cancelled"> {
  const file = new File([blob], filename, { type: "application/pdf" });
  const nav = navigator as Navigator & {
    canShare?: (data: { files?: File[] }) => boolean;
    share?: (data: ShareData & { files?: File[] }) => Promise<void>;
  };

  const isCancelled = (err: unknown) => {
    if (!(err instanceof Error)) return false;
    const name = err.name?.toLowerCase() || "";
    const msg = err.message?.toLowerCase() || "";
    return name === "aborterror" || name === "notallowederror" || msg.includes("cancel") || msg.includes("abort");
  };

  const tryShareWithFiles = async (): Promise<"shared" | "error" | "cancelled"> => {
    if (!nav.share) return "error";
    try {
      await nav.share({ files: [file], title: opts.title, text: opts.text });
      return "shared";
    } catch (err) {
      if (isCancelled(err)) return "cancelled";
      return "error";
    }
  };

  // Muitos navegadores mobile reportam canShare=false para PDFs, mas ainda
  // conseguem abrir o painel nativo de compartilhamento. Por isso tentamos
  // compartilhar com arquivo sempre que houver navigator.share e estivermos
  // em mobile, ou quando canShare confirmar explicitamente o suporte.
  const canShareFiles = nav.canShare?.({ files: [file] }) ?? false;
  if (canShareFiles || isMobile()) {
    const result = await tryShareWithFiles();
    if (result === "shared") return "shared";
    if (result === "cancelled") return "cancelled";
    // error → segue para fallback abaixo
  }

  // Fallback: quando o navegador não consegue compartilhar arquivos
  // (canShare=false e share indisponível/falhou), baixamos o PDF e abrimos
  // direto a conversa do WhatsApp com a mensagem, para o usuário apenas
  // anexar o arquivo recém-baixado.
  downloadBlob(blob, filename);
  if (opts.whatsappPhone !== undefined) {
    const url = buildWhatsAppUrl(opts.whatsappPhone, opts.text);
    window.open(url, "_blank", "noopener,noreferrer");
    return "whatsapp";
  }
  return "downloaded";
}


export function isMobile(): boolean {
  return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
}
