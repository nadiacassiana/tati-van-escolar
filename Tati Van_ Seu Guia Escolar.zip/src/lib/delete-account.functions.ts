import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type DeleteInput = { motivo?: string | null; motivo_texto?: string | null };

export const deleteAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: DeleteInput | undefined) => ({
    motivo: (data?.motivo ?? null) as string | null,
    motivo_texto: (data?.motivo_texto ?? null) as string | null,
  }))
  .handler(async ({ context, data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const userId = context.userId;

    // 1) Snapshot do perfil ANTES de qualquer remoção
    const { data: perfil } = await (supabaseAdmin as any)
      .from("profiles")
      .select("nome, email, whatsapp, cidade, estado, plan_status, created_at")
      .eq("user_id", userId)
      .maybeSingle();

    const cadastroEm: string | null = perfil?.created_at ?? null;
    const diasPermanencia = cadastroEm
      ? Math.max(0, Math.floor((Date.now() - new Date(cadastroEm).getTime()) / 86_400_000))
      : null;

    // 2) Registra a exclusão para análise administrativa
    const { error: histErr } = await (supabaseAdmin as any).from("deleted_accounts").insert({
      user_id: userId,
      nome: perfil?.nome ?? null,
      email: perfil?.email ?? null,
      whatsapp: perfil?.whatsapp ?? null,
      cidade: perfil?.cidade ?? null,
      estado: perfil?.estado ?? null,
      cadastro_em: cadastroEm,
      dias_permanencia: diasPermanencia,
      status_no_momento: perfil?.plan_status ?? null,
      motivo: data.motivo,
      motivo_texto: data.motivo_texto,
    });
    if (histErr) throw new Error(`Falha ao registrar exclusão: ${histErr.message}`);

    // 3) Remove os dados do motorista
    const tables = [
      "recibos",
      "pagamentos",
      "gastos",
      "documentos",
      "contratos",
      "mensagens_historico",
      "mensagens",
      "rotas_ativas",
      "saude_van_snapshots",
      "responsaveis",
      "alunos",
    ];

    for (const t of tables) {
      const { error } = await (supabaseAdmin as any).from(t).delete().eq("user_id", userId);
      if (error) throw new Error(`Falha ao remover ${t}: ${(error as any).message}`);
    }

    const { error: delErr } = await supabaseAdmin.auth.admin.deleteUser(userId);
    if (delErr) throw new Error(`Falha ao remover conta: ${delErr.message}`);

    return { ok: true };
  });
