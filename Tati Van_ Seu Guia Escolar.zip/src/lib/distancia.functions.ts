import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type DistanciaInput = { origem?: string; destino?: string };

export type PontoResolvido = {
  label: string;
  lat: number;
  lon: number;
  provedor: string;
  alternativaLabel: string | null;
  divergenciaKm: number | null;
};

export type DistanciaResultado = {
  distanciaKm: number;
  duracaoMin: number;
  provedorRota: string;
  origem: PontoResolvido;
  destino: PontoResolvido;
  osrm: { distanciaKm: number; duracaoMin: number } | null;
  valhalla: { distanciaKm: number; duracaoMin: number } | null;
  linhaRetaKm: number;
  avisos: string[];
  // compatibilidade
  origemLabel: string;
  destinoLabel: string;
};

export const calcularDistancia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: DistanciaInput | undefined) => {
    const origem = (data?.origem ?? "").trim();
    const destino = (data?.destino ?? "").trim();
    if (origem.length < 4) throw new Error("Informe o endereço da escola.");
    if (destino.length < 4) throw new Error("Informe o endereço da residência do aluno.");
    return { origem, destino };
  })
  .handler(async ({ data }): Promise<DistanciaResultado> => {
    const { geocodificar, calcularRota, distanciaLinhaReta } = await import("./distancia.server");

    const [a, b] = await Promise.all([geocodificar(data.origem), geocodificar(data.destino)]);
    if (!a)
      throw new Error(
        "Não localizamos o endereço da escola. Confira rua, número, bairro e cidade/UF e tente de novo.",
      );
    if (!b)
      throw new Error(
        "Não localizamos o endereço da residência. Confira rua, número, bairro e cidade/UF e tente de novo.",
      );

    const rota = await calcularRota(a.escolhido, b.escolhido);
    if (!rota)
      throw new Error(
        "O serviço de rotas está indisponível no momento. Aguarde alguns instantes e tente novamente.",
      );

    const avisos: string[] = [];
    const flagGeo = (nome: string, g: typeof a) => {
      if (g.divergenciaKm != null && g.divergenciaKm > 1) {
        avisos.push(
          `Os provedores de mapa localizaram ${nome} em pontos diferentes (${g.divergenciaKm.toFixed(1)} km de distância entre eles). Confira o endereço resolvido abaixo.`,
        );
      }
    };
    flagGeo("a escola", a);
    flagGeo("a residência", b);

    const flagPrecisao = (nome: string, g: typeof a) => {
      if (!g.escolhido.precisa) {
        avisos.push(
          `Não encontramos o número exato ${nome}: usamos um ponto no meio da rua, então a distância pode ficar bem diferente da real. Inclua número, bairro e cidade/UF.`,
        );
      }
    };
    flagPrecisao("da escola", a);
    flagPrecisao("da residência", b);

    if (rota.divergenteEntreProvedores) {
      avisos.push(
        "Os dois serviços de rota retornaram trajetos bem diferentes. Estamos exibindo o mais longo (mais conservador).",
      );
    }

    const linhaRetaKm = distanciaLinhaReta(a.escolhido, b.escolhido);
    if (rota.escolhida.distanciaKm < linhaRetaKm) {
      avisos.push("O trajeto retornado ficou menor que a distância em linha reta — resultado suspeito.");
    }

    const simples = (r: { distanciaKm: number; duracaoMin: number } | null) =>
      r ? { distanciaKm: r.distanciaKm, duracaoMin: r.duracaoMin } : null;

    return {
      distanciaKm: rota.escolhida.distanciaKm,
      duracaoMin: rota.escolhida.duracaoMin,
      provedorRota: rota.escolhida.provedor,
      origem: {
        label: a.escolhido.label,
        lat: a.escolhido.lat,
        lon: a.escolhido.lon,
        provedor: a.escolhido.provedor,
        alternativaLabel: a.alternativa?.label ?? null,
        divergenciaKm: a.divergenciaKm,
      },
      destino: {
        label: b.escolhido.label,
        lat: b.escolhido.lat,
        lon: b.escolhido.lon,
        provedor: b.escolhido.provedor,
        alternativaLabel: b.alternativa?.label ?? null,
        divergenciaKm: b.divergenciaKm,
      },
      osrm: simples(rota.osrm),
      valhalla: simples(rota.valhalla),
      linhaRetaKm,
      avisos,
      origemLabel: a.escolhido.label,
      destinoLabel: b.escolhido.label,
    };
  });

type CoordInput = {
  origem: { lat: number; lon: number; label?: string };
  destino: { lat: number; lon: number; label?: string };
};

/** Calcula a rota a partir de coordenadas exatas, sem passar por geocodificação. */
export const calcularDistanciaPorCoordenadas = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: CoordInput | undefined) => {
    const ok = (p?: { lat: number; lon: number }) =>
      p && Number.isFinite(p.lat) && Number.isFinite(p.lon) && Math.abs(p.lat) <= 90 && Math.abs(p.lon) <= 180;
    if (!ok(data?.origem) || !ok(data?.destino)) throw new Error("Coordenadas inválidas.");
    return data as CoordInput;
  })
  .handler(async ({ data }): Promise<DistanciaResultado> => {
    const { calcularRota, distanciaLinhaReta } = await import("./distancia.server");

    const a = {
      lat: data.origem.lat,
      lon: data.origem.lon,
      label: data.origem.label ?? `${data.origem.lat}, ${data.origem.lon}`,
      provedor: "Nominatim" as const,
      precisa: true,
    };
    const b = {
      lat: data.destino.lat,
      lon: data.destino.lon,
      label: data.destino.label ?? `${data.destino.lat}, ${data.destino.lon}`,
      provedor: "Nominatim" as const,
      precisa: true,
    };

    const rota = await calcularRota(a, b);
    if (!rota)
      throw new Error("O serviço de rotas está indisponível no momento. Aguarde alguns instantes e tente novamente.");

    const simples = (r: { distanciaKm: number; duracaoMin: number } | null) =>
      r ? { distanciaKm: r.distanciaKm, duracaoMin: r.duracaoMin } : null;

    return {
      distanciaKm: rota.escolhida.distanciaKm,
      duracaoMin: rota.escolhida.duracaoMin,
      provedorRota: rota.escolhida.provedor,
      origem: { label: a.label, lat: a.lat, lon: a.lon, provedor: "Coordenadas", alternativaLabel: null, divergenciaKm: null },
      destino: { label: b.label, lat: b.lat, lon: b.lon, provedor: "Coordenadas", alternativaLabel: null, divergenciaKm: null },
      osrm: simples(rota.osrm),
      valhalla: simples(rota.valhalla),
      linhaRetaKm: distanciaLinhaReta(a, b),
      avisos: ["Resultado calculado a partir de coordenadas fixas de teste (sem geocodificação)."],
      origemLabel: a.label,
      destinoLabel: b.label,
    };
  });
