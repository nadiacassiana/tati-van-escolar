export type Ponto = {
  lat: number;
  lon: number;
  label: string;
  provedor: "Nominatim" | "Photon";
  /** true quando o geocodificador achou o número exato da casa (e não só o eixo da rua). */
  precisa: boolean;
};

const UA = "TatiVanEscolar/1.0 (transporte escolar; contato via app)";

async function tentarJson(url: string, init?: RequestInit): Promise<unknown | null> {
  try {
    const res = await fetch(url, init);
    if (!res.ok) {
      console.error(`[distancia] ${url} respondeu ${res.status}`);
      return null;
    }
    return await res.json();
  } catch (e) {
    console.error(`[distancia] falha ao chamar ${url}`, e);
    return null;
  }
}

export function distanciaLinhaReta(a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
  const R = 6371;
  const rad = (v: number) => (v * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLon = rad(b.lon - a.lon);
  const s =
    Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

async function geocodeNominatim(endereco: string): Promise<Ponto | null> {
  const json = (await tentarJson(
    "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=1&countrycodes=br&q=" +
      encodeURIComponent(endereco),
    { headers: { "User-Agent": UA, Referer: "https://tatiassistentevirtual.com.br", Accept: "application/json" } },
  )) as Array<{
    lat: string;
    lon: string;
    display_name: string;
    address?: { house_number?: string };
  }> | null;
  const first = json?.[0];
  if (!first) return null;
  return {
    lat: Number(first.lat),
    lon: Number(first.lon),
    label: first.display_name,
    provedor: "Nominatim",
    precisa: Boolean(first.address?.house_number),
  };
}

async function geocodePhoton(endereco: string): Promise<Ponto | null> {
  // Importante: NÃO enviar lang=pt — a API responde 400 e o fallback morre.
  const json = (await tentarJson(
    "https://photon.komoot.io/api/?limit=1&q=" + encodeURIComponent(endereco + ", Brasil"),
    { headers: { Accept: "application/json" } },
  )) as {
    features?: Array<{
      geometry?: { coordinates?: [number, number] };
      properties?: Record<string, string | undefined>;
    }>;
  } | null;
  const f = json?.features?.[0];
  const coords = f?.geometry?.coordinates;
  if (!f || !coords) return null;
  const p = f.properties ?? {};
  const label = [p['name'], p['street'], p['housenumber'], p['suburb'], p['city'], p['state'], p['country']]
    .filter(Boolean)
    .join(", ");
  return {
    lat: coords[1],
    lon: coords[0],
    label: label || endereco,
    provedor: "Photon",
    precisa: Boolean(p['housenumber']),
  };
}

export type GeocodeResultado = {
  escolhido: Ponto;
  alternativa: Ponto | null;
  divergenciaKm: number | null;
};

/** Consulta os dois provedores e sinaliza divergência em vez de aceitar o primeiro resultado. */
export async function geocodificar(endereco: string): Promise<GeocodeResultado | null> {
  const [nom, pho] = await Promise.all([geocodeNominatim(endereco), geocodePhoton(endereco)]);
  // Prefere o provedor que localizou o número exato; só cai no eixo da rua quando ninguém acha o número.
  const escolhido = (nom?.precisa ? nom : pho?.precisa ? pho : (nom ?? pho)) ?? null;
  if (!escolhido) return null;
  const alternativa = escolhido === nom ? pho : nom;
  const divergenciaKm = nom && pho ? distanciaLinhaReta(nom, pho) : null;
  return { escolhido, alternativa, divergenciaKm };
}

export type Rota = { distanciaKm: number; duracaoMin: number; provedor: "OSRM" | "Valhalla" };

async function rotaOsrm(a: Ponto, b: Ponto): Promise<Rota | null> {
  const json = (await tentarJson(
    `https://router.project-osrm.org/route/v1/driving/${a.lon},${a.lat};${b.lon},${b.lat}?overview=false`,
    { headers: { Accept: "application/json", "User-Agent": UA } },
  )) as { routes?: Array<{ distance: number; duration: number }> } | null;
  const r = json?.routes?.[0];
  if (!r) return null;
  return { distanciaKm: r.distance / 1000, duracaoMin: r.duration / 60, provedor: "OSRM" };
}

async function rotaValhalla(a: Ponto, b: Ponto): Promise<Rota | null> {
  const json = (await tentarJson("https://valhalla1.openstreetmap.de/route", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json", "User-Agent": UA },
    body: JSON.stringify({
      locations: [
        { lat: a.lat, lon: a.lon },
        { lat: b.lat, lon: b.lon },
      ],
      costing: "auto",
      units: "kilometers",
    }),
  })) as { trip?: { summary?: { length?: number; time?: number } } } | null;
  const s = json?.trip?.summary;
  if (!s || typeof s.length !== "number" || typeof s.time !== "number") return null;
  return { distanciaKm: s.length, duracaoMin: s.time / 60, provedor: "Valhalla" };
}

export type RotaComparada = {
  escolhida: Rota;
  osrm: Rota | null;
  valhalla: Rota | null;
  divergenteEntreProvedores: boolean;
};

/**
 * Consulta os dois roteadores de carro e compara.
 * Valhalla usa modelo de velocidade mais realista, então é o preferido quando os dois concordam.
 * Quando divergem muito, adota o trajeto mais longo (mais conservador) e sinaliza.
 */
export async function calcularRota(a: Ponto, b: Ponto): Promise<RotaComparada | null> {
  const [osrm, valhalla] = await Promise.all([rotaOsrm(a, b), rotaValhalla(a, b)]);
  if (!osrm && !valhalla) return null;
  if (!osrm || !valhalla) {
    return { escolhida: (valhalla ?? osrm)!, osrm, valhalla, divergenteEntreProvedores: false };
  }
  const maior = Math.max(osrm.distanciaKm, valhalla.distanciaKm);
  const menor = Math.min(osrm.distanciaKm, valhalla.distanciaKm);
  const divergente = maior > 0 && (maior - menor) / maior > 0.2;
  const escolhida = divergente ? (osrm.distanciaKm > valhalla.distanciaKm ? osrm : valhalla) : valhalla;
  return { escolhida, osrm, valhalla, divergenteEntreProvedores: divergente };
}
