/**
 * Documentos legíveis na tela (contrato e garantia/reserva de vaga).
 *
 * O mesmo HTML é usado para:
 *  - pré-visualização na tela (sem baixar nada);
 *  - a leitura do responsável antes de assinar pelo link público;
 *  - a versão em IMAGEM enviada pelo WhatsApp (PDF não anexa de forma
 *    confiável junto da mensagem).
 *
 * O PDF continua existindo para download/arquivo.
 */
import { formatBRL } from "./format";
import { parseAssinatura } from "./assinatura";
import { fraseInadimplencia } from "./encargos";
import type { MarcaVan } from "./marca";

import {
  abatimentoLabel,
  formatDataBR,
  mensalidadePrevistaFrase,
  prazoRespostaTexto,
  saudacaoReserva,
  tipoLabel,
  valorLabel,
} from "./garantia-vaga";

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

const esc = (v: unknown): string =>
  String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const nl = (v: unknown): string => esc(v).replace(/\n/g, "<br>");

function fmtDate(d: unknown): string {
  const s = typeof d === "string" ? d : "";
  if (!s) return "____/____/______";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (m) return `${m[3]}/${m[2]}/${m[1]}`;
  const dt = new Date(s);
  return Number.isNaN(dt.getTime()) ? "____/____/______" : dt.toLocaleDateString("pt-BR");
}

/** Serializa a assinatura para o atributo lido pelo gerador de PDF. */
export function sigAttr(raw: unknown): string {
  const a = parseAssinatura(raw);
  return a ? esc(JSON.stringify(a)) : "";
}

function blocoAssinatura(raw: unknown, nomePadrao: string, papel: string): string {
  const a = parseAssinatura(raw);
  const img = a
    ? `<img src="${a.imagem}" alt="" class="sig-img">`
    : `<div class="sig-vazia">Aguardando assinatura</div>`;
  const quando = a
    ? `<div class="sig-data">Assinado em ${new Date(a.em).toLocaleDateString("pt-BR")} às ${new Date(a.em).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}</div>`
    : "";
  return `<div class="sig-box">${img}<div class="sig-nome">${esc(a?.nome || nomePadrao)}</div><div class="sig-papel">${esc(papel)}</div>${quando}</div>`;
}

const BASE_CSS = `
  * { box-sizing: border-box; }
  body { font-family: 'Helvetica', Arial, sans-serif; color: #1a1a2e; max-width: 780px; margin: 0 auto; padding: 32px; line-height: 1.6; background: #fff; }
  .header { border-bottom: 4px solid #2563eb; padding-bottom: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; gap: 16px; }
  .logo { font-size: 24px; font-weight: 800; color: #1e3a8a; display: flex; align-items: center; gap: 10px; }
  .logo img { max-height: 56px; max-width: 150px; object-fit: contain; }
  h1 { font-size: 20px; text-align: center; margin: 24px 0; text-transform: uppercase; letter-spacing: 1px; }
  h2 { font-size: 13px; text-transform: uppercase; color: #2563eb; border-bottom: 1px solid #e5e7eb; padding-bottom: 4px; margin-top: 22px; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 24px; margin: 12px 0; }
  .row { padding: 6px 0; }
  .label { font-size: 11px; text-transform: uppercase; color: #6b7280; font-weight: 600; }
  .value { font-size: 14px; font-weight: 500; }
  .clausula { margin: 10px 0; text-align: justify; font-size: 13px; }
  .aviso { border: 1px solid #93c5fd; background: #eff6ff; color: #1e3a8a; border-radius: 8px; padding: 10px 12px; font-size: 13px; margin: 12px 0; }
  .obs { border: 1px solid #fbbf24; background: #fffbeb; border-radius: 8px; padding: 10px 12px; font-size: 13px; margin: 12px 0; }
  .sign { margin-top: 40px; display: grid; grid-template-columns: 1fr 1fr; gap: 32px; }
  .sig-box { border-top: 1px solid #1a1a2e; padding-top: 8px; text-align: center; }
  .sig-img { display: block; margin: -56px auto 4px; max-height: 60px; max-width: 200px; object-fit: contain; }
  .sig-vazia { height: 56px; display: flex; align-items: center; justify-content: center; font-size: 11px; color: #9ca3af; margin-top: -64px; }
  .sig-nome { font-size: 13px; font-weight: 700; }
  .sig-papel { font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: #6b7280; }
  .sig-data { font-size: 10px; color: #6b7280; margin-top: 2px; }
  .footer { margin-top: 32px; text-align: center; font-size: 11px; color: #6b7280; border-top: 1px solid #e5e7eb; padding-top: 12px; }
  @media print { body { margin: 0; padding: 24px; } }
`;

function documento(titulo: string, corpo: string): string {
  return `<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(titulo)}</title><style>${BASE_CSS}</style></head><body>${corpo}</body></html>`;
}

function cabecalho(marca: MarcaVan, direita: string, extra = ""): string {
  return `<div class="header" data-brand-name="${esc(marca.nome)}" data-brand-logo="${marca.logo || ""}"${extra}>
  <div class="logo">${marca.logo ? `<img src="${marca.logo}" alt="">` : ""}<span>${esc(marca.nome)}</span></div>
  <div style="font-size:11px;color:#6b7280;text-align:right">${direita}</div>
</div>`;
}

/* ------------------------------------------------------------------ */
/* Contrato                                                            */
/* ------------------------------------------------------------------ */

export type ContratoDoc = {
  id: string;
  aluno_nome: string;
  responsavel?: string | null;
  escola?: string | null;
  endereco?: string | null;
  telefone?: string | null;
  email_responsavel?: string | null;
  mensalidade?: number | string | null;
  dia_vencimento?: number | string | null;
  data_inicio?: string | null;
  data_termino?: string | null;
  turno?: string | null;
  horario_ida?: string | null;
  horario_volta?: string | null;
  forma_pagamento?: string | null;
  pix_motorista?: string | null;
  pessoas_autorizadas?: string | null;
  telefone_emergencia?: string | null;
  observacoes_importantes?: string | null;
  observacoes?: string | null;
  multa_atraso?: number | string | null;
  multa_tipo?: string | null;
  juros_dia?: number | string | null;
  juros_tipo?: string | null;
  clausulas_adicionais?: string | null;
  clausulas_custom?: unknown;
  autoriza_imagem?: boolean | null;
  assinatura_motorista?: unknown;
  assinatura_responsavel?: unknown;
};


export const CLAUSULAS: Array<{ titulo: string; texto: string }> = [
  {
    titulo: "Pontualidade",
    texto:
      "O responsável compromete-se a estar presente no horário combinado. O motorista aguardará apenas o tempo necessário para o embarque seguro do aluno, evitando atrasos aos demais alunos da rota.",
  },
  {
    titulo: "Atrasos frequentes",
    texto:
      "Atrasos constantes poderão gerar revisão dos horários da rota ou reavaliação da prestação do serviço.",
  },
  {
    titulo: "Falta do aluno",
    texto:
      "Sempre que possível, o responsável deverá comunicar previamente quando o aluno não utilizará o transporte.",
  },
  {
    titulo: "Segurança",
    texto: "O aluno será entregue somente às pessoas autorizadas pelo responsável.",
  },
  {
    titulo: "Trânsito e imprevistos",
    texto:
      "Trânsito, acidentes, chuvas, interdições e demais imprevistos poderão ocasionar atrasos sem caracterizar descumprimento contratual.",
  },
  {
    titulo: "Alteração de rota",
    texto:
      "O motorista poderá alterar a rota buscando maior eficiência e segurança, comunicando previamente quando necessário.",
  },
  {
    titulo: "Atualização cadastral",
    texto:
      "O responsável deverá manter sempre atualizados telefone, WhatsApp, e-mail, endereço, escola, pessoas autorizadas e demais informações importantes.",
  },
  {
    titulo: "Conservação do veículo",
    texto:
      "O motorista compromete-se a manter o veículo em perfeitas condições de manutenção e segurança.",
  },
  {
    titulo: "Respeito",
    texto:
      "Motorista e responsáveis comprometem-se a manter respeito e cordialidade em toda a relação contratual.",
  },
  {
    titulo: "Cancelamento",
    texto: "O cancelamento deverá ser comunicado com antecedência mínima de 30 (trinta) dias.",
  },
  {
    titulo: "Inadimplência",
    texto:
      "Em caso de inadimplência, poderão ser adotadas as medidas previstas no contrato e na legislação aplicável.",
  },
];

export type Clausula = { titulo: string; texto: string };

/** Cláusulas base do contrato: personalizadas quando existirem, senão as padrão. */
export function clausulasBase(c: ContratoDoc): Clausula[] {
  return Array.isArray(c.clausulas_custom) && c.clausulas_custom.length
    ? (c.clausulas_custom as Clausula[]).filter((cl) => cl && (cl.titulo || cl.texto)).map((cl) => ({ ...cl }))
    : CLAUSULAS.map((cl) => ({ ...cl }));
}

/** Cláusulas efetivas do contrato: base + multa/juros + adicionais. */
export function clausulasDoContrato(c: ContratoDoc): Clausula[] {
  const base = clausulasBase(c);


  const frase = fraseInadimplencia(c);
  const lista = base.map((cl) => {
    if (!frase) return { ...cl };
    const ehInadimplencia = /inadimpl/i.test(cl.titulo || "");
    if (!ehInadimplencia || cl.texto.includes(frase)) return { ...cl };
    return { ...cl, texto: `${cl.texto} ${frase}`.trim() };
  });

  if (frase && !lista.some((cl) => cl.texto.includes(frase))) {
    lista.push({ titulo: "Multa e juros por atraso", texto: frase });
  }

  const extras = String(c.clausulas_adicionais || "")
    .split(/\n{2,}/)
    .map((t) => t.trim())
    .filter(Boolean);
  for (const texto of extras) lista.push({ titulo: "Regra especial", texto });

  if (c.autoriza_imagem === true) {
    lista.push({
      titulo: "Autorização de uso de imagem",
      texto:
        "O responsável AUTORIZA o uso da imagem do aluno em fotos e vídeos para fins de divulgação do transporte escolar, sem qualquer ônus, podendo revogar esta autorização a qualquer momento mediante comunicação ao motorista.",
    });
  }

  return lista;
}

export function buildContratoHTML(c: ContratoDoc, motoristaNome: string, marca: MarcaVan): string {
  const clausulasHTML = clausulasDoContrato(c)
    .map((cl, i) => `<p class="clausula"><b>${i + 1}. ${esc(cl.titulo)}.</b> ${esc(cl.texto)}</p>`)
    .join("");


  const corpo = `
${cabecalho(marca, `Contrato Nº ${esc(String(c.id).slice(0, 8).toUpperCase())}`)}
<h1>Contrato de Prestação de Serviço — Transporte Escolar</h1>

<h2>Motorista</h2>
<div class="grid">
  <div class="row"><div class="label">Nome</div><div class="value">${esc(motoristaNome)}</div></div>
  ${c.pix_motorista ? `<div class="row"><div class="label">Chave PIX</div><div class="value">${esc(c.pix_motorista)}</div></div>` : ""}
</div>

<h2>Dados do Aluno</h2>
<div class="grid">
  <div class="row"><div class="label">Nome do aluno</div><div class="value">${esc(c.aluno_nome)}</div></div>
  <div class="row"><div class="label">Escola</div><div class="value">${esc(c.escola || "—")}</div></div>
  <div class="row"><div class="label">Endereço</div><div class="value">${esc(c.endereco || "—")}</div></div>
  <div class="row"><div class="label">Turno</div><div class="value">${esc(c.turno || "—")}</div></div>
  ${c.horario_ida ? `<div class="row"><div class="label">Horário de ida</div><div class="value">${esc(c.horario_ida)}</div></div>` : ""}
  ${c.horario_volta ? `<div class="row"><div class="label">Horário de volta</div><div class="value">${esc(c.horario_volta)}</div></div>` : ""}
</div>

<h2>Responsável</h2>
<div class="grid">
  <div class="row"><div class="label">Nome</div><div class="value">${esc(c.responsavel || "—")}</div></div>
  <div class="row"><div class="label">Telefone</div><div class="value">${esc(c.telefone || "—")}</div></div>
  ${c.email_responsavel ? `<div class="row"><div class="label">E-mail</div><div class="value">${esc(c.email_responsavel)}</div></div>` : ""}
  ${c.telefone_emergencia ? `<div class="row"><div class="label">Telefone de emergência</div><div class="value">${esc(c.telefone_emergencia)}</div></div>` : ""}
</div>
${c.pessoas_autorizadas ? `<h2>Pessoas autorizadas a buscar o aluno</h2><p class="clausula">${nl(c.pessoas_autorizadas)}</p>` : ""}

<h2>Condições Financeiras e Vigência</h2>
<div class="grid">
  <div class="row"><div class="label">Mensalidade</div><div class="value">R$ ${formatBRL(Number(c.mensalidade || 0))}</div></div>
  <div class="row"><div class="label">Dia de vencimento</div><div class="value">Todo dia ${esc(c.dia_vencimento ?? "—")}</div></div>
  ${c.forma_pagamento ? `<div class="row"><div class="label">Forma de pagamento</div><div class="value">${esc(c.forma_pagamento)}</div></div>` : ""}
  <div class="row"><div class="label">Início</div><div class="value">${fmtDate(c.data_inicio)}</div></div>
  <div class="row"><div class="label">Término</div><div class="value">${fmtDate(c.data_termino)}</div></div>
</div>

<h2>Cláusulas</h2>
${clausulasHTML}

${c.observacoes_importantes ? `<h2>Observações importantes</h2><p class="clausula">${nl(c.observacoes_importantes)}</p>` : ""}
${c.observacoes ? `<h2>Observações</h2><p class="clausula">${nl(c.observacoes)}</p>` : ""}

<h2>Assinaturas</h2>
<div class="sign" data-resp-nome="${esc(c.responsavel || "Responsável")}" data-sig-motorista="${sigAttr(c.assinatura_motorista)}" data-sig-responsavel="${sigAttr(c.assinatura_responsavel)}">
  ${blocoAssinatura(c.assinatura_responsavel, c.responsavel || "Responsável", "Responsável pelo(a) aluno(a)")}
  ${blocoAssinatura(c.assinatura_motorista, marca.nome, "Transportador(a)")}
</div>

<div class="footer">${esc(marca.nome)} • ${new Date().toLocaleDateString("pt-BR")}</div>`;

  return documento(`Contrato — ${c.aluno_nome}`, corpo);
}

/* ------------------------------------------------------------------ */
/* Garantia / Reserva de vaga                                          */
/* ------------------------------------------------------------------ */

export type GarantiaDoc = {
  id: string;
  aluno_nome: string;
  escola?: string | null;
  responsavel_nome?: string | null;
  responsavel_whatsapp?: string | null;
  ano_referencia: number | string;
  tipo: string;
  tipo_outro?: string | null;
  cobrar?: boolean | null;
  valor?: number | string | null;
  abater?: boolean | null;
  abater_em?: string | null;
  abater_outro?: string | null;
  prazo_resposta?: string | null;
  observacoes?: string | null;
  mensalidade_prevista?: number | string | null;
  confirmado_em?: string | null;
  assinatura_motorista?: unknown;
  assinatura_responsavel?: unknown;
};

export function buildGarantiaHTML(g: GarantiaDoc, marca: MarcaVan): string {
  const tipoTxt = tipoLabel({ tipo: g.tipo, tipo_outro: g.tipo_outro ?? null } as never);
  const valorTxt = valorLabel({ cobrar: !!g.cobrar, valor: Number(g.valor || 0) } as never);
  const abatTxt = abatimentoLabel({
    abater: !!g.abater,
    abater_em: g.abater_em ?? null,
    abater_outro: g.abater_outro ?? null,
  } as never);

  const termo =
    `Declaro estar ciente e de acordo com as condições acima descritas para a reserva da vaga no transporte escolar durante o ano letivo de ${esc(String(g.ano_referencia))}. ` +
    (g.cobrar && Number(g.valor) > 0
      ? g.abater
        ? `O valor pago a título de reserva será ${esc(abatTxt.toLowerCase())}. `
        : "O valor pago a título de reserva não será abatido das mensalidades. "
      : "Não há cobrança de valor para esta reserva de vaga. ") +
    "Este documento não substitui o contrato de prestação de serviço nem gera cobrança automática de mensalidade.";

  const corpo = `
${cabecalho(marca, `Reserva de vaga<br>Emitido em ${new Date().toLocaleDateString("pt-BR")}`)}
<h1>Termo de Reserva de Vaga — ${esc(String(g.ano_referencia))}</h1>

<p class="clausula">${esc(marca.nome)} registra a reserva de 1 (uma) vaga no serviço de transporte escolar para o(a) aluno(a) ${esc(g.aluno_nome)}${g.escola ? `, da escola ${esc(g.escola)}` : ""}, referente ao ano letivo de ${esc(String(g.ano_referencia))}, na modalidade "${esc(tipoTxt)}", conforme as condições abaixo acordadas com o(a) responsável${g.responsavel_nome ? ` ${esc(g.responsavel_nome)}` : ""}.</p>

<p class="clausula"><b>${esc(saudacaoReserva(g))}</b></p>

${mensalidadePrevistaFrase(g) ? `<p class="clausula"><b>Valor da mensalidade:</b> ${esc(mensalidadePrevistaFrase(g))}</p>` : ""}

<h2>Dados</h2>
<div class="grid">
  <div class="row"><div class="label">Aluno(a)</div><div class="value">${esc(g.aluno_nome)}</div></div>
  <div class="row"><div class="label">Escola</div><div class="value">${esc(g.escola || "—")}</div></div>
  <div class="row"><div class="label">Responsável</div><div class="value">${esc(g.responsavel_nome || "—")}</div></div>
  <div class="row"><div class="label">Ano letivo</div><div class="value">${esc(String(g.ano_referencia))}</div></div>
  <div class="row"><div class="label">Tipo</div><div class="value">${esc(tipoTxt)}</div></div>
  <div class="row"><div class="label">Valor</div><div class="value">${esc(valorTxt)}</div></div>
  ${g.abater ? `<div class="row"><div class="label">Abatimento</div><div class="value">${esc(abatTxt)}</div></div>` : ""}
  ${g.prazo_resposta ? `<div class="row"><div class="label">Responder até</div><div class="value">${esc(formatDataBR(g.prazo_resposta))}</div></div>` : ""}
</div>

${(g.observacoes || "").trim() ? `<div class="obs"><b>Observações:</b> ${nl(g.observacoes)}</div>` : ""}
${g.prazo_resposta ? `<div class="aviso">🗓️ ${esc(prazoRespostaTexto(g.prazo_resposta))}</div>` : ""}

<h2>Termo de concordância</h2>
<p class="clausula">${termo}</p>

<h2>Assinaturas</h2>
<div class="sign" data-resp-nome="${esc(g.responsavel_nome || "Responsável")}" data-sig-motorista="${sigAttr(g.assinatura_motorista)}" data-sig-responsavel="${sigAttr(g.assinatura_responsavel)}">
  ${blocoAssinatura(g.assinatura_motorista, marca.nome, "Transportador(a)")}
  ${blocoAssinatura(g.assinatura_responsavel, g.responsavel_nome || "Responsável", "Responsável pelo(a) aluno(a)")}
</div>

<div class="footer">${esc(marca.nome)} • Reserva de vaga ${esc(String(g.ano_referencia))}</div>`;

  return documento(`Reserva de vaga — ${g.aluno_nome}`, corpo);
}

/* ------------------------------------------------------------------ */
/* Documento → imagem (WhatsApp)                                       */
/* ------------------------------------------------------------------ */

/**
 * Rasteriza o documento HTML em uma ou mais imagens PNG (páginas A4).
 * Usado no WhatsApp, onde o PDF não é anexado de forma confiável.
 */
export async function documentoParaImagens(html: string, maxPaginas = 6): Promise<Blob[]> {
  const { default: html2canvas } = await import("html2canvas");

  const iframe = document.createElement("iframe");
  iframe.setAttribute("aria-hidden", "true");
  iframe.style.cssText =
    "position:fixed;left:-10000px;top:0;width:820px;height:1200px;border:0;opacity:0;";
  document.body.appendChild(iframe);

  try {
    const doc = iframe.contentDocument;
    if (!doc) return [];
    doc.open();
    doc.write(html);
    doc.close();

    // aguarda imagens (logo/assinaturas) carregarem
    const imgs = Array.from(doc.images);
    await Promise.all(
      imgs.map(
        (img) =>
          new Promise<void>((resolve) => {
            if (img.complete) return resolve();
            img.onload = () => resolve();
            img.onerror = () => resolve();
            setTimeout(resolve, 2500);
          }),
      ),
    );
    await new Promise((r) => setTimeout(r, 60));

    const body = doc.body;
    const fullH = Math.max(body.scrollHeight, body.offsetHeight);
    iframe.style.height = `${fullH + 40}px`;

    const canvas = await html2canvas(body, {
      backgroundColor: "#ffffff",
      scale: 2,
      width: 820,
      height: fullH,
      windowWidth: 820,
      windowHeight: fullH,
      useCORS: true,
      logging: false,
    });

    const pageH = Math.round(canvas.width * 1.414);
    const paginas = Math.min(maxPaginas, Math.max(1, Math.ceil(canvas.height / pageH)));
    const blobs: Blob[] = [];

    for (let i = 0; i < paginas; i++) {
      const top = i * pageH;
      const h = Math.min(pageH, canvas.height - top);
      if (h <= 0) break;
      const page = document.createElement("canvas");
      page.width = canvas.width;
      page.height = h;
      const ctx = page.getContext("2d");
      if (!ctx) continue;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, page.width, page.height);
      ctx.drawImage(canvas, 0, top, canvas.width, h, 0, 0, canvas.width, h);
      const blob = await new Promise<Blob | null>((resolve) =>
        page.toBlob((b) => resolve(b), "image/png", 0.95),
      );
      if (blob) blobs.push(blob);
    }
    return blobs;
  } finally {
    iframe.remove();
  }
}

/** Compartilha as imagens do documento + mensagem pelo painel nativo. */
export async function compartilharImagensDocumento(
  blobs: Blob[],
  baseName: string,
  opts: { title: string; text: string },
): Promise<"shared" | "downloaded" | "cancelled"> {
  const files = blobs.map(
    (b, i) =>
      new File([b], `${baseName}${blobs.length > 1 ? `-${i + 1}` : ""}.png`, { type: "image/png" }),
  );
  const nav = navigator as Navigator & {
    canShare?: (data: { files?: File[] }) => boolean;
    share?: (data: ShareData & { files?: File[] }) => Promise<void>;
  };

  if (files.length && nav.share) {
    const podeArquivos = nav.canShare?.({ files }) ?? true;
    if (podeArquivos) {
      try {
        await nav.share({ files, title: opts.title, text: opts.text });
        return "shared";
      } catch (err) {
        const name = err instanceof Error ? err.name.toLowerCase() : "";
        const msg = err instanceof Error ? err.message.toLowerCase() : "";
        if (name === "aborterror" || msg.includes("cancel") || msg.includes("abort"))
          return "cancelled";
      }
    }
  }

  for (const file of files) {
    const url = URL.createObjectURL(file);
    const a = document.createElement("a");
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10_000);
  }
  return "downloaded";
}
