/**
 * Multa por atraso e juros de mora (opcionais).
 *
 * Regras:
 *  - Ambos são opcionais: quando zerados, nada muda no sistema.
 *  - Cada um pode ser em porcentagem (%) sobre a mensalidade ou em reais (R$).
 *  - A multa incide uma única vez após o vencimento; os juros incidem por dia
 *    de atraso até a liquidação.
 */
import { formatBRL } from "./format";

export type TipoEncargo = "percentual" | "reais";

export type EncargoConfig = {
  multa_atraso?: number | string | null;
  multa_tipo?: string | null;
  juros_dia?: number | string | null;
  juros_tipo?: string | null;
};

export function normalizeTipoEncargo(v: unknown): TipoEncargo {
  return v === "reais" ? "reais" : "percentual";
}

const num = (v: unknown): number => {
  const n = Number(v ?? 0);
  return Number.isFinite(n) && n > 0 ? n : 0;
};

export function temEncargos(cfg: EncargoConfig | null | undefined): boolean {
  if (!cfg) return false;
  return num(cfg.multa_atraso) > 0 || num(cfg.juros_dia) > 0;
}

function label(valor: number, tipo: TipoEncargo): string {
  if (valor <= 0) return "";
  return tipo === "reais"
    ? `R$ ${formatBRL(valor)}`
    : `${valor.toLocaleString("pt-BR", { maximumFractionDigits: 2 })}%`;
}

export function multaLabel(cfg: EncargoConfig): string {
  return label(num(cfg.multa_atraso), normalizeTipoEncargo(cfg.multa_tipo));
}

export function jurosLabel(cfg: EncargoConfig): string {
  return label(num(cfg.juros_dia), normalizeTipoEncargo(cfg.juros_tipo));
}

export type EncargosCalculados = {
  multa: number;
  juros: number;
  encargos: number;
  total: number;
};

/** Valor atualizado de uma parcela em atraso. */
export function calcularEncargos(
  valorOriginal: number,
  diasAtraso: number,
  cfg: EncargoConfig | null | undefined,
): EncargosCalculados {
  const base = Number(valorOriginal) || 0;
  const dias = Math.max(0, Math.floor(diasAtraso || 0));
  if (!cfg || dias <= 0) return { multa: 0, juros: 0, encargos: 0, total: base };

  const multaValor = num(cfg.multa_atraso);
  const jurosValor = num(cfg.juros_dia);
  const multa =
    multaValor <= 0 ? 0 : normalizeTipoEncargo(cfg.multa_tipo) === "reais" ? multaValor : (base * multaValor) / 100;
  const jurosDia =
    jurosValor <= 0 ? 0 : normalizeTipoEncargo(cfg.juros_tipo) === "reais" ? jurosValor : (base * jurosValor) / 100;
  const juros = jurosDia * dias;

  const round = (n: number) => Math.round(n * 100) / 100;
  const m = round(multa);
  const j = round(juros);
  return { multa: m, juros: j, encargos: round(m + j), total: round(base + m + j) };
}

/** Frase da cláusula de inadimplência (vazia quando não houver configuração). */
export function fraseInadimplencia(cfg: EncargoConfig | null | undefined): string {
  if (!cfg || !temEncargos(cfg)) return "";
  const m = multaLabel(cfg);
  const j = jurosLabel(cfg);
  if (m && j) {
    return `Em caso de atraso no pagamento após o vencimento, incidirá multa de ${m}, acrescida de juros de mora de ${j} por dia de atraso até a liquidação.`;
  }
  if (m) {
    return `Em caso de atraso no pagamento após o vencimento, incidirá multa de ${m} até a liquidação.`;
  }
  return `Em caso de atraso no pagamento após o vencimento, incidirão juros de mora de ${j} por dia de atraso até a liquidação.`;
}
