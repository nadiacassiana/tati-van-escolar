import { supabase } from "@/integrations/supabase/client";

export type EnderecoPartes = {
  rua: string;
  numero: string;
  bairro: string;
  cidade: string;
  estado: string;
  cep: string;
};

export type Escola = EnderecoPartes & {
  id: string;
  nome: string;
  /** Endereço completo em texto (mantido em sincronia com as partes). */
  endereco: string;
};

const COLS = "id, nome, endereco, rua, numero, bairro, cidade, estado, cep";

/** Monta o endereço completo a partir das partes (Rua, Número, Bairro, Cidade, Estado, CEP). */
export function comporEndereco(p: Partial<EnderecoPartes>): string {
  const rua = (p.rua || "").trim();
  const numero = (p.numero || "").trim();
  const bairro = (p.bairro || "").trim();
  const cidade = (p.cidade || "").trim();
  const estado = (p.estado || "").trim();
  const cep = (p.cep || "").trim();
  if (!rua && !bairro && !cidade && !estado && !cep) return "";
  const linha1 = [rua, numero].filter(Boolean).join(", ");
  const cidadeUf = [cidade, estado].filter(Boolean).join(" - ");
  return [linha1, bairro, cidadeUf, cep].filter(Boolean).join(" - ");
}

/**
 * Extrai Rua, Número, Bairro, Cidade, Estado e CEP de um endereço salvo
 * como texto único (formatos comuns: "Rua X, 123 - Bairro - Cidade - UF - CEP").
 */
export function separarEndereco(texto: string): EnderecoPartes {
  const vazio: EnderecoPartes = { rua: "", numero: "", bairro: "", cidade: "", estado: "", cep: "" };
  let t = (texto || "").trim();
  if (!t || t === "—") return vazio;

  const out = { ...vazio };

  // CEP em qualquer posição
  const cepM = t.match(/\b(\d{5})-?(\d{3})\b/);
  if (cepM) {
    out.cep = `${cepM[1]}-${cepM[2]}`;
    t = t.replace(cepM[0], " ");
  }

  const partes = t
    .split(/\s*[-–|]\s*|\s*,\s*(?=[^\d])/)
    .map((p) => p.trim())
    .filter(Boolean);

  // Primeira parte: rua (+ número, se houver)
  const primeira = partes.shift() || "";
  const numM = primeira.match(/^(.*?)[,\s]+n?º?\.?\s*(\d+[A-Za-z]?)\s*$/i);
  if (numM) {
    out.rua = (numM[1] || "").replace(/[,\s]+$/, "").trim();
    out.numero = (numM[2] || "").trim();
  } else {
    out.rua = primeira.replace(/[,\s]+$/, "").trim();
  }

  // Estado (UF isolada ou "Cidade/UF")
  for (let i = partes.length - 1; i >= 0; i--) {
    const p = partes[i] as string;
    const ufSolo = p.match(/^([A-Za-z]{2})$/);
    const cidadeUf = p.match(/^(.+?)\s*\/\s*([A-Za-z]{2})$/);
    if (ufSolo) {
      out.estado = (ufSolo[1] as string).toUpperCase();
      partes.splice(i, 1);
      break;
    }
    if (cidadeUf) {
      out.cidade = (cidadeUf[1] as string).trim();
      out.estado = (cidadeUf[2] as string).toUpperCase();
      partes.splice(i, 1);
      break;
    }
  }

  if (!out.numero && partes.length) {
    const idx = partes.findIndex((p) => /^n?º?\.?\s*\d+[A-Za-z]?$/i.test(p));
    if (idx >= 0) {
      out.numero = (partes[idx] as string).replace(/[^\dA-Za-z]/g, "");
      partes.splice(idx, 1);
    }
  }

  if (partes.length) out.bairro = partes.shift() as string;
  if (!out.cidade && partes.length) out.cidade = partes.shift() as string;

  return out;
}

/** Lista as escolas (com endereço) cadastradas pelo motorista. */
export async function listarEscolas(): Promise<Escola[]> {
  const { data } = await supabase
    .from("escolas")
    .select(COLS)
    .order("nome", { ascending: true });
  return (((data as unknown) as Escola[]) || []).map((e) => ({
    ...e,
    rua: e.rua || "",
    numero: e.numero || "",
    bairro: e.bairro || "",
    cidade: e.cidade || "",
    estado: e.estado || "",
    cep: e.cep || "",
  }));
}

/** Cria/atualiza o endereço (texto simples) de uma escola. */
export async function salvarEscolaEndereco(userId: string, nome: string, endereco: string): Promise<void> {
  const nomeLimpo = nome.trim();
  if (!nomeLimpo) return;
  const { error } = await supabase
    .from("escolas")
    .upsert({ user_id: userId, nome: nomeLimpo, endereco: endereco.trim() } as never, { onConflict: "user_id,nome" });
  if (error) throw error;
}

/** Cria/atualiza a escola com endereço detalhado. */
export async function salvarEscola(
  userId: string,
  nome: string,
  partes: Partial<EnderecoPartes>,
): Promise<void> {
  const nomeLimpo = nome.trim();
  if (!nomeLimpo) return;
  const { error } = await supabase.from("escolas").upsert(
    {
      user_id: userId,
      nome: nomeLimpo,
      rua: (partes.rua || "").trim(),
      numero: (partes.numero || "").trim(),
      bairro: (partes.bairro || "").trim(),
      cidade: (partes.cidade || "").trim(),
      estado: (partes.estado || "").trim(),
      cep: (partes.cep || "").trim(),
      endereco: comporEndereco(partes),
    } as never,
    { onConflict: "user_id,nome" },
  );
  if (error) throw error;
}

/** Remove uma escola cadastrada. */
export async function excluirEscola(id: string): Promise<void> {
  const { error } = await supabase.from("escolas").delete().eq("id", id);
  if (error) throw error;
}

/** Mapa nome -> endereço para consulta rápida. */
export function mapaEnderecos(escolas: Escola[]): Record<string, string> {
  const m: Record<string, string> = {};
  for (const e of escolas) {
    const end = e.endereco || comporEndereco(e);
    if (end) m[e.nome] = end;
  }
  return m;
}
