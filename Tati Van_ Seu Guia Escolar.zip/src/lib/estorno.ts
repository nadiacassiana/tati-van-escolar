// Estorno (desfazer recebimento) — corrige uma baixa feita por engano.
// Regra: o pagamento deixa de existir (a cobrança volta ao status anterior por
// competência), o recibo permanece guardado, porém marcado como estornado —
// nunca some do histórico.
import { supabase } from "@/integrations/supabase/client";
import type { Recibo } from "@/lib/recibo";
import { monthRefOf, vencimentoDate } from "@/lib/mensalidades";

export type ReciboLog = { em: string; evento: string };

export function parseReciboLog(raw: unknown): ReciboLog[] {
  if (!Array.isArray(raw)) return [];
  return (raw as ReciboLog[]).filter((h) => h && typeof h.evento === "string");
}

export function isEstornado(r: Pick<Recibo, "estornado_em">): boolean {
  return !!r.estornado_em;
}

/** Recibos que ainda valem como recebimento (ignora os estornados). */
export function recibosValidos<T extends { estornado_em?: string | null }>(lista: T[]): T[] {
  return lista.filter((r) => !r.estornado_em);
}

/**
 * Desfaz o recebimento de um recibo:
 * 1. apaga o pagamento vinculado (a mensalidade volta a pendente/vencida);
 * 2. corrige o status do aluno quando a competência é o mês atual;
 * 3. marca o recibo como estornado, mantendo o histórico da correção.
 */
export async function estornarRecebimento(
  recibo: Recibo,
  motivo?: string,
): Promise<{ ok: boolean; erro?: string }> {
  if (recibo.estornado_em) return { ok: false, erro: "Este recebimento já foi desfeito." };

  if (recibo.pagamento_id) {
    const { error } = await supabase.from("pagamentos").delete().eq("id", recibo.pagamento_id);
    if (error) return { ok: false, erro: "Não foi possível desfazer o recebimento." };
  } else if (recibo.aluno_id) {
    await supabase
      .from("pagamentos")
      .delete()
      .eq("aluno_id", recibo.aluno_id)
      .eq("mes_referencia", recibo.mes_referencia);
  }

  // Status do aluno só reflete o mês corrente.
  if (recibo.aluno_id && recibo.mes_referencia === monthRefOf(new Date())) {
    const { data: aluno } = await supabase
      .from("alunos")
      .select("vencimento")
      .eq("id", recibo.aluno_id)
      .maybeSingle();
    const dia = Number((aluno as { vencimento?: number } | null)?.vencimento ?? 1);
    const venc = vencimentoDate(recibo.mes_referencia, dia);
    const hoje = new Date();
    const hoje0 = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate());
    const status = venc.getTime() < hoje0.getTime() ? "vencido" : "pendente";
    await supabase.from("alunos").update({ status_mensalidade: status }).eq("id", recibo.aluno_id);
  }

  const agora = new Date().toISOString();
  const historico = [
    ...parseReciboLog(recibo.historico),
    {
      em: agora,
      evento: motivo?.trim()
        ? `Recebimento desfeito (estornado): ${motivo.trim()}`
        : "Recebimento desfeito (estornado) pela motorista",
    },
  ];

  const { error } = await supabase
    .from("recibos")
    .update({ estornado_em: agora, estorno_motivo: motivo?.trim() || null, historico })
    .eq("id", recibo.id);
  if (error) return { ok: false, erro: "Recebimento desfeito, mas não foi possível atualizar o recibo." };

  return { ok: true };
}
