import jsPDF from "jspdf";
import { getMarca } from "./marca";
import { parseAssinatura } from "./assinatura";
import { desenharAssinaturas } from "./assinatura-pdf";

import type { MotoristaPerfil } from "./whatsapp";
import {
  abatimentoLabel,
  formatDataBR,
  formatDataHora,
  mensalidadePrevistaFrase,
  prazoRespostaTexto,
  saudacaoReserva,
  tipoLabel,
  valorLabel,
  type GarantiaVaga,
} from "./garantia-vaga";


function hoje(): string {
  return new Date().toLocaleDateString("pt-BR");
}

/** Documento de Reserva de Vaga (A4) com a identidade visual da motorista. */
export function garantiaToPdfBlob(g: GarantiaVaga, motorista: MotoristaPerfil): Blob {
  const marca = getMarca(motorista);
  const pdf = new jsPDF("p", "mm", "a4");
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const marginX = 16;
  const contentW = pageW - marginX * 2;
  let y = 14;

  const setText = (
    size: number,
    style: "normal" | "bold" = "normal",
    color: [number, number, number] = [26, 26, 46],
  ) => {
    pdf.setFont("helvetica", style);
    pdf.setFontSize(size);
    pdf.setTextColor(color[0], color[1], color[2]);
  };

  // ---------- Cabeçalho ----------
  let textX = marginX;
  if (marca.logo) {
    try {
      const props = pdf.getImageProperties(marca.logo);
      const maxH = 18;
      const maxW = 40;
      const ratio = props.width / props.height;
      let h = maxH;
      let w = h * ratio;
      if (w > maxW) {
        w = maxW;
        h = w / ratio;
      }
      pdf.addImage(marca.logo, props.fileType || "PNG", marginX, y, w, h, undefined, "FAST");
      textX = marginX + w + 5;
    } catch {
      textX = marginX;
    }
  }

  setText(16, "bold", [30, 58, 138]);
  pdf.text(marca.nome, textX, y + 6);
  setText(9, "normal", [82, 82, 91]);
  let infoY = y + 12;
  const sub = [motorista.apelido, motorista.nome_completo].filter(Boolean).join(" • ");
  if (sub) {
    pdf.text(sub, textX, infoY);
    infoY += 4.5;
  }
  if (motorista.telefone) {
    pdf.text(`Tel: ${motorista.telefone}`, textX, infoY);
    infoY += 4.5;
  }
  if (motorista.email) {
    pdf.text(motorista.email, textX, infoY);
    infoY += 4.5;
  }

  pdf.setFillColor(30, 64, 175);
  pdf.roundedRect(pageW - marginX - 50, y, 50, 8, 1.5, 1.5, "F");
  setText(9, "bold", [255, 255, 255]);
  pdf.text("RESERVA DE VAGA", pageW - marginX - 25, y + 5.5, { align: "center" });
  setText(8, "normal", [107, 114, 128]);
  pdf.text(`Emitido em ${hoje()}`, pageW - marginX, y + 14, { align: "right" });

  y = Math.max(infoY, y + 22) + 2;
  pdf.setDrawColor(30, 64, 175);
  pdf.setLineWidth(1.1);
  pdf.line(marginX, y, pageW - marginX, y);
  y += 10;

  // ---------- Título ----------
  setText(14, "bold", [26, 26, 46]);
  pdf.text(`TERMO DE RESERVA DE VAGA — ${g.ano_referencia}`, pageW / 2, y, { align: "center" });
  y += 10;

  // ---------- Texto ----------
  const texto =
    `${marca.nome} registra a reserva de 1 (uma) vaga no serviço de transporte escolar para o(a) aluno(a) ` +
    `${g.aluno_nome}${g.escola ? `, da escola ${g.escola}` : ""}, referente ao ano letivo de ${g.ano_referencia}, ` +
    `na modalidade "${tipoLabel(g)}", conforme as condições abaixo acordadas com o(a) responsável` +
    `${g.responsavel_nome ? ` ${g.responsavel_nome}` : ""}.`;
  setText(10.5, "normal", [26, 26, 46]);
  for (const l of pdf.splitTextToSize(texto, contentW) as string[]) {
    pdf.text(l, marginX, y);
    y += 5.8;
  }
  y += 3;

  const saudacao = saudacaoReserva(g);
  setText(10.5, "bold", [30, 58, 138]);
  for (const l of pdf.splitTextToSize(saudacao, contentW) as string[]) {
    pdf.text(l, marginX, y);
    y += 5.8;
  }
  y += 3;

  const fraseMensalidade = mensalidadePrevistaFrase(g);
  if (fraseMensalidade) {
    setText(10.5, "bold", [26, 26, 46]);
    pdf.text("Valor da mensalidade:", marginX, y);
    y += 5.5;
    setText(10.5, "normal", [26, 26, 46]);
    for (const l of pdf.splitTextToSize(fraseMensalidade, contentW) as string[]) {
      pdf.text(l, marginX, y);
      y += 5.5;
    }
    y += 3;
  }
  y += 3;

  // ---------- Dados ----------
  const gap = 6;
  const colW = (contentW - gap) / 2;

  const drawBox = (x: number, top: number, w: number, title: string, rows: [string, string][]) => {
    const boxH = 10 + rows.length * 7.4;
    pdf.setDrawColor(226, 232, 240);
    pdf.setLineWidth(0.3);
    pdf.roundedRect(x, top, w, boxH, 2, 2, "S");
    setText(8, "bold", [30, 64, 175]);
    pdf.text(title.toUpperCase(), x + 4, top + 6);
    rows.forEach(([k, v], i) => {
      const ry = top + 12.5 + i * 7.4;
      setText(8, "normal", [107, 114, 128]);
      pdf.text(`${k}:`, x + 4, ry);
      setText(9, "bold", [26, 26, 46]);
      const val = (pdf.splitTextToSize(v || "—", w - 34) as string[])[0];
      pdf.text(val, x + 30, ry);
    });
    return boxH;
  };

  const alunoRows: [string, string][] = [
    ["Aluno(a)", g.aluno_nome || "—"],
    ["Escola", g.escola || "—"],
    ["Ano", String(g.ano_referencia)],
  ];
  const respRows: [string, string][] = [
    ["Responsável", g.responsavel_nome || "—"],
    ["WhatsApp", g.responsavel_whatsapp || "—"],
    ["Tipo", tipoLabel(g)],
  ];
  if (g.prazo_resposta) respRows.push(["Responder até", formatDataBR(g.prazo_resposta)]);
  const h1 = drawBox(marginX, y, colW, "Aluno(a)", alunoRows);
  const h2 = drawBox(marginX + colW + gap, y, colW, "Responsável", respRows);
  y += Math.max(h1, h2) + 8;

  // ---------- Condições ----------
  const info: [string, string][] = [
    ["Valor", valorLabel(g)],
    ["Abatimento", g.abater ? abatimentoLabel(g) : "Não"],
    ["Emissão", hoje()],
  ];
  const iw = (contentW - gap * 2) / 3;
  info.forEach(([k, v], i) => {
    const x = marginX + i * (iw + gap);
    pdf.setDrawColor(226, 232, 240);
    pdf.roundedRect(x, y, iw, 16, 2, 2, "S");
    setText(7, "normal", [107, 114, 128]);
    pdf.text(k.toUpperCase(), x + 3, y + 5.5);
    setText(9, "bold", [26, 26, 46]);
    const val = (pdf.splitTextToSize(v, iw - 6) as string[]).slice(0, 2);
    val.forEach((l, j) => pdf.text(l, x + 3, y + 11 + j * 4.2));
  });
  y += 22;

  if ((g.observacoes || "").trim()) {
    const obsLines = pdf.splitTextToSize(`Observações: ${g.observacoes.trim()}`, contentW - 6) as string[];
    const obsH = 6 + obsLines.length * 5;
    pdf.setFillColor(255, 251, 235);
    pdf.setDrawColor(251, 191, 36);
    pdf.setLineWidth(0.5);
    pdf.roundedRect(marginX, y, contentW, obsH, 2, 2, "FD");
    setText(9, "normal", [55, 65, 81]);
    obsLines.forEach((l, i) => pdf.text(l, marginX + 3, y + 5 + i * 5));
    y += obsH + 6;
  }

  if (g.prazo_resposta) {
    const prazoLines = pdf.splitTextToSize(prazoRespostaTexto(g.prazo_resposta), contentW - 6) as string[];
    const pH = 6 + prazoLines.length * 5;
    pdf.setFillColor(239, 246, 255);
    pdf.setDrawColor(59, 130, 246);
    pdf.setLineWidth(0.5);
    pdf.roundedRect(marginX, y, contentW, pH, 2, 2, "FD");
    setText(9, "normal", [30, 58, 138]);
    prazoLines.forEach((l, i) => pdf.text(l, marginX + 3, y + 5 + i * 5));
    y += pH + 6;
  }

  // ---------- Termo de concordância ----------
  const termo =
    `Declaro estar ciente e de acordo com as condições acima descritas para a reserva da vaga no ` +
    `transporte escolar durante o ano letivo de ${g.ano_referencia}. ` +
    (g.cobrar && Number(g.valor) > 0
      ? g.abater
        ? `O valor pago a título de reserva será ${abatimentoLabel(g).toLowerCase()}. `
        : "O valor pago a título de reserva não será abatido das mensalidades. "
      : "Não há cobrança de valor para esta reserva de vaga. ") +
    "Este documento não substitui o contrato de prestação de serviço nem gera cobrança automática de mensalidade.";
  setText(9.5, "normal", [55, 65, 81]);
  const termoLines = pdf.splitTextToSize(termo, contentW) as string[];
  for (const l of termoLines) {
    pdf.text(l, marginX, y);
    y += 5.2;
  }

  // ---------- Assinaturas ----------
  const aMot = parseAssinatura((g as { assinatura_motorista?: unknown }).assinatura_motorista);
  const aResp = parseAssinatura((g as { assinatura_responsavel?: unknown }).assinatura_responsavel);
  y = Math.min(y + 20, pageH - 44);
  y = desenharAssinaturas(pdf, {
    x: marginX,
    largura: contentW,
    y,
    esquerda: {
      papelLabel: "Transportador(a)",
      nomePadrao: marca.nome,
      assinatura: aMot,
    },
    direita: {
      papelLabel: "Responsável pelo(a) aluno(a)",
      nomePadrao: g.responsavel_nome || "Responsável",
      assinatura: aResp,
    },
  });

  if (aResp) {
    setText(8, "normal", [82, 82, 91]);
    const nota =
      "Documento assinado digitalmente pelo responsável, com registro de nome, data e hora." +
      (g.confirmado_em ? ` Confirmado em ${formatDataHora(g.confirmado_em)}.` : "");
    const notaLines = pdf.splitTextToSize(nota, contentW) as string[];
    notaLines.forEach((l, i) => pdf.text(l, pageW / 2, y + 4 + i * 4.2, { align: "center" }));
  }



  // ---------- Rodapé ----------
  setText(7, "normal", [156, 163, 175]);
  pdf.text(`${marca.nome} • Reserva de vaga ${g.ano_referencia}`, pageW / 2, pageH - 8, { align: "center" });

  return pdf.output("blob");
}

export function garantiaFilename(g: GarantiaVaga): string {
  const safe = (g.aluno_nome || "aluno").replace(/[^\p{L}\p{N}\s-]/gu, "").replace(/\s+/g, "_");
  return `Reserva_de_Vaga_${g.ano_referencia}_${safe}.pdf`;
}
