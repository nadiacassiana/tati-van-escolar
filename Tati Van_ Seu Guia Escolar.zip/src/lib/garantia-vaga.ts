import type { Tables } from "@/integrations/supabase/types";
import { formatBRL } from "./format";

export type GarantiaVaga = Tables<"garantias_vaga">;

export type GarantiaStatus = "pendente" | "confirmado" | "recusado";

export type HistoricoItem = { em: string; evento: string };

export const TIPO_OPCOES = [
  { value: "rematricula", label: "Rematrícula" },
  { value: "reserva", label: "Reserva de vaga" },
  { value: "outro", label: "Outro" },
] as const;

export const ABATER_OPCOES = [
  { value: "primeira", label: "Primeira mensalidade" },
  { value: "ultima", label: "Última mensalidade" },
  { value: "mes", label: "Mês específico" },
  { value: "outro", label: "Outro" },
] as const;

export const STATUS_LABEL: Record<GarantiaStatus, string> = {
  pendente: "⏳ Pendente",
  confirmado: "✅ Confirmado",
  recusado: "❌ Recusado",
};

export function tipoLabel(g: Pick<GarantiaVaga, "tipo" | "tipo_outro">): string {
  if (g.tipo === "outro") return (g.tipo_outro || "").trim() || "Outro";
  return TIPO_OPCOES.find((t) => t.value === g.tipo)?.label ?? g.tipo;
}

export function abatimentoLabel(
  g: Pick<GarantiaVaga, "abater" | "abater_em" | "abater_outro">,
): string {
  if (!g.abater) return "Sem abatimento";
  if (g.abater_em === "mes") {
    const raw = (g.abater_outro || "").trim();
    if (/^\d{4}-\d{2}$/.test(raw)) {
      const [y, m] = raw.split("-").map(Number);
      const label = new Date(y, m - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
      return `Abatido em ${label}`;
    }
    return "Abatido em mês específico";
  }
  if (g.abater_em === "outro") return (g.abater_outro || "").trim() || "Abatimento combinado";
  const found = ABATER_OPCOES.find((a) => a.value === g.abater_em);
  return found ? `Abatido na ${found.label.toLowerCase()}` : "Abatimento combinado";
}

export function valorLabel(g: Pick<GarantiaVaga, "cobrar" | "valor">): string {
  if (!g.cobrar) return "Sem cobrança";
  const v = Number(g.valor || 0);
  if (v <= 0) return "Sem custo (R$ 0,00)";
  return `R$ ${formatBRL(v)}`;
}

/** Frase condicional sobre a mensalidade do próximo ano, quando informada. */
export function mensalidadePrevistaFrase(g: {
  ano_referencia: number | string;
  mensalidade_prevista?: number | string | null;
}): string {
  const v = Number(g.mensalidade_prevista || 0);
  if (v <= 0) return "";
  return `O valor da mensalidade para o ano letivo de ${g.ano_referencia} será de R$ ${formatBRL(v)} (referente ao parcelamento do contrato anual).`;
}

export function parseHistorico(raw: unknown): HistoricoItem[] {
  if (!Array.isArray(raw)) return [];
  return (raw as HistoricoItem[]).filter((h) => h && typeof h.evento === "string");
}

export function pushHistorico(raw: unknown, evento: string): HistoricoItem[] {
  return [...parseHistorico(raw), { em: new Date().toISOString(), evento }];
}

/** Data (YYYY-MM-DD) no formato DD/MM/AAAA. */
export function formatDataBR(iso?: string | null): string {
  if (!iso) return "";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : "";
}

/** Texto padrão do prazo de resposta do responsável. */
export function prazoRespostaTexto(iso?: string | null): string {
  const d = formatDataBR(iso);
  if (!d) return "";
  return `Solicitamos a confirmação da reserva de vaga até o dia ${d}. Após essa data, caso não tenhamos retorno, a vaga poderá ser disponibilizada para outro aluno.`;
}

export function formatDataHora(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return `${d.toLocaleDateString("pt-BR")} às ${d.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

/** Saudação inicial de acordo com a origem do aluno (rematrícula x novo/lista de espera). */
export function saudacaoReserva(g: {
  tipo: string;
  aluno_nome: string;
  ano_referencia: number | string;
}): string {
  if (g.tipo === "rematricula") {
    return "Muito obrigado pela parceria e pela confiança no nosso trabalho ao longo deste ano!";
  }
  return `Ficamos muito felizes em informar que temos uma vaga disponível para o(a) ${g.aluno_nome} para o ano letivo de ${g.ano_referencia}!`;
}

/** Mensagem pronta para o WhatsApp do responsável. */
export function buildGarantiaMessage(g: GarantiaVaga, vanNome: string): string {
  const linhas: string[] = [];
  const resp = (g.responsavel_nome || "").trim();
  linhas.push(`Olá${resp ? `, ${resp}` : ""}! 😊`);
  linhas.push("");
  linhas.push(
    `Estamos organizando as vagas do transporte escolar para ${g.ano_referencia} e queremos garantir a vaga do(a) ${g.aluno_nome}.`,
  );
  linhas.push("");
  linhas.push("🎟️ Reserva de vaga");
  linhas.push(`💰 Valor: ${valorLabel(g)}`);
  if (g.cobrar && g.abater) linhas.push(`↩️ ${abatimentoLabel(g)}`);
  const fraseMensalidade = mensalidadePrevistaFrase(g);
  if (fraseMensalidade) linhas.push(fraseMensalidade);
  if ((g.observacoes || "").trim()) {
    linhas.push("");
    linhas.push(g.observacoes.trim());
  }
  if (g.prazo_resposta) {
    linhas.push("");
    linhas.push(`🗓️ ${prazoRespostaTexto(g.prazo_resposta)}`);
  }
  linhas.push("");
  linhas.push(
    "Para garantir a vaga, é só abrir o link abaixo e assinar digitalmente na tela do celular. ✍️",
  );
  linhas.push("");
  linhas.push(
    "A assinatura é registrada no documento junto com a data e a hora, sem precisar imprimir nada.",
  );

  linhas.push("");
  linhas.push(`${saudacaoReserva(g)} 💙`);
  linhas.push("");
  linhas.push(`Obrigada pela confiança! 💙\n${vanNome}`);

  return linhas.join("\n");
}
