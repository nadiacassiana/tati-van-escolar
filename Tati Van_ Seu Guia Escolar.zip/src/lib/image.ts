// Lê um File de imagem, redimensiona para no máximo MAX px (lado maior)
// e devolve um data URL JPEG ~85% — pequeno o bastante para salvar em TEXT.
export async function fileToCompressedDataUrl(file: File, max = 480, quality = 0.85): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(r.error);
    r.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image();
    i.onload = () => resolve(i);
    i.onerror = () => reject(new Error("Imagem inválida"));
    i.src = dataUrl;
  });

  const scale = Math.min(1, max / Math.max(img.width, img.height));
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, w, h);
  return canvas.toDataURL("image/jpeg", quality);
}

/**
 * Logotipo da van: aceita apenas PNG/JPG, recorta as bordas vazias (branco ou
 * transparente), redimensiona para o tamanho ideal mantendo a proporção e
 * aplica compressão leve. A largura final é 2x a exibida (600px) para o
 * logotipo sair nítido no PDF, sem distorção nem peso extra.
 */
export async function fileToLogoDataUrl(file: File, maxWidth = 300, scaleFactor = 2): Promise<string> {
  if (!/^image\/(png|jpe?g)$/i.test(file.type)) {
    throw new Error("Envie uma imagem PNG ou JPG.");
  }
  const isPng = /png/i.test(file.type);

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(r.error);
    r.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const i = new Image();
    i.onload = () => resolve(i);
    i.onerror = () => reject(new Error("Imagem inválida"));
    i.src = dataUrl;
  });

  // --- 1) Detecta a área útil (recorte automático de espaço vazio) ---
  let sx = 0;
  let sy = 0;
  let sw = img.width;
  let sh = img.height;
  try {
    const probe = document.createElement("canvas");
    probe.width = img.width;
    probe.height = img.height;
    const pctx = probe.getContext("2d", { willReadFrequently: true });
    if (pctx) {
      pctx.drawImage(img, 0, 0);
      const { data } = pctx.getImageData(0, 0, probe.width, probe.height);
      let minX = probe.width;
      let minY = probe.height;
      let maxX = -1;
      let maxY = -1;
      for (let y = 0; y < probe.height; y++) {
        for (let x = 0; x < probe.width; x++) {
          const i = (y * probe.width + x) * 4;
          const a = data[i + 3];
          const isEmpty = a < 12 || (data[i] > 244 && data[i + 1] > 244 && data[i + 2] > 244);
          if (isEmpty) continue;
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
      if (maxX > minX && maxY > minY) {
        // margem de respiro de 2% para não cortar rente ao desenho
        const padX = Math.round((maxX - minX) * 0.02);
        const padY = Math.round((maxY - minY) * 0.02);
        sx = Math.max(0, minX - padX);
        sy = Math.max(0, minY - padY);
        sw = Math.min(img.width - sx, maxX - minX + 1 + padX * 2);
        sh = Math.min(img.height - sy, maxY - minY + 1 + padY * 2);
      }
    }
  } catch {
    /* imagem de outra origem: segue sem recorte */
  }

  // --- 2) Redimensiona mantendo proporção (nunca amplia) ---
  const target = maxWidth * scaleFactor;
  const scale = Math.min(1, target / sw);
  const w = Math.max(1, Math.round(sw * scale));
  const h = Math.max(1, Math.round(sh * scale));

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  if (!isPng) {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, w, h);
  }
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, w, h);

  // --- 3) Compressão leve preservando nitidez ---
  return isPng ? canvas.toDataURL("image/png") : canvas.toDataURL("image/jpeg", 0.92);
}

