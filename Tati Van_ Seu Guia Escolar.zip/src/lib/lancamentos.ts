// Lançamentos financeiros — extensão do financeiro para separar tipos de valores.
// Mensalidades continuam sendo calculadas por competência (src/lib/mensalidades.ts).
// Esta tabela guarda: reserva de vaga, crédito do aluno e outros lançamentos.
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import type { GarantiaVaga } from "@/lib/garantia-vaga";
import { formatBRL } from "@/lib/format";

export type Lancamento = Tables<"lancamentos_financeiros">;

export type TipoLancamento = "mensalidade" | "garantia" | "credito" | "plano_anual" | "outros";
export type StatusLancamento = "a_receber" | "recebido";

export const TIPO_LABEL: Record<TipoLancamento, string> = {
  mensalidade: "Mensalidade",
  garantia: "Reserva de vaga",
  credito: "Crédito do aluno",
  plano_anual: "Plano Anual",
  outros: "Outros",
};

export const TIPO_UI: Record<TipoLancamento, string> = {
  mensalidade: "bg-primary/10 text-primary border-primary/30",
  garantia: "bg-warning/20 text-warning-foreground border-warning/40",
  credito: "bg-success/15 text-success border-success/30",
  plano_anual: "bg-accent/20 text-accent-foreground border-accent/40",
  outros: "bg-muted text-muted-foreground",
};


export const STATUS_LANC_LABEL: Record<StatusLancamento, string> = {
  a_receber: "🟡 A receber",
  recebido: "🟢 Recebido",
};

export type LogItem = { em: string; evento: string };

export function parseLog(raw: unknown): LogItem[] {
  if (!Array.isArray(raw)) return [];
  return (raw as LogItem[]).filter((h) => h && typeof h.evento === "string");
}

export function pushLog(raw: unknown, evento: string): LogItem[] {
  return [...parseLog(raw), { em: new Date().toISOString(), evento }];
}

/** Rótulo legível da regra de abatimento guardada no crédito. */
export function regraLabel(regra?: string | null): string {
  if (!regra) return "Uso livre";
  if (regra === "primeira") return "Abater na primeira mensalidade";
  if (regra === "ultima") return "Abater na última mensalidade";
  if (regra.startsWith("mes:")) return `Abater em ${formatCompetenciaBR(regra.slice(4))}`;
  return regra;
}

export function formatCompetenciaBR(ref: string): string {
  const [y, m] = ref.split("-").map(Number);
  if (!y || !m) return ref;
  const label = new Date(y, m - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
  return label.charAt(0).toUpperCase() + label.slice(1);
}

/** Converte a configuração de abatimento da garantia para a regra do crédito. */
export function regraDaGarantia(g: Pick<GarantiaVaga, "abater" | "abater_em" | "abater_outro">): string | null {
  if (!g.abater) return null;
  if (g.abater_em === "mes") {
    const raw = (g.abater_outro || "").trim();
    return /^\d{4}-\d{2}$/.test(raw) ? `mes:${raw}` : null;
  }
  if (g.abater_em === "primeira" || g.abater_em === "ultima") return g.abater_em;
  return (g.abater_outro || "").trim() || null;
}

// ————————————————————————————————————————————————
// Sincronização com o módulo Reserva de Vaga
// ————————————————————————————————————————————————

/**
 * Garante um único lançamento "Reserva de vaga" por aluno + ano.
 * Nunca cria mensalidade e nunca duplica cobrança.
 */
export async function syncGarantiaLancamento(userId: string, g: GarantiaVaga): Promise<void> {
  const { data: existente } = await supabase
    .from("lancamentos_financeiros")
    .select("*")
    .eq("aluno_id", g.aluno_id ?? "")
    .eq("tipo", "garantia")
    .eq("ano_referencia", g.ano_referencia)
    .maybeSingle();
  const atual = (existente as Lancamento | null) ?? null;

  const deveExistir = g.cobrar && Number(g.valor || 0) > 0 && g.status !== "recusado";

  if (!deveExistir) {
    // Só remove o que ainda não foi recebido — histórico de valores pagos é preservado.
    if (atual && atual.status === "a_receber") {
      await supabase.from("lancamentos_financeiros").delete().eq("id", atual.id);
    }
    return;
  }

  if (!atual) {
    await supabase.from("lancamentos_financeiros").insert({
      user_id: userId,
      aluno_id: g.aluno_id,
      aluno_nome: g.aluno_nome,
      tipo: "garantia",
      descricao: `Reserva de vaga ${g.ano_referencia}`,
      valor: Number(g.valor || 0),
      status: "a_receber",
      ano_referencia: g.ano_referencia,
      garantia_id: g.id,
      origem: "Gerado pela Reserva de Vaga",
      regra_abatimento: regraDaGarantia(g),
      historico: pushLog([], "Lançamento gerado pela Reserva de Vaga"),
    });
    return;
  }

  if (atual.status === "recebido") return; // não altera valores já recebidos
  await supabase
    .from("lancamentos_financeiros")
    .update({
      valor: Number(g.valor || 0),
      aluno_nome: g.aluno_nome,
      garantia_id: g.id,
      regra_abatimento: regraDaGarantia(g),
      historico: pushLog(atual.historico, "Lançamento atualizado pela Reserva de Vaga"),
    })
    .eq("id", atual.id);
}

/** Marca a garantia como recebida e, se houver abatimento, gera o crédito do aluno. */
export async function receberGarantia(
  userId: string,
  l: Lancamento,
  data: string,
): Promise<{ credito: boolean }> {
  await supabase
    .from("lancamentos_financeiros")
    .update({
      status: "recebido",
      data_recebimento: data,
      historico: pushLog(l.historico, `Recebido em ${data.split("-").reverse().join("/")}`),
    })
    .eq("id", l.id);

  if (!l.regra_abatimento || Number(l.valor) <= 0) return { credito: false };

  const { data: jaTem } = await supabase
    .from("lancamentos_financeiros")
    .select("id")
    .eq("aluno_id", l.aluno_id ?? "")
    .eq("tipo", "credito")
    .eq("ano_referencia", l.ano_referencia ?? 0)
    .maybeSingle();
  if (jaTem) return { credito: false };

  await supabase.from("lancamentos_financeiros").insert({
    user_id: userId,
    aluno_id: l.aluno_id,
    aluno_nome: l.aluno_nome,
    tipo: "credito",
    descricao: `Crédito da reserva de vaga ${l.ano_referencia ?? ""}`.trim(),
    valor: Number(l.valor),
    saldo_restante: Number(l.valor),
    status: "recebido",
    ano_referencia: l.ano_referencia,
    garantia_id: l.garantia_id,
    origem: "Gerado pela Reserva de Vaga",
    regra_abatimento: l.regra_abatimento,
    historico: pushLog([], "Crédito gerado a partir da reserva de vaga paga"),
  });
  return { credito: true };
}

/** Créditos com saldo disponível de um aluno. */
export function creditosDoAluno(lancamentos: Lancamento[], alunoId: string): Lancamento[] {
  return lancamentos.filter(
    (l) => l.tipo === "credito" && l.aluno_id === alunoId && Number(l.saldo_restante) > 0,
  );
}

export function saldoCreditoAluno(lancamentos: Lancamento[], alunoId: string): number {
  return creditosDoAluno(lancamentos, alunoId).reduce((s, l) => s + Number(l.saldo_restante), 0);
}

/**
 * O crédito deve ser aplicado automaticamente nesta competência?
 * Respeita exatamente a escolha feita na garantia.
 */
export function creditoAutoAplicavel(
  credito: Lancamento,
  competencia: string,
  primeiraEmAberto: string | null,
): boolean {
  const regra = credito.regra_abatimento || "";
  if (regra === "primeira") return !!primeiraEmAberto && competencia === primeiraEmAberto;
  if (regra.startsWith("mes:")) return competencia === regra.slice(4);
  return false; // "última mensalidade" e regras livres exigem confirmação da motorista
}

/** Registra o uso do crédito, atualizando o saldo restante e o log. */
export async function aplicarCredito(
  credito: Lancamento,
  valorAplicado: number,
  competencia: string,
): Promise<void> {
  const novoSaldo = Math.max(0, Number(credito.saldo_restante) - valorAplicado);
  await supabase
    .from("lancamentos_financeiros")
    .update({
      saldo_restante: novoSaldo,
      historico: pushLog(
        credito.historico,
        `Desconto aplicado automaticamente na mensalidade de ${formatCompetenciaBR(competencia)}: R$ ${formatBRL(valorAplicado)} (saldo restante R$ ${formatBRL(novoSaldo)})`,
      ),
    })
    .eq("id", credito.id);
}
