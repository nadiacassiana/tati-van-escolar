import { describe, expect, it, vi, beforeEach } from "vitest";

const state = {
  user: { id: "user-1" } as { id: string } | null,
  profile: null as { logo?: string | null } | null,
  profileError: null as { message: string } | null,
  hang: false,
};

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    auth: {
      getUser: async () => ({ data: { user: state.user } }),
    },
    from: () => ({
      select: () => ({
        eq: () => ({
          maybeSingle: async () => {
            if (state.hang) await new Promise(() => {});
            if (state.profileError) return { data: null, error: state.profileError };
            return { data: state.profile, error: null };
          },
        }),
      }),
    }),
  },
}));

const PNG = "data:image/png;base64,iVBORw0KGgo=";

async function freshStore() {
  vi.resetModules();
  return await import("./logo-store");
}

beforeEach(() => {
  window.localStorage.clear();
  state.user = { id: "user-1" };
  state.profile = null;
  state.profileError = null;
  state.hang = false;
  vi.spyOn(console, "error").mockImplementation(() => {});
});

describe("loadVanLogo — o login nunca pode depender do logotipo", () => {
  it("retorna vazio quando o perfil não tem logotipo", async () => {
    const store = await freshStore();
    state.profile = { logo: null };
    await expect(store.loadVanLogo()).resolves.toBe("");
  });

  it("não lança quando a consulta do perfil falha", async () => {
    const store = await freshStore();
    state.profileError = { message: "permission denied" };
    await expect(store.loadVanLogo()).resolves.toBe("");
  });

  it("não lança quando não há sessão", async () => {
    const store = await freshStore();
    state.user = null;
    await expect(store.loadVanLogo()).resolves.toBe("");
  });

  it("descarta logotipo corrompido e segue sem imagem", async () => {
    const store = await freshStore();
    state.profile = { logo: "isto-nao-e-uma-imagem" };
    await expect(store.loadVanLogo()).resolves.toBe("");
  });

  it("descarta logotipo grande demais (protege o token de login)", async () => {
    const store = await freshStore();
    state.profile = { logo: "data:image/png;base64," + "A".repeat(1_000_000) };
    await expect(store.loadVanLogo()).resolves.toBe("");
  });

  it("aceita logotipo válido", async () => {
    const store = await freshStore();
    state.profile = { logo: PNG };
    await expect(store.loadVanLogo()).resolves.toBe(PNG);
    expect(store.getVanLogo()).toBe(PNG);
  });

  it("desiste após o tempo limite em vez de travar o app", async () => {
    vi.useFakeTimers();
    const store = await freshStore();
    state.hang = true;
    const p = store.loadVanLogo();
    await vi.advanceTimersByTimeAsync(9000);
    await expect(p).resolves.toBe("");
    vi.useRealTimers();
  });
});

describe("cache local do logotipo", () => {
  it("ignora cache corrompido no localStorage", async () => {
    window.localStorage.setItem("tati_van_logo", "conteudo-invalido");
    const store = await freshStore();
    expect(store.getVanLogo()).toBe("");
    expect(window.localStorage.getItem("tati_van_logo")).toBeNull();
  });

  it("reaproveita cache válido", async () => {
    window.localStorage.setItem("tati_van_logo", PNG);
    const store = await freshStore();
    expect(store.getVanLogo()).toBe(PNG);
  });
});
