import { useSyncExternalStore } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * O logotipo da van é uma imagem grande (data URL).
 * Ele NUNCA pode ser gravado em `user_metadata`: esses dados entram no token de
 * login (JWT), o token vira um cabeçalho gigante e o acesso à conta quebra.
 * Por isso ele vive na tabela `profiles` e fica em cache aqui no navegador.
 */
const LS_KEY = "tati_van_logo";
const MAX_LOGO_CHARS = 900_000; // ~650 KB de imagem

let current: string = "";
let loaded = false;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}

/** Só aceitamos um logotipo válido e de tamanho seguro. Qualquer outra coisa vira "sem logotipo". */
function sanitize(value: string | null | undefined): string {
  const v = (value || "").trim();
  if (!v) return "";
  if (v.length > MAX_LOGO_CHARS) return "";
  if (!v.startsWith("data:image/") && !/^https?:\/\//i.test(v)) return "";
  return v;
}

function readCache(): string {
  if (typeof window === "undefined") return "";
  try {
    const raw = window.localStorage.getItem(LS_KEY);
    const clean = sanitize(raw);
    if (raw && !clean) window.localStorage.removeItem(LS_KEY);
    return clean;
  } catch {
    return "";
  }
}


function writeCache(value: string) {
  if (typeof window === "undefined") return;
  try {
    if (value) window.localStorage.setItem(LS_KEY, value);
    else window.localStorage.removeItem(LS_KEY);
  } catch {
    /* cota cheia: seguimos apenas com o valor em memória */
  }
}

export function getVanLogo(): string {
  if (!loaded && typeof window !== "undefined") {
    current = readCache();
    loaded = true;
  }
  return current;
}

function setLocal(value: string) {
  current = value;
  loaded = true;
  writeCache(value);
  emit();
}

/**
 * Carrega o logotipo do perfil do usuário logado. Nunca lança e nunca trava:
 * se demorar ou falhar, seguimos sem logotipo (o app não pode depender disso).
 */
export async function loadVanLogo(): Promise<string> {
  try {
    const timeout = new Promise<null>((resolve) => setTimeout(() => resolve(null), 8000));
    const work = (async () => {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user?.id;
      if (!uid) return null;
      const { data, error } = await supabase
        .from("profiles")
        .select("logo")
        .eq("user_id", uid)
        .maybeSingle();
      if (error) {
        console.error("[logo] falha ao carregar o logotipo do perfil:", error.message);
        return null;
      }
      return (data as { logo?: string | null } | null) ?? { logo: "" };
    })();

    const result = await Promise.race([work, timeout]);
    if (!result) return getVanLogo();
    setLocal(sanitize(result.logo));
    return current;
  } catch (e) {
    console.error("[logo] erro inesperado ao carregar o logotipo:", e);
    return getVanLogo();
  }
}


/**
 * Salva o logotipo no perfil. Só atualiza a tela se o banco confirmar.
 * Retorna uma mensagem de erro quando não foi possível salvar.
 */
export async function saveVanLogo(dataUrl: string): Promise<{ error?: string }> {
  const value = (dataUrl || "").trim();
  if (value && !value.startsWith("data:image/")) {
    return { error: "Arquivo de imagem inválido." };
  }
  if (value.length > MAX_LOGO_CHARS) {
    return { error: "A imagem ficou grande demais. Envie um arquivo menor." };
  }
  const { data: userData } = await supabase.auth.getUser();
  const uid = userData.user?.id;
  if (!uid) return { error: "Sessão expirada. Entre novamente." };

  const { error } = await supabase
    .from("profiles")
    .update({ logo: value || null })
    .eq("user_id", uid);

  if (error) {
    console.error("[logo] falha ao salvar o logotipo:", error.message);
    return { error: error.message };
  }
  setLocal(value);
  return {};
}

export function clearVanLogoCache() {
  setLocal("");
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

/** Reage a mudanças do logotipo (retorna "" no servidor). */
export function useVanLogo(): string {
  return useSyncExternalStore(subscribe, getVanLogo, () => "");
}
