import { createServerFn } from "@tanstack/react-start";

export type Ponto = { lat: number; lng: number } | null;

export type GeoRota = {
  casa: Ponto;
  escola: Ponto;
};

async function geocode(endereco: string): Promise<Ponto> {
  if (!endereco.trim()) return null;
  const { geocodificar } = await import("./distancia.server");
  const resultado = await geocodificar(endereco);
  return resultado ? { lat: resultado.escolhido.lat, lng: resultado.escolhido.lon } : null;
}

/**
 * Geocodifica somente os endereços já vinculados a uma parada de rota
 * (casa do aluno e escola). Não aceita endereço livre do cliente.
 */
export const geocodificarRota = createServerFn({ method: "POST" })
  .inputValidator((input: { rota: string; parada?: string | null }) => ({
    rota: String(input.rota),
    parada: input.parada ? String(input.parada) : null,
  }))
  .handler(async ({ data }): Promise<GeoRota> => {
    const { createClient } = await import("@supabase/supabase-js");
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
    const url = process.env["SUPABASE_URL"]!;
    const supa = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
            h.delete("Authorization");
          }
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });

    const { data: status } = await supa.rpc("get_rota_status", {
      _rota: data.rota,
      _parada: data.parada as unknown as string,
    });

    const minha = (status as { minha?: { endereco_casa?: string; endereco_escola?: string } } | null)?.minha;
    if (!minha) return { casa: null, escola: null };

    const [casa, escola] = await Promise.all([
      geocode(minha.endereco_casa || ""),
      geocode(minha.endereco_escola || ""),
    ]);
    return { casa, escola };
  });
