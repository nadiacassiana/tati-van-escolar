import type { MotoristaPerfil } from "./whatsapp";

export type MarcaVan = {
  /** Nome que aparece no cabeçalho dos documentos. */
  nome: string;
  /** Logotipo em data URL, quando a motorista tiver enviado. */
  logo?: string;
};

/**
 * Identidade visual dos documentos (recibos, contratos, reservas de vaga, PDFs).
 * Sempre pertence à motorista — nunca à plataforma.
 */
export function getMarca(m: MotoristaPerfil | null | undefined): MarcaVan {
  const nome =
    (m?.empresa || "").trim() ||
    (m?.nome_completo || "").trim() ||
    "Transporte Escolar";
  const logo = (m?.logo || "").trim();
  return logo ? { nome, logo } : { nome };
}
