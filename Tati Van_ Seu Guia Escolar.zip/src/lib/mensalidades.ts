// Controle de mensalidades por competência (mês de referência).
// Cada mês gera sua própria cobrança, com status independente.

export type StatusMensalidade = "pago" | "pendente" | "vencido";

export type AlunoMensalidade = {
  id: string;
  nome: string;
  avatar?: string;
  fotoUrl?: string;
  sexo?: string | null;
  mensalidade: number;
  vencimento: number;
  whatsapp?: string;
  telefone?: string;
  escola?: string;
  turma?: string;
  responsavel?: string;
  created_at?: string;
  arquivado_em?: string | null;
  /** Multa/juros por atraso configurados no cadastro (opcionais). */
  multa_atraso?: number | null;
  multa_tipo?: string | null;
  juros_dia?: number | null;
  juros_tipo?: string | null;
};

export type PagamentoMini = {
  id: string;
  aluno_id: string;
  mes_referencia: string;
  valor: number;
  metodo?: string;
  data_pagamento?: string;
};

export type Competencia = {
  key: string;
  aluno: AlunoMensalidade;
  mes: string; // YYYY-MM
  valor: number;
  vencimentoISO: string;
  status: StatusMensalidade;
  diasAtraso: number;
  /** Mês futuro já quitado (pagamento antecipado). */
  antecipada?: boolean;
  pagamento?: PagamentoMini;
};

export function monthRefOf(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function formatMesRef(ref: string): string {
  const [y, m] = ref.split("-").map(Number);
  if (!y || !m) return ref;
  const label = new Date(y, m - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
  return label.charAt(0).toUpperCase() + label.slice(1);
}

export function vencimentoDate(ref: string, dia: number): Date {
  const [y, m] = ref.split("-").map(Number);
  const lastDay = new Date(y, m, 0).getDate();
  return new Date(y, m - 1, Math.min(Math.max(dia || 1, 1), lastDay));
}

function addMonth(ref: string): string {
  const [y, m] = ref.split("-").map(Number);
  const d = new Date(y, m, 1);
  return monthRefOf(d);
}

function monthsRange(startRef: string, endRef: string): string[] {
  const out: string[] = [];
  let cur = startRef;
  let guard = 0;
  while (cur <= endRef && guard < 240) {
    out.push(cur);
    cur = addMonth(cur);
    guard++;
  }
  return out;
}

/** Gera todas as competências (mês a mês) de cada aluno, do início até o mês atual. */
export function buildCompetencias(
  alunos: AlunoMensalidade[],
  pagamentos: PagamentoMini[],
  hoje: Date = new Date(),
): Competencia[] {
  const hoje0 = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate());
  const mesAtual = monthRefOf(hoje0);
  const pagosMap = new Map<string, PagamentoMini>();
  const pagosPorAluno = new Map<string, string[]>();
  for (const p of pagamentos) {
    pagosMap.set(`${p.aluno_id}|${p.mes_referencia}`, p);
    const arr = pagosPorAluno.get(p.aluno_id) || [];
    arr.push(p.mes_referencia);
    pagosPorAluno.set(p.aluno_id, arr);
  }

  const out: Competencia[] = [];
  for (const aluno of alunos) {
    const inicioCadastro = aluno.created_at ? monthRefOf(aluno.created_at) : mesAtual;
    const pagosRefs = (pagosPorAluno.get(aluno.id) || []).sort();
    const inicio = pagosRefs.length && pagosRefs[0] < inicioCadastro ? pagosRefs[0] : inicioCadastro;
    const fim = aluno.arquivado_em ? monthRefOf(aluno.arquivado_em) : mesAtual;
    let limite = fim < mesAtual ? fim : mesAtual;
    // Meses futuros já quitados (pagamento antecipado) também entram na lista,
    // sempre em ordem cronológica. Sem antecipação, nada muda.
    const ultimoPago = pagosRefs[pagosRefs.length - 1];
    if (ultimoPago && ultimoPago > limite) limite = ultimoPago;
    if (limite < inicio) continue;

    for (const mes of monthsRange(inicio, limite)) {
      const pagamento = pagosMap.get(`${aluno.id}|${mes}`);
      const venc = vencimentoDate(mes, aluno.vencimento);
      let status: StatusMensalidade = "pendente";
      let diasAtraso = 0;
      if (pagamento) {
        status = "pago";
      } else if (venc.getTime() < hoje0.getTime()) {
        status = "vencido";
        diasAtraso = Math.floor((hoje0.getTime() - venc.getTime()) / 86400000);
      }
      out.push({
        key: `${aluno.id}|${mes}`,
        aluno,
        mes,
        valor: pagamento ? Number(pagamento.valor) : Number(aluno.mensalidade),
        vencimentoISO: `${venc.getFullYear()}-${String(venc.getMonth() + 1).padStart(2, "0")}-${String(venc.getDate()).padStart(2, "0")}`,
        status,
        diasAtraso,
        ...(status === "pago" && mes > mesAtual ? { antecipada: true } : {}),
        ...(pagamento ? { pagamento } : {}),
      });
    }
  }
  return out;
}

export function formatDataBR(iso: string): string {
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

export const STATUS_UI: Record<StatusMensalidade, { label: string; emoji: string; className: string }> = {
  pago: { label: "Pago", emoji: "🟢", className: "bg-success/15 text-success border-success/30" },
  pendente: { label: "Pendente", emoji: "🟡", className: "bg-warning/20 text-warning-foreground border-warning/40" },
  vencido: { label: "Vencido", emoji: "🔴", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

/**
 * Próximas competências ainda não vencidas de um aluno (para antecipação).
 * Não altera o cálculo normal de mensalidades — é apenas uma projeção.
 */
export function competenciasFuturas(
  aluno: AlunoMensalidade,
  pagamentos: PagamentoMini[],
  meses = 12,
  hoje: Date = new Date(),
): Competencia[] {
  const pagos = new Set(
    pagamentos.filter((p) => p.aluno_id === aluno.id).map((p) => p.mes_referencia),
  );
  const out: Competencia[] = [];
  let ref = monthRefOf(hoje);
  for (let i = 0; i < meses; i++) {
    ref = addMonth(ref);
    if (pagos.has(ref)) continue;
    const venc = vencimentoDate(ref, aluno.vencimento);
    out.push({
      key: `${aluno.id}|${ref}`,
      aluno,
      mes: ref,
      valor: Number(aluno.mensalidade),
      vencimentoISO: `${venc.getFullYear()}-${String(venc.getMonth() + 1).padStart(2, "0")}-${String(venc.getDate()).padStart(2, "0")}`,
      status: "pendente",
      diasAtraso: 0,
    });
  }
  return out;
}
