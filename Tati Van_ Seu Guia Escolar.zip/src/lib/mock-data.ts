// Mock data for visual MVP. All in-memory, no backend.

export type Aluno = {
  id: string;
  nome: string;
  escola: string;
  turma: string;
  endereco: string;
  responsavel: string;
  telefone: string;
  whatsapp: string;
  mensalidade: number;
  vencimento: number;
  horarioIda: string;
  horarioVolta: string;
  aniversario: string;
  observacoes: string;
  podeBuscar: string;
  naoPodeBuscar: string;
  restricoes: string;
  avatar: string;
  fotoUrl?: string;
  statusMensalidade: "pago" | "pendente" | "atrasado";
};

export const alunos: Aluno[] = [
  {
    id: "1",
    nome: "João Silva",
    escola: "Escola Municipal Recanto Feliz",
    turma: "3º Ano A",
    endereco: "Rua das Flores, 120 — Vila Mariana",
    responsavel: "Mariana Silva",
    telefone: "(11) 99876-1234",
    whatsapp: "5511998761234",
    mensalidade: 380,
    vencimento: 5,
    horarioIda: "06:50",
    horarioVolta: "12:10",
    aniversario: "12/03",
    observacoes: "Usa óculos. Sentar próximo ao motorista.",
    podeBuscar: "Mãe, Pai e Avó Tereza",
    naoPodeBuscar: "Tio Roberto",
    restricoes: "Guarda compartilhada — quartas com o pai.",
    avatar: "🧒",
    statusMensalidade: "pago",
  },
  {
    id: "2",
    nome: "Maria Santos",
    escola: "Colégio Saber Mais",
    turma: "1º Ano B",
    endereco: "Av. Brasil, 1450 — Centro",
    responsavel: "Felipe Santos",
    telefone: "(11) 99231-4422",
    whatsapp: "5511992314422",
    mensalidade: 380,
    vencimento: 10,
    horarioIda: "07:00",
    horarioVolta: "12:30",
    aniversario: "28/08",
    observacoes: "Alérgica a amendoim.",
    podeBuscar: "Pai e Mãe",
    naoPodeBuscar: "",
    restricoes: "",
    avatar: "👧",
    statusMensalidade: "pendente",
  },
  {
    id: "3",
    nome: "Felipe Costa",
    escola: "Escola Municipal Recanto Feliz",
    turma: "4º Ano A",
    endereco: "Rua Pedro Álvares, 88 — Jardim Aurora",
    responsavel: "Camila Costa",
    telefone: "(11) 98112-7766",
    whatsapp: "5511981127766",
    mensalidade: 420,
    vencimento: 5,
    horarioIda: "06:45",
    horarioVolta: "12:10",
    aniversario: "02/11",
    observacoes: "",
    podeBuscar: "Mãe e Avô",
    naoPodeBuscar: "",
    restricoes: "",
    avatar: "👦",
    statusMensalidade: "atrasado",
  },
  {
    id: "4",
    nome: "Ana Beatriz",
    escola: "Colégio Saber Mais",
    turma: "2º Ano A",
    endereco: "Rua das Acácias, 32 — Vila Nova",
    responsavel: "Patrícia Lima",
    telefone: "(11) 97744-1100",
    whatsapp: "5511977441100",
    mensalidade: 380,
    vencimento: 15,
    horarioIda: "06:55",
    horarioVolta: "12:20",
    aniversario: "19/06",
    observacoes: "Levar para a aula de balé às quartas.",
    podeBuscar: "Mãe e Tia Cláudia",
    naoPodeBuscar: "",
    restricoes: "",
    avatar: "🧒",
    statusMensalidade: "pago",
  },
  {
    id: "5",
    nome: "Pedro Henrique",
    escola: "Escola Sementinha",
    turma: "Pré II",
    endereco: "Av. das Palmeiras, 900 — Bosque",
    responsavel: "Renata Almeida",
    telefone: "(11) 99333-8821",
    whatsapp: "5511993338821",
    mensalidade: 360,
    vencimento: 8,
    horarioIda: "07:10",
    horarioVolta: "11:50",
    aniversario: "05/01",
    observacoes: "Tem mochila vermelha.",
    podeBuscar: "Mãe e Pai",
    naoPodeBuscar: "",
    restricoes: "",
    avatar: "👦",
    statusMensalidade: "pago",
  },
  {
    id: "6",
    nome: "Sofia Oliveira",
    escola: "Colégio Saber Mais",
    turma: "1º Ano A",
    endereco: "Rua Bela Vista, 17 — Centro",
    responsavel: "Daniel Oliveira",
    telefone: "(11) 98800-2211",
    whatsapp: "5511988002211",
    mensalidade: 380,
    vencimento: 5,
    horarioIda: "07:00",
    horarioVolta: "12:30",
    aniversario: "21/09",
    observacoes: "",
    podeBuscar: "Pai e Avó",
    naoPodeBuscar: "",
    restricoes: "",
    avatar: "👧",
    statusMensalidade: "pendente",
  },
];

export type Responsavel = {
  id: string;
  nome: string;
  telefone: string;
  whatsapp: string;
  pix: string;
  endereco: string;
  observacoes: string;
  filhos: string[];
};

export const responsaveis: Responsavel[] = [
  { id: "r1", nome: "Mariana Silva", telefone: "(11) 99876-1234", whatsapp: "5511998761234", pix: "mariana.silva@email.com", endereco: "Rua das Flores, 120", observacoes: "Prefere mensagem por WhatsApp.", filhos: ["João Silva"] },
  { id: "r2", nome: "Felipe Santos", telefone: "(11) 99231-4422", whatsapp: "5511992314422", pix: "(11) 99231-4422", endereco: "Av. Brasil, 1450", observacoes: "", filhos: ["Maria Santos"] },
  { id: "r3", nome: "Camila Costa", telefone: "(11) 98112-7766", whatsapp: "5511981127766", pix: "camila.costa@email.com", endereco: "Rua Pedro Álvares, 88", observacoes: "Pagamento atrasado neste mês.", filhos: ["Felipe Costa"] },
  { id: "r4", nome: "Patrícia Lima", telefone: "(11) 97744-1100", whatsapp: "5511977441100", pix: "12345678900", endereco: "Rua das Acácias, 32", observacoes: "", filhos: ["Ana Beatriz"] },
  { id: "r5", nome: "Renata Almeida", telefone: "(11) 99333-8821", whatsapp: "5511993338821", pix: "renata.almeida@email.com", endereco: "Av. das Palmeiras, 900", observacoes: "", filhos: ["Pedro Henrique"] },
  { id: "r6", nome: "Daniel Oliveira", telefone: "(11) 98800-2211", whatsapp: "5511988002211", pix: "daniel.oliveira@email.com", endereco: "Rua Bela Vista, 17", observacoes: "", filhos: ["Sofia Oliveira"] },
];

export type Gasto = {
  id: string;
  data: string;
  categoria: string;
  valor: number;
  km?: number;
  obs?: string;
};

export const gastos: Gasto[] = [
  { id: "g1", data: "2026-06-24", categoria: "Combustível", valor: 280, km: 84520, obs: "Posto Shell — 38L" },
  { id: "g2", data: "2026-06-20", categoria: "Lavagem", valor: 60, obs: "Lavagem completa" },
  { id: "g3", data: "2026-06-15", categoria: "Troca de óleo", valor: 320, km: 84100, obs: "Óleo + filtro" },
  { id: "g4", data: "2026-06-10", categoria: "Combustível", valor: 295, km: 83800 },
  { id: "g5", data: "2026-06-02", categoria: "Pneus", valor: 1800, km: 83200, obs: "4 pneus novos" },
  { id: "g6", data: "2026-05-28", categoria: "Seguro", valor: 280, obs: "Parcela mensal" },
  { id: "g7", data: "2026-05-22", categoria: "Combustível", valor: 270, km: 83000 },
];

export type Manutencao = {
  id: string;
  item: string;
  ultima: string;
  proxima: string;
  km: number;
  status: "ok" | "proximo" | "atrasado";
};

export const manutencoes: Manutencao[] = [
  { id: "m1", item: "Troca de óleo", ultima: "15/06/2026", proxima: "15/12/2026", km: 84100, status: "ok" },
  { id: "m2", item: "Pneus", ultima: "02/06/2026", proxima: "02/06/2027", km: 83200, status: "ok" },
  { id: "m3", item: "Freios", ultima: "10/03/2026", proxima: "10/09/2026", km: 79800, status: "proximo" },
  { id: "m4", item: "Embreagem", ultima: "20/12/2025", proxima: "20/12/2026", km: 75200, status: "ok" },
  { id: "m5", item: "Correia dentada", ultima: "10/01/2026", proxima: "10/01/2027", km: 76400, status: "ok" },
  { id: "m6", item: "Bateria", ultima: "05/02/2025", proxima: "05/08/2026", km: 70200, status: "atrasado" },
];

export type Agenda = {
  id: string;
  titulo: string;
  data: string;
  tipo: "documento" | "manutencao" | "compromisso";
};

export const agenda: Agenda[] = [
  { id: "a1", titulo: "Licenciamento da van", data: "2026-07-15", tipo: "documento" },
  { id: "a2", titulo: "Vistoria INMETRO", data: "2026-08-02", tipo: "documento" },
  { id: "a3", titulo: "Renovação do seguro", data: "2026-09-12", tipo: "documento" },
  { id: "a4", titulo: "Tacógrafo — aferição", data: "2026-07-28", tipo: "documento" },
  { id: "a5", titulo: "Revisão dos freios", data: "2026-09-10", tipo: "manutencao" },
  { id: "a6", titulo: "Reunião com pais — Escola Saber Mais", data: "2026-07-04", tipo: "compromisso" },
];

export const mensagensProntas = [
  "Bom dia! Estou chegando para buscar seu filho 😊🚐",
  "Seu filho já embarcou e está a caminho da escola.",
  "Estamos chegando em casa, por favor já desça.",
  "Lembrete amigável: a mensalidade vence amanhã 💙",
  "Hoje não haverá transporte. Combinaremos a reposição.",
  "Bom dia! Trânsito intenso hoje, podemos atrasar uns minutos.",
];

export const dashboardStats = {
  totalAlunos: alunos.length,
  recebidas: alunos.filter((a) => a.statusMensalidade === "pago").length,
  pendentes: alunos.filter((a) => a.statusMensalidade === "pendente").length,
  atrasadas: alunos.filter((a) => a.statusMensalidade === "atrasado").length,
  receitaMes: alunos.reduce((s, a) => s + a.mensalidade, 0),
  ultimoAbastecimento: { data: "24/06/2026", valor: 280, km: 84520 },
  saudeVan: 92,
  diasTrial: 27,
};
