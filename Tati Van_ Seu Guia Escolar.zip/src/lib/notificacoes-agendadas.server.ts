/**
 * Fila de notificações agendadas (server-only).
 *
 * Usada pelo teste real de "notificação com o app fechado": a linha fica
 * gravada no banco e quem dispara é a varredura do servidor, nunca o celular.
 */
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { criarNotificacao } from "./push.server";

type Row = {
  id: string;
  user_id: string;
  tipo: string;
  titulo: string;
  corpo: string;
  url: string | null;
};

/** Envia todas as notificações agendadas cujo horário já chegou. */
export async function processarNotificacoesAgendadas(): Promise<{ enviadas: number }> {
  const agora = new Date().toISOString();
  const { data } = await supabaseAdmin
    .from("notificacoes_agendadas")
    .select("id, user_id, tipo, titulo, corpo, url")
    .is("enviada_em", null)
    .lte("agendada_para", agora)
    .limit(50);

  const linhas = (data ?? []) as Row[];
  let enviadas = 0;

  for (const linha of linhas) {
    // Marca antes de enviar para evitar envio duplicado em execuções paralelas.
    const { data: marcada } = await supabaseAdmin
      .from("notificacoes_agendadas")
      .update({ enviada_em: new Date().toISOString() })
      .eq("id", linha.id)
      .is("enviada_em", null)
      .select("id")
      .maybeSingle();
    if (!marcada) continue;

    await criarNotificacao({
      userId: linha.user_id,
      tipo: (linha.tipo as never) ?? "teste",
      titulo: linha.titulo,
      corpo: linha.corpo,
      url: linha.url ?? "/dashboard",
      dados: { agendada: true },
      dedupeKey: `agendada:${linha.id}`,
    });
    enviadas += 1;
  }

  return { enviadas };
}
