/**
 * Catálogo central de tipos de notificação da Tati Van Escolar.
 *
 * Para criar uma notificação nova no futuro (mensalidade, checklist, rota,
 * documento...), basta adicionar uma entrada aqui e chamar
 * `criarNotificacao({ tipo: "...", ... })` no servidor. Nada mais precisa
 * ser reconstruído.
 */
export const NOTIFICACAO_TIPOS = {
  aniversario_aluno: {
    emoji: "🎂",
    label: "Aniversário de aluno",
    urlPadrao: "/dashboard#aniversariantes",
  },
  mensalidade_vencendo: {
    emoji: "💰",
    label: "Mensalidade a vencer",
    urlPadrao: "/financeiro",
  },
  mensalidade_atrasada: {
    emoji: "⚠️",
    label: "Mensalidade atrasada",
    urlPadrao: "/financeiro",
  },
  checklist: { emoji: "📋", label: "Checklist da van", urlPadrao: "/checklist" },
  documento_vencendo: { emoji: "📄", label: "Documento a vencer", urlPadrao: "/documentos" },
  rota: { emoji: "🚐", label: "Rota", urlPadrao: "/checklist" },
  aviso: { emoji: "🔔", label: "Aviso importante", urlPadrao: "/dashboard" },
  teste: { emoji: "🔔", label: "Notificação de teste", urlPadrao: "/dashboard" },
} as const;

export type NotificacaoTipo = keyof typeof NOTIFICACAO_TIPOS;

export type Notificacao = {
  id: string;
  tipo: string;
  titulo: string;
  corpo: string;
  url: string | null;
  dados: Record<string, unknown>;
  lida_em: string | null;
  created_at: string;
};

export function emojiDoTipo(tipo: string): string {
  return (NOTIFICACAO_TIPOS as Record<string, { emoji: string }>)[tipo]?.emoji ?? "🔔";
}
