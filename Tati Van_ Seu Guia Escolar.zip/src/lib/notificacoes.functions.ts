import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Chave pública VAPID — pode ser pública por definição. */
export const getVapidPublicKey = createServerFn({ method: "GET" }).handler(async () => {
  return { publicKey: process.env['VAPID_PUBLIC_KEY'] ?? "" };
});

export const salvarPushSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { endpoint: string; p256dh: string; auth: string; userAgent?: string }) => {
    if (!input?.endpoint || !input.p256dh || !input.auth) throw new Error("Assinatura inválida");
    return input;
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("push_subscriptions")
      .upsert(
        {
          user_id: context.userId,
          endpoint: data.endpoint,
          p256dh: data.p256dh,
          auth: data.auth,
          user_agent: data.userAgent ?? null,
          ativo: true,
          ultimo_erro: null,
        },
        { onConflict: "endpoint" },
      );
    if (error) throw error;
    return { ok: true };
  });

export const removerPushSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { endpoint: string }) => input)
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("push_subscriptions")
      .delete()
      .eq("user_id", context.userId)
      .eq("endpoint", data.endpoint);
    return { ok: true };
  });

/** Push de teste: confirma que o aparelho realmente recebe notificações. */
export const enviarNotificacaoTeste = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { enviarPushParaUsuario } = await import("./push.server");
    const res = await enviarPushParaUsuario(context.userId, {
      title: "🔔 Tati Van Escolar",
      body: "As notificações estão ativas! Você receberá aqui os avisos da sua van.",
      url: "/dashboard",
      tag: "tati-teste",
    });
    return res;
  });

/** TESTE: simula o aniversário de um aluno (não altera dados dos alunos). */
export const simularAniversarioAgora = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { nome?: string } | undefined) => input ?? {})
  .handler(async ({ data, context }) => {
    const { simularAniversario } = await import("./aniversario-simulacao.server");
    return simularAniversario(context.userId, data?.nome ?? "Ana Beatriz Souza");
  });

/** Roda os geradores de notificação do dia para o motorista logado. */
export const sincronizarNotificacoes = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { sincronizarAniversariosDoUsuario } = await import("./aniversarios.server");
    const criadas = await sincronizarAniversariosDoUsuario(context.userId);
    return { criadas };
  });


/**
 * TESTE REAL EM SEGUNDO PLANO: agenda uma notificação para daqui a X minutos.
 * Quem envia é o servidor — o app pode estar fechado. Não toca em dados reais.
 */
export const agendarTesteEmSegundoPlano = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { minutos?: number } | undefined) => ({
    minutos: Math.min(Math.max(Math.round(input?.minutos ?? 2), 1), 60),
  }))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const quando = new Date(Date.now() + data.minutos * 60_000);
    const { error } = await supabaseAdmin.from("notificacoes_agendadas").insert({
      user_id: context.userId,
      tipo: "teste",
      titulo: "Teste com o app fechado",
      corpo:
        "Esta notificação foi enviada pelo servidor da Tati, sem o app estar aberto. Toque para abrir a Tati. ✅",
      url: "/dashboard",
      agendada_para: quando.toISOString(),
    });
    if (error) throw error;
    return { ok: true, minutos: data.minutos, quando: quando.toISOString() };
  });
