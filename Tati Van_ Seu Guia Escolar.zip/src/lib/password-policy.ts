/**
 * Política de senha forte — aplicada SOMENTE quando uma nova senha é criada
 * (nova conta, alteração voluntária, redefinição por "Esqueci minha senha").
 * O login de contas existentes NÃO usa estas regras.
 */
export type PasswordRule = {
  id: string;
  label: string;
  test: (senha: string) => boolean;
};

export const PASSWORD_RULES: PasswordRule[] = [
  { id: "len", label: "Mínimo de 8 caracteres", test: (s) => s.length >= 8 },
  { id: "upper", label: "Pelo menos 1 letra maiúscula (A-Z)", test: (s) => /[A-Z]/.test(s) },
  { id: "lower", label: "Pelo menos 1 letra minúscula (a-z)", test: (s) => /[a-z]/.test(s) },
  { id: "digit", label: "Pelo menos 1 número (0-9)", test: (s) => /[0-9]/.test(s) },
  {
    id: "special",
    label: "Pelo menos 1 caractere especial (! @ # $ % & *)",
    test: (s) => /[^A-Za-z0-9]/.test(s),
  },
];

export function checkPassword(senha: string) {
  return PASSWORD_RULES.map((r) => ({ ...r, ok: r.test(senha) }));
}

export function isStrongPassword(senha: string): boolean {
  return PASSWORD_RULES.every((r) => r.test(senha));
}

/** Primeira exigência não atendida, para mensagens de erro. */
export function firstPasswordError(senha: string): string | null {
  const falha = PASSWORD_RULES.find((r) => !r.test(senha));
  return falha ? `Sua senha precisa atender: ${falha.label.toLowerCase()}.` : null;
}
