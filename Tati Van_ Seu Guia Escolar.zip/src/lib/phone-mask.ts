// Máscara de telefone/WhatsApp brasileiro: (11) 99999-9999 ou (11) 9999-9999
export function maskPhoneBR(input: string): string {
  const d = (input || "").replace(/\D/g, "").slice(0, 11);
  if (d.length === 0) return "";
  if (d.length <= 2) return `(${d}`;
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}

export function onlyDigitsPhone(input: string): string {
  return (input || "").replace(/\D/g, "");
}

export function isValidPhoneBR(input: string): boolean {
  const d = onlyDigitsPhone(input);
  return d.length === 10 || d.length === 11;
}

// Retorna número no formato E.164 sem "+" para uso em wa.me (ex: 5511999999999)
export function whatsappLink(phone: string, text?: string): string {
  const d = onlyDigitsPhone(phone);
  const full = d.startsWith("55") ? d : `55${d}`;
  const q = text ? `?text=${encodeURIComponent(text)}` : "";
  return `https://wa.me/${full}${q}`;
}
