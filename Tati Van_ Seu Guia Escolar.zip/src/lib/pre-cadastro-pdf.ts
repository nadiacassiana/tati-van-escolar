import jsPDF from "jspdf";
import type { Tables } from "@/integrations/supabase/types";

export type PreCadastroRow = Tables<"pre_cadastros">;

export function dataHoraBR(iso: string | null | undefined) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
}

export function dataBR(iso: string | null | undefined) {
  if (!iso) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (m) return `${m[3]}/${m[2]}/${m[1]}`;
  const d = new Date(iso);
  return isNaN(d.getTime()) ? "—" : d.toLocaleDateString("pt-BR");
}

export function usoImagemLabel(v: boolean | null) {
  if (v === true) return "Autorizado";
  if (v === false) return "Não autorizado";
  return "Não informado";
}

/**
 * Comprovante simples (A4) do auto-cadastro preenchido pelo responsável,
 * para fins de comprovação jurídica (data/hora, dados e aceite de imagem).
 */
export function gerarComprovantePreCadastroPDF(p: PreCadastroRow, marca?: string) {
  const pdf = new jsPDF("p", "mm", "a4");
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const marginX = 18;
  const contentW = pageW - marginX * 2;
  let y = 20;

  const ensure = (h: number) => {
    if (y + h > pageH - 18) {
      pdf.addPage();
      y = 20;
    }
  };

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(15);
  pdf.text("Comprovante de Cadastro - Transporte Escolar", marginX, y);
  y += 7;
  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(10);
  pdf.setTextColor(90);
  pdf.text(marca || "Transporte Escolar", marginX, y);
  y += 5;
  pdf.text("Ficha preenchida pelo responsavel por meio de link publico de auto-cadastro.", marginX, y);
  y += 6;
  pdf.setTextColor(0);
  pdf.setDrawColor(200);
  pdf.line(marginX, y, pageW - marginX, y);
  y += 8;

  const secao = (titulo: string) => {
    ensure(14);
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(11);
    pdf.text(titulo, marginX, y);
    y += 6;
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(10);
  };

  const linha = (rotulo: string, valor: string) => {
    const texto = `${rotulo}: ${valor || "—"}`;
    const linhas = pdf.splitTextToSize(texto, contentW) as string[];
    ensure(linhas.length * 5 + 2);
    pdf.text(linhas, marginX, y);
    y += linhas.length * 5 + 1;
  };

  secao("Registro de envio");
  linha("Data e hora do preenchimento", dataHoraBR(p.created_at));
  linha("Data e hora da aprovacao pela motorista", p.status === "aprovado" ? dataHoraBR(p.updated_at) : "Pendente de aprovacao");
  linha("Identificador da ficha", p.id);
  y += 3;

  secao("Dados do aluno");
  linha("Nome completo", p.aluno_nome);
  linha("Data de nascimento", dataBR(p.data_nascimento));
  linha("Escola", p.escola);
  linha("Serie/Ano", p.serie);
  y += 3;

  secao("Endereco de embarque/desembarque");
  linha("Rua", p.rua);
  linha("Numero", p.numero);
  linha("Bairro", p.bairro);
  linha("Ponto de referencia", p.referencia);
  y += 3;

  secao("Responsavel");
  linha("Nome", p.responsavel_nome);
  linha("WhatsApp", p.responsavel_whatsapp);
  linha("CPF", p.responsavel_cpf || "—");
  linha("E-mail", p.responsavel_email || "—");
  linha("Telefone de emergencia", p.telefone_emergencia || "—");
  linha("Pessoas autorizadas", p.pessoas_autorizadas || "—");
  linha("Observacoes", p.observacoes || "—");
  y += 3;

  secao("Autorizacao de uso de imagem");
  const aceite =
    p.autoriza_imagem === true
      ? "AUTORIZADO - o responsavel autorizou o uso da imagem do aluno em fotos/videos para divulgacao do transporte escolar."
      : p.autoriza_imagem === false
        ? "NAO AUTORIZADO - o responsavel nao autorizou o uso da imagem do aluno."
        : "NAO INFORMADO - o responsavel nao respondeu a esta pergunta.";
  const aceiteLinhas = pdf.splitTextToSize(aceite, contentW) as string[];
  ensure(aceiteLinhas.length * 5 + 4);
  pdf.text(aceiteLinhas, marginX, y);
  y += aceiteLinhas.length * 5 + 6;

  const rodape = pdf.splitTextToSize(
    "Documento gerado eletronicamente a partir do registro armazenado no sistema. O preenchimento foi realizado diretamente pelo responsavel legal por meio de link proprio, com data e hora registradas automaticamente.",
    contentW,
  ) as string[];
  ensure(rodape.length * 4.5 + 6);
  pdf.setFontSize(8.5);
  pdf.setTextColor(110);
  pdf.text(rodape, marginX, y);

  const nome = (p.aluno_nome || "aluno").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "-").toLowerCase();
  pdf.save(`comprovante-cadastro-${nome}.pdf`);
}
