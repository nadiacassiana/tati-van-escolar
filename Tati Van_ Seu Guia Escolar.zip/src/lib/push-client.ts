/** Camada de navegador do sistema de push da Tati (Service Worker + Push API). */

export type PushSuporte =
  | { ok: true }
  | { ok: false; motivo: string };

const SW_URL = "/push-sw.js";

function isIos(): boolean {
  if (typeof navigator === "undefined") return false;
  const ua = navigator.userAgent;
  return /iPad|iPhone|iPod/.test(ua) || (/Macintosh/.test(ua) && "ontouchend" in document);
}

/** No iPhone o push só existe quando o app está instalado na Tela de Início. */
export function estaInstaladoComoApp(): boolean {
  if (typeof window === "undefined") return false;
  const standalone = window.matchMedia?.("(display-mode: standalone)")?.matches;
  const iosStandalone = (window.navigator as unknown as { standalone?: boolean }).standalone;
  return Boolean(standalone || iosStandalone);
}

export function verificarSuporte(): PushSuporte {
  if (typeof window === "undefined") return { ok: false, motivo: "Ambiente sem navegador." };
  if (window.top !== window.self) {
    return {
      ok: false,
      motivo:
        "As notificações não podem ser ativadas dentro da pré-visualização. Abra a Tati em uma aba/app normal.",
    };
  }
  if (!("serviceWorker" in navigator)) {
    return { ok: false, motivo: "Este navegador não suporta notificações (sem Service Worker)." };
  }
  if (!("Notification" in window)) {
    return { ok: false, motivo: "Este navegador não suporta notificações." };
  }
  if (!("PushManager" in window)) {
    if (isIos() && !estaInstaladoComoApp()) {
      return {
        ok: false,
        motivo:
          "No iPhone é preciso instalar a Tati na Tela de Início (Safari → Compartilhar → Adicionar à Tela de Início) para receber notificações.",
      };
    }
    return { ok: false, motivo: "Este navegador não suporta notificações push." };
  }
  if (isIos() && !estaInstaladoComoApp()) {
    return {
      ok: false,
      motivo:
        "No iPhone é preciso instalar a Tati na Tela de Início (Safari → Compartilhar → Adicionar à Tela de Início) para receber notificações.",
    };
  }
  return { ok: true };
}

export function permissaoAtual(): NotificationPermission | "indisponivel" {
  if (typeof window === "undefined" || !("Notification" in window)) return "indisponivel";
  return Notification.permission;
}

export async function registrarServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (verificarSuporte().ok === false) return null;
  try {
    const existente = await navigator.serviceWorker.getRegistration(SW_URL);
    if (existente) return existente;
    return await navigator.serviceWorker.register(SW_URL, { scope: "/" });
  } catch (e) {
    console.error("[push] falha ao registrar service worker", e);
    return null;
  }
}

export async function assinaturaAtual(): Promise<PushSubscription | null> {
  if (verificarSuporte().ok === false) return null;
  try {
    const reg = await navigator.serviceWorker.getRegistration(SW_URL);
    if (!reg) return null;
    return await reg.pushManager.getSubscription();
  } catch {
    return null;
  }
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) out[i] = raw.charCodeAt(i);
  return out;
}

export type AssinaturaSerializada = {
  endpoint: string;
  p256dh: string;
  auth: string;
  userAgent: string;
};

function serializar(sub: PushSubscription): AssinaturaSerializada {
  const json = sub.toJSON() as { endpoint?: string; keys?: { p256dh?: string; auth?: string } };
  return {
    endpoint: json.endpoint ?? sub.endpoint,
    p256dh: json.keys?.p256dh ?? "",
    auth: json.keys?.auth ?? "",
    userAgent: typeof navigator !== "undefined" ? navigator.userAgent.slice(0, 300) : "",
  };
}

/**
 * Pede permissão (se necessário) e cria/recupera a assinatura push do aparelho.
 * Devolve os dados que o servidor precisa guardar, ou um erro amigável.
 */
export async function ativarNotificacoes(
  vapidPublicKey: string,
): Promise<{ ok: true; assinatura: AssinaturaSerializada } | { ok: false; motivo: string }> {
  const suporte = verificarSuporte();
  if (!suporte.ok) return { ok: false, motivo: suporte.motivo };

  const permissao = await Notification.requestPermission();
  if (permissao === "denied") {
    return {
      ok: false,
      motivo:
        "Permissão negada. Você pode liberar depois nas configurações de notificações do navegador e ativar novamente aqui.",
    };
  }
  if (permissao !== "granted") return { ok: false, motivo: "Permissão não concedida." };

  const reg = await registrarServiceWorker();
  if (!reg) return { ok: false, motivo: "Não foi possível preparar as notificações neste aparelho." };
  await navigator.serviceWorker.ready;

  try {
    const existente = await reg.pushManager.getSubscription();
    const sub =
      existente ??
      (await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey) as BufferSource,
      }));
    return { ok: true, assinatura: serializar(sub) };
  } catch (e) {
    console.error("[push] falha ao assinar", e);
    return { ok: false, motivo: "Não foi possível registrar este aparelho para notificações." };
  }
}

export async function desativarNotificacoes(): Promise<string | null> {
  const sub = await assinaturaAtual();
  if (!sub) return null;
  const endpoint = sub.endpoint;
  try {
    await sub.unsubscribe();
  } catch {
    /* mesmo falhando localmente, removemos do servidor */
  }
  return endpoint;
}
