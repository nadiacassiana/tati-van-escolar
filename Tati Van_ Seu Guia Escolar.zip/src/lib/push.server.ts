/**
 * Núcleo de envio de notificações da Tati (server-only).
 *
 * Fluxo único e reutilizável:
 *   criarNotificacao() → grava na Central de Notificações da motorista
 *                      → envia Web Push real para os aparelhos registrados.
 */
import { ApplicationServerKeys, generatePushHTTPRequest } from "webpush-webcrypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { NotificacaoTipo } from "./notificacoes-tipos";
import { NOTIFICACAO_TIPOS } from "./notificacoes-tipos";

export type PushPayload = {
  title: string;
  body: string;
  url?: string;
  tag?: string;
  data?: Record<string, unknown>;
};

let chavesCache: ApplicationServerKeys | null = null;

async function getChaves(): Promise<ApplicationServerKeys> {
  if (chavesCache) return chavesCache;
  const raw = process.env['VAPID_KEYS_JSON'];
  if (!raw) throw new Error("VAPID_KEYS_JSON ausente");
  chavesCache = await ApplicationServerKeys.fromJSON(
    JSON.parse(raw) as { publicKey: string; privateKey: string },
  );
  return chavesCache;
}

type SubRow = { id: string; endpoint: string; p256dh: string; auth: string };

/** Envia um push real para todos os aparelhos ativos de um motorista. */
export async function enviarPushParaUsuario(
  userId: string,
  payload: PushPayload,
): Promise<{ enviados: number; falhas: number }> {
  const { data } = await supabaseAdmin
    .from("push_subscriptions")
    .select("id, endpoint, p256dh, auth")
    .eq("user_id", userId)
    .eq("ativo", true);

  const subs = (data ?? []) as SubRow[];
  if (subs.length === 0) return { enviados: 0, falhas: 0 };

  const keys = await getChaves();
  const contato = process.env['VAPID_SUBJECT'] || "mailto:contato@tatiassistentevirtual.com.br";
  const corpo = JSON.stringify({
    title: payload.title,
    body: payload.body,
    url: payload.url ?? "/dashboard",
    tag: payload.tag ?? "tati",
    data: payload.data ?? {},
  });

  let enviados = 0;
  let falhas = 0;

  await Promise.all(
    subs.map(async (sub) => {
      try {
        const req = await generatePushHTTPRequest({
          applicationServerKeys: keys,
          payload: corpo,
          target: { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
          adminContact: contato,
          // 24h de validade e urgência alta: o aparelho é acordado mesmo
          // com o app fechado / em economia de bateria (doze mode).
          ttl: 60 * 60 * 24,
          urgency: "high",
        });
        const res = await fetch(req.endpoint, {
          method: "POST",
          headers: req.headers,
          body: req.body,
        });
        if (res.ok) {
          enviados += 1;
          return;
        }
        falhas += 1;
        const texto = await res.text().catch(() => "");
        // 404/410 = aparelho desinstalou o app ou revogou a permissão.
        if (res.status === 404 || res.status === 410) {
          await supabaseAdmin.from("push_subscriptions").delete().eq("id", sub.id);
        } else {
          await supabaseAdmin
            .from("push_subscriptions")
            .update({ ultimo_erro: `${res.status} ${texto}`.slice(0, 300) })
            .eq("id", sub.id);
        }
      } catch (e) {
        falhas += 1;
        console.error("[push] erro ao enviar", e);
      }
    }),
  );

  return { enviados, falhas };
}

export type NovaNotificacao = {
  userId: string;
  tipo: NotificacaoTipo;
  titulo: string;
  corpo: string;
  url?: string;
  dados?: Record<string, unknown>;
  /** Impede duplicidade (ex.: "aniversario:<alunoId>:2026-08-22"). */
  dedupeKey?: string;
  enviarPush?: boolean;
};

/**
 * Cria a notificação interna e dispara o push. Se a dedupeKey já existir para
 * o mesmo motorista, nada é criado e nenhum push é enviado.
 */
export async function criarNotificacao(
  n: NovaNotificacao,
): Promise<{ criada: boolean; id?: string; push?: { enviados: number; falhas: number } }> {
  const url = n.url ?? NOTIFICACAO_TIPOS[n.tipo].urlPadrao;

  if (n.dedupeKey) {
    const { data: existente } = await supabaseAdmin
      .from("notificacoes")
      .select("id")
      .eq("user_id", n.userId)
      .eq("dedupe_key", n.dedupeKey)
      .maybeSingle();
    if (existente) return { criada: false };
  }

  const { data, error } = await supabaseAdmin
    .from("notificacoes")
    .insert({
      user_id: n.userId,
      tipo: n.tipo,
      titulo: n.titulo,
      corpo: n.corpo,
      url,
      dados: (n.dados ?? {}) as never,
      dedupe_key: n.dedupeKey ?? null,
    })
    .select("id")
    .maybeSingle();

  if (error) {
    // 23505 = corrida com outra execução: a notificação já existe.
    if ((error as { code?: string }).code === "23505") return { criada: false };
    throw error;
  }

  let push: { enviados: number; falhas: number } | undefined;
  if (n.enviarPush !== false) {
    push = await enviarPushParaUsuario(n.userId, {
      title: `${NOTIFICACAO_TIPOS[n.tipo].emoji} ${n.titulo}`,
      body: n.corpo,
      url,
      tag: n.dedupeKey ?? n.tipo,
      data: n.dados ?? {},
    });
    if (push.enviados > 0 && data?.id) {
      await supabaseAdmin
        .from("notificacoes")
        .update({ push_enviado_em: new Date().toISOString() })
        .eq("id", data.id);
    }
  }

  return { criada: true, id: data?.id, push };
}
