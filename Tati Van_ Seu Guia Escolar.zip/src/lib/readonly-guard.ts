// Bloqueio global de escrita no modo "Conta pausada" (somente leitura).
// Intercepta as requisições de gravação enviadas ao banco de dados,
// garantindo que nenhuma funcionalidade altere ou crie dados enquanto a
// conta estiver pausada. A consulta aos dados já cadastrados continua livre.
import { toast } from "sonner";

let readOnly = false;
let installed = false;

const WRITE_METHODS = new Set(["POST", "PATCH", "PUT", "DELETE"]);

export function setReadOnlyMode(value: boolean) {
  readOnly = value;
  if (value) installGuard();
}

export function isReadOnlyMode() {
  return readOnly;
}

let lastToast = 0;
export function notifyPaused() {
  const now = Date.now();
  if (now - lastToast < 3000) return;
  lastToast = now;
  toast.error("Conta pausada", {
    description: "Ative sua assinatura para voltar a utilizar todas as funcionalidades.",
  });
}

function installGuard() {
  if (installed || typeof window === "undefined") return;
  installed = true;

  const originalFetch = window.fetch.bind(window);
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    try {
      if (readOnly) {
        const url =
          typeof input === "string"
            ? input
            : input instanceof URL
            ? input.toString()
            : input.url;
        const method = (
          init?.method ??
          (typeof input === "object" && "method" in input ? input.method : "GET")
        ).toUpperCase();

        // Somente as gravações na API de dados são bloqueadas.
        // Autenticação e o fluxo de assinatura continuam funcionando.
        if (url.includes("/rest/v1/") && WRITE_METHODS.has(method)) {
          notifyPaused();
          return new Response(
            JSON.stringify({ message: "Conta pausada: modo somente leitura." }),
            { status: 403, headers: { "content-type": "application/json" } },
          );
        }
      }
    } catch {
      /* nunca quebrar o fetch por causa do guard */
    }
    return originalFetch(input as RequestInfo, init);
  };
}
