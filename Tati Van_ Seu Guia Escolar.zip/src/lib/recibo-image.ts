import { formatBRL } from "./format";
import { METODO_LABEL, formatDateBR, formatMesReferencia, type Recibo } from "./recibo";
import type { MotoristaPerfil } from "./whatsapp";

const SCRIPT_FONT = '"Great Vibes", "Segoe Script", "Brush Script MT", cursive';

async function ensureScriptFont() {
  try {
    const fonts = (document as Document & { fonts?: FontFaceSet }).fonts;
    if (fonts?.load) {
      await Promise.race([
        fonts.load(`48px "Great Vibes"`),
        new Promise((res) => setTimeout(res, 1500)),
      ]);
    }
  } catch {
    /* fonte opcional */
  }
}

function loadImage(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
    setTimeout(() => resolve(null), 2500);
  });
}

/**
 * Gera uma imagem compacta e elegante do recibo, otimizada para
 * compartilhamento no WhatsApp (proporção próxima de um cartão).
 */
export async function reciboToImageBlob(r: Recibo, motorista: MotoristaPerfil): Promise<Blob | null> {
  await ensureScriptFont();
  const logo = (motorista.logo || "").trim();
  const logoImg = logo ? await loadImage(logo) : null;

  const scale = 2;
  const W = 760;
  const pad = 40;
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;

  // ---- medir altura dinâmica ----
  const linhas: [string, string][] = [
    ["Responsável", r.responsavel_nome || "—"],
    ["Aluno(a)", r.aluno_nome],
    ["Mês de referência", formatMesReferencia(r.mes_referencia)],
    ["Data do pagamento", formatDateBR(r.data_pagamento)],
    ["Forma de pagamento", METODO_LABEL[r.metodo || ""] || r.metodo || "—"],
  ];
  if (r.escola) linhas.splice(2, 0, ["Escola", r.escola]);

  const headerH = 112;
  const valorH = 120;
  const rowH = 40;
  const listaH = linhas.length * rowH + 16;
  const assinaturaH = 150;
  const footerH = 60;
  const H = headerH + valorH + listaH + assinaturaH + footerH;

  canvas.width = W * scale;
  canvas.height = H * scale;
  ctx.scale(scale, scale);

  const azul = "#1e40af";
  const azulEscuro = "#1e3a8a";
  const cinza = "#6b7280";
  const escuro = "#1a1a2e";

  // fundo
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, W, H);

  // ---- header ----
  ctx.fillStyle = azul;
  ctx.fillRect(0, 0, W, headerH);

  let textX = pad;
  if (logoImg) {
    const maxH = 64;
    const ratio = logoImg.width / logoImg.height || 1;
    let h = maxH;
    let w = h * ratio;
    if (w > 130) { w = 130; h = w / ratio; }
    ctx.save();
    ctx.fillStyle = "#ffffff";
    const bx = pad - 6, by = 20, bw = w + 12, bh = h + 12;
    ctx.beginPath();
    ctx.roundRect(bx, by, bw, bh, 10);
    ctx.fill();
    ctx.drawImage(logoImg, pad, by + 6, w, h);
    ctx.restore();
    textX = pad + w + 20;
  }

  ctx.fillStyle = "#ffffff";
  ctx.textBaseline = "alphabetic";
  ctx.font = "bold 26px system-ui, -apple-system, Segoe UI, sans-serif";
  const empresa = motorista.empresa || "Transporte Escolar";
  ctx.fillText(truncate(ctx, empresa, W - textX - pad - 150), textX, 58);
  ctx.font = "15px system-ui, -apple-system, Segoe UI, sans-serif";
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  const sub = [motorista.apelido, motorista.telefone].filter(Boolean).join(" • ");
  if (sub) ctx.fillText(truncate(ctx, sub, W - textX - pad - 150), textX, 84);

  ctx.textAlign = "right";
  ctx.font = "bold 13px system-ui, sans-serif";
  ctx.fillStyle = "rgba(255,255,255,0.8)";
  ctx.fillText("RECIBO DE PAGAMENTO", W - pad, 52);
  ctx.font = "bold 24px system-ui, sans-serif";
  ctx.fillStyle = "#ffffff";
  ctx.fillText(r.numero, W - pad, 82);
  ctx.textAlign = "left";

  // ---- valor ----
  let y = headerH;
  ctx.fillStyle = "#eff6ff";
  ctx.fillRect(0, y, W, valorH);
  ctx.textAlign = "center";
  ctx.fillStyle = cinza;
  ctx.font = "bold 13px system-ui, sans-serif";
  ctx.fillText("VALOR RECEBIDO", W / 2, y + 32);
  ctx.fillStyle = azulEscuro;
  ctx.font = "bold 44px system-ui, sans-serif";
  ctx.fillText(`R$ ${formatBRL(Number(r.valor))}`, W / 2, y + 78);
  ctx.fillStyle = "#374151";
  ctx.font = "600 15px system-ui, sans-serif";
  ctx.fillText(`Referente a ${formatMesReferencia(r.mes_referencia)}`, W / 2, y + 102);
  ctx.textAlign = "left";

  // ---- lista de dados ----
  y += valorH + 12;
  for (const [k, v] of linhas) {
    ctx.fillStyle = cinza;
    ctx.font = "14px system-ui, sans-serif";
    ctx.fillText(k, pad, y + 24);
    ctx.fillStyle = escuro;
    ctx.font = "600 15px system-ui, sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(truncate(ctx, v, W / 2 - pad), W - pad, y + 24);
    ctx.textAlign = "left";
    ctx.strokeStyle = "#e5e7eb";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad, y + rowH - 6);
    ctx.lineTo(W - pad, y + rowH - 6);
    ctx.stroke();
    y += rowH;
  }

  // ---- assinatura manuscrita ----
  y += 26;
  const assinatura = (motorista.apelido || motorista.nome_completo || "Motorista").trim();
  ctx.textAlign = "center";
  ctx.fillStyle = escuro;
  ctx.font = `52px ${SCRIPT_FONT}`;
  ctx.fillText(assinatura, W / 2, y + 44);
  ctx.strokeStyle = "#cbd5e1";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(W / 2 - 160, y + 60);
  ctx.lineTo(W / 2 + 160, y + 60);
  ctx.stroke();
  ctx.fillStyle = cinza;
  ctx.font = "13px system-ui, sans-serif";
  ctx.fillText("Recebido por", W / 2, y + 80);
  if (motorista.nome_completo) {
    ctx.font = "600 13px system-ui, sans-serif";
    ctx.fillStyle = "#374151";
    ctx.fillText(motorista.nome_completo, W / 2, y + 100);
  }

  // ---- rodapé ----
  ctx.fillStyle = "#f8fafc";
  ctx.fillRect(0, H - footerH, W, footerH);
  ctx.fillStyle = cinza;
  ctx.font = "12px system-ui, sans-serif";
  ctx.fillText(
    `Documento emitido em ${formatDateBR(r.created_at.slice(0, 10))} • Tati Van Escolar`,
    W / 2,
    H - footerH / 2 + 4,
  );
  ctx.textAlign = "left";

  return await new Promise<Blob | null>((resolve) => canvas.toBlob((b) => resolve(b), "image/png", 0.95));
}

function truncate(ctx: CanvasRenderingContext2D, text: string, maxW: number): string {
  if (ctx.measureText(text).width <= maxW) return text;
  let t = text;
  while (t.length > 3 && ctx.measureText(t + "…").width > maxW) t = t.slice(0, -1);
  return t + "…";
}

export function reciboImageFilename(r: Recibo): string {
  const safe = r.numero.replace(/[^\w-]/g, "");
  return `recibo-${safe || "pagamento"}.png`;
}

/** Compartilha a imagem do recibo + mensagem pelo compartilhamento nativo. */
export async function shareImageFile(
  blob: Blob,
  filename: string,
  opts: { title: string; text: string },
): Promise<"shared" | "downloaded" | "cancelled"> {
  const file = new File([blob], filename, { type: "image/png" });
  const nav = navigator as Navigator & {
    canShare?: (data: { files?: File[] }) => boolean;
    share?: (data: ShareData & { files?: File[] }) => Promise<void>;
  };

  const isCancelled = (err: unknown) => {
    if (!(err instanceof Error)) return false;
    const name = err.name?.toLowerCase() || "";
    const msg = err.message?.toLowerCase() || "";
    return name === "aborterror" || msg.includes("cancel") || msg.includes("abort");
  };

  if (nav.share) {
    const canShareFiles = nav.canShare?.({ files: [file] }) ?? true;
    if (canShareFiles) {
      try {
        await nav.share({ files: [file], title: opts.title, text: opts.text });
        return "shared";
      } catch (err) {
        if (isCancelled(err)) return "cancelled";
      }
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
  return "downloaded";
}
