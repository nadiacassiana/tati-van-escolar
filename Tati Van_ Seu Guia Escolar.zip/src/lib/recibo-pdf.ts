import jsPDF from "jspdf";
import { formatBRL } from "./format";
import { METODO_LABEL, formatDateBR, formatMesReferencia, reciboTextoOficial, type Recibo } from "./recibo";
import type { MotoristaPerfil } from "./whatsapp";

/**
 * Generates a Receipt PDF (A4) by drawing directly with jsPDF.
 * Avoids html2canvas/iframe blank-output issues and supports multi-page.
 */
export function reciboToPdfBlob(r: Recibo, motorista: MotoristaPerfil): Blob {
  const pdf = new jsPDF("p", "mm", "a4");
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const marginX = 16;
  const marginTop = 14;
  const marginBottom = 18;
  const contentW = pageW - marginX * 2;
  const safeBottom = pageH - marginBottom;
  let cursorY = marginTop;

  const nomeOficial = motorista.nome_completo || "Motorista";
  const empresa = motorista.empresa || "";
  const apelido = motorista.apelido || "";

  const setText = (size: number, style: "normal" | "bold" = "normal", color: [number, number, number] = [26, 26, 46]) => {
    pdf.setFont("helvetica", style);
    pdf.setFontSize(size);
    pdf.setTextColor(color[0], color[1], color[2]);
  };

  const ensureSpace = (h: number) => {
    if (cursorY + h <= safeBottom) return;
    pdf.addPage();
    cursorY = marginTop;
  };

  // ---------- Header ----------
  // Identidade visual da motorista: logotipo quando existir, senão só o nome.
  let textX = marginX;
  const logo = (motorista.logo || "").trim();
  if (logo) {
    try {
      const props = pdf.getImageProperties(logo);
      const maxH = 18;
      const maxW = 40;
      const ratio = props.width / props.height;
      let h = maxH;
      let w = h * ratio;
      if (w > maxW) { w = maxW; h = w / ratio; }
      pdf.addImage(logo, props.fileType || "PNG", marginX, cursorY, w, h, undefined, "FAST");
      textX = marginX + w + 5;
    } catch {
      textX = marginX;
    }
  }

  setText(16, "bold", [30, 58, 138]);
  pdf.text(empresa || "Transporte Escolar", textX, cursorY + 6);

  setText(9, "normal", [82, 82, 91]);
  const sub = [apelido, nomeOficial].filter(Boolean).join(" • ");
  if (sub) pdf.text(sub, textX, cursorY + 12);
  let infoY = cursorY + 17;
  if (motorista.telefone) { pdf.text(`Tel: ${motorista.telefone}`, textX, infoY); infoY += 4.5; }
  if (motorista.email) { pdf.text(motorista.email, textX, infoY); infoY += 4.5; }

  // Receipt label box
  pdf.setFillColor(30, 64, 175);
  pdf.roundedRect(pageW - marginX - 36, cursorY, 36, 8, 1.5, 1.5, "F");
  setText(10, "bold", [255, 255, 255]);
  pdf.text("RECIBO", pageW - marginX - 18, cursorY + 5.5, { align: "center" });
  setText(14, "bold", [30, 58, 138]);
  pdf.text(r.numero, pageW - marginX, cursorY + 15, { align: "right" });
  setText(8, "normal", [107, 114, 128]);
  pdf.text(`Emitido em ${formatDateBR(r.created_at.slice(0, 10))}`, pageW - marginX, cursorY + 20, { align: "right" });

  cursorY = Math.max(infoY, cursorY + 22) + 2;
  pdf.setDrawColor(30, 64, 175);
  pdf.setLineWidth(1.1);
  pdf.line(marginX, cursorY, pageW - marginX, cursorY);
  cursorY += 8;

  // ---------- Highlighted amount ----------
  ensureSpace(28);
  pdf.setFillColor(239, 246, 255);
  pdf.roundedRect(marginX, cursorY, contentW, 26, 3, 3, "F");
  setText(8, "normal", [82, 82, 91]);
  pdf.text("VALOR RECEBIDO", pageW / 2, cursorY + 6, { align: "center" });
  setText(22, "bold", [30, 58, 138]);
  pdf.text(`R$ ${formatBRL(Number(r.valor))}`, pageW / 2, cursorY + 16, { align: "center" });
  setText(9, "bold", [55, 65, 81]);
  pdf.text(`Referente a ${formatMesReferencia(r.mes_referencia)}`, pageW / 2, cursorY + 22, { align: "center" });
  cursorY += 32;

  // ---------- Official text ----------
  const oficial = reciboTextoOficial(r);
  setText(10, "normal", [26, 26, 46]);
  const oficialLines = pdf.splitTextToSize(oficial, contentW) as string[];
  for (const line of oficialLines) {
    ensureSpace(6);
    pdf.text(line, marginX, cursorY);
    cursorY += 5.5;
  }
  cursorY += 4;

  // ---------- Two-column data: Responsável / Aluno ----------
  const gap = 6;
  const colW = (contentW - gap) / 2;

  const respLines: [string, string][] = [];
  if (r.responsavel_nome) respLines.push(["Nome", r.responsavel_nome]);
  if (r.responsavel_cpf) respLines.push(["CPF", r.responsavel_cpf]);
  if (r.responsavel_telefone) respLines.push(["Telefone", r.responsavel_telefone]);
  if (r.responsavel_email) respLines.push(["E-mail", r.responsavel_email]);

  const aluLines: [string, string][] = [["Aluno(a)", r.aluno_nome]];
  if (r.escola) aluLines.push(["Escola", r.escola]);
  if (r.turma) aluLines.push(["Turma", r.turma]);
  if (r.periodo) aluLines.push(["Período", r.periodo]);

  const drawBox = (x: number, y: number, w: number, title: string, rows: [string, string][]) => {
    const lineH = 4.6;
    const innerLines = rows.flatMap(([, v]) => pdf.splitTextToSize(v, w - 8) as string[]);
    const boxH = 10 + rows.length * (lineH + 2) + innerLines.length * 0;
    pdf.setDrawColor(226, 232, 240);
    pdf.setLineWidth(0.3);
    pdf.roundedRect(x, y, w, boxH, 2, 2, "S");
    setText(8, "bold", [30, 64, 175]);
    pdf.text(title.toUpperCase(), x + 4, y + 6);
    let ly = y + 12;
    for (const [k, v] of rows) {
      setText(7, "normal", [107, 114, 128]);
      pdf.text(k.toUpperCase(), x + 4, ly);
      setText(9, "normal", [26, 26, 46]);
      const vl = pdf.splitTextToSize(v, w - 8) as string[];
      pdf.text(vl[0] || "—", x + 4, ly + 4);
      ly += lineH + 2.5;
    }
    return boxH;
  };

  const respH = 10 + respLines.length * 7.1;
  const aluH = 10 + aluLines.length * 7.1;
  const boxH = Math.max(respH, aluH);
  ensureSpace(boxH + 4);
  drawBox(marginX, cursorY, colW, "Responsável", respLines.length ? respLines : [["—", "—"]]);
  drawBox(marginX + colW + gap, cursorY, colW, "Aluno(a)", aluLines);
  cursorY += boxH + 6;

  // ---------- Info row ----------
  const info: [string, string][] = [
    ["Vencimento", formatDateBR(r.data_vencimento)],
    ["Pagamento", formatDateBR(r.data_pagamento)],
    ["Forma", METODO_LABEL[r.metodo || ""] || r.metodo || "—"],
    ["Mês ref.", formatMesReferencia(r.mes_referencia)],
  ];
  ensureSpace(16);
  const iw = (contentW - gap * 3) / 4;
  info.forEach(([k, v], i) => {
    const x = marginX + i * (iw + gap);
    pdf.setDrawColor(226, 232, 240);
    pdf.roundedRect(x, cursorY, iw, 14, 2, 2, "S");
    setText(7, "normal", [107, 114, 128]);
    pdf.text(k.toUpperCase(), x + 3, cursorY + 5);
    setText(9, "bold", [26, 26, 46]);
    pdf.text(v, x + 3, cursorY + 11);
  });
  cursorY += 18;

  // ---------- Observações ----------
  if (r.observacoes) {
    const obsLines = pdf.splitTextToSize(`Observações: ${r.observacoes}`, contentW - 6) as string[];
    const obsH = 6 + obsLines.length * 5;
    ensureSpace(obsH + 2);
    pdf.setFillColor(255, 251, 235);
    pdf.setDrawColor(251, 191, 36);
    pdf.setLineWidth(0.5);
    pdf.roundedRect(marginX, cursorY, contentW, obsH, 2, 2, "FD");
    setText(9, "normal", [55, 65, 81]);
    obsLines.forEach((l, i) => pdf.text(l, marginX + 3, cursorY + 5 + i * 5));
    cursorY += obsH + 4;
  }

  // ---------- Signature ----------
  ensureSpace(28);
  cursorY += 14;
  const sigW = contentW * 0.6;
  const sigX = marginX + (contentW - sigW) / 2;
  pdf.setDrawColor(26, 26, 46);
  pdf.setLineWidth(0.4);
  pdf.line(sigX, cursorY, sigX + sigW, cursorY);
  setText(10, "bold", [26, 26, 46]);
  pdf.text(nomeOficial, pageW / 2, cursorY + 5, { align: "center" });
  setText(8, "normal", [107, 114, 128]);
  pdf.text("Recebido por", pageW / 2, cursorY + 10, { align: "center" });
  if (empresa) pdf.text(empresa, pageW / 2, cursorY + 14, { align: "center" });

  // ---------- Footer ----------
  cursorY = safeBottom + 6;
  setText(7, "normal", [156, 163, 175]);
  pdf.text(`${empresa || nomeOficial} • ${r.numero}`, pageW / 2, pageH - 8, { align: "center" });

  return pdf.output("blob");
}

export function reciboFilename(r: Recibo): string {
  const safe = (r.aluno_nome || "recibo").replace(/[^\p{L}\p{N}\s-]/gu, "").replace(/\s+/g, "_");
  return `Recibo_${r.numero}_${safe}.pdf`;
}

/**
 * Gera o PDF do recibo usando exatamente o mesmo modelo visual (com assinatura)
 * usado na pré-visualização do compartilhamento.
 */
export async function reciboToPdfBlobFromImage(
  r: Recibo,
  motorista: MotoristaPerfil,
): Promise<Blob | null> {
  const { reciboToImageBlob } = await import("./recibo-image");
  const img = await reciboToImageBlob(r, motorista);
  if (!img) return null;

  const dataUrl: string = await new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(new Error("read error"));
    fr.readAsDataURL(img);
  });

  const dims = await new Promise<{ w: number; h: number }>((resolve) => {
    const el = new Image();
    el.onload = () => resolve({ w: el.naturalWidth, h: el.naturalHeight });
    el.onerror = () => resolve({ w: 760, h: 1000 });
    el.src = dataUrl;
  });

  const pdf = new jsPDF("p", "mm", "a4");
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const margin = 10;
  const maxW = pageW - margin * 2;
  const maxH = pageH - margin * 2;
  const ratio = Math.min(maxW / dims.w, maxH / dims.h);
  const w = dims.w * ratio;
  const h = dims.h * ratio;
  pdf.addImage(dataUrl, "PNG", (pageW - w) / 2, (pageH - h) / 2, w, h, undefined, "FAST");
  return pdf.output("blob");
}
