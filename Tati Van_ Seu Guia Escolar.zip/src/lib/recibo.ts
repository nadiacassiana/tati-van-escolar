import { formatBRL } from "./format";
import type { MotoristaPerfil } from "./whatsapp";

export type Recibo = {
  id: string;
  numero: string;
  aluno_id: string | null;
  aluno_nome: string;
  escola: string | null;
  turma: string | null;
  periodo: string | null;
  responsavel_nome: string | null;
  responsavel_cpf: string | null;
  responsavel_telefone: string | null;
  responsavel_whatsapp: string | null;
  responsavel_email: string | null;
  mes_referencia: string;
  valor: number;
  data_vencimento: string | null;
  data_pagamento: string;
  metodo: string | null;
  observacoes: string | null;
  favorito: boolean;
  envios: { canal: string; data: string }[];
  created_at: string;
  pagamento_id?: string | null;
  estornado_em?: string | null;
  estorno_motivo?: string | null;
  historico?: unknown;
};

export const METODO_LABEL: Record<string, string> = {
  pix: "PIX",
  dinheiro: "Dinheiro",
  cartao: "Cartão",
  transferencia: "Transferência",
  outro: "Outro",
};

export function formatMesReferencia(mesRef: string): string {
  // "YYYY-MM"
  const [y, m] = mesRef.split("-").map((v) => parseInt(v, 10));
  if (!y || !m) return mesRef;
  const nomes = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
  return `${nomes[m - 1]}/${y}`;
}

export function formatDateBR(iso: string | null | undefined): string {
  if (!iso) return "—";
  const [y, m, d] = iso.split("T")[0].split("-");
  if (!y || !m || !d) return iso;
  return `${d}/${m}/${y}`;
}

export function reciboTextoOficial(r: Recibo): string {
  const valor = `R$ ${formatBRL(Number(r.valor))}`;
  const resp = r.responsavel_nome || "—";
  return `Declaro ter recebido de ${resp} a importância de ${valor} referente ao serviço de transporte escolar prestado ao aluno(a) ${r.aluno_nome}, correspondente ao mês de ${formatMesReferencia(r.mes_referencia)}.`;
}

export function reciboWhatsAppMessage(r: Recibo, motorista: MotoristaPerfil): string {
  const apelido = motorista.apelido || motorista.nome_completo || "Motorista";
  const respPrimeiro = (r.responsavel_nome || "").split(" ")[0] || "responsável";
  return [
    `Olá, ${respPrimeiro}! 👋`,
    "",
    `Recebi o pagamento referente ao transporte escolar do(a) ${r.aluno_nome}.`,
    `Segue o recibo nº ${r.numero} — ${formatMesReferencia(r.mes_referencia)} — R$ ${formatBRL(Number(r.valor))}.`,
    "",
    "Muito obrigado pela confiança! 💙",
    "",
    "Atenciosamente,",
    apelido,
  ].join("\n");
}

/** Mensagem que acompanha a imagem do recibo no compartilhamento nativo. */
export function reciboMensagemCompartilhamento(r: Recibo, motorista: MotoristaPerfil): string {
  const apelido = motorista.apelido || motorista.nome_completo || "Motorista";
  const respPrimeiro = (r.responsavel_nome || "").split(" ")[0] || "responsável";
  const mes = formatMesReferencia(r.mes_referencia).toLowerCase();
  return [
    `Olá, ${respPrimeiro}!`,
    "",
    `Recebi o pagamento referente ao transporte escolar de ${r.aluno_nome}, referente ao mês de ${mes}.`,
    "",
    `Segue o recibo nº ${r.numero}.`,
    "",
    "Muito obrigada pela confiança!",
    "",
    "Atenciosamente,",
    apelido,
  ].join("\n");
}

export function reciboEmailSubject(r: Recibo): string {
  return `Recibo de Pagamento — Transporte Escolar (${formatMesReferencia(r.mes_referencia)})`;
}

export function reciboEmailBody(r: Recibo, motorista: MotoristaPerfil, link?: string): string {
  const apelido = motorista.apelido || motorista.nome_completo || "Motorista";
  const respPrimeiro = (r.responsavel_nome || "").split(" ")[0] || "responsável";
  const lines = [
    `Olá, ${respPrimeiro}!`,
    "",
    `Segue o recibo referente ao pagamento da mensalidade do transporte escolar do(a) ${r.aluno_nome}.`,
    "",
    `Recibo nº: ${r.numero}`,
    `Mês de referência: ${formatMesReferencia(r.mes_referencia)}`,
    `Valor: R$ ${formatBRL(Number(r.valor))}`,
    `Pagamento em: ${formatDateBR(r.data_pagamento)}`,
  ];
  if (link) {
    lines.push("", `Visualizar recibo: ${link}`);
  }
  lines.push("", "Muito obrigado pela confiança.", "", "Atenciosamente,", apelido);
  return lines.join("\n");
}
