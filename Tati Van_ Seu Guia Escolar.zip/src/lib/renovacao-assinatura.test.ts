import { describe, expect, it } from "vitest";
import { computeAccountStatus } from "./account-status";
import { resolverRenovacao, proximoVencimentoNovoCiclo } from "./renovacao-assinatura";

const assinante = (nextDue: string | null) => ({
  plan_status: "ativo",
  asaas_subscription_id: "sub_1",
  next_due_date: nextDue,
  created_at: "2026-01-01T00:00:00Z",
});

describe("renovação após pausa por falta de pagamento", () => {
  it("pagamento antes do vencimento: mantém o ciclo atual", () => {
    const r = resolverRenovacao("2026-08-20", new Date("2026-08-18T12:00:00Z"));
    expect(r.reativada).toBe(false);
    expect(r.novoVencimento).toBeNull();
  });

  it("pagamento durante a tolerância: mantém o ciclo atual", () => {
    for (const dia of ["2026-08-20", "2026-08-21", "2026-08-22", "2026-08-23"]) {
      const r = resolverRenovacao("2026-08-20", new Date(`${dia}T12:00:00Z`));
      expect(r.reativada).toBe(false);
    }
  });

  it("conta pausada e paga dias depois: novo ciclo de 30 dias a partir do pagamento", () => {
    const r = resolverRenovacao("2026-08-20", new Date("2026-08-29T12:00:00Z"));
    expect(r.reativada).toBe(true);
    expect(r.novoVencimento).toBe("2026-09-28");
  });

  it("vários dias pausado: nada é cobrado proporcionalmente", () => {
    const r = resolverRenovacao("2026-08-20", new Date("2026-10-05T12:00:00Z"));
    expect(r.novoVencimento).toBe("2026-11-04");
  });

  it("novo vencimento reativa o acesso (sem somente leitura)", () => {
    const novo = proximoVencimentoNovoCiclo(new Date("2026-08-29T12:00:00Z"));
    const s = computeAccountStatus(assinante(novo), new Date("2026-08-29T12:00:00Z"));
    expect(s.phase).toBe("ativo");
    expect(s.isReadOnly).toBe(false);
  });

  it("não interfere no teste gratuito de 10 dias", () => {
    const s = computeAccountStatus({ created_at: new Date().toISOString() });
    expect(s.phase).toBe("trial");
    expect(s.isReadOnly).toBe(false);
  });
});
