// Regra de renovação após pausa por falta de pagamento (assinatura paga).
//
// Não altera: vencimento normal, tolerância de 3 dias, pausa automática,
// nem o período de teste gratuito de 10 dias.
//
// Quando a conta já estava PAUSADA por inadimplência (venceu e passou da
// tolerância) e o pagamento é confirmado, começa um NOVO ciclo completo de
// 30 dias a partir da data da confirmação — sem cobrança proporcional e sem
// descontar os dias parados.

import { PAYMENT_GRACE_DAYS } from "@/lib/account-status";

export const RENEWAL_CYCLE_DAYS = 30;

function startOfDayUTCFromISO(value: string): number | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (!m) return null;
  return Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
}

function toISODate(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(
    d.getUTCDate(),
  ).padStart(2, "0")}`;
}

/** Data (YYYY-MM-DD) do fim de um novo ciclo de 30 dias iniciado em `confirmadoEm`. */
export function proximoVencimentoNovoCiclo(confirmadoEm: Date = new Date()): string {
  const base = new Date(
    Date.UTC(confirmadoEm.getUTCFullYear(), confirmadoEm.getUTCMonth(), confirmadoEm.getUTCDate()),
  );
  base.setUTCDate(base.getUTCDate() + RENEWAL_CYCLE_DAYS);
  return toISODate(base);
}

/**
 * A conta estava pausada por falta de pagamento?
 * Verdadeiro quando o vencimento já passou há mais dias do que a tolerância.
 */
export function estavaPausadaPorFaltaDePagamento(
  vencimento: string | null | undefined,
  agora: Date = new Date(),
): boolean {
  if (!vencimento) return false;
  const due = startOfDayUTCFromISO(vencimento);
  if (due === null) return false;
  const hoje = Date.UTC(agora.getUTCFullYear(), agora.getUTCMonth(), agora.getUTCDate());
  const atraso = Math.floor((hoje - due) / 86_400_000);
  return atraso > PAYMENT_GRACE_DAYS;
}

export type Renovacao = {
  /** A conta estava pausada e foi reativada por este pagamento */
  reativada: boolean;
  /** Novo vencimento (YYYY-MM-DD) quando houve reativação; senão null */
  novoVencimento: string | null;
};

/**
 * Decide a renovação a partir do vencimento anterior e da data de confirmação
 * do pagamento. Só gera novo ciclo quando a conta estava pausada.
 */
export function resolverRenovacao(
  vencimentoAnterior: string | null | undefined,
  confirmadoEm: Date = new Date(),
): Renovacao {
  if (!estavaPausadaPorFaltaDePagamento(vencimentoAnterior, confirmadoEm)) {
    return { reativada: false, novoVencimento: null };
  }
  return { reativada: true, novoVencimento: proximoVencimentoNovoCiclo(confirmadoEm) };
}
