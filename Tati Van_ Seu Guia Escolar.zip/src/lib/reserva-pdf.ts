import jsPDF from "jspdf";
import { formatBRL } from "./format";
import { getMarca } from "./marca";
import type { MotoristaPerfil } from "./whatsapp";

export type ReservaVaga = {
  alunoNome: string;
  escola?: string;
  turma?: string;
  responsavel?: string;
  telefone?: string;
  endereco?: string;
  turno?: string;
  horarioIda?: string;
  horarioVolta?: string;
  mensalidade?: number;
  vencimento?: number;
  anoLetivo: string;
  observacoes?: string;
};

function hoje(): string {
  return new Date().toLocaleDateString("pt-BR");
}

/**
 * Documento de Reserva de Vaga (A4) com a identidade visual da motorista:
 * logotipo (quando enviado) e nome da van no cabeçalho e no rodapé.
 */
export function reservaToPdfBlob(r: ReservaVaga, motorista: MotoristaPerfil): Blob {
  const marca = getMarca(motorista);
  const pdf = new jsPDF("p", "mm", "a4");
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const marginX = 16;
  const contentW = pageW - marginX * 2;
  let y = 14;

  const setText = (
    size: number,
    style: "normal" | "bold" = "normal",
    color: [number, number, number] = [26, 26, 46],
  ) => {
    pdf.setFont("helvetica", style);
    pdf.setFontSize(size);
    pdf.setTextColor(color[0], color[1], color[2]);
  };

  // ---------- Cabeçalho (identidade da van) ----------
  let textX = marginX;
  if (marca.logo) {
    try {
      const props = pdf.getImageProperties(marca.logo);
      const maxH = 18;
      const maxW = 40;
      const ratio = props.width / props.height;
      let h = maxH;
      let w = h * ratio;
      if (w > maxW) {
        w = maxW;
        h = w / ratio;
      }
      pdf.addImage(marca.logo, props.fileType || "PNG", marginX, y, w, h, undefined, "FAST");
      textX = marginX + w + 5;
    } catch {
      textX = marginX;
    }
  }

  setText(16, "bold", [30, 58, 138]);
  pdf.text(marca.nome, textX, y + 6);
  setText(9, "normal", [82, 82, 91]);
  const sub = [motorista.apelido, motorista.nome_completo].filter(Boolean).join(" • ");
  let infoY = y + 12;
  if (sub) {
    pdf.text(sub, textX, infoY);
    infoY += 4.5;
  }
  if (motorista.telefone) {
    pdf.text(`Tel: ${motorista.telefone}`, textX, infoY);
    infoY += 4.5;
  }
  if (motorista.email) {
    pdf.text(motorista.email, textX, infoY);
    infoY += 4.5;
  }

  pdf.setFillColor(30, 64, 175);
  pdf.roundedRect(pageW - marginX - 46, y, 46, 8, 1.5, 1.5, "F");
  setText(9, "bold", [255, 255, 255]);
  pdf.text("RESERVA DE VAGA", pageW - marginX - 23, y + 5.5, { align: "center" });
  setText(8, "normal", [107, 114, 128]);
  pdf.text(`Emitido em ${hoje()}`, pageW - marginX, y + 14, { align: "right" });

  y = Math.max(infoY, y + 22) + 2;
  pdf.setDrawColor(30, 64, 175);
  pdf.setLineWidth(1.1);
  pdf.line(marginX, y, pageW - marginX, y);
  y += 10;

  // ---------- Título ----------
  setText(14, "bold", [26, 26, 46]);
  pdf.text(`COMPROVANTE DE RESERVA DE VAGA — ${r.anoLetivo}`, pageW / 2, y, { align: "center" });
  y += 10;

  // ---------- Texto oficial ----------
  const texto =
    `${marca.nome} confirma a reserva de 1 (uma) vaga no serviço de transporte escolar para o(a) aluno(a) ` +
    `${r.alunoNome}${r.escola ? `, matriculado(a) na escola ${r.escola}` : ""}${r.turma ? ` (turma ${r.turma})` : ""}, ` +
    `referente ao ano letivo de ${r.anoLetivo}, mediante as condições combinadas com o(a) responsável` +
    `${r.responsavel ? ` ${r.responsavel}` : ""}.`;
  setText(10.5, "normal", [26, 26, 46]);
  const linhas = pdf.splitTextToSize(texto, contentW) as string[];
  for (const l of linhas) {
    pdf.text(l, marginX, y);
    y += 5.8;
  }
  y += 6;

  // ---------- Blocos de dados ----------
  const gap = 6;
  const colW = (contentW - gap) / 2;

  const drawBox = (x: number, top: number, w: number, title: string, rows: [string, string][]) => {
    const boxH = 10 + rows.length * 7.4;
    pdf.setDrawColor(226, 232, 240);
    pdf.setLineWidth(0.3);
    pdf.roundedRect(x, top, w, boxH, 2, 2, "S");
    setText(8, "bold", [30, 64, 175]);
    pdf.text(title.toUpperCase(), x + 4, top + 6);
    let ly = top + 12;
    for (const [k, v] of rows) {
      setText(7, "normal", [107, 114, 128]);
      pdf.text(k.toUpperCase(), x + 4, ly);
      setText(9, "normal", [26, 26, 46]);
      const vl = pdf.splitTextToSize(v || "—", w - 8) as string[];
      pdf.text(vl[0] || "—", x + 4, ly + 4);
      ly += 7.4;
    }
    return boxH;
  };

  const alunoRows: [string, string][] = [["Aluno(a)", r.alunoNome]];
  if (r.escola) alunoRows.push(["Escola", r.escola]);
  if (r.turma) alunoRows.push(["Turma", r.turma]);
  if (r.turno) alunoRows.push(["Turno", r.turno]);

  const respRows: [string, string][] = [];
  if (r.responsavel) respRows.push(["Responsável", r.responsavel]);
  if (r.telefone) respRows.push(["Telefone", r.telefone]);
  if (r.endereco) respRows.push(["Endereço", r.endereco]);
  if (respRows.length === 0) respRows.push(["Responsável", "—"]);

  const h1 = 10 + alunoRows.length * 7.4;
  const h2 = 10 + respRows.length * 7.4;
  drawBox(marginX, y, colW, "Aluno(a)", alunoRows);
  drawBox(marginX + colW + gap, y, colW, "Responsável", respRows);
  y += Math.max(h1, h2) + 8;

  // ---------- Condições ----------
  const info: [string, string][] = [
    ["Ida", r.horarioIda || "—"],
    ["Volta", r.horarioVolta || "—"],
    ["Mensalidade", r.mensalidade ? `R$ ${formatBRL(Number(r.mensalidade))}` : "—"],
    ["Vencimento", r.vencimento ? `Todo dia ${r.vencimento}` : "—"],
  ];
  const iw = (contentW - gap * 3) / 4;
  info.forEach(([k, v], i) => {
    const x = marginX + i * (iw + gap);
    pdf.setDrawColor(226, 232, 240);
    pdf.roundedRect(x, y, iw, 14, 2, 2, "S");
    setText(7, "normal", [107, 114, 128]);
    pdf.text(k.toUpperCase(), x + 3, y + 5);
    setText(9, "bold", [26, 26, 46]);
    pdf.text(v, x + 3, y + 11);
  });
  y += 20;

  if (r.observacoes) {
    const obsLines = pdf.splitTextToSize(`Observações: ${r.observacoes}`, contentW - 6) as string[];
    const obsH = 6 + obsLines.length * 5;
    pdf.setFillColor(255, 251, 235);
    pdf.setDrawColor(251, 191, 36);
    pdf.setLineWidth(0.5);
    pdf.roundedRect(marginX, y, contentW, obsH, 2, 2, "FD");
    setText(9, "normal", [55, 65, 81]);
    obsLines.forEach((l, i) => pdf.text(l, marginX + 3, y + 5 + i * 5));
    y += obsH + 6;
  }

  // ---------- Assinaturas ----------
  y = Math.min(y + 16, pageH - 46);
  const sigW = (contentW - 16) / 2;
  pdf.setDrawColor(26, 26, 46);
  pdf.setLineWidth(0.4);
  pdf.line(marginX, y, marginX + sigW, y);
  pdf.line(marginX + sigW + 16, y, marginX + sigW * 2 + 16, y);
  setText(9, "bold", [26, 26, 46]);
  pdf.text(marca.nome, marginX + sigW / 2, y + 5, { align: "center" });
  pdf.text(r.responsavel || "Responsável", marginX + sigW + 16 + sigW / 2, y + 5, { align: "center" });
  setText(8, "normal", [107, 114, 128]);
  pdf.text("Transportador(a)", marginX + sigW / 2, y + 10, { align: "center" });
  pdf.text("Responsável pelo(a) aluno(a)", marginX + sigW + 16 + sigW / 2, y + 10, { align: "center" });

  // ---------- Rodapé ----------
  setText(7, "normal", [156, 163, 175]);
  pdf.text(`${marca.nome} • Reserva de vaga ${r.anoLetivo}`, pageW / 2, pageH - 8, { align: "center" });

  return pdf.output("blob");
}

export function reservaFilename(r: ReservaVaga): string {
  const safe = (r.alunoNome || "aluno").replace(/[^\p{L}\p{N}\s-]/gu, "").replace(/\s+/g, "_");
  return `Reserva_de_Vaga_${r.anoLetivo}_${safe}.pdf`;
}
