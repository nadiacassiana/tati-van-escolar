import { supabase } from "@/integrations/supabase/client";

export type Turno = "manha" | "tarde" | "integral";
export type Sentido = "ida" | "volta";
export type RotaAtiva = {
  id: string;
  user_id?: string;
  turno: Turno;
  sentido: Sentido;
  motorista_nome: string | null;
  iniciada_em: string;
  encerrada_em: string | null;
  expira_em: string | null;
  revogada_em: string | null;
  ultima_lat: number | null;
  ultima_lng: number | null;
  ultima_atualizacao: string | null;
};

/** Limite absoluto de funcionamento de qualquer rota (trava de segurança). */
export const MAX_HORAS = 4;
/** Falhas seguidas de envio antes de desligar o rastreamento por segurança. */
const MAX_FALHAS = 5;

export type ParadaStatus = "pendente" | "embarcado" | "ausente" | "desembarcado";
export type RotaParada = {
  id: string;
  rota_id: string;
  aluno_id: string | null;
  aluno_nome: string;
  ordem: number;
  status: ParadaStatus;
  embarcado_em: string | null;
  desembarcado_em: string | null;
};

export const turnoLabel: Record<Turno, string> = {
  manha: "manhã",
  tarde: "tarde",
  integral: "integral",
};

/** Nome do momento da rota exibido nos botões e mensagens. */
export const momentoLabel: Record<Turno, Record<Sentido, string>> = {
  manha: { ida: "Ida — Manhã", volta: "Volta — Meio-Dia" },
  tarde: { ida: "Ida — Tarde", volta: "Volta — Fim de Tarde" },
  integral: { ida: "Ida — Integral (Manhã)", volta: "Volta — Integral (Fim de Tarde)" },
};

export const sentidoLabel: Record<Sentido, string> = {
  ida: "Ida: Casa → Escola",
  volta: "Volta: Escola → Casa",
};



export function trackingUrl(rotaId: string, paradaId?: string | null): string {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  return `${origin}/rastrear/${rotaId}${paradaId ? `?p=${paradaId}` : ""}`;
}

/** Cria as paradas (ordem de embarque) de uma rota. */
export async function criarParadas(
  rotaId: string,
  userId: string,
  alunos: { id: string; nome: string }[],
): Promise<RotaParada[]> {
  if (alunos.length === 0) return [];
  const rows = alunos.map((a, i) => ({
    rota_id: rotaId,
    user_id: userId,
    aluno_id: a.id,
    aluno_nome: a.nome,
    ordem: i,
  }));
  const { data, error } = await supabase.from("rota_paradas").insert(rows).select("*");
  if (error) {
    console.warn("[rota-ativa] falha ao criar paradas:", error.message);
    return [];
  }
  return (data as unknown as RotaParada[]) || [];
}

export async function listarParadas(rotaId: string): Promise<RotaParada[]> {
  const { data } = await supabase
    .from("rota_paradas")
    .select("*")
    .eq("rota_id", rotaId)
    .order("ordem", { ascending: true });
  return (data as unknown as RotaParada[]) || [];
}

export async function atualizarParada(paradaId: string, status: ParadaStatus): Promise<void> {
  const agora = new Date().toISOString();
  await supabase
    .from("rota_paradas")
    .update({
      status,
      embarcado_em: status === "embarcado" ? agora : null,
      desembarcado_em: status === "desembarcado" ? agora : null,
    })
    .eq("id", paradaId);
}


/** Retorna true se a rota ainda está publicamente acessível (não expirada, não revogada, não encerrada). */
export function linkAtivo(r: Pick<RotaAtiva, "encerrada_em" | "expira_em" | "revogada_em"> | null): boolean {
  if (!r) return false;
  if (r.encerrada_em) return false;
  if (r.revogada_em) return false;
  if (r.expira_em && new Date(r.expira_em).getTime() <= Date.now()) return false;
  return true;
}

export async function getRotaAtiva(userId: string, turno: Turno, sentido: Sentido = "ida"): Promise<RotaAtiva | null> {
  const { data } = await supabase
    .from("rotas_ativas")
    .select("*")
    .eq("user_id", userId)
    .eq("turno", turno)
    .eq("sentido", sentido)
    .is("encerrada_em", null)
    .order("iniciada_em", { ascending: false })
    .limit(1)
    .maybeSingle();
  return (data as RotaAtiva) || null;
}

export async function iniciarRota(
  userId: string,
  turno: Turno,
  motoristaNome?: string,
  duracaoHoras: number = 2,
  sentido: Sentido = "ida",
): Promise<RotaAtiva> {
  // Encerra qualquer rota anterior aberta do mesmo turno e sentido
  await supabase
    .from("rotas_ativas")
    .update({ encerrada_em: new Date().toISOString() })
    .eq("user_id", userId).eq("turno", turno).eq("sentido", sentido).is("encerrada_em", null);

  const horas = Math.min(MAX_HORAS, duracaoHoras && duracaoHoras > 0 ? duracaoHoras : 2);
  const expira_em = new Date(Date.now() + horas * 3600_000).toISOString();

  const { data, error } = await supabase
    .from("rotas_ativas")
    .insert({ user_id: userId, turno, sentido, motorista_nome: motoristaNome || null, expira_em })
    .select("*")
    .single();
  if (error || !data) throw error || new Error("Falha ao criar rota");
  const rota = data as RotaAtiva;
  startWatching(rota.id, rota.expira_em);
  return rota;
}


export async function encerrarRota(rotaId: string): Promise<void> {
  stopWatching(rotaId);
  await supabase
    .from("rotas_ativas")
    .update({ encerrada_em: new Date().toISOString() })
    .eq("id", rotaId);
}

/** Revoga apenas o link público sem encerrar o rastreamento do motorista. */
export async function revogarLink(rotaId: string): Promise<void> {
  await supabase
    .from("rotas_ativas")
    .update({ revogada_em: new Date().toISOString() })
    .eq("id", rotaId);
}

/** Ajusta o horário de expiração de um link já criado. Passe null para "somente ao encerrar". */
export async function atualizarExpiracao(rotaId: string, expira_em: string | null): Promise<void> {
  await supabase
    .from("rotas_ativas")
    .update({ expira_em })
    .eq("id", rotaId);
}

type Tracker = {
  watchId: number | null;
  heartbeat: ReturnType<typeof setInterval> | null;
  expiraTimer: ReturnType<typeof setTimeout> | null;
  expiraEm: number | null;
  wakeLock: { release: () => Promise<void> } | null;
  onVisibility: () => void;
  ultimoEnvio: number;
  falhas: number;
};


const rastreios = new Map<string, Tracker>();

async function enviarPosicao(rotaId: string, pos: GeolocationPosition) {
  const t = rastreios.get(rotaId);
  if (!t) return;
  if (t.expiraEm && Date.now() >= t.expiraEm) { stopWatching(rotaId); return; }
  const agora = Date.now();
  if (agora - t.ultimoEnvio < 4000) return; // evita gravações excessivas
  t.ultimoEnvio = agora;

  try {
    const { error } = await supabase.from("rotas_ativas").update({
      ultima_lat: pos.coords.latitude,
      ultima_lng: pos.coords.longitude,
      ultima_atualizacao: new Date().toISOString(),
    }).eq("id", rotaId);
    if (error) throw new Error(error.message);
    t.falhas = 0;
  } catch (e) {
    // Falhas ficam isoladas nesta rota: nunca derrubam a sessão nem outras telas.
    t.falhas += 1;
    console.warn("[rota-ativa] falha ao enviar posição:", (e as Error).message);
    if (t.falhas >= MAX_FALHAS) {
      console.warn("[rota-ativa] muitas falhas seguidas — rastreamento desligado por segurança.");
      stopWatching(rotaId);
    }
  }
}

function armarWatch(rotaId: string) {
  const t = rastreios.get(rotaId);
  if (!t || t.watchId != null) return;
  t.watchId = navigator.geolocation.watchPosition(
    (pos) => { void enviarPosicao(rotaId, pos); },
    (err) => { console.warn("[rota-ativa] geolocation error:", err.message); },
    { enableHighAccuracy: true, maximumAge: 5_000, timeout: 30_000 },
  );
}

async function pedirWakeLock(rotaId: string) {
  const t = rastreios.get(rotaId);
  const nav = navigator as Navigator & { wakeLock?: { request: (t: "screen") => Promise<{ release: () => Promise<void> }> } };
  if (!t || t.wakeLock || !nav.wakeLock) return;
  try {
    t.wakeLock = await nav.wakeLock.request("screen");
  } catch {
    /* usuário/navegador pode negar */
  }
}

export function startWatching(rotaId: string, expiraEm?: string | null) {
  if (typeof navigator === "undefined" || !navigator.geolocation) return;
  if (rastreios.has(rotaId)) return;

  // Trava dura: nunca rastreia além do limite máximo absoluto, mesmo com data inválida.
  const teto = Date.now() + MAX_HORAS * 3600_000;
  const escolhido = expiraEm ? new Date(expiraEm).getTime() : teto;
  const limite = Number.isFinite(escolhido) ? Math.min(escolhido, teto) : teto;
  if (limite <= Date.now()) return; // já expirou: não envia nada

  const tracker: Tracker = {
    watchId: null,
    heartbeat: null,
    expiraTimer: null,
    expiraEm: limite,
    wakeLock: null,
    ultimoEnvio: 0,
    falhas: 0,
    onVisibility: () => {
      if (typeof document === "undefined" || document.visibilityState !== "visible") return;
      const t = rastreios.get(rotaId);
      if (t?.expiraEm && Date.now() >= t.expiraEm) { stopWatching(rotaId); return; }
      // Ao voltar do segundo plano, religa o GPS e envia uma posição imediata.
      if (t?.watchId != null) {
        navigator.geolocation.clearWatch(t.watchId);
        t.watchId = null;
      }
      armarWatch(rotaId);
      void pedirWakeLock(rotaId);
      navigator.geolocation.getCurrentPosition(
        (pos) => { void enviarPosicao(rotaId, pos); },
        () => {},
        { enableHighAccuracy: true, maximumAge: 0, timeout: 20_000 },
      );
    },
  };
  rastreios.set(rotaId, tracker);

  armarWatch(rotaId);
  void pedirWakeLock(rotaId);

  // Rede de segurança: mesmo se o watch adormecer, pede a posição a cada 15s.
  tracker.heartbeat = setInterval(() => {
    const t = rastreios.get(rotaId);
    if (t?.expiraEm && Date.now() >= t.expiraEm) { stopWatching(rotaId); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => { void enviarPosicao(rotaId, pos); },
      () => {},
      { enableHighAccuracy: true, maximumAge: 10_000, timeout: 20_000 },
    );
  }, 15_000);

  // Desliga o GPS e encerra a rota exatamente no fim do tempo escolhido (auto-kill).
  tracker.expiraTimer = setTimeout(() => {
    stopWatching(rotaId);
    void supabase
      .from("rotas_ativas")
      .update({ encerrada_em: new Date().toISOString() })
      .eq("id", rotaId)
      .is("encerrada_em", null)
      .then(() => {}, () => {}); // erro aqui nunca afeta o resto do app
  }, Math.max(0, limite - Date.now()));

  if (typeof document !== "undefined") {
    document.addEventListener("visibilitychange", tracker.onVisibility);
  }
}


export function stopWatching(rotaId: string) {
  const t = rastreios.get(rotaId);
  if (!t) return;
  if (t.watchId != null && typeof navigator !== "undefined" && navigator.geolocation) {
    navigator.geolocation.clearWatch(t.watchId);
  }
  if (t.heartbeat) clearInterval(t.heartbeat);
  if (t.expiraTimer) clearTimeout(t.expiraTimer);

  if (typeof document !== "undefined") {
    document.removeEventListener("visibilitychange", t.onVisibility);
  }
  void t.wakeLock?.release().catch(() => {});
  rastreios.delete(rotaId);
}

