import jsPDF from "jspdf";
import { supabase } from "@/integrations/supabase/client";
import { turnoLabel, type ParadaStatus, type RotaParada, type Turno } from "./rota-ativa";
import type { MotoristaPerfil } from "./whatsapp";

export type RotaHistorico = {
  id: string;
  turno: Turno;
  motorista_nome: string | null;
  iniciada_em: string;
  encerrada_em: string;
  paradas: RotaParada[];
};

export const statusLabel: Record<ParadaStatus, string> = {
  embarcado: "Embarcado",
  desembarcado: "Desembarcado",
  ausente: "Ausente / Falta",
  pendente: "Não embarcou",
};

export function horaBR(iso: string | null | undefined): string {
  if (!iso) return "--:--";
  return new Date(iso).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "America/Sao_Paulo",
  });
}

export function dataBR(iso: string): string {
  return new Date(iso).toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" });
}

/** Busca rotas encerradas do motorista dentro de um intervalo (ISO). */
export async function listarHistorico(
  userId: string,
  inicioISO: string,
  fimISO: string,
): Promise<RotaHistorico[]> {
  const { data, error } = await supabase
    .from("rotas_ativas")
    .select("id, turno, motorista_nome, iniciada_em, encerrada_em")
    .eq("user_id", userId)
    .not("encerrada_em", "is", null)
    .gte("iniciada_em", inicioISO)
    .lte("iniciada_em", fimISO)
    .order("iniciada_em", { ascending: false });

  if (error || !data || data.length === 0) return [];

  const ids = data.map((r) => r.id as string);
  const { data: paradas } = await supabase
    .from("rota_paradas")
    .select("*")
    .in("rota_id", ids)
    .order("ordem", { ascending: true });

  const porRota = new Map<string, RotaParada[]>();
  for (const p of (paradas as unknown as RotaParada[]) || []) {
    const arr = porRota.get(p.rota_id) || [];
    arr.push(p);
    porRota.set(p.rota_id, arr);
  }

  return data.map((r) => ({
    id: r.id as string,
    turno: r.turno as Turno,
    motorista_nome: (r.motorista_nome as string) || null,
    iniciada_em: r.iniciada_em as string,
    encerrada_em: r.encerrada_em as string,
    paradas: porRota.get(r.id as string) || [],
  }));
}

export function resumoRota(r: RotaHistorico) {
  const embarcados = r.paradas.filter((p) => p.status === "embarcado").length;
  const desembarcados = r.paradas.filter((p) => p.status === "desembarcado").length;
  const ausentes = r.paradas.filter((p) => p.status === "ausente").length;
  const pendentes = r.paradas.filter((p) => p.status === "pendente").length;
  return { embarcados, desembarcados, ausentes, pendentes, total: r.paradas.length };
}

/** Gera o PDF do relatório de rotas do período. */
export function historicoToPdfBlob(
  rotas: RotaHistorico[],
  periodo: string,
  motorista: MotoristaPerfil,
): Blob {
  const pdf = new jsPDF("p", "mm", "a4");
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const marginX = 16;
  const safeBottom = pageH - 18;
  let y = 16;

  const setText = (
    size: number,
    style: "normal" | "bold" = "normal",
    color: [number, number, number] = [26, 26, 46],
  ) => {
    pdf.setFont("helvetica", style);
    pdf.setFontSize(size);
    pdf.setTextColor(color[0], color[1], color[2]);
  };

  const ensure = (h: number) => {
    if (y + h > safeBottom) {
      pdf.addPage();
      y = 16;
    }
  };

  setText(16, "bold", [30, 58, 138]);
  pdf.text(motorista.empresa || "Transporte Escolar", marginX, y + 6);
  y += 12;
  setText(11, "bold");
  pdf.text("Relatório de Rotas", marginX, y);
  y += 6;
  setText(9, "normal", [82, 82, 91]);
  pdf.text(`Período: ${periodo}`, marginX, y);
  y += 5;
  pdf.text(
    `Motorista: ${motorista.nome_completo || motorista.apelido || "—"} • Emitido em ${new Date().toLocaleString("pt-BR")}`,
    marginX,
    y,
  );
  y += 8;

  if (rotas.length === 0) {
    setText(10, "normal");
    pdf.text("Nenhuma rota finalizada no período.", marginX, y);
    return pdf.output("blob");
  }

  for (const r of rotas) {
    const { embarcados, desembarcados, ausentes, pendentes, total } = resumoRota(r);
    ensure(22);
    pdf.setDrawColor(220, 226, 240);
    pdf.setFillColor(240, 245, 255);
    pdf.rect(marginX, y, pageW - marginX * 2, 14, "F");
    setText(11, "bold", [30, 58, 138]);
    pdf.text(
      `${dataBR(r.iniciada_em)} — Rota da ${turnoLabel[r.turno]}`,
      marginX + 3,
      y + 6,
    );
    setText(9, "normal", [82, 82, 91]);
    pdf.text(
      `Início ${horaBR(r.iniciada_em)} • Fim ${horaBR(r.encerrada_em)} • ${embarcados} embarcados, ${desembarcados} desembarcados, ${ausentes} ausentes, ${pendentes} pendentes (${total} alunos)`,
      marginX + 3,
      y + 11,
    );
    y += 18;

    for (const p of r.paradas) {
      ensure(6);
      setText(9, "normal");
      let hora = "";
      if (p.status === "embarcado" && p.embarcado_em) hora = ` às ${horaBR(p.embarcado_em)}`;
      if (p.status === "desembarcado" && p.desembarcado_em) hora = ` às ${horaBR(p.desembarcado_em)}`;
      pdf.text(`• ${p.aluno_nome} — ${statusLabel[p.status]}${hora}`, marginX + 5, y);
      y += 5;
    }
    y += 4;
  }

  return pdf.output("blob");
}
