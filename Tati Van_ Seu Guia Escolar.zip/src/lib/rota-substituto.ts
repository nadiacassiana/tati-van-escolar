import { supabase } from "@/integrations/supabase/client";
import type { Turno } from "@/lib/rota-ativa";

/** Parada enviada ao substituto — apenas dados operacionais, nunca financeiros. */
export type ParadaSubstituto = {
  nome: string;
  endereco: string;
  escola: string;
  escola_endereco?: string;
  periodo: string;
  responsavel: string;
  telefone: string;
};

export type RotaSubstituto = {
  id: string;
  turno: Turno;
  titular_nome: string | null;
  expira_em: string;
  revogada_em: string | null;
  created_at: string;
};

export type RotaSubstitutoPublica = {
  encontrada: boolean;
  estado?: "ativa" | "revogada" | "expirada";
  turno?: Turno;
  titular_nome?: string | null;
  expira_em?: string;
  criada_em?: string;
  paradas?: ParadaSubstituto[];
};

export function substitutoUrl(id: string): string {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  return `${origin}/substituto/${id}`;
}

/** Cria (ou substitui) o link de 24h com a ordem de paradas definida pela titular. */
export async function criarRotaSubstituto(
  userId: string,
  turno: Turno,
  titularNome: string | null,
  paradas: ParadaSubstituto[],
): Promise<RotaSubstituto> {
  // revoga links anteriores do mesmo turno
  await supabase
    .from("rotas_substituto")
    .update({ revogada_em: new Date().toISOString() })
    .eq("user_id", userId)
    .eq("turno", turno)
    .is("revogada_em", null);

  const { data, error } = await supabase
    .from("rotas_substituto")
    .insert({
      user_id: userId,
      turno,
      titular_nome: titularNome,
      paradas: paradas as unknown as never,
      expira_em: new Date(Date.now() + 24 * 3600_000).toISOString(),
    })
    .select("id, turno, titular_nome, expira_em, revogada_em, created_at")
    .single();
  if (error || !data) throw error || new Error("Falha ao criar link do substituto");
  return data as unknown as RotaSubstituto;
}

export async function getRotaSubstitutoAtiva(userId: string, turno: Turno): Promise<RotaSubstituto | null> {
  const { data } = await supabase
    .from("rotas_substituto")
    .select("id, turno, titular_nome, expira_em, revogada_em, created_at")
    .eq("user_id", userId)
    .eq("turno", turno)
    .is("revogada_em", null)
    .gt("expira_em", new Date().toISOString())
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return (data as unknown as RotaSubstituto) || null;
}

export async function revogarRotaSubstituto(id: string): Promise<void> {
  await supabase
    .from("rotas_substituto")
    .update({ revogada_em: new Date().toISOString() })
    .eq("id", id);
}

export async function carregarRotaSubstitutoPublica(id: string): Promise<RotaSubstitutoPublica> {
  const { data, error } = await supabase.rpc("get_rota_substituto", { _id: id });
  if (error || !data) return { encontrada: false };
  return data as unknown as RotaSubstitutoPublica;
}

/** Abre a busca do endereço no mapa livre OpenStreetMap. */
export function osmUrl(endereco: string): string {
  return `https://www.openstreetmap.org/search?query=${encodeURIComponent(endereco)}`;
}

export function wazeUrl(endereco: string): string {
  return `https://waze.com/ul?q=${encodeURIComponent(endereco)}&navigate=yes`;
}
