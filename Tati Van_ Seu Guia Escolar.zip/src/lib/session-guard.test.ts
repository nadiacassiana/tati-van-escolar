import { describe, expect, it, vi, beforeEach } from "vitest";

vi.mock("@/integrations/supabase/client", () => ({
  supabase: { auth: { signOut: vi.fn().mockRejectedValue(new Error("offline")) } },
}));

import { hardClearSession, purgeCorruptedSession, forceSignOut } from "./session-guard";

const AUTH_KEY = "sb-projeto-auth-token";

beforeEach(() => {
  window.localStorage.clear();
  vi.spyOn(console, "error").mockImplementation(() => {});
});

describe("purgeCorruptedSession", () => {
  it("mantém uma sessão saudável", () => {
    window.localStorage.setItem(AUTH_KEY, JSON.stringify({ access_token: "a".repeat(500) }));
    expect(purgeCorruptedSession()).toBe(false);
    expect(window.localStorage.getItem(AUTH_KEY)).not.toBeNull();
  });

  it("remove sessão gigante (token inflado por logotipo)", () => {
    window.localStorage.setItem(AUTH_KEY, "x".repeat(200_000));
    expect(purgeCorruptedSession()).toBe(true);
    expect(window.localStorage.getItem(AUTH_KEY)).toBeNull();
  });
});

describe("hardClearSession", () => {
  it("limpa sessão e cache do logotipo", () => {
    window.localStorage.setItem(AUTH_KEY, "abc");
    window.localStorage.setItem("tati_van_logo", "data:image/png;base64,AAA");
    hardClearSession();
    expect(window.localStorage.getItem(AUTH_KEY)).toBeNull();
    expect(window.localStorage.getItem("tati_van_logo")).toBeNull();
  });
});

describe("forceSignOut", () => {
  it("limpa localmente mesmo se o servidor falhar", async () => {
    window.localStorage.setItem(AUTH_KEY, "abc");
    await expect(forceSignOut()).resolves.toBeUndefined();
    expect(window.localStorage.getItem(AUTH_KEY)).toBeNull();
  });
});
