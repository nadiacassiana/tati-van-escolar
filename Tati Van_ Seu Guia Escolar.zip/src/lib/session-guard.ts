import { supabase } from "@/integrations/supabase/client";

/**
 * Rede de segurança contra sessões corrompidas/gigantes.
 *
 * Se o token guardado no navegador ficar grande demais (por exemplo, se algum dado
 * pesado for parar no perfil de login), TODAS as requisições passam a falhar e a
 * tela trava. Aqui detectamos e limpamos isso automaticamente.
 */
const MAX_TOKEN_CHARS = 16_000; // um token saudável tem ~1-3 KB

function authKeys(): string[] {
  if (typeof window === "undefined") return [];
  const keys: string[] = [];
  try {
    for (let i = 0; i < window.localStorage.length; i++) {
      const k = window.localStorage.key(i);
      if (k && k.startsWith("sb-") && k.includes("auth-token")) keys.push(k);
    }
  } catch {
    /* storage indisponível */
  }
  return keys;
}

/** Remove qualquer vestígio de sessão local. Nunca lança. */
export function hardClearSession() {
  if (typeof window === "undefined") return;
  try {
    for (const k of authKeys()) window.localStorage.removeItem(k);
    window.localStorage.removeItem("tati_van_logo");
  } catch (e) {
    console.error("[auth] não foi possível limpar a sessão local:", e);
  }
}

/** @returns true quando uma sessão corrompida foi encontrada e removida. */
export function purgeCorruptedSession(): boolean {
  let purged = false;
  for (const k of authKeys()) {
    let value = "";
    try {
      value = window.localStorage.getItem(k) || "";
    } catch {
      continue;
    }
    if (value.length > MAX_TOKEN_CHARS) {
      console.error(
        `[auth] sessão local corrompida (${value.length} caracteres em ${k}). Limpando para permitir novo login.`,
      );
      try {
        window.localStorage.removeItem(k);
      } catch {
        /* ignore */
      }
      purged = true;
    }
  }
  return purged;
}

/** Sai da conta com segurança, mesmo se a chamada ao servidor falhar. */
export async function forceSignOut() {
  try {
    await supabase.auth.signOut({ scope: "local" });
  } catch (e) {
    console.error("[auth] signOut falhou, limpando localmente:", e);
  }
  hardClearSession();
}
