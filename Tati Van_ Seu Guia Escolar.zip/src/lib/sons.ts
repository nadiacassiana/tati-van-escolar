/**
 * Efeitos sonoros do app (buzina de boas-vindas e som de sucesso/pagamento).
 * Arquivos MP3 reais servidos localmente em /public/assets, sem síntese WebAudio.
 */

const STORAGE_KEY = "tati_sons_ativos";

export function sonsAtivos(): boolean {
  if (typeof localStorage === "undefined") return false;
  try {
    return localStorage.getItem(STORAGE_KEY) !== "0";
  } catch {
    return true;
  }
}

export function setSonsAtivos(v: boolean) {
  try {
    localStorage.setItem(STORAGE_KEY, v ? "1" : "0");
  } catch {
    /* ignore */
  }
}

export const SRC_BUZINA = "/assets/buzina.mp3";
export const SRC_CAIXA = "/assets/caixa.mp3";

const VOLUMES: Record<string, number> = {
  [SRC_BUZINA]: 0.5,
  [SRC_CAIXA]: 0.4, // caixa registradora: volume suave (40%)
};

function volumeDe(src: string): number {
  return VOLUMES[src] ?? 0.5;
}

const cache: Record<string, HTMLAudioElement> = {};

function getAudio(src: string): HTMLAudioElement | null {
  if (typeof window === "undefined") return null;
  let audio = cache[src];
  if (!audio) {
    audio = new Audio(src);
    audio.preload = "auto";
    audio.volume = volumeDe(src);
    try {
      audio.load();
    } catch {
      /* ignore */
    }
    cache[src] = audio;
  }
  return audio;
}

/** Pré-carrega os efeitos sonoros para execução instantânea. */
export function precarregarSons() {
  getAudio(SRC_BUZINA);
  getAudio(SRC_CAIXA);
}

/** Toca um MP3; se o navegador bloquear (autoplay), repete no primeiro toque/clique. */
function tocarMp3(src: string, esperarInteracao = false) {
  const audio = getAudio(src);
  if (!audio) return;
  try {
    audio.currentTime = 0;
  } catch {
    /* ignore */
  }
  audio.volume = volumeDe(src);
  const p = audio.play();
  if (p && typeof p.catch === "function") {
    p.catch(() => {
      if (!esperarInteracao) return;
      const handler = () => {
        limpar();
        if (!sonsAtivos()) return;
        try {
          audio.currentTime = 0;
        } catch {
          /* ignore */
        }
        void audio.play().catch(() => undefined);
      };
      const eventos: (keyof DocumentEventMap)[] = ["pointerdown", "touchstart", "keydown", "click"];
      const limpar = () => eventos.forEach((e) => document.removeEventListener(e, handler));
      eventos.forEach((e) => document.addEventListener(e, handler, { once: true, passive: true }));
    });
  }
}

/** "Bip-bip" de buzina de van — toca a cada acesso ao painel. */
export function tocarBoasVindas() {
  if (!sonsAtivos()) return;
  tocarMp3(SRC_BUZINA, true);
}

/** Som real de caixa registradora (sem fallback sintetizado). */
export function tocarSucesso() {
  if (!sonsAtivos()) return;
  tocarMp3(SRC_CAIXA);
}


/** Animação rápida de check verde no centro da tela. */
export function animarCheck() {
  if (typeof document === "undefined") return;
  const el = document.createElement("div");
  el.setAttribute("aria-hidden", "true");
  el.style.cssText =
    "position:fixed;inset:0;z-index:9998;display:flex;align-items:center;justify-content:center;pointer-events:none;";
  el.innerHTML = `
    <div style="width:104px;height:104px;border-radius:9999px;background:rgba(22,163,74,0.95);display:flex;align-items:center;justify-content:center;box-shadow:0 10px 30px rgba(0,0,0,.25);animation:tati-check-pop .55s ease-out forwards">
      <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
    </div>
    <style>@keyframes tati-check-pop{0%{transform:scale(.4);opacity:0}40%{transform:scale(1.08);opacity:1}100%{transform:scale(1);opacity:1}}</style>`;
  document.body.appendChild(el);
  setTimeout(() => {
    el.style.transition = "opacity .3s";
    el.style.opacity = "0";
    setTimeout(() => el.remove(), 320);
  }, 900);
}

/** Sucesso completo: check verde + som. */
export function feedbackSucesso() {
  animarCheck();
  tocarSucesso();
}
