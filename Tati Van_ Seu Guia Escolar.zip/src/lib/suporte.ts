// Ponto único de configuração do canal de suporte da Tati Assistente Virtual.
// Para mudar o telefone no futuro, altere APENAS este arquivo.

export const SUPORTE_WHATSAPP = "5511964600186";

export const SUPORTE_WHATSAPP_DISPLAY = "(11) 96460-0186";

export const SUPORTE_EMAIL = "tatiassistentevirtualbr@gmail.com";

export const SUPORTE_HORARIO = "Segunda a sexta, das 9h às 18h";

export function suporteWhatsAppLink(
  mensagem = "Olá, Tati Van Escolar! Preciso de ajuda com a plataforma.",
) {
  return `https://wa.me/${SUPORTE_WHATSAPP}?text=${encodeURIComponent(mensagem)}`;
}
