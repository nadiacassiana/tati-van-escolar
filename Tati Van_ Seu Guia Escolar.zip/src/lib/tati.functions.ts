import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { CONHECIMENTO, mesRef, TATI_EMAIL_TESTE, type Mensagem } from "@/lib/tati-conhecimento";

export const perguntarTati = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { mensagens: Mensagem[] }) => {
    if (!input?.mensagens?.length) throw new Error("Mensagem vazia");
    return { mensagens: input.mensagens.slice(-12) };
  })
  .handler(async ({ data, context }) => {
    const email = String((context.claims as { email?: string })?.email ?? "").toLowerCase();
    if (email !== TATI_EMAIL_TESTE) {
      return { erro: "Recurso em teste restrito.", resposta: "" };
    }

    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) return { erro: "IA não configurada.", resposta: "" };

    const sb = context.supabase;
    const hoje = new Date();
    const anoRef = `${hoje.getFullYear()}-01`;

    const [perfilRes, alunosRes, pagamentosRes] = await Promise.all([
      sb.from("profiles").select("nome, plan_status, subscription_status, next_due_date, trial_ends_at").eq("user_id", context.userId).maybeSingle(),
      sb.from("alunos").select("id, nome, mensalidade, vencimento, escola, turma, turno, arquivado_em").eq("user_id", context.userId).order("nome"),
      sb.from("pagamentos").select("aluno_id, mes_referencia, valor, data_pagamento").eq("user_id", context.userId).gte("mes_referencia", anoRef),
    ]);

    const alunos = (alunosRes.data ?? []).filter((a) => !a.arquivado_em);
    const pagos = new Set((pagamentosRes.data ?? []).map((p) => `${p.aluno_id}|${p.mes_referencia}`));
    const mesAtual = mesRef(hoje);

    const linhas = alunos.map((a) => {
      const pagouMes = pagos.has(`${a.id}|${mesAtual}`);
      return `- ${a.nome} | mensalidade R$ ${Number(a.mensalidade).toFixed(2)} | vence dia ${a.vencimento} | escola: ${a.escola || "-"} | turno: ${a.turno || "-"} | ${mesAtual}: ${pagouMes ? "PAGO" : "em aberto"}`;
    });

    const totalPrevisto = alunos.reduce((s, a) => s + Number(a.mensalidade || 0), 0);
    const recebidoMes = (pagamentosRes.data ?? [])
      .filter((p) => p.mes_referencia === mesAtual)
      .reduce((s, p) => s + Number(p.valor || 0), 0);

    const perfil = perfilRes.data as { nome?: string | null; plan_status?: string | null; next_due_date?: string | null } | null;

    const contexto = `DADOS DA CONTA (tempo real, ${hoje.toLocaleDateString("pt-BR")}):
Motorista: ${perfil?.nome || "não informado"}
Situação do plano: ${perfil?.plan_status || "-"}${perfil?.next_due_date ? ` | próximo vencimento: ${perfil.next_due_date}` : ""}
Mês de referência atual: ${mesAtual}
Alunos ativos: ${alunos.length}
Total previsto no mês: R$ ${totalPrevisto.toFixed(2)}
Total já recebido no mês: R$ ${recebidoMes.toFixed(2)}
Lista de alunos:
${linhas.join("\n") || "(nenhum aluno cadastrado)"}`;

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
          "Lovable-API-Key": apiKey,
          "X-Lovable-AIG-SDK": "fetch",
        },
        body: JSON.stringify({
          model: "google/gemini-3.7-flash",
          messages: [
            { role: "system", content: CONHECIMENTO },
            { role: "system", content: contexto },
            ...data.mensagens,
          ],
        }),
      });

      if (!res.ok) {
        const texto = await res.text();
        console.error("[tati] gateway", res.status, texto);
        if (res.status === 429) return { erro: "Muitas perguntas seguidas. Espere um pouquinho e tente de novo.", resposta: "" };
        if (res.status === 402) return { erro: "Os créditos de IA acabaram. Fale com o suporte.", resposta: "" };
        return { erro: "Não consegui responder agora. Tente novamente.", resposta: "" };
      }

      const json = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
      const resposta = json.choices?.[0]?.message?.content?.trim() ?? "";
      return { erro: "", resposta };
    } catch (e) {
      console.error("[tati] erro", e);
      return { erro: "Não consegui responder agora. Tente novamente.", resposta: "" };
    }
  });
