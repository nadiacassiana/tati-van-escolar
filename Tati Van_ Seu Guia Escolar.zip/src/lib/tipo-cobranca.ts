// Tipo de cobrança do aluno — define se ele gera mensalidades ou cobrança única anual.
export type TipoCobranca = "mensal" | "anual_vista" | "anual_parcelado";

/** Normaliza valores antigos ("anual" = contrato anual parcelado). */
export function normalizeTipoCobranca(v: unknown): TipoCobranca {
  if (v === "anual_vista") return "anual_vista";
  if (v === "anual_parcelado" || v === "anual") return "anual_parcelado";
  return "mensal";
}

export const TIPO_COBRANCA_LABEL: Record<TipoCobranca, string> = {
  mensal: "📆 Mensal",
  anual_vista: "🗓️ Plano anual — pagamento à vista",
  anual_parcelado: "🗓️ Plano anual — parcelado",
};

export const TIPO_COBRANCA_AJUDA: Record<TipoCobranca, string> = {
  mensal: "Cobrança mensal, como já funciona hoje.",
  anual_vista: "Cobrança única anual. Este aluno NÃO gera mensalidades — aparece apenas em “Planos anuais”.",
  anual_parcelado: "Contrato anual pago em mensalidades. Segue o fluxo normal de mensalidades, sem cobrança única.",
};

/** Alunos com plano anual à vista não entram no cálculo de mensalidades. */
export function geraMensalidades(v: unknown): boolean {
  return normalizeTipoCobranca(v) !== "anual_vista";
}
