import { supabase } from "@/integrations/supabase/client";

export type EventoTipo =
  | "login"
  | "rota_iniciada"
  | "link_compartilhado"
  | "whatsapp_enviado"
  | "checklist_usado"
  | "aluno_cadastrado"
  | "responsavel_cadastrado"
  | "contrato_gerado"
  | "recibo_emitido"
  | "garantia_recebida"
  | "plano_anual_criado"
  | "plano_anual_recebido"
  | "credito_aplicado"
  | "mensalidade_antecipada"
  | "rota_substituto_gerada"

  | "acesso_negado_admin";

/**
 * Fire-and-forget: registra um evento do usuário e atualiza ultimo_acesso.
 * Nunca lança erro — falhas de rastreamento não podem quebrar o app.
 */
export async function trackEvent(tipo: EventoTipo, descricao?: string, metadata?: Record<string, unknown>) {
  try {
    const { data } = await supabase.auth.getUser();
    const uid = data.user?.id;
    if (!uid) return;
    await Promise.allSettled([
      supabase.from("user_events" as never).insert({
        user_id: uid,
        tipo,
        descricao: descricao ?? null,
        metadata: metadata ?? null,
      } as never),
      supabase.from("profiles" as never).update({ ultimo_acesso: new Date().toISOString() } as never).eq("user_id", uid),
    ]);
  } catch {
    /* silencioso */
  }
}
