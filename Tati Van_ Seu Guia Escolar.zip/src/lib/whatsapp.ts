import { formatBRL } from "./format";
import { getVanLogo } from "./logo-store";

export type MotoristaPerfil = {
  nome_completo?: string;
  apelido?: string;
  empresa?: string;
  telefone?: string;
  whatsapp?: string;
  email?: string;
  pix?: string;
  banco?: string;
  /** Logotipo da van (data URL) — identidade visual da motorista nos documentos. */
  logo?: string;
};

export type VarContext = {
  responsavel?: string;
  aluno?: string;
  motorista?: string;
  mensalidade?: number;
  vencimento?: number | string;
  pix?: string;
  telefone?: string;
  escola?: string;
};

export function getMotoristaFromUser(user: { email?: string; user_metadata?: Record<string, unknown> } | null): MotoristaPerfil {
  const m = (user?.user_metadata || {}) as Record<string, string | undefined>;
  return {
    nome_completo: m.nome_completo,
    apelido: m.apelido,
    empresa: m.empresa,
    telefone: m.telefone || m.whatsapp,
    whatsapp: m.whatsapp || m.telefone,
    email: m.email_motorista || user?.email,
    pix: m.pix,
    banco: m.banco,
    // O logotipo vive na tabela de perfis (nunca em user_metadata, que iria para o JWT).
    logo: getVanLogo(),
  };
}

export function getDisplayName(motorista: MotoristaPerfil): string {
  const apelido = (motorista.apelido || "").trim();
  if (apelido) return apelido;
  const base = (motorista.nome_completo || "").trim();
  if (base) return base.split(/\s+/)[0];
  return "motorista";
}

export function getGreeting(date: Date = new Date()): string {
  const h = date.getHours();
  if (h < 12) return "Bom dia";
  if (h < 18) return "Boa tarde";
  return "Boa noite";
}

export function getNomeOficial(motorista: MotoristaPerfil): string {
  return (motorista.nome_completo || "").trim() || "motorista";
}

export function applyVariables(text: string, ctx: VarContext, motorista: MotoristaPerfil): string {
  const now = new Date();
  const data = now.toLocaleDateString("pt-BR");
  const hora = now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  const map: Record<string, string> = {
    responsavel: ctx.responsavel || "",
    aluno: ctx.aluno || "",
    motorista: ctx.motorista || motorista.apelido || motorista.nome_completo || "",
    nome_motorista: motorista.nome_completo || motorista.apelido || "",
    mensalidade: ctx.mensalidade != null ? `R$ ${formatBRL(ctx.mensalidade)}` : "",
    vencimento: ctx.vencimento != null ? String(ctx.vencimento) : "",
    pix: ctx.pix || motorista.pix || "",
    telefone: ctx.telefone || motorista.telefone || "",
    escola: ctx.escola || "",
    data,
    hora,
  };
  return text.replace(/\{(\w+)\}/g, (_, k) => map[k] ?? `{${k}}`);
}

// Normaliza um telefone brasileiro para o formato E.164 sem "+" exigido pelo WhatsApp.
// Aceita entrada com máscara ("(11) 98765-4321"), apenas dígitos ("11987654321")
// ou já com DDI ("5511987654321"). Nunca duplica o "55".
export function toWhatsAppE164(phone: string): string {
  const digits = (phone || "").replace(/\D/g, "");
  if (!digits) return "";
  // 10 dígitos (fixo) ou 11 (celular): adiciona DDI 55
  if (digits.length === 10 || digits.length === 11) return `55${digits}`;
  // Já vem com 55 + 10/11 dígitos
  if ((digits.length === 12 || digits.length === 13) && digits.startsWith("55")) return digits;
  // Fallback: se começar com 55 e tiver tamanho plausível, mantém; senão prefixa 55
  return digits.startsWith("55") ? digits : `55${digits}`;
}

export function buildWhatsAppUrl(phone: string, text: string): string {
  const full = toWhatsAppE164(phone);
  return `https://wa.me/${full}?text=${encodeURIComponent(text)}`;
}

export const VARIAVEIS_DISPONIVEIS = [
  { key: "{responsavel}", label: "Nome do responsável" },
  { key: "{aluno}", label: "Nome do aluno" },
  { key: "{motorista}", label: "Seu nome" },
  { key: "{nome_motorista}", label: "Nome do motorista" },
  { key: "{mensalidade}", label: "Valor da mensalidade" },
  { key: "{vencimento}", label: "Dia do vencimento" },
  { key: "{pix}", label: "Sua chave PIX" },
  { key: "{telefone}", label: "Seu telefone" },
  { key: "{escola}", label: "Escola do aluno" },
  { key: "{data}", label: "Data de hoje" },
  { key: "{hora}", label: "Hora atual" },
];

export type MensagemPadrao = { nome: string; emoji: string; texto: string; favorito?: boolean; categoria: string };

export const CATEGORIAS = [
  { id: "Transporte Diário", label: "🚐 Transporte Diário", emoji: "🚐" },
  { id: "Financeiro", label: "💰 Financeiro", emoji: "💰" },
  { id: "Escola", label: "🎓 Escola", emoji: "🎓" },
  { id: "Relacionamento", label: "❤️ Relacionamento", emoji: "❤️" },
  { id: "Emergências", label: "🚨 Emergências", emoji: "🚨" },
] as const;

export const PACOTES_MENSAGENS: Record<string, MensagemPadrao[]> = {
  "Transporte Diário": [
    { categoria: "Transporte Diário", nome: "Estou chegando para buscar", emoji: "🚐", texto: "Bom dia, {responsavel}! Estou chegando para buscar {aluno} 😊🚐", favorito: true },
    { categoria: "Transporte Diário", nome: "Aluno embarcou com segurança", emoji: "🏫", texto: "Olá {responsavel}, {aluno} já embarcou com segurança e está a caminho da escola. 💙", favorito: true },
    { categoria: "Transporte Diário", nome: "Estamos chegando em casa", emoji: "🏠", texto: "Olá {responsavel}, estamos chegando em casa com {aluno}. Por favor, já desça. 🙏" },
    { categoria: "Transporte Diário", nome: "Pequeno atraso hoje", emoji: "⏰", texto: "Bom dia, {responsavel}! Hoje teremos um pequeno atraso devido ao trânsito. Obrigado pela compreensão! 🙏" },
    { categoria: "Transporte Diário", nome: "Sem transporte hoje", emoji: "❌", texto: "Olá {responsavel}, hoje não haverá transporte. Combinaremos a reposição. Qualquer dúvida estou à disposição." },
  ],
  "Financeiro": [
    { categoria: "Financeiro", nome: "Lembrete de vencimento", emoji: "💰", texto: "Olá {responsavel}! Lembrete amigável: a mensalidade de {aluno} ({mensalidade}) vence dia {vencimento}. PIX: {pix} 💙" },
    { categoria: "Financeiro", nome: "Mensalidade em atraso", emoji: "⚠️", texto: "Olá {responsavel}, a mensalidade de {aluno} ({mensalidade}) está em atraso. Poderia regularizar quando possível? PIX: {pix} 🙏" },
    { categoria: "Financeiro", nome: "Cobrança cordial (Padrão)", emoji: "💙", texto: "Olá, {responsavel}! 😊\n\nEsperamos que esteja tudo bem com você.\n\nPassamos para lembrar que a mensalidade do transporte escolar de {aluno} está pendente.\n\nQuando puder, pedimos a gentileza de realizar a regularização.\n\nPIX: {pix}\n\nCaso o pagamento já tenha sido realizado, desconsidere esta mensagem.\n\nAgradecemos a atenção! 💙", favorito: true },
    { categoria: "Financeiro", nome: "Cobrança objetiva", emoji: "📌", texto: "Olá, {responsavel}!\n\nConsta em nosso controle uma pendência referente à mensalidade do transporte escolar de {aluno}.\n\nQuando possível, pedimos a gentileza de efetuar o pagamento.\n\nPIX: {pix}\n\nCaso o pagamento já tenha sido realizado, desconsidere esta mensagem.\n\nObrigado pela atenção!" },
    { categoria: "Financeiro", nome: "Cobrança acolhedora", emoji: "🤝", texto: "Olá, {responsavel}! 😊\n\nPassando para lembrar da mensalidade do transporte escolar de {aluno}.\n\nSabemos que imprevistos podem acontecer. Quando puder, pedimos a gentileza de verificar essa pendência.\n\nPIX: {pix}\n\nSe o pagamento já foi realizado, desconsidere esta mensagem.\n\nConte sempre conosco! 💙" },
    { categoria: "Financeiro", nome: "Pagamento recebido", emoji: "✅", texto: "Olá {responsavel}! Confirmo o recebimento da mensalidade de {aluno}. Muito obrigado! 💙" },
    { categoria: "Financeiro", nome: "Envio da chave PIX", emoji: "🔑", texto: "Olá {responsavel}, segue minha chave PIX: {pix}. Qualquer dúvida estou à disposição. 💙" },
    { categoria: "Financeiro", nome: "Agradecimento pelo pagamento", emoji: "🙏", texto: "Olá {responsavel}, agradeço pelo pagamento em dia da mensalidade de {aluno}. Conte sempre comigo! 💙" },
  ],
  "Escola": [
    { categoria: "Escola", nome: "Volta às aulas", emoji: "📚", texto: "Olá {responsavel}! Lembrete: as aulas retornam em {data}. {aluno} já está na rota. 📚🚐" },
    { categoria: "Escola", nome: "Mudança de horário", emoji: "🕐", texto: "Olá {responsavel}, informo que haverá mudança no horário de {aluno}. Por favor, confirme o recebimento. 🙏" },
    { categoria: "Escola", nome: "Passeio escolar", emoji: "🎒", texto: "Olá {responsavel}, {aluno} terá passeio escolar. Por favor, verifique o horário diferenciado com a escola. 💙" },
    { categoria: "Escola", nome: "Feriado", emoji: "🎉", texto: "Olá {responsavel}! Lembrete: amanhã é feriado, não haverá transporte. Bom descanso! ✨" },
    { categoria: "Escola", nome: "Comunicado importante", emoji: "📢", texto: "Olá {responsavel}, tenho um comunicado importante sobre o transporte de {aluno}. Por favor, leia com atenção. 🙏" },
  ],
  "Relacionamento": [
    { categoria: "Relacionamento", nome: "Boas-vindas às Famílias", emoji: "🚌", texto: "Olá, {responsavel}! 😊\n\nÉ uma alegria ter o(a) {aluno} conosco!\n\nPara oferecer um atendimento cada vez mais organizado, seguro e prático, passarei a utilizar um novo sistema de gestão do transporte escolar: Tati Van Escolar.\n\nA partir de agora, sempre que necessário, você poderá receber:\n\n🚌 Avisos importantes sobre o transporte escolar;\n\n📍 Compartilhamento da localização da van durante o trajeto;\n\n💰 Recibos de pagamento pelo WhatsApp;\n\n📄 Comunicados e lembretes importantes;\n\n📲 Mensagens rápidas para facilitar nossa comunicação.\n\nTudo isso foi pensado para proporcionar mais tranquilidade às famílias, melhorar nossa comunicação e oferecer ainda mais segurança durante o transporte escolar.\n\nSempre que precisar, estarei à disposição.\n\nMuito obrigada pela confiança!\n\nAtenciosamente,\n\n{nome_motorista} 🚌" },
    { categoria: "Relacionamento", nome: "Feliz aniversário", emoji: "🎂", texto: "Parabéns, {aluno}! 🎉🎂 Que seu dia seja repleto de alegrias! Um abraço da Tati Van." },
    { categoria: "Relacionamento", nome: "Boas férias", emoji: "🌴", texto: "Olá {responsavel}, desejo boas férias a {aluno} e toda a família! Até a volta! ☀️🌴" },
    { categoria: "Relacionamento", nome: "Feliz Natal", emoji: "🎄", texto: "Olá {responsavel}, desejo a vocês um Feliz Natal cheio de paz e amor! 🎄✨" },
    { categoria: "Relacionamento", nome: "Feliz Ano Novo", emoji: "🎆", texto: "Olá {responsavel}, desejo um Ano Novo repleto de saúde, paz e realizações! 🎆✨" },
    { categoria: "Relacionamento", nome: "Agradecimento pela confiança", emoji: "💙", texto: "Olá {responsavel}, obrigado pela confiança em transportar {aluno}. Conte sempre comigo! 💙" },
  ],
  "Emergências": [
    { categoria: "Emergências", nome: "Problema mecânico", emoji: "🔧", texto: "Olá {responsavel}, estamos com um problema mecânico. {aluno} está em segurança. Atualizo em breve. 🙏" },
    { categoria: "Emergências", nome: "Trânsito intenso", emoji: "🚦", texto: "Olá {responsavel}, trânsito muito intenso hoje. Vamos atrasar um pouco. Obrigado pela compreensão! 🙏" },
    { categoria: "Emergências", nome: "Alteração devido ao clima", emoji: "🌧️", texto: "Olá {responsavel}, devido ao mau tempo haverá alteração na rota de {aluno}. Aviso assim que normalizar. 💙" },
    { categoria: "Emergências", nome: "Aluno não compareceu", emoji: "❓", texto: "Olá {responsavel}, {aluno} não compareceu hoje no ponto. Está tudo bem? 🙏" },
    { categoria: "Emergências", nome: "Contato urgente", emoji: "🚨", texto: "Olá {responsavel}, preciso falar com você com urgência sobre {aluno}. Por favor, me ligue: {telefone}." },
  ],
};

export const MENSAGENS_PADRAO: MensagemPadrao[] = Object.values(PACOTES_MENSAGENS).flat();
