import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Gift, CreditCard, XCircle, Clock, TrendingUp, Calendar, Activity, Heart, Search, Shield, MessageCircle, MessageSquare, Mail, User as UserIcon, Copy, Trash2, MoreVertical, RotateCcw, CalendarPlus, CheckCircle2, Lock, Unlock, RefreshCw, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { computeAccountStatus } from "@/lib/account-status";
import { supabase } from "@/integrations/supabase/client";
import { useIsAdmin } from "@/hooks/use-is-admin";
import { FabricaCartoes } from "@/components/fabrica-cartoes";

import { whatsappLink } from "@/lib/phone-mask";
import { BarChart, Bar, XAxis, YAxis, Tooltip as RTooltip, ResponsiveContainer, LineChart, Line, Legend, CartesianGrid } from "recharts";
import { useServerFn } from "@tanstack/react-start";
import { adminExtendTrial, adminResetTrial, adminConvertToSubscriber, adminSetBlocked, adminDeleteUser, adminMarkManualPayment, adminSyncAsaasDueDates, adminGiveCourtesy } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Painel Administrativo — Tati" }, { name: "robots", content: "noindex" }] }),
  component: AdminPage,
});

const TRIAL_DAYS = 10;

type Profile = {
  user_id: string;
  nome: string | null;
  cidade: string | null;
  estado: string | null;
  whatsapp: string | null;
  whatsapp_consent: boolean | null;
  email: string | null;
  plan_status: string;
  assinante_desde: string | null;
  cancelado_em: string | null;
  ultimo_acesso: string | null;
  created_at: string;
  trial_started_at: string | null;
  trial_days_bonus: number | null;
  blocked_at: string | null;
  asaas_subscription_id: string | null;
  asaas_next_due_date: string | null;
  subscription_status: string | null;
  trial_ends_at: string | null;
  payment_method: string | null;
  next_due_date: string | null;
};

type UserEvent = {
  id: string;
  user_id: string;
  tipo: string;
  descricao: string | null;
  created_at: string;
};

type LinhaUsuario = Profile & {
  alunos: number;
  responsaveis: number;
  contratos: number;
  recibos: number;
  rotas: number;
  diasRestantes: number;
  /** Possui assinatura ativa (Asaas ou pagamento manual registrado) */
  assinante: boolean;

  statusLabel: string;
  statusClass: string;
  situacaoLabel: string;
  situacaoClass: string;
  proximoVencimento: string | null;
  vencimentoLabel: string;
  vencimentoClass: string;
};

function diasEntre(a: Date, b: Date) {
  return Math.floor((b.getTime() - a.getTime()) / (1000 * 60 * 60 * 24));
}

function formatData(iso: string | null) {
  if (!iso) return "—";
  const isDateOnly = iso.length <= 10 && !iso.includes("T");
  const d = isDateOnly ? new Date(`${iso}T00:00:00`) : new Date(iso);
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });
}
function formatHora(iso: string) {
  return new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}
function formatDataHora(iso: string) {
  return new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

function diasAteData(iso: string | null): number | null {
  if (!iso) return null;
  const alvo = new Date(iso);
  alvo.setHours(0, 0, 0, 0);
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  return Math.ceil((alvo.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
}

function classeVencimento(iso: string | null): string {
  const dias = diasAteData(iso);
  if (dias === null) return "text-muted-foreground";
  if (dias < 0) return "text-destructive font-medium";
  if (dias <= 5) return "text-warning font-medium";
  return "text-muted-foreground";
}

function calcularTrialEndsAt(p: Profile): string | null {
  if (p.trial_ends_at) return p.trial_ends_at;
  // Contas antigas não gravavam trial_started_at: o teste começa no cadastro.
  const inicio = p.trial_started_at || p.created_at;
  if (!inicio) return null;
  const base = new Date(inicio);
  const bonus = Number(p.trial_days_bonus || 0);
  base.setUTCDate(base.getUTCDate() + TRIAL_DAYS + bonus);
  return base.toISOString();
}

const tipoLabels: Record<string, string> = {
  login: "entrou no sistema",
  rota_iniciada: "iniciou uma rota",
  link_compartilhado: "compartilhou o link de rastreamento",
  whatsapp_enviado: "enviou mensagem pelo WhatsApp",
  checklist_usado: "abriu o checklist",
  aluno_cadastrado: "cadastrou um aluno",
  responsavel_cadastrado: "cadastrou um responsável",
  contrato_gerado: "gerou um contrato",
  recibo_emitido: "emitiu um recibo",
  acesso_negado_admin: "⚠️ tentou acessar o painel admin sem permissão",
};

const MOTIVO_LABELS: Record<string, string> = {
  preco: "Preço da assinatura",
  funcionalidades: "Faltavam funcionalidades",
  dificuldade: "Difícil de utilizar",
  parou_atividade: "Parou o transporte escolar",
  outro_sistema: "Foi para outro sistema",
  problemas_tecnicos: "Problemas técnicos",
  outro: "Outro motivo",
};

type DeletedAccount = {
  id: string;
  user_id: string;
  nome: string | null;
  email: string | null;
  cidade: string | null;
  estado: string | null;
  cadastro_em: string | null;
  excluido_em: string;
  dias_permanencia: number | null;
  status_no_momento: string | null;
  motivo: string | null;
  motivo_texto: string | null;
};

const STATUS_EXCLUSAO_LABEL: Record<string, string> = {
  trial: "Teste gratuito",
  ativo: "Assinante",
  cancelado: "Cancelado",
};

type RetentionSurvey = {
  id: string;
  user_id: string;
  motivos: string[];
  comentario: string | null;
  created_at: string;
};

type Feedback = {
  id: string;
  user_id: string;
  mensagem: string;
  created_at: string;
};

const RETENTION_MOTIVO_LABELS: Record<string, string> = {
  facilidade_uso: "Facilidade de uso",
  organizacao_alunos: "Organização dos alunos",
  controle_financeiro: "Controle financeiro",
  contratos: "Contratos",
  recibos: "Recibos",
  checklist_diario: "Checklist diário",
  rastreamento_rota: "Rastreamento da rota",
  compartilhamento_responsaveis: "Compartilhamento com responsáveis",
  controle_documentos: "Controle de documentos",
  economia_tempo: "Economia de tempo",
  atendimento_suporte: "Atendimento e suporte",
  outro: "Outro motivo",
};

function AdminPage() {
  const navigate = useNavigate();
  const isAdmin = useIsAdmin();
  const [loading, setLoading] = useState(true);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  /** Primeira cobrança em aberto no Asaas por usuária (nunca calculada manualmente). */
  const [asaasDue, setAsaasDue] = useState<Record<string, string | null>>({});

  const [eventos, setEventos] = useState<UserEvent[]>([]);
  const [counts, setCounts] = useState<Record<string, { alunos: number; responsaveis: number; contratos: number; recibos: number; rotas: number }>>({});
  const [totais, setTotais] = useState({ alunos: 0, responsaveis: 0, contratos: 0, recibos: 0, escolas: 0, rotas: 0, links: 0 });
  const [busca, setBusca] = useState("");
  const [perfilAberto, setPerfilAberto] = useState<LinhaUsuario | null>(null);
  const [excluidos, setExcluidos] = useState<DeletedAccount[]>([]);
  const [retencaoSurveys, setRetencaoSurveys] = useState<RetentionSurvey[]>([]);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [periodoRet, setPeriodoRet] = useState<"7" | "30" | "90" | "all">("all");
  const [buscaExcl, setBuscaExcl] = useState("");
  const [periodoExcl, setPeriodoExcl] = useState<"7" | "30" | "90" | "all">("all");

  // Ações administrativas
  const extendFn = useServerFn(adminExtendTrial);
  const resetFn = useServerFn(adminResetTrial);
  const convertFn = useServerFn(adminConvertToSubscriber);
  const manualPayFn = useServerFn(adminMarkManualPayment);
  const blockFn = useServerFn(adminSetBlocked);
  const deleteFn = useServerFn(adminDeleteUser);
  const cortesiaFn = useServerFn(adminGiveCourtesy);
  const [acaoBusy, setAcaoBusy] = useState(false);
  const [extendAlvo, setExtendAlvo] = useState<LinhaUsuario | null>(null);
  const [extendDias, setExtendDias] = useState<string>("7");
  const [convertAlvo, setConvertAlvo] = useState<LinhaUsuario | null>(null);
  const [convertData, setConvertData] = useState<string>("");
  const [convertCpf, setConvertCpf] = useState<string>("");
  const [convertPessoa, setConvertPessoa] = useState<"PF" | "PJ">("PF");
  const [convertManual, setConvertManual] = useState(false);
  const [confirmar, setConfirmar] = useState<{
    tipo: "reset" | "block" | "unblock" | "delete" | "cortesia";
    alvo: LinhaUsuario;
  } | null>(null);

  // Timeline / auditoria
  const [tlBusca, setTlBusca] = useState("");
  const [tlTipo, setTlTipo] = useState<string>("all");
  const [tlPeriodo, setTlPeriodo] = useState<"today" | "7" | "30" | "custom">("30");
  const [tlDesde, setTlDesde] = useState<string>("");
  const [tlAte, setTlAte] = useState<string>("");
  const [tlEventos, setTlEventos] = useState<UserEvent[]>([]);
  const [tlLoading, setTlLoading] = useState(false);
  const [tlOffset, setTlOffset] = useState(0);
  const [tlFim, setTlFim] = useState(false);
  const TL_PAGE = 100;

  const copiar = async (valor: string, label: string) => {
    try {
      await navigator.clipboard.writeText(valor);
      toast.success(`${label} copiado!`);
    } catch {
      toast.error("Não foi possível copiar.");
    }
  };
  const abrirWhatsApp = (p: { whatsapp: string | null; nome: string | null }) => {
    if (!p.whatsapp) return toast.error("Motorista não cadastrou WhatsApp.");
    const nome = (p.nome || "").split(" ")[0] || "";
    const texto = `Olá${nome ? ` ${nome}` : ""}! Aqui é da Tati Assistente Virtual.`;
    window.open(whatsappLink(p.whatsapp, texto), "_blank", "noopener,noreferrer");
  };
  const abrirEmail = (p: { email: string | null }) => {
    if (!p.email) return toast.error("Motorista sem e-mail cadastrado.");
    window.location.href = `mailto:${p.email}`;
  };

  useEffect(() => {
    if (isAdmin === false) {
      // Log da tentativa de acesso não autorizado (frontend); RLS impede leitura no backend.
      supabase.auth.getUser().then(({ data }) => {
        if (data.user) {
          supabase.from("user_events" as never).insert({
            user_id: data.user.id,
            tipo: "acesso_negado_admin",
            descricao: `tentou acessar /admin sem papel admin (${data.user.email ?? "sem e-mail"})`,
          } as never);
        }
      });
      navigate({ to: "/dashboard", replace: true });
    }
  }, [isAdmin, navigate]);

  const carregarTudo = useCallback(async () => {
    setLoading(true);
    const [pRes, eRes, alRes, rpRes, ctRes, rcRes, rtRes, dxRes, rsRes, fbRes] = await Promise.all([
      supabase.from("profiles" as never).select("*"),
      supabase.from("user_events" as never).select("*").gte("created_at", new Date(Date.now() - 30 * 86400e3).toISOString()).order("created_at", { ascending: false }).limit(2000),
      supabase.from("alunos").select("user_id, escola"),
      supabase.from("responsaveis").select("user_id"),
      supabase.from("contratos").select("user_id"),
      supabase.from("recibos").select("user_id"),
      supabase.from("rotas_ativas").select("user_id"),
      supabase.from("deleted_accounts" as never).select("*").order("excluido_em", { ascending: false }).limit(500),
      supabase.from("retention_surveys" as never).select("*").order("created_at", { ascending: false }).limit(1000),
      supabase.from("feedbacks" as never).select("*").order("created_at", { ascending: false }).limit(1000),
    ]);
    const acc: Record<string, { alunos: number; responsaveis: number; contratos: number; recibos: number; rotas: number }> = {};
    const bump = (uid: string | null | undefined, key: keyof typeof acc[string]) => {
      if (!uid) return;
      acc[uid] = acc[uid] || { alunos: 0, responsaveis: 0, contratos: 0, recibos: 0, rotas: 0 };
      acc[uid][key]++;
    };
    const alunosData = (alRes.data ?? []) as { user_id: string | null; escola: string | null }[];
    alunosData.forEach((r) => bump(r.user_id, "alunos"));
    (rpRes.data ?? []).forEach((r: { user_id: string | null }) => bump(r.user_id, "responsaveis"));
    (ctRes.data ?? []).forEach((r: { user_id: string | null }) => bump(r.user_id, "contratos"));
    (rcRes.data ?? []).forEach((r: { user_id: string | null }) => bump(r.user_id, "recibos"));
    (rtRes.data ?? []).forEach((r: { user_id: string | null }) => bump(r.user_id, "rotas"));
    const escolasSet = new Set(alunosData.map((r) => (r.escola || "").trim().toLowerCase()).filter(Boolean));
    const eventosData = ((eRes.data ?? []) as unknown) as UserEvent[];
    const linksCriados = eventosData.filter((e) => e.tipo === "link_compartilhado").length;
    setTotais({
      alunos: alunosData.length,
      responsaveis: (rpRes.data ?? []).length,
      contratos: (ctRes.data ?? []).length,
      recibos: (rcRes.data ?? []).length,
      escolas: escolasSet.size,
      rotas: (rtRes.data ?? []).length,
      links: linksCriados,
    });
    setCounts(acc);
    setProfiles(((pRes.data ?? []) as unknown) as Profile[]);
    setEventos(eventosData);
    setExcluidos(((dxRes.data ?? []) as unknown) as DeletedAccount[]);
    setRetencaoSurveys(((rsRes.data ?? []) as unknown) as RetentionSurvey[]);
    setFeedbacks(((fbRes.data ?? []) as unknown) as Feedback[]);
    setLoading(false);

    // Próxima cobrança sempre vinda do Asaas (primeira fatura em aberto).
    // Nunca calcular a data manualmente.
    try {
      const r = await adminSyncAsaasDueDates({ data: {} } as never);
      setAsaasDue((r as { due_dates?: Record<string, string | null> }).due_dates ?? {});
    } catch (e) {
      console.warn("[admin] falha ao sincronizar próximas cobranças:", e);
    }
  }, []);

  useEffect(() => {
    if (!isAdmin) return;
    carregarTudo();
  }, [isAdmin, carregarTudo]);

  // Rola até a seção de sugestões quando acessado via /admin#sugestoes
  useEffect(() => {
    if (loading || window.location.hash !== "#sugestoes") return;
    const t = setTimeout(() => {
      document.getElementById("sugestoes")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 300);
    return () => clearTimeout(t);
  }, [loading]);



  // ==== Ações administrativas por usuária ====
  async function runAcao(exec: () => Promise<unknown>, sucesso: string) {
    setAcaoBusy(true);
    try {
      await exec();
      if (sucesso) toast.success(sucesso);
      await carregarTudo();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Falha na operação.");
    } finally {
      setAcaoBusy(false);
    }
  }

  function confirmarExecutar() {
    if (!confirmar) return;
    const { tipo, alvo } = confirmar;
    setConfirmar(null);
    if (tipo === "reset") {
      runAcao(() => resetFn({ data: { user_id: alvo.user_id } }), "Trial reiniciado.");
    } else if (tipo === "block") {
      runAcao(() => blockFn({ data: { user_id: alvo.user_id, blocked: true } }), "Conta bloqueada.");
    } else if (tipo === "unblock") {
      runAcao(() => blockFn({ data: { user_id: alvo.user_id, blocked: false } }), "Conta desbloqueada.");
    } else if (tipo === "delete") {
      runAcao(() => deleteFn({ data: { user_id: alvo.user_id } }), "Conta excluída.");
    } else if (tipo === "cortesia") {
      runAcao(
        async () => {
          const res = await cortesiaFn({ data: { user_id: alvo.user_id } });
          const dataBR = String(res.next_due_date).split("-").reverse().join("/");
          toast.success(`Acesso de cortesia concedido com sucesso até ${dataBR}!`);
        },
        "",
      );
    }
  }

  function abrirConverter(l: LinhaUsuario) {
    // Padrão: primeira cobrança 10 dias à frente (fim do trial).
    const d = new Date();
    d.setDate(d.getDate() + 10);
    setConvertData(d.toISOString().slice(0, 10));
    setConvertCpf("");
    setConvertPessoa("PF");
    setConvertManual(false);
    setConvertAlvo(l);
  }

  function converterConfirmar() {
    if (!convertAlvo) return;
    const alvo = convertAlvo;
    if (convertManual) {
      const payload = { user_id: alvo.user_id, next_due_date: convertData };
      setConvertAlvo(null);
      runAcao(
        () => manualPayFn({ data: payload }),
        `Pagamento manual registrado. Próximo vencimento em ${convertData.split("-").reverse().join("/")}.`,
      );
      return;
    }
    const payload = {
      user_id: alvo.user_id,
      next_due_date: convertData,
      cpf_cnpj: convertCpf.replace(/\D/g, ""),
      person_type: convertPessoa,
    };
    setConvertAlvo(null);
    runAcao(
      () => convertFn({ data: payload }),
      "Convertida em assinante e assinatura criada no Asaas.",
    );
  }

  function estenderConfirmar() {
    if (!extendAlvo) return;
    const dias = Math.max(1, Math.min(365, Math.floor(Number(extendDias) || 0)));
    const alvo = extendAlvo;
    setExtendAlvo(null);
    runAcao(
      () => extendFn({ data: { user_id: alvo.user_id, days: dias } }),
      `Trial estendido em ${dias} dia(s).`,
    );
  }

  // ==== Timeline completa (auditoria) ====
  const carregarTimeline = useCallback(async (reset: boolean) => {
    if (!isAdmin) return;
    setTlLoading(true);
    const offset = reset ? 0 : tlOffset;
    let q = supabase.from("user_events" as never).select("*").order("created_at", { ascending: false });
    if (tlTipo !== "all") q = q.eq("tipo", tlTipo);
    let desdeIso: string | null = null;
    let ateIso: string | null = null;
    const hojeIni = new Date(); hojeIni.setHours(0, 0, 0, 0);
    if (tlPeriodo === "today") desdeIso = hojeIni.toISOString();
    else if (tlPeriodo === "7") desdeIso = new Date(Date.now() - 7 * 86400e3).toISOString();
    else if (tlPeriodo === "30") desdeIso = new Date(Date.now() - 30 * 86400e3).toISOString();
    else if (tlPeriodo === "custom") {
      if (tlDesde) desdeIso = new Date(tlDesde + "T00:00:00").toISOString();
      if (tlAte) ateIso = new Date(tlAte + "T23:59:59").toISOString();
    }
    if (desdeIso) q = q.gte("created_at", desdeIso);
    if (ateIso) q = q.lte("created_at", ateIso);
    // Filtro por usuário: se busca é nome, resolve a lista de user_ids
    const termo = tlBusca.trim().toLowerCase();
    if (termo) {
      const ids = profiles.filter((p) => (p.nome || "").toLowerCase().includes(termo)
        || (p.email || "").toLowerCase().includes(termo)).map((p) => p.user_id);
      if (ids.length === 0) {
        setTlEventos([]); setTlFim(true); setTlLoading(false); return;
      }
      q = q.in("user_id", ids);
    }
    const { data, error } = await q.range(offset, offset + TL_PAGE - 1);
    if (error) {
      toast.error(error.message);
      setTlLoading(false);
      return;
    }
    const novos = ((data ?? []) as unknown) as UserEvent[];
    setTlEventos(reset ? novos : [...tlEventos, ...novos]);
    setTlOffset(offset + novos.length);
    setTlFim(novos.length < TL_PAGE);
    setTlLoading(false);
  }, [isAdmin, tlOffset, tlTipo, tlPeriodo, tlDesde, tlAte, tlBusca, profiles, tlEventos]);

  // Reset ao mudar filtros
  useEffect(() => {
    if (!isAdmin) return;
    setTlOffset(0);
    setTlFim(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    carregarTimeline(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin, tlTipo, tlPeriodo, tlDesde, tlAte, tlBusca, profiles.length]);


  const linhas: LinhaUsuario[] = useMemo(() => {
    const agora = new Date();
    return profiles.map((p) => {
      const c = counts[p.user_id] || { alunos: 0, responsaveis: 0, contratos: 0, recibos: 0, rotas: 0 };
      const trialBase = new Date(p.trial_started_at || p.created_at);
      const bonus = Number(p.trial_days_bonus || 0);
      const diasUso = diasEntre(trialBase, agora);
      const restantes = Math.max(0, TRIAL_DAYS + bonus - diasUso);

      // Assinatura confirmada: plano ativo, assinatura no Asaas ou pagamento manual registrado.
      // A partir daqui nenhuma informação de teste deve ser exibida.
      const assinante =
        p.plan_status === "ativo" ||
        !!p.asaas_subscription_id ||
        p.payment_method === "MANUAL";

      let statusLabel = "Teste";
      let statusClass = "bg-accent/40 text-accent-foreground border-accent";
      if (p.blocked_at) {
        statusLabel = "Bloqueado";
        statusClass = "bg-destructive/15 text-destructive border-destructive/30";
      } else if (assinante && p.payment_method === "CORTESIA") {
        statusLabel = "Ativo (Cortesia)";
        statusClass = "bg-accent/40 text-accent-foreground border-accent";
      } else if (assinante) {
        statusLabel = "Assinante";
        statusClass = "bg-success/15 text-success border-success/30";
      } else if (p.plan_status === "cancelado") {
        statusLabel = "Cancelado";
        statusClass = "bg-destructive/15 text-destructive border-destructive/30";
      } else if (restantes === 0) {
        statusLabel = "Teste vencido";
        statusClass = "bg-destructive/15 text-destructive border-destructive/30";
      }

      let proximoVencimento: string | null = null;
      let vencimentoLabel = "—";
      if (assinante) {
        // Assinatura no Asaas: usar sempre a primeira cobrança em aberto retornada pela API.
        // Nunca calcular a data manualmente.
        proximoVencimento = p.asaas_subscription_id
          ? (asaasDue[p.user_id] ?? p.asaas_next_due_date ?? p.next_due_date ?? null)
          : (p.next_due_date ?? null);
        vencimentoLabel = proximoVencimento ? "Próx. cobrança" : "—";

      } else if (p.plan_status === "cancelado") {
        vencimentoLabel = "Cancelado";
      } else if (restantes === 0) {
        vencimentoLabel = "Teste vencido";
      } else {
        const trialEnds = calcularTrialEndsAt(p);
        if (trialEnds) {
          proximoVencimento = trialEnds;
          vencimentoLabel = "Fim do teste";
        }
      }
      const vencimentoClass = classeVencimento(proximoVencimento);

      // Situação do fluxo automático (mesma lógica aplicada na área do motorista)
      const acc = computeAccountStatus(p as never, agora);
      let situacaoLabel = "Assinante ativo";
      let situacaoClass = "bg-success/15 text-success border-success/30";
      if (p.blocked_at) {
        situacaoLabel = "Bloqueado";
        situacaoClass = "bg-destructive/15 text-destructive border-destructive/30";
      } else if (assinante) {
        if (acc.phase === "mensalidade_vencida") {
          situacaoLabel = `Mensalidade vencida (${acc.graceDaysLeft === 0 ? "último dia" : `${acc.graceDaysLeft} dia${acc.graceDaysLeft > 1 ? "s" : ""}`})`;
          situacaoClass = "bg-warning/15 text-warning border-warning/30";
        } else if (acc.phase === "inadimplente") {
          situacaoLabel = "Pausada por inadimplência";
          situacaoClass = "bg-destructive/15 text-destructive border-destructive/30";
        } else {
          situacaoLabel = "Assinante ativo";
          situacaoClass = "bg-success/15 text-success border-success/30";
        }

      } else if (acc.phase === "trial") {
        situacaoLabel = "Teste ativo";
        situacaoClass = "bg-accent/40 text-accent-foreground border-accent";
      } else if (acc.phase === "tolerancia") {
        situacaoLabel = `Tolerância (${acc.graceDaysLeft === 0 ? "último dia" : `${acc.graceDaysLeft} dia${acc.graceDaysLeft > 1 ? "s" : ""}`})`;
        situacaoClass = "bg-warning/15 text-warning border-warning/30";
      } else if (acc.phase === "pausada") {
        situacaoLabel = "Conta pausada";
        situacaoClass = "bg-destructive/15 text-destructive border-destructive/30";
      }

      return { ...p, ...c, diasRestantes: restantes, assinante, statusLabel, statusClass, situacaoLabel, situacaoClass, proximoVencimento, vencimentoLabel, vencimentoClass };

    });
  }, [profiles, counts, asaasDue]);

  const linhasFiltradas = useMemo(() => {
    const q = busca.trim().toLowerCase();
    if (!q) return linhas;
    return linhas.filter((l) => (l.nome || "").toLowerCase().includes(q));
  }, [linhas, busca]);

  const stats = useMemo(() => {
    const total = linhas.length;
    const trial = linhas.filter((l) => !l.assinante && l.plan_status !== "cancelado" && l.diasRestantes > 0).length;
    const ativos = linhas.filter((l) => l.assinante).length;
    const cancelados = linhas.filter((l) => !l.assinante && l.plan_status === "cancelado").length;
    const vencemHoje = linhas.filter((l) => !l.assinante && l.plan_status !== "cancelado" && l.diasRestantes === 0).length;

    const agora = Date.now();
    const em7 = linhas.filter((l) => agora - new Date(l.created_at).getTime() < 7 * 86400e3).length;
    const em30 = linhas.filter((l) => agora - new Date(l.created_at).getTime() < 30 * 86400e3).length;
    return { total, trial, ativos, cancelados, vencemHoje, em7, em30 };
  }, [linhas]);

  const nomePorUser = useMemo(() => {
    const m = new Map<string, string>();
    profiles.forEach((p) => m.set(p.user_id, p.nome || "Usuária"));
    return m;
  }, [profiles]);

  const emailPorUser = useMemo(() => {
    const m = new Map<string, string>();
    profiles.forEach((p) => {
      if (p.email) m.set(p.user_id, p.email);
    });
    return m;
  }, [profiles]);

  const uso = useMemo(() => {
    const inicioHoje = new Date(); inicioHoje.setHours(0, 0, 0, 0);
    const inicioSemana = new Date(Date.now() - 7 * 86400e3);
    const usersHoje = new Set<string>();
    const usersSemana = new Set<string>();
    const rotasHoje = new Set<string>();
    const linksHoje = new Set<string>();
    const checklistHoje = new Set<string>();
    const whatsHoje = new Set<string>();
    eventos.forEach((e) => {
      const t = new Date(e.created_at);
      if (t >= inicioSemana) usersSemana.add(e.user_id);
      if (t >= inicioHoje) {
        usersHoje.add(e.user_id);
        if (e.tipo === "rota_iniciada") rotasHoje.add(e.user_id);
        if (e.tipo === "link_compartilhado") linksHoje.add(e.user_id);
        if (e.tipo === "checklist_usado") checklistHoje.add(e.user_id);
        if (e.tipo === "whatsapp_enviado") whatsHoje.add(e.user_id);
      }
    });
    return { usersHoje: usersHoje.size, usersSemana: usersSemana.size, rotasHoje: rotasHoje.size, linksHoje: linksHoje.size, checklistHoje: checklistHoje.size, whatsHoje: whatsHoje.size };
  }, [eventos]);

  const feedHoje = useMemo(() => {
    const inicioHoje = new Date(); inicioHoje.setHours(0, 0, 0, 0);
    return eventos.filter((e) => new Date(e.created_at) >= inicioHoje).slice(0, 30);
  }, [eventos]);

  const alertas = useMemo(() => {
    const b = { hoje: [] as LinhaUsuario[], amanha: [] as LinhaUsuario[], em3: [] as LinhaUsuario[], em7: [] as LinhaUsuario[] };
    // Assinantes nunca aparecem nos alertas de teste.
    linhas.filter((l) => !l.assinante && l.plan_status !== "cancelado" && !l.blocked_at).forEach((l) => {

      if (l.diasRestantes === 0) b.hoje.push(l);
      else if (l.diasRestantes === 1) b.amanha.push(l);
      else if (l.diasRestantes <= 3) b.em3.push(l);
      else if (l.diasRestantes <= 7) b.em7.push(l);
    });
    return b;
  }, [linhas]);

  const conversao = useMemo(() => {
    const iniciados = linhas.length;
    const convertidos = linhas.filter((l) => l.assinante).length;
    const taxa = iniciados === 0 ? 0 : Math.round((convertidos / iniciados) * 100);
    return { iniciados, convertidos, taxa };
  }, [linhas]);

  const retencao = useMemo(() => {
    const agora = Date.now();
    // Base 7d: usuárias com >= 7 dias de conta; retidas = com evento após o dia 7 (mesmo depois de expirar)
    const base7 = linhas.filter((l) => agora - new Date(l.created_at).getTime() >= 7 * 86400e3);
    const base30 = linhas.filter((l) => agora - new Date(l.created_at).getTime() >= 30 * 86400e3);
    const ativosPorUser = new Map<string, Date>();
    eventos.forEach((e) => {
      const t = new Date(e.created_at);
      const cur = ativosPorUser.get(e.user_id);
      if (!cur || t > cur) ativosPorUser.set(e.user_id, t);
    });
    const retidos7 = base7.filter((l) => {
      const last = ativosPorUser.get(l.user_id);
      return last && last.getTime() - new Date(l.created_at).getTime() >= 7 * 86400e3;
    }).length;
    const retidos30 = base30.filter((l) => {
      const last = ativosPorUser.get(l.user_id);
      return last && last.getTime() - new Date(l.created_at).getTime() >= 30 * 86400e3;
    }).length;
    // Abandono no teste: trial com >= 3 dias sem atividade nos últimos 3 dias
    const abandonados = linhas.filter((l) => {
      if (l.assinante || l.plan_status === "cancelado") return false;
      const last = ativosPorUser.get(l.user_id);
      if (!last) return true;
      return agora - last.getTime() > 3 * 86400e3;
    }).length;
    const taxa7 = base7.length ? Math.round((retidos7 / base7.length) * 100) : 0;
    const taxa30 = base30.length ? Math.round((retidos30 / base30.length) * 100) : 0;
    return { base7: base7.length, retidos7, taxa7, base30: base30.length, retidos30, taxa30, abandonados };
  }, [linhas, eventos]);

  

  // Estatísticas de contas excluídas
  const exclStats = useMemo(() => {
    const agora = Date.now();
    const em7 = excluidos.filter((d) => agora - new Date(d.excluido_em).getTime() < 7 * 86400e3).length;
    const em30 = excluidos.filter((d) => agora - new Date(d.excluido_em).getTime() < 30 * 86400e3).length;
    const totalUsers = linhas.length + excluidos.length;
    const perc = totalUsers === 0 ? 0 : Math.round((excluidos.length / totalUsers) * 100);
    return { total: excluidos.length, em7, em30, perc };
  }, [excluidos, linhas.length]);

  // Filtro de exclusões (busca + período)
  const excluidosFiltrados = useMemo(() => {
    const q = buscaExcl.trim().toLowerCase();
    const cutoff = periodoExcl === "all" ? 0 : Date.now() - Number(periodoExcl) * 86400e3;
    return excluidos.filter((d) => {
      if (cutoff && new Date(d.excluido_em).getTime() < cutoff) return false;
      if (q && !(d.nome || "").toLowerCase().includes(q)) return false;
      return true;
    });
  }, [excluidos, buscaExcl, periodoExcl]);

  // Motivos de exclusão (gráfico)
  const motivosChart = useMemo(() => {
    const map: Record<string, number> = {};
    excluidos.forEach((d) => {
      const k = d.motivo || "nao_informado";
      map[k] = (map[k] || 0) + 1;
    });
    return Object.entries(map).map(([k, v]) => ({
      motivo: k === "nao_informado" ? "Não informado" : MOTIVO_LABELS[k] || k,
      total: v,
    })).sort((a, b) => b.total - a.total);
  }, [excluidos]);

  // Evolução mensal: cadastros vs exclusões (últimos 6 meses)
  const mensalChart = useMemo(() => {
    const meses: { key: string; label: string; cadastros: number; exclusoes: number }[] = [];
    const hoje = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(hoje.getFullYear(), hoje.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      meses.push({ key, label: d.toLocaleDateString("pt-BR", { month: "short" }), cadastros: 0, exclusoes: 0 });
    }
    const bucket = (iso: string) => {
      const d = new Date(iso);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    };
    profiles.forEach((p) => {
      const k = bucket(p.created_at);
      const m = meses.find((x) => x.key === k);
      if (m) m.cadastros++;
    });
    excluidos.forEach((d) => {
      const k = bucket(d.excluido_em);
      const m = meses.find((x) => x.key === k);
      if (m) m.exclusoes++;
      // Conta também no mês de cadastro original
      if (d.cadastro_em) {
        const kc = bucket(d.cadastro_em);
        const mc = meses.find((x) => x.key === kc);
        if (mc) mc.cadastros++;
      }
    });
    return meses;
  }, [profiles, excluidos]);

  // Pesquisa de retenção: filtrar por período e agregar motivos
  const retencaoFiltrada = useMemo(() => {
    const cutoff = periodoRet === "all" ? 0 : Date.now() - Number(periodoRet) * 86400e3;
    return retencaoSurveys.filter((r) => !cutoff || new Date(r.created_at).getTime() >= cutoff);
  }, [retencaoSurveys, periodoRet]);

  const retencaoRanking = useMemo(() => {
    const map: Record<string, number> = {};
    retencaoFiltrada.forEach((r) => {
      (r.motivos || []).forEach((m) => { map[m] = (map[m] || 0) + 1; });
    });
    const total = retencaoFiltrada.length;
    return Object.entries(map)
      .map(([k, v]) => ({
        chave: k,
        motivo: RETENTION_MOTIVO_LABELS[k] || k,
        total: v,
        perc: total ? Math.round((v / total) * 100) : 0,
      }))
      .sort((a, b) => b.total - a.total);
  }, [retencaoFiltrada]);

  const retencaoComentarios = useMemo(
    () => retencaoFiltrada.filter((r) => (r.comentario || "").trim()),
    [retencaoFiltrada],
  );


  if (isAdmin === null || (isAdmin && loading)) {
    return <div className="p-8 text-sm text-muted-foreground">Carregando painel...</div>;
  }
  if (!isAdmin) return null;

  return (
    <div className="mx-auto max-w-7xl space-y-6 p-2">
      <div className="flex items-center gap-2">
        <Shield className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-extrabold">Painel Administrativo</h1>
          <p className="text-sm text-muted-foreground">Visão geral da Tati Van Escolar 💙</p>
        </div>
      </div>

      {/* Atalhos rápidos */}
      <div className="flex flex-wrap gap-2">
        <a
          href="#fabrica-cartoes"
          className="inline-flex items-center gap-1.5 rounded-full border bg-accent px-3 py-1.5 text-xs font-bold text-accent-foreground shadow-sm transition hover:opacity-90"
        >
          <Sparkles className="h-3.5 w-3.5" /> Fábrica de Cartões de Venda
        </a>
        <a
          href="#sugestoes"
          className="inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold text-muted-foreground transition hover:bg-muted"
        >
          <MessageSquare className="h-3.5 w-3.5" /> Sugestões &amp; Feedbacks
        </a>
      </div>

      {/* Cards principais */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={<Users className="h-4 w-4" />} label="Total de usuárias" value={stats.total} tone="primary" />
        <StatCard icon={<Gift className="h-4 w-4" />} label="Em teste grátis" value={stats.trial} tone="accent" />
        <StatCard icon={<CreditCard className="h-4 w-4" />} label="Assinaturas ativas" value={stats.ativos} tone="success" />
        <StatCard icon={<XCircle className="h-4 w-4" />} label="Assinaturas canceladas" value={stats.cancelados} tone="destructive" />
        <StatCard icon={<Clock className="h-4 w-4" />} label="Testes vencendo hoje" value={stats.vencemHoje} tone="warning" />
        <StatCard icon={<TrendingUp className="h-4 w-4" />} label="Novos em 7 dias" value={stats.em7} tone="primary" />
        <StatCard icon={<Calendar className="h-4 w-4" />} label="Novos em 30 dias" value={stats.em30} tone="primary" />
        <StatCard icon={<Heart className="h-4 w-4 text-destructive" />} label="Ativas hoje" value={uso.usersHoje} tone="accent" />
        <StatCard icon={<Trash2 className="h-4 w-4" />} label="Contas excluídas" value={exclStats.total} tone="destructive" />
      </div>

      {/* Ativas hoje - feed */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold"><Heart className="h-4 w-4 text-destructive" /> Usuárias ativas hoje ({uso.usersHoje})</div>
        {feedHoje.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">Ninguém registrou atividade hoje ainda.</p>
        ) : (
          <ul className="mt-3 space-y-1.5 text-sm">
            {feedHoje.map((e) => (
              <li key={e.id} className="flex items-baseline gap-2">
                <span className="text-xs text-muted-foreground tabular-nums">{formatHora(e.created_at)}</span>
                <span><strong>{nomePorUser.get(e.user_id) || "Usuária"}</strong> {tipoLabels[e.tipo] || e.tipo}</span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* Estatísticas gerais da plataforma */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold"><Activity className="h-4 w-4" /> Estatísticas gerais</div>
        <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7 text-sm">
          <MiniStat label="Alunos" value={totais.alunos} />
          <MiniStat label="Responsáveis" value={totais.responsaveis} />
          <MiniStat label="Contratos" value={totais.contratos} />
          <MiniStat label="Recibos" value={totais.recibos} />
          <MiniStat label="Escolas" value={totais.escolas} />
          <MiniStat label="Rotas" value={totais.rotas} />
          <MiniStat label="Links criados" value={totais.links} />
        </div>
      </Card>

      {/* Retenção */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold"><TrendingUp className="h-4 w-4" /> Taxa de retenção</div>
        <div className="mt-3 grid gap-3 sm:grid-cols-3 text-sm">
          <MiniStat label={`Após 7 dias (${retencao.retidos7}/${retencao.base7})`} value={`${retencao.taxa7}%`} />
          <MiniStat label={`Após 30 dias (${retencao.retidos30}/${retencao.base30})`} value={`${retencao.taxa30}%`} />
          <MiniStat label="Abandonaram o teste" value={retencao.abandonados} />
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">Considera "retida" a usuária que registrou atividade após o 7º ou 30º dia de conta. "Abandonou" = está em teste e sem atividade nos últimos 3 dias.</p>
      </Card>


      {/* Uso e conversão */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center gap-2 font-bold"><Activity className="h-4 w-4" /> Uso da plataforma</div>
          <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
            <MiniStat label="Acessaram hoje" value={uso.usersHoje} />
            <MiniStat label="Acessaram na semana" value={uso.usersSemana} />
            <MiniStat label="Iniciaram rota hoje" value={uso.rotasHoje} />
            <MiniStat label="Compartilharam link" value={uso.linksHoje} />
            <MiniStat label="Usaram checklist" value={uso.checklistHoje} />
            <MiniStat label="Enviaram WhatsApp" value={uso.whatsHoje} />
          </div>
        </Card>

        <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center gap-2 font-bold"><TrendingUp className="h-4 w-4" /> Conversão</div>
          <div className="mt-3 grid grid-cols-3 gap-3 text-sm">
            <MiniStat label="Testes iniciados" value={conversao.iniciados} />
            <MiniStat label="Convertidos" value={conversao.convertidos} />
            <MiniStat label="Taxa" value={`${conversao.taxa}%`} />
          </div>
        </Card>
      </div>

      {/* Alertas */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold"><Clock className="h-4 w-4" /> Testes prestes a vencer</div>
        <div className="mt-3 grid gap-4 md:grid-cols-4">
          <AlertaCol titulo="Vence hoje" cor="text-destructive" lista={alertas.hoje} />
          <AlertaCol titulo="Vence amanhã" cor="text-warning-foreground" lista={alertas.amanha} />
          <AlertaCol titulo="Em até 3 dias" cor="text-warning-foreground" lista={alertas.em3} />
          <AlertaCol titulo="Em até 7 dias" cor="text-muted-foreground" lista={alertas.em7} />
        </div>
      </Card>

      {/* Lista de usuárias */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="font-bold">Usuárias cadastradas ({linhasFiltradas.length})</div>
          <div className="relative w-full max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Pesquisar por nome..." className="pl-9" />
          </div>
        </div>
        <div className="mt-3 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Ações</TableHead>
                <TableHead>WhatsApp</TableHead>
                <TableHead>Cidade / UF</TableHead>
                <TableHead>Cadastro</TableHead>
                <TableHead>Trial</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Situação</TableHead>
                <TableHead>Próximo vencimento</TableHead>
                <TableHead>Último acesso</TableHead>
                <TableHead className="text-right">Alunos</TableHead>
                <TableHead className="text-right">Resp.</TableHead>
                <TableHead className="text-right">Contratos</TableHead>
                <TableHead className="text-right">Recibos</TableHead>
                <TableHead className="text-right">Rotas</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {linhasFiltradas.map((l) => (
                <TableRow key={l.user_id}>
                  <TableCell className="font-medium">{l.nome || "—"}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        title={l.whatsapp ? `Abrir conversa no WhatsApp (${l.whatsapp})` : "WhatsApp não cadastrado"}
                        onClick={() => abrirWhatsApp(l)}
                        disabled={!l.whatsapp}
                        className="h-8 w-8 text-success"
                      >
                        <MessageCircle className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        title={l.email ? `Enviar e-mail (${l.email})` : "Sem e-mail"}
                        onClick={() => abrirEmail(l)}
                        disabled={!l.email}
                        className="h-8 w-8 text-primary"
                      >
                        <Mail className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        title="Ver perfil completo"
                        onClick={() => setPerfilAberto(l)}
                        className="h-8 w-8"
                      >
                        <UserIcon className="h-4 w-4" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button size="icon" variant="ghost" className="h-8 w-8" title="Mais ações" disabled={acaoBusy}>
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-56">
                          <DropdownMenuLabel>Gerenciar trial</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => { setExtendAlvo(l); setExtendDias("7"); }}>
                            <CalendarPlus className="mr-2 h-4 w-4" /> Estender período de teste
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setConfirmar({ tipo: "reset", alvo: l })}>
                            <RotateCcw className="mr-2 h-4 w-4" /> Reiniciar trial
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => abrirConverter(l)}
                            disabled={l.assinante}
                          >
                            <CheckCircle2 className="mr-2 h-4 w-4" /> Converter em assinante
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuLabel>Conta</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => setConfirmar({ tipo: "cortesia", alvo: l })}>
                            <Gift className="mr-2 h-4 w-4" /> 🎁 Dar Cortesia (+30 dias)
                          </DropdownMenuItem>
                          {l.blocked_at ? (
                            <DropdownMenuItem onClick={() => setConfirmar({ tipo: "unblock", alvo: l })}>
                              <Unlock className="mr-2 h-4 w-4" /> Desbloquear conta
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem onClick={() => setConfirmar({ tipo: "block", alvo: l })}>
                              <Lock className="mr-2 h-4 w-4" /> Bloquear conta
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem
                            onClick={() => setConfirmar({ tipo: "delete", alvo: l })}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" /> Excluir conta
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                  <TableCell className="text-xs">
                    {l.whatsapp ? (
                      <div className="flex items-center gap-1">
                        <span className="tabular-nums">{l.whatsapp}</span>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-6 w-6"
                          title="Copiar número"
                          onClick={() => copiar(l.whatsapp!, "WhatsApp")}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                        {l.whatsapp_consent ? (
                          <Badge variant="outline" className="ml-1 border-success/40 text-success text-[10px] px-1 py-0">LGPD ✓</Badge>
                        ) : (
                          <Badge variant="outline" className="ml-1 border-muted-foreground/30 text-muted-foreground text-[10px] px-1 py-0">sem consent.</Badge>
                        )}
                      </div>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-xs">{l.cidade ? `${l.cidade}${l.estado ? ` / ${l.estado}` : ""}` : "—"}</TableCell>
                  <TableCell className="text-xs">{formatData(l.created_at)}</TableCell>
                  <TableCell className="text-xs">{l.diasRestantes} dias</TableCell>
                  <TableCell><Badge variant="outline" className={l.statusClass}>{l.statusLabel}</Badge></TableCell>
                  <TableCell><Badge variant="outline" className={l.situacaoClass}>{l.situacaoLabel}</Badge></TableCell>
                  <TableCell className="text-xs">
                    {l.proximoVencimento ? (
                      <div className="flex flex-col">
                        <span className={l.vencimentoClass}>{formatData(l.proximoVencimento)}</span>
                        <span className="text-[10px] text-muted-foreground">{l.vencimentoLabel}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground">{l.vencimentoLabel}</span>
                    )}
                  </TableCell>
                  <TableCell className="text-xs">{formatData(l.ultimo_acesso)}</TableCell>
                  <TableCell className="text-right tabular-nums">{l.alunos}</TableCell>
                  <TableCell className="text-right tabular-nums">{l.responsaveis}</TableCell>
                  <TableCell className="text-right tabular-nums">{l.contratos}</TableCell>
                  <TableCell className="text-right tabular-nums">{l.recibos}</TableCell>
                  <TableCell className="text-right tabular-nums">{l.rotas}</TableCell>
                </TableRow>
              ))}
              {linhasFiltradas.length === 0 && (
                <TableRow><TableCell colSpan={14} className="text-center text-sm text-muted-foreground py-6">Nenhuma usuária encontrada.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Contas excluídas */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold"><Trash2 className="h-4 w-4 text-destructive" /> Contas excluídas</div>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4 text-sm">
          <MiniStat label="Total" value={exclStats.total} />
          <MiniStat label="Últimos 7 dias" value={exclStats.em7} />
          <MiniStat label="Últimos 30 dias" value={exclStats.em30} />
          <MiniStat label="% do total cadastrado" value={`${exclStats.perc}%`} />
        </div>

        {excluidos.length > 0 && (
          <div className="mt-5 grid gap-4 lg:grid-cols-2">
            <div className="rounded-lg border p-3">
              <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2">Principais motivos</div>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={motivosChart} layout="vertical" margin={{ left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" allowDecimals={false} />
                  <YAxis type="category" dataKey="motivo" width={140} tick={{ fontSize: 11 }} />
                  <RTooltip />
                  <Bar dataKey="total" fill="hsl(var(--destructive))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="rounded-lg border p-3">
              <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2">Cadastros × exclusões (6 meses)</div>
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={mensalChart}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="label" />
                  <YAxis allowDecimals={false} />
                  <RTooltip />
                  <Legend />
                  <Line type="monotone" dataKey="cadastros" stroke="hsl(var(--primary))" name="Cadastros" />
                  <Line type="monotone" dataKey="exclusoes" stroke="hsl(var(--destructive))" name="Exclusões" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        <div className="mt-5 flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={buscaExcl} onChange={(e) => setBuscaExcl(e.target.value)} placeholder="Pesquisar por nome..." className="pl-9" />
          </div>
          <div className="flex gap-1">
            {(["7", "30", "90", "all"] as const).map((p) => (
              <Button key={p} size="sm" variant={periodoExcl === p ? "default" : "outline"} onClick={() => setPeriodoExcl(p)}>
                {p === "all" ? "Tudo" : `${p}d`}
              </Button>
            ))}
          </div>
          <span className="text-xs text-muted-foreground ml-auto">{excluidosFiltrados.length} resultado(s)</span>
        </div>

        <div className="mt-3 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Cidade / UF</TableHead>
                <TableHead>Cadastro</TableHead>
                <TableHead>Exclusão</TableHead>
                <TableHead className="text-right">Permanência</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Motivo</TableHead>
                <TableHead>Comentário</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {excluidosFiltrados.map((d) => (
                <TableRow key={d.id}>
                  <TableCell className="font-medium">{d.nome || "—"}</TableCell>
                  <TableCell className="text-xs">{d.cidade ? `${d.cidade}${d.estado ? ` / ${d.estado}` : ""}` : "—"}</TableCell>
                  <TableCell className="text-xs">{formatData(d.cadastro_em)}</TableCell>
                  <TableCell className="text-xs">{formatData(d.excluido_em)}</TableCell>
                  <TableCell className="text-right text-xs tabular-nums">{d.dias_permanencia ?? "—"} d</TableCell>
                  <TableCell className="text-xs">{d.status_no_momento ? (STATUS_EXCLUSAO_LABEL[d.status_no_momento] || d.status_no_momento) : "—"}</TableCell>
                  <TableCell className="text-xs">{d.motivo ? (MOTIVO_LABELS[d.motivo] || d.motivo) : <span className="text-muted-foreground">não informado</span>}</TableCell>
                  <TableCell className="text-xs max-w-[240px] truncate" title={d.motivo_texto || ""}>{d.motivo_texto || "—"}</TableCell>
                </TableRow>
              ))}
              {excluidosFiltrados.length === 0 && (
                <TableRow><TableCell colSpan={8} className="text-center text-sm text-muted-foreground py-6">Nenhuma exclusão registrada no período.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">Estas informações são usadas exclusivamente para análise interna e melhoria contínua da plataforma.</p>
      </Card>

      {/* Motivos de permanência */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-bold">
            <Heart className="h-4 w-4 text-destructive" /> Motivos pelos quais os usuários permanecem na plataforma
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">{retencaoFiltrada.length} resposta(s)</span>
            <div className="flex gap-1">
              {(["7", "30", "90", "all"] as const).map((p) => (
                <Button key={p} size="sm" variant={periodoRet === p ? "default" : "outline"} onClick={() => setPeriodoRet(p)}>
                  {p === "all" ? "Tudo" : `${p}d`}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {retencaoFiltrada.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">Nenhuma resposta recebida no período.</p>
        ) : (
          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <div className="rounded-lg border p-3">
              <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2">Ranking dos motivos</div>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={retencaoRanking} layout="vertical" margin={{ left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" allowDecimals={false} />
                  <YAxis type="category" dataKey="motivo" width={160} tick={{ fontSize: 11 }} />
                  <RTooltip formatter={(v: number) => [`${v} respostas`, "Total"]} />
                  <Bar dataKey="total" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="rounded-lg border p-3">
              <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2">Percentual por motivo</div>
              <ul className="space-y-2">
                {retencaoRanking.map((m) => (
                  <li key={m.chave}>
                    <div className="flex items-center justify-between text-sm">
                      <span className="truncate pr-2">{m.motivo}</span>
                      <span className="tabular-nums text-muted-foreground">{m.total} • {m.perc}%</span>
                    </div>
                    <div className="mt-1 h-2 rounded bg-muted overflow-hidden">
                      <div className="h-full bg-primary" style={{ width: `${m.perc}%` }} />
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {retencaoComentarios.length > 0 && (
          <div className="mt-5">
            <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground mb-2">
              Comentários e sugestões ({retencaoComentarios.length})
            </div>
            <ul className="max-h-72 space-y-2 overflow-y-auto">
              {retencaoComentarios.map((r) => (
                <li key={r.id} className="rounded-lg border p-3 text-sm">
                  <div className="mb-1 flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
                    <span className="font-medium">{nomePorUser.get(r.user_id) || "Usuária"}</span>
                    <span>{formatData(r.created_at)}</span>
                  </div>
                  <p className="whitespace-pre-wrap">{r.comentario}</p>
                </li>
              ))}
            </ul>
          </div>
        )}
        <p className="mt-3 text-[11px] text-muted-foreground">
          Estas respostas são utilizadas exclusivamente para melhorar a plataforma e entender o
          comportamento dos usuários.
        </p>
      </Card>

      {/* Fábrica de Cartões de Venda */}
      <div id="fabrica-cartoes" className="scroll-mt-20">
        <FabricaCartoes />
      </div>



      {/* Sugestões & Feedbacks — enviadas direto pelo app */}
      <Card id="sugestoes" className="scroll-mt-20 p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-bold">
            <MessageSquare className="h-4 w-4" /> Sugestões &amp; Feedbacks
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">{feedbacks.length} recebida(s)</span>
            <Button variant="outline" size="sm" onClick={() => void carregarTudo()}>
              <RefreshCw className="mr-1 h-3.5 w-3.5" /> Atualizar
            </Button>
          </div>
        </div>
        {feedbacks.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">Nenhuma sugestão recebida ainda.</p>
        ) : (
          <ul className="mt-4 max-h-96 space-y-2 overflow-y-auto">
            {feedbacks.map((f) => (
              <li key={f.id} className="rounded-lg border p-3 text-sm">
                <div className="mb-1 flex flex-wrap items-center justify-between gap-x-2 gap-y-0.5 text-[11px] text-muted-foreground">
                  <span className="font-medium text-foreground">
                    {nomePorUser.get(f.user_id) || "Usuária"}
                    {emailPorUser.get(f.user_id) && (
                      <span className="ml-1.5 font-normal text-muted-foreground">
                        ({emailPorUser.get(f.user_id)})
                      </span>
                    )}
                  </span>
                  <span>{formatDataHora(f.created_at)}</span>
                </div>
                <p className="whitespace-pre-wrap">{f.mensagem}</p>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* Auditoria — linha do tempo completa e paginada */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 font-bold">
            <Activity className="h-4 w-4" /> Histórico completo de atividades
          </div>
          <span className="text-xs text-muted-foreground">{tlEventos.length} evento(s){tlFim ? " • fim" : ""}</span>
        </div>

        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={tlBusca}
              onChange={(e) => setTlBusca(e.target.value)}
              placeholder="Buscar por nome ou e-mail..."
              className="pl-9"
            />
          </div>
          <Select value={tlTipo} onValueChange={setTlTipo}>
            <SelectTrigger><SelectValue placeholder="Tipo de atividade" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as atividades</SelectItem>
              {Object.entries(tipoLabels).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={tlPeriodo} onValueChange={(v) => setTlPeriodo(v as typeof tlPeriodo)}>
            <SelectTrigger><SelectValue placeholder="Período" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Hoje</SelectItem>
              <SelectItem value="7">Últimos 7 dias</SelectItem>
              <SelectItem value="30">Último mês</SelectItem>
              <SelectItem value="custom">Personalizado</SelectItem>
            </SelectContent>
          </Select>
          {tlPeriodo === "custom" ? (
            <div className="flex items-center gap-1">
              <Input type="date" value={tlDesde} onChange={(e) => setTlDesde(e.target.value)} className="text-xs" />
              <Input type="date" value={tlAte} onChange={(e) => setTlAte(e.target.value)} className="text-xs" />
            </div>
          ) : (
            <Button variant="outline" onClick={() => { setTlBusca(""); setTlTipo("all"); setTlPeriodo("30"); }}>
              Limpar filtros
            </Button>
          )}
        </div>

        {tlLoading && tlEventos.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">Carregando...</p>
        ) : tlEventos.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">Nenhuma atividade encontrada com os filtros aplicados.</p>
        ) : (
          <>
            <ul className="mt-4 max-h-[500px] space-y-1.5 overflow-y-auto text-sm">
              {tlEventos.map((e) => (
                <li key={e.id} className={`flex items-baseline gap-2 ${e.tipo === "acesso_negado_admin" ? "text-destructive" : ""}`}>
                  <span className="text-xs text-muted-foreground tabular-nums shrink-0">{formatDataHora(e.created_at)}</span>
                  <span><strong>{nomePorUser.get(e.user_id) || "Usuária"}</strong> {tipoLabels[e.tipo] || e.tipo}</span>
                </li>
              ))}
            </ul>
            <div className="mt-3 flex justify-center">
              <Button
                variant="outline"
                size="sm"
                disabled={tlLoading || tlFim}
                onClick={() => carregarTimeline(false)}
              >
                {tlLoading ? "Carregando..." : tlFim ? "Todos os registros carregados" : "Carregar mais"}
              </Button>
            </div>
          </>
        )}
        <p className="mt-2 text-[11px] text-muted-foreground">
          Ferramenta de auditoria — consulte qualquer atividade antiga sem perder registros quando novas ações acontecerem.
        </p>
      </Card>

      {/* Dialog: estender trial */}
      <Dialog open={extendAlvo !== null} onOpenChange={(o) => { if (!o) setExtendAlvo(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Estender período de teste</DialogTitle>
            <DialogDescription>
              {extendAlvo ? `Adicionar dias ao trial de ${extendAlvo.nome || "usuário"}.` : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Dias a adicionar</label>
            <Input
              type="number"
              min={1}
              max={365}
              value={extendDias}
              onChange={(e) => setExtendDias(e.target.value)}
            />
            <div className="flex flex-wrap gap-1">
              {[3, 7, 15, 30].map((n) => (
                <Button key={n} size="sm" variant="outline" onClick={() => setExtendDias(String(n))}>
                  +{n} dias
                </Button>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setExtendAlvo(null)}>Cancelar</Button>
            <Button onClick={estenderConfirmar} disabled={acaoBusy}>Estender</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog: confirmação genérica */}
      <Dialog open={confirmar !== null} onOpenChange={(o) => { if (!o) setConfirmar(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>
              {confirmar?.tipo === "reset" && "Reiniciar trial?"}
              {confirmar?.tipo === "block" && "Bloquear conta?"}
              {confirmar?.tipo === "unblock" && "Desbloquear conta?"}
              {confirmar?.tipo === "delete" && "Excluir conta definitivamente?"}
              {confirmar?.tipo === "cortesia" && "Conceder cortesia para este assinante?"}
            </DialogTitle>
            <DialogDescription>
              {confirmar ? (
                <>
                  Usuário: <strong>{confirmar.alvo.nome || confirmar.alvo.email || confirmar.alvo.user_id}</strong>.
                  {confirmar.tipo === "reset" && " O trial será reiniciado para hoje e o status voltará para teste."}
                  {confirmar.tipo === "block" && " O usuário não conseguirá acessar o sistema até ser desbloqueado."}
                  {confirmar.tipo === "unblock" && " O usuário voltará a poder acessar o sistema."}
                  {confirmar.tipo === "delete" && " Esta ação é irreversível — todos os dados serão apagados."}
                  {confirmar.tipo === "cortesia" && " O acesso será liberado imediatamente por +30 dias a partir de hoje, sem gerar ou alterar cobranças no Asaas."}
                </>
              ) : null}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmar(null)}>Cancelar</Button>
            <Button
              variant={confirmar?.tipo === "delete" || confirmar?.tipo === "block" ? "destructive" : "default"}
              onClick={confirmarExecutar}
              disabled={acaoBusy}
            >
              Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog: converter em assinante (com data da 1ª cobrança) */}
      <Dialog open={convertAlvo !== null} onOpenChange={(o) => { if (!o) setConvertAlvo(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4" /> Converter em assinante
            </DialogTitle>
            <DialogDescription>
              {convertAlvo ? (
                <>Usuário: <strong>{convertAlvo.nome || convertAlvo.email || convertAlvo.user_id}</strong>.</>
              ) : null}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div className="rounded-md border bg-muted/40 p-3">
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Plano</div>
              <div className="mt-1">Tati Van Escolar · <strong>R$ 29,90/mês</strong> · Ciclo mensal</div>
              <div className="text-xs text-muted-foreground mt-1">Formas de pagamento: PIX, Boleto ou Cartão (escolhidas pela cliente na fatura Asaas).</div>
            </div>

            <label className="flex items-start gap-2 rounded-md border p-3 cursor-pointer hover:bg-muted/40">
              <input
                type="checkbox"
                className="mt-0.5 h-4 w-4 accent-primary"
                checked={convertManual}
                onChange={(e) => setConvertManual(e.target.checked)}
              />
              <div className="text-sm">
                <div className="font-medium">Pagamento manual recebido</div>
                <div className="text-[11px] text-muted-foreground mt-0.5">
                  Marque quando a cliente já pagou por fora (PIX direto, dinheiro etc.). Nada será criado
                  no Asaas agora — apenas registramos internamente o próximo vencimento. Quando essa data
                  chegar, a cliente verá o botão <strong>Pagar</strong> na área dela e informará os dados
                  do Asaas naquele momento.
                </div>
              </div>
            </label>

            <div className="space-y-1">
              <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                {convertManual ? "Próximo vencimento" : "Data da primeira cobrança"}{" "}
                <span className="text-destructive">*</span>
              </label>
              <Input
                type="date"
                value={convertData}
                min={new Date().toISOString().slice(0, 10)}
                onChange={(e) => setConvertData(e.target.value)}
              />
              <p className="text-[11px] text-muted-foreground">
                {convertManual
                  ? "A cliente verá essa data como próximo vencimento. Nenhuma cobrança será gerada no Asaas até que ela clique em Pagar."
                  : "Essa data será usada para criar a assinatura no Asaas. Nenhuma cobrança anterior será gerada; as próximas serão automáticas a cada mês."}
              </p>
            </div>

            {!convertManual && (!convertAlvo || !(convertAlvo as unknown as { asaas_customer_id?: string }).asaas_customer_id) ? (
              <div className="space-y-2 rounded-md border p-3">
                <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Dados para criar a cliente no Asaas
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant={convertPessoa === "PF" ? "default" : "outline"}
                    onClick={() => setConvertPessoa("PF")}
                  >
                    Pessoa Física
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={convertPessoa === "PJ" ? "default" : "outline"}
                    onClick={() => setConvertPessoa("PJ")}
                  >
                    Pessoa Jurídica
                  </Button>
                </div>
                <Input
                  inputMode="numeric"
                  placeholder={convertPessoa === "PF" ? "CPF (somente números)" : "CNPJ (somente números)"}
                  value={convertCpf}
                  onChange={(e) => setConvertCpf(e.target.value.replace(/\D/g, ""))}
                  maxLength={14}
                />
                <p className="text-[11px] text-muted-foreground">
                  Obrigatório apenas se a cliente ainda não estiver cadastrada no Asaas.
                </p>
              </div>
            ) : null}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConvertAlvo(null)}>Cancelar</Button>
            <Button
              onClick={converterConfirmar}
              disabled={acaoBusy || !convertData}
            >
              {convertManual ? "Registrar pagamento manual" : "Confirmar conversão"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>



      <Dialog open={perfilAberto !== null} onOpenChange={(o) => { if (!o) setPerfilAberto(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><UserIcon className="h-4 w-4" /> Perfil do motorista</DialogTitle>
          </DialogHeader>
          {perfilAberto && (
            <div className="space-y-3 text-sm">
              <PerfilLinha label="Nome" valor={perfilAberto.nome || "—"} />
              <PerfilLinha label="E-mail" valor={perfilAberto.email || "—"} onCopy={perfilAberto.email ? () => copiar(perfilAberto.email!, "E-mail") : undefined} />
              <PerfilLinha label="WhatsApp" valor={perfilAberto.whatsapp || "—"} onCopy={perfilAberto.whatsapp ? () => copiar(perfilAberto.whatsapp!, "WhatsApp") : undefined} />
              <PerfilLinha label="Consentimento WhatsApp (LGPD)" valor={perfilAberto.whatsapp_consent ? "Autorizado ✅" : "Não autorizado"} />
              <PerfilLinha label="Cidade / UF" valor={perfilAberto.cidade ? `${perfilAberto.cidade}${perfilAberto.estado ? ` / ${perfilAberto.estado}` : ""}` : "—"} />
              <PerfilLinha label="Cadastro" valor={formatData(perfilAberto.created_at)} />
              <PerfilLinha label="Trial restante" valor={`${perfilAberto.diasRestantes} dias`} />
              <PerfilLinha label="Status" valor={perfilAberto.statusLabel} />
              <PerfilLinha label="Situação" valor={perfilAberto.situacaoLabel} />
              <PerfilLinha label="Último acesso" valor={formatData(perfilAberto.ultimo_acesso)} />
              <div className="grid grid-cols-2 gap-2 pt-2">
                <Button
                  variant="outline"
                  onClick={() => abrirWhatsApp(perfilAberto)}
                  disabled={!perfilAberto.whatsapp}
                  className="text-success"
                >
                  <MessageCircle className="mr-1 h-4 w-4" /> WhatsApp
                </Button>
                <Button
                  variant="outline"
                  onClick={() => abrirEmail(perfilAberto)}
                  disabled={!perfilAberto.email}
                >
                  <Mail className="mr-1 h-4 w-4" /> E-mail
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PerfilLinha({ label, valor, onCopy }: { label: string; valor: string; onCopy?: () => void }) {
  return (
    <div className="flex items-start justify-between gap-2 border-b pb-2 last:border-0">
      <div>
        <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="font-medium">{valor}</div>
      </div>
      {onCopy && (
        <Button size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={onCopy} title="Copiar">
          <Copy className="h-3 w-3" />
        </Button>
      )}
    </div>
  );
}

function StatCard({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number; tone: "primary" | "accent" | "success" | "destructive" | "warning" }) {
  const toneMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    accent: "bg-accent/30 text-accent-foreground",
    success: "bg-success/10 text-success",
    destructive: "bg-destructive/10 text-destructive",
    warning: "bg-warning/20 text-warning-foreground",
  };
  return (
    <Card className="p-4" style={{ boxShadow: "var(--shadow-card)" }}>
      <div className={`inline-flex h-8 w-8 items-center justify-center rounded-lg ${toneMap[tone]}`}>{icon}</div>
      <div className="mt-2 text-2xl font-extrabold tabular-nums">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </Card>
  );
}

function MiniStat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-lg border p-3">
      <div className="text-lg font-extrabold tabular-nums">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}

function AlertaCol({ titulo, cor, lista }: { titulo: string; cor: string; lista: LinhaUsuario[] }) {
  return (
    <div>
      <div className={`text-xs font-bold uppercase tracking-wide ${cor}`}>{titulo} ({lista.length})</div>
      {lista.length === 0 ? (
        <p className="mt-1 text-xs text-muted-foreground">Ninguém</p>
      ) : (
        <ul className="mt-1 space-y-0.5 text-sm">
          {lista.slice(0, 8).map((l) => (
            <li key={l.user_id} className="truncate">{l.nome || "Usuária"}</li>
          ))}
        </ul>
      )}
    </div>
  );
}
