import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/agenda")({
  head: () => ({ meta: [{ title: "Agenda — Tati Van" }] }),
  component: AgendaPage,
});

type Item = { id: string; nome: string; vencimento: string };

function AgendaPage() {
  const [itens, setItens] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("documentos").select("id, nome, vencimento").not("vencimento", "is", null).order("vencimento");
      setItens(((data as unknown) as Item[]) || []);
      setLoading(false);
    })();
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">Agenda 📅</h1>
        <p className="text-sm text-muted-foreground">Vencimentos dos seus documentos da van.</p>
      </div>

      <Card className="overflow-hidden" style={{ boxShadow: "var(--shadow-card)" }}>
        {loading ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : itens.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">
            Cadastre documentos com data de vencimento para vê-los aqui.
          </div>
        ) : (
          <ul className="divide-y">
            {itens.map((a) => {
              const d = new Date(a.vencimento + "T00:00:00");
              const dias = Math.ceil((d.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
              const tag = dias < 0 ? `vencido há ${-dias}d` : dias === 0 ? "hoje" : `em ${dias} dias`;
              const tone = dias < 0 ? "bg-destructive/15 text-destructive border-destructive/30" : dias <= 30 ? "bg-warning/20 text-warning-foreground border-warning/40" : "";
              return (
                <li key={a.id} className="flex items-center gap-4 px-5 py-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <FileText className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold truncate">{a.nome}</div>
                    <div className="text-xs text-muted-foreground">
                      {d.toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}
                    </div>
                  </div>
                  <Badge variant="outline" className={tone}>{tag}</Badge>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
