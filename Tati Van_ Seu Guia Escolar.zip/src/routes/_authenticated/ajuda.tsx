import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, MessageCircle, HelpCircle, Sparkles } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { suporteWhatsAppLink, SUPORTE_WHATSAPP_DISPLAY, SUPORTE_HORARIO } from "@/lib/suporte";

export const Route = createFileRoute("/_authenticated/ajuda")({
  head: () => ({
    meta: [
      { title: "Central de Ajuda — Tati Van Escolar" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AjudaPage,
});

const FAQ = [
  {
    q: "Como cadastro um novo aluno?",
    a: "Vá em Alunos e toque em “Novo aluno”. Preencha nome, mensalidade, dia de vencimento e vincule o responsável. Se o responsável ainda não existir, você pode criá-lo na mesma tela.",
  },
  {
    q: "Como cobro uma mensalidade pelo WhatsApp?",
    a: "Em Financeiro, toque em “Cobrar” ao lado do aluno. Você vê uma prévia da mensagem, pode editá-la e, ao confirmar, o WhatsApp abre com o texto pronto.",
  },
  {
    q: "Como funciona o período de teste gratuito?",
    a: "Você tem 10 dias grátis a partir da criação da conta. Depois, há 3 dias de tolerância com acesso completo. Sem assinatura, a conta fica em modo somente leitura até a confirmação do pagamento.",
  },
  {
    q: "Quais formas de pagamento posso usar na assinatura?",
    a: "PIX, Boleto ou Cartão de Crédito. Você escolhe na própria fatura, na tela Assinatura.",
  },
  {
    q: "Como instalo a Tati Van no meu celular?",
    a: "Em Configurações › Como instalar o aplicativo você encontra o passo a passo para iPhone e Android. Não é preciso baixar nada da loja.",
  },
  {
    q: "Como envio o link de rastreio da rota?",
    a: "Inicie a rota pelo Checklist. O link é gerado automaticamente e pode ser enviado aos responsáveis. Ele expira quando a rota é encerrada ou no tempo que você escolher.",
  },
  {
    q: "Meus dados ficam seguros?",
    a: "Sim. Cada motorista acessa apenas os próprios dados e você pode exportar um backup completo em PDF ou Excel a qualquer momento em Configurações.",
  },
];

const NOVIDADES = [
  {
    data: "Agosto 2026",
    titulo: "Central de Ajuda e botão de suporte rápido",
    texto: "Agora você fala com a gente de qualquer tela pelo botão “Precisa de ajuda?”.",
  },
  {
    data: "Julho 2026",
    titulo: "Controle de mensalidades por competência",
    texto: "Débitos de meses anteriores continuam vinculados ao mês correto, com card de atrasos no painel.",
  },
  {
    data: "Julho 2026",
    titulo: "Envio de mensagens em grupo melhorado",
    texto: "No celular o envio é sequencial com barra de progresso; no computador abre várias conversas de uma vez.",
  },
  {
    data: "Junho 2026",
    titulo: "Assinatura com PIX, Boleto e Cartão",
    texto: "Tela de assinatura renovada, com fatura disponível assim que gerada.",
  },
];

function AjudaPage() {
  const linkSuporte = suporteWhatsAppLink();

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link to="/configuracoes">
            <ChevronLeft className="h-4 w-4" /> Voltar
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-2xl font-extrabold">💬 Central de Ajuda</h1>
        <p className="text-sm text-muted-foreground">
          Tire suas dúvidas, veja as novidades ou fale direto com a gente.
        </p>
      </div>

      <Card
        className="overflow-hidden border-0 p-5 text-primary-foreground sm:p-6"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="flex flex-col items-start gap-4 sm:flex sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
          <div className="min-w-0">
            <div className="text-sm uppercase tracking-wider opacity-80">Atendimento humano</div>
            <div className="mt-1 text-xl font-extrabold">Fale com a Tati</div>
            <div className="mt-0.5 text-sm opacity-90 sm:mt-1">
              {SUPORTE_WHATSAPP_DISPLAY} · {SUPORTE_HORARIO}
            </div>
          </div>
          <Button size="lg" variant="secondary" className="w-full shrink-0 font-bold sm:w-auto" asChild>
            <a href={linkSuporte} target="_blank" rel="noopener noreferrer">
              <MessageCircle className="mr-2 h-4 w-4" /> Falar com o Suporte
            </a>
          </Button>
        </div>
      </Card>



      <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold">
          <HelpCircle className="h-4 w-4 text-primary" /> Perguntas Frequentes (FAQ)
        </div>
        <Accordion type="single" collapsible className="mt-2">
          {FAQ.map((item, i) => (
            <AccordionItem key={i} value={`faq-${i}`}>
              <AccordionTrigger className="text-left text-sm font-semibold">
                {item.q}
              </AccordionTrigger>
              <AccordionContent className="text-sm text-muted-foreground">
                {item.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </Card>

      <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold">
          <Sparkles className="h-4 w-4 text-accent-foreground" /> Novidades da Tati Van Escolar
        </div>
        <ul className="mt-4 space-y-4">
          {NOVIDADES.map((n, i) => (
            <li key={i} className="flex gap-3">
              <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary" />
              <div className="min-w-0">
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  {n.data}
                </div>
                <div className="text-sm font-bold">{n.titulo}</div>
                <p className="text-sm text-muted-foreground">{n.texto}</p>
              </div>
            </li>
          ))}
        </ul>
      </Card>

    </div>
  );
}
