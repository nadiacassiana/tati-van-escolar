import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { normalizeTipoCobranca, TIPO_COBRANCA_LABEL, TIPO_COBRANCA_AJUDA, type TipoCobranca } from "@/lib/tipo-cobranca";
import type { Aluno } from "@/lib/mock-data";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import { Plus, Search, Phone, MapPin, Pencil, Camera, Image as ImageIcon, Trash2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { fileToCompressedDataUrl } from "@/lib/image";
import { AlunoAvatar } from "@/components/aluno-avatar";
import { avatarPorSexo, isAvatarUrl, type Sexo } from "@/lib/aluno-avatar";
import { trackEvent } from "@/lib/track-event";
import { ArchiveDeleteActions } from "@/components/archive-delete-actions";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DateInputBR } from "@/components/date-input-br";
import { maskPhoneBR } from "@/lib/phone-mask";
import { HistoricoMensalidades } from "@/components/historico-mensalidades";
import { HistoricoReservasVaga } from "@/components/historico-reservas-vaga";
import { PreCadastros } from "@/components/pre-cadastros";
import { PreCadastroAuditoria, usePreCadastrosAprovados } from "@/components/pre-cadastro-auditoria";
import { comporEndereco, separarEndereco, listarEscolas, type Escola } from "@/lib/escolas";




export const Route = createFileRoute("/_authenticated/alunos")({
  head: () => ({ meta: [{ title: "Alunos — Tati Van" }] }),
  component: AlunosPage,
});

const statusMap = {
  pago: { label: "Em dia", className: "bg-success/15 text-success border-success/30" },
  pendente: { label: "Pendente", className: "bg-warning/20 text-warning-foreground border-warning/40" },
  atrasado: { label: "Atrasado", className: "bg-destructive/15 text-destructive border-destructive/30" },
} as const;

const emptyForm = {
  nome: "",
  sexo: "" as "" | "masculino" | "feminino",
  tipoCobranca: "mensal" as TipoCobranca,

  escola: "",
  endereco: "",
  rua: "",
  numero: "",
  bairro: "",
  cidade: "",
  estado: "",
  cep: "",
  responsavel: "",
  telefone: "",
  respEmail: "",
  respEmergencia: "",
  respAutorizadas: "",
  mensalidade: "",
  vencimento: "",
  multaAtraso: "",
  multaTipo: "percentual",
  jurosDia: "",
  jurosTipo: "percentual",

  horarioIda: "",
  horarioVolta: "",
  turno: "" as "" | "manha" | "tarde" | "integral",
  aniversario: "", // YYYY-MM-DD
  observacoes: "",
  fotoUrl: "",
};



// Converte "DD/MM/YYYY" ou "DD/MM" -> "YYYY-MM-DD" (para input type=date)
function aniversarioToInput(v: string): string {
  if (!v) return "";
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  const parts = v.split("/");
  if (parts.length < 2) return "";
  const [d, m, y] = parts;
  const year = y || String(new Date().getFullYear());
  return `${year}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
}

// Converte "YYYY-MM-DD" -> "DD/MM/YYYY" para armazenar
function aniversarioToDb(v: string): string {
  if (!v) return "";
  const m = v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return v;
  return `${m[3]}/${m[2]}/${m[1]}`;
}

type AlunoRow = Tables<"alunos">;
type AlunoInsert = TablesInsert<"alunos">;
type AlunoUpdate = TablesUpdate<"alunos">;

function normalizeStatus(status: string): Aluno["statusMensalidade"] {
  return status === "pago" || status === "atrasado" ? status : "pendente";
}

type EnderecoAluno = { rua: string; numero: string; bairro: string; cidade: string; estado: string; cep: string };

function fromRow(row: AlunoRow): Aluno & EnderecoAluno & { sexo: Sexo; tipoCobranca: TipoCobranca; turno: "manha" | "tarde" | "integral" | null; arquivadoEm: string | null; createdAt: string; multaAtraso: number; multaTipo: string; jurosDia: number; jurosTipo: string } {
  const end = row as AlunoRow & Partial<EnderecoAluno>;
  const enc = row as AlunoRow & { multa_atraso?: number | null; multa_tipo?: string | null; juros_dia?: number | null; juros_tipo?: string | null };
  const sexo = ((row as AlunoRow & { sexo?: string }).sexo as Sexo) ?? null;

  return {
    id: row.id,
    nome: row.nome,
    escola: row.escola,
    turma: row.turma,
    endereco: row.endereco,
    rua: end.rua || "",
    numero: end.numero || "",
    bairro: end.bairro || "",
    cidade: end.cidade || "",
    estado: end.estado || "",
    cep: end.cep || "",
    responsavel: row.responsavel,
    telefone: row.telefone,
    whatsapp: row.whatsapp,
    mensalidade: Number(row.mensalidade),
    vencimento: row.vencimento,
    horarioIda: row.horario_ida,
    horarioVolta: row.horario_volta,
    turno: ((row as AlunoRow & { turno?: string | null }).turno ?? null) as "manha" | "tarde" | "integral" | null,
    aniversario: row.aniversario,
    observacoes: row.observacoes,
    podeBuscar: row.pode_buscar,
    naoPodeBuscar: row.nao_pode_buscar,
    restricoes: row.restricoes,
    avatar: row.avatar,
    fotoUrl: (row as AlunoRow & { foto_url?: string }).foto_url || "",
    statusMensalidade: normalizeStatus(row.status_mensalidade),
    sexo,
    tipoCobranca: normalizeTipoCobranca((row as AlunoRow & { tipo_cobranca?: string }).tipo_cobranca),

    multaAtraso: Number(enc.multa_atraso ?? 0),
    multaTipo: enc.multa_tipo || "percentual",
    jurosDia: Number(enc.juros_dia ?? 0),
    jurosTipo: enc.juros_tipo || "percentual",
    arquivadoEm: (row as AlunoRow & { arquivado_em?: string | null }).arquivado_em ?? null,
    createdAt: (row as AlunoRow & { created_at?: string }).created_at ?? "",
  };
}


/** Usa as partes salvas e, quando faltarem, extrai do endereço em texto único. */
function enderecoDoAluno(aluno: Partial<EnderecoAluno> & { endereco?: string }): EnderecoAluno {
  const partes: EnderecoAluno = {
    rua: aluno.rua || "",
    numero: aluno.numero || "",
    bairro: aluno.bairro || "",
    cidade: aluno.cidade || "",
    estado: aluno.estado || "",
    cep: aluno.cep || "",
  };
  if (partes.rua && partes.numero && partes.bairro) return partes;
  const extraido = separarEndereco(aluno.endereco === "—" ? "" : aluno.endereco || "");
  return {
    rua: partes.rua || extraido.rua,
    numero: partes.numero || extraido.numero,
    bairro: partes.bairro || extraido.bairro,
    cidade: partes.cidade || extraido.cidade,
    estado: partes.estado || extraido.estado,
    cep: partes.cep || extraido.cep,
  };
}

function buildPayload(form: typeof emptyForm) {
  const mensalidade = parseMoney(form.mensalidade);
  const venc = parseInt(form.vencimento, 10);
  const sexo = form.sexo || null;
  return {
    nome: form.nome.trim(),
    escola: form.escola || "—",
    turma: "",
    endereco: comporEndereco(form) || form.endereco || "—",
    rua: form.rua.trim(),
    numero: form.numero.trim(),
    bairro: form.bairro.trim(),
    cidade: form.cidade.trim(),
    estado: form.estado.trim().toUpperCase(),
    cep: form.cep.trim(),
    responsavel: form.responsavel || "—",
    telefone: form.telefone || "—",
    whatsapp: form.telefone.replace(/\D/g, ""),
    mensalidade,
    vencimento: Number.isFinite(venc) && venc >= 1 && venc <= 31 ? venc : 5,
    horario_ida: form.horarioIda || "—",
    horario_volta: form.horarioVolta || "—",
    turno: form.turno || null,
    aniversario: aniversarioToDb(form.aniversario),
    observacoes: form.observacoes,
    pode_buscar: "",
    nao_pode_buscar: "",
    restricoes: "",
    avatar: avatarPorSexo(sexo as Sexo),
    foto_url: form.fotoUrl || "",
    sexo,
    tipo_cobranca: normalizeTipoCobranca(form.tipoCobranca),
    multa_atraso: parseMoney(form.multaAtraso),
    multa_tipo: form.multaTipo,
    juros_dia: parseMoney(form.jurosDia),
    juros_tipo: form.jurosTipo,

    status_mensalidade: "pendente",
  };
}


// Aceita "R$ 150,00", "150", "150,19", "1.250,50", "1250.50" etc.
function parseMoney(input: string): number {
  if (!input) return 0;
  const cleaned = input.replace(/[^\d,.-]/g, "").trim();
  if (!cleaned) return 0;
  const hasComma = cleaned.includes(",");
  const hasDot = cleaned.includes(".");
  let normalized = cleaned;
  if (hasComma && hasDot) {
    normalized = cleaned.replace(/\./g, "").replace(",", ".");
  } else if (hasComma) {
    normalized = cleaned.replace(",", ".");
  }
  const n = parseFloat(normalized);
  return isNaN(n) ? 0 : n;
}

type ContratoMini = { id: string; aluno_id: string | null; aluno_nome: string; status: string; data_inicio: string | null; data_termino: string | null; mensalidade: number };

function ContratoBadge({ contrato }: { contrato: ContratoMini | undefined }) {
  if (!contrato) return null;
  const status = contrato.status === "encerrado" ? "🔴 Encerrado" : contrato.status === "renovacao" ? "🟡 Renovação" : "🟢 Ativo";
  return (
    <div className="mt-3 rounded-lg border bg-secondary/40 p-2 text-xs">
      <div className="font-semibold mb-1">📄 Contrato atual</div>
      <div className="flex justify-between"><span className="text-muted-foreground">Situação</span><span>{status}</span></div>
      <div className="flex justify-between"><span className="text-muted-foreground">Vigência</span>
        <span>{contrato.data_inicio ? new Date(contrato.data_inicio).toLocaleDateString("pt-BR") : "—"} → {contrato.data_termino ? new Date(contrato.data_termino).toLocaleDateString("pt-BR") : "—"}</span>
      </div>
    </div>
  );
}



function FotoPicker({
  value,
  onChange,
  fallbackAvatar,
}: {
  value: string;
  onChange: (v: string) => void;
  fallbackAvatar?: string;
}) {

  const cameraRef = useRef<HTMLInputElement>(null);
  const galleryRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    try {
      const url = await fileToCompressedDataUrl(file);
      onChange(url);
    } catch {
      toast.error("Não consegui processar essa imagem.");
    } finally {
      setBusy(false);
      if (cameraRef.current) cameraRef.current.value = "";
      if (galleryRef.current) galleryRef.current.value = "";
    }
  };

  const renderFallback = () => {
    if (!fallbackAvatar) {
      return <span className="text-3xl text-muted-foreground">📷</span>;
    }
    if (isAvatarUrl(fallbackAvatar)) {
      return <img src={fallbackAvatar} alt="Avatar padrão" className="h-full w-full object-cover" />;
    }
    return <span className="text-5xl">{fallbackAvatar}</span>;
  };

  return (
    <div className="flex items-center gap-4">
      <div className="h-20 w-20 shrink-0 overflow-hidden rounded-2xl bg-secondary flex items-center justify-center">
        {value ? (
          <img src={value} alt="Prévia" className="h-full w-full object-cover" />
        ) : (
          renderFallback()
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        <input
          ref={cameraRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />
        <input
          ref={galleryRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />
        <Button type="button" variant="outline" size="sm" disabled={busy} onClick={() => cameraRef.current?.click()}>
          <Camera className="mr-1 h-4 w-4" /> Câmera
        </Button>
        <Button type="button" variant="outline" size="sm" disabled={busy} onClick={() => galleryRef.current?.click()}>
          <ImageIcon className="mr-1 h-4 w-4" /> Galeria
        </Button>
        {value && (
          <Button type="button" variant="ghost" size="sm" className="text-destructive" onClick={() => onChange("")}>
            <Trash2 className="mr-1 h-4 w-4" /> Remover
          </Button>
        )}
      </div>
    </div>
  );
}

type RespMini = {
  id: string;
  nome: string;
  telefone: string;
  whatsapp: string;
  endereco: string;
  email: string | null;
  pessoas_autorizadas: string | null;
  telefone_emergencia: string | null;
  alunos_ids: string[];
};

const RESP_COLS = "id, nome, telefone, whatsapp, endereco, email, pessoas_autorizadas, telefone_emergencia, alunos_ids";

function onlyDigits(s: string) {
  return (s || "").replace(/\D/g, "");
}


function AlunosPage() {
  const { user } = Route.useRouteContext();
  const [q, setQ] = useState("");
  const [lista, setLista] = useState<(Aluno & { sexo: Sexo; tipoCobranca: TipoCobranca; arquivadoEm: string | null; createdAt: string })[]>([]);
  const [historyByAluno, setHistoryByAluno] = useState<Record<string, number>>({});
  const [view, setView] = useState<"ativos" | "arquivados">("ativos");

  const [contratos, setContratos] = useState<ContratoMini[]>([]);
  const [responsaveis, setResponsaveis] = useState<RespMini[]>([]);
  const [escolasCad, setEscolasCad] = useState<Escola[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [selectedRespId, setSelectedRespId] = useState<string | null>(null);
  const [respSugOpen, setRespSugOpen] = useState(false);
  const [duplicado, setDuplicado] = useState<RespMini | null>(null);
  const [histAluno, setHistAluno] = useState<(Aluno & { arquivadoEm: string | null; createdAt: string; multaAtraso?: number; multaTipo?: string; jurosDia?: number; jurosTipo?: string }) | null>(null);
  const [reservaAluno, setReservaAluno] = useState<{ id: string; nome: string } | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const fichasPublicas = usePreCadastrosAprovados();

  useEffect(() => {
    let active = true;

    const loadAlunos = async () => {
      setLoading(true);
      const [a, c, r, pag, rec, esc] = await Promise.all([
        supabase.from("alunos").select("*").order("created_at", { ascending: false }),
        supabase.from("contratos").select("id, aluno_id, aluno_nome, status, data_inicio, data_termino, mensalidade"),
        supabase.from("responsaveis").select(RESP_COLS).order("nome"),
        supabase.from("pagamentos").select("aluno_id"),
        supabase.from("recibos").select("aluno_id"),
        listarEscolas(),
      ]);

      if (!active) return;

      if (a.error) {
        toast.error("Não foi possível carregar os alunos.");
        setLoading(false);
        return;
      }

      const hist: Record<string, number> = {};
      const bump = (id: string | null | undefined) => { if (id) hist[id] = (hist[id] || 0) + 1; };
      ((c.data as { aluno_id: string | null }[]) || []).forEach((x) => bump(x.aluno_id));
      ((pag.data as { aluno_id: string | null }[]) || []).forEach((x) => bump(x.aluno_id));
      ((rec.data as { aluno_id: string | null }[]) || []).forEach((x) => bump(x.aluno_id));
      setHistoryByAluno(hist);


      setLista((a.data || []).map(fromRow));
      setContratos(((c.data as unknown) as ContratoMini[]) || []);
      setResponsaveis(((r.data as unknown) as RespMini[]) || []);
      setEscolasCad(esc || []);
      setLoading(false);
    };


    loadAlunos();

    return () => {
      active = false;
    };
  }, [reloadKey]);

  const filtrados = lista.filter((a) => {
    const matchView = view === "arquivados" ? !!a.arquivadoEm : !a.arquivadoEm;
    return matchView && a.nome.toLowerCase().includes(q.toLowerCase());
  });
  const totalAtivos = lista.filter((a) => !a.arquivadoEm).length;
  const totalArquivados = lista.filter((a) => !!a.arquivadoEm).length;

  const handleArchive = async (a: Aluno & { arquivadoEm: string | null }) => {
    const { error } = await supabase.from("alunos").update({ arquivado_em: new Date().toISOString() } as unknown as AlunoUpdate).eq("id", a.id);
    if (error) return toast.error("Não foi possível arquivar.");
    setLista((prev) => prev.map((x) => (x.id === a.id ? { ...x, arquivadoEm: new Date().toISOString() } : x)));
    toast.success(`${a.nome} foi arquivado. Histórico preservado.`);
  };

  const handleRestore = async (a: Aluno & { arquivadoEm: string | null }) => {
    const { error } = await supabase.from("alunos").update({ arquivado_em: null } as unknown as AlunoUpdate).eq("id", a.id);
    if (error) return toast.error("Não foi possível restaurar.");
    setLista((prev) => prev.map((x) => (x.id === a.id ? { ...x, arquivadoEm: null } : x)));
    toast.success(`${a.nome} foi restaurado.`);
  };

  const handleDelete = async (a: Aluno & { arquivadoEm: string | null }) => {
    const { error } = await supabase.from("alunos").delete().eq("id", a.id);
    if (error) return toast.error("Não foi possível excluir.");
    setLista((prev) => prev.filter((x) => x.id !== a.id));
    toast.success(`${a.nome} foi excluído definitivamente.`);
  };


  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setSelectedRespId(null);
    setOpen(true);
  };

  const openEdit = (aluno: Aluno & { sexo?: Sexo; tipoCobranca?: TipoCobranca }) => {
    const enc = aluno as { multaAtraso?: number; multaTipo?: string; jurosDia?: number; jurosTipo?: string };
    setEditingId(aluno.id);

    const telefone = aluno.telefone === "—" ? "" : aluno.telefone;
    const match =
      responsaveis.find((r) => r.nome.toLowerCase() === (aluno.responsavel || "").toLowerCase()) ||
      responsaveis.find((r) => onlyDigits(r.telefone) && onlyDigits(r.telefone) === onlyDigits(telefone));
    setForm({
      nome: aluno.nome,
      sexo: (aluno.sexo === "masculino" || aluno.sexo === "feminino") ? aluno.sexo : "",
      tipoCobranca: normalizeTipoCobranca(aluno.tipoCobranca),

      escola: aluno.escola === "—" ? "" : aluno.escola,
      endereco: aluno.endereco === "—" ? "" : aluno.endereco,
      ...enderecoDoAluno(aluno),
      responsavel: aluno.responsavel === "—" ? "" : aluno.responsavel,
      telefone,
      respEmail: match?.email || "",
      respEmergencia: match?.telefone_emergencia || "",
      respAutorizadas: match?.pessoas_autorizadas || aluno.podeBuscar || "",
      mensalidade: aluno.mensalidade ? String(aluno.mensalidade) : "",
      vencimento: aluno.vencimento ? String(aluno.vencimento) : "",
      multaAtraso: Number(enc.multaAtraso) > 0 ? String(enc.multaAtraso) : "",
      multaTipo: enc.multaTipo || "percentual",
      jurosDia: Number(enc.jurosDia) > 0 ? String(enc.jurosDia) : "",
      jurosTipo: enc.jurosTipo || "percentual",
      horarioIda: aluno.horarioIda === "—" ? "" : aluno.horarioIda,
      horarioVolta: aluno.horarioVolta === "—" ? "" : aluno.horarioVolta,
      turno: (aluno as { turno?: "manha" | "tarde" | "integral" | null }).turno ?? "",
      aniversario: aniversarioToInput(aluno.aniversario || ""),
      observacoes: aluno.observacoes || "",
      fotoUrl: aluno.fotoUrl || "",
    });
    setSelectedRespId(match?.id || null);
    setOpen(true);
  };


  async function vincularAlunoAoResponsavel(alunoId: string, resp: RespMini) {
    const ids = Array.isArray(resp.alunos_ids) ? resp.alunos_ids : [];
    if (ids.includes(alunoId)) return;
    const novosIds = [...ids, alunoId];
    await supabase.from("responsaveis").update({ alunos_ids: novosIds }).eq("id", resp.id);
    setResponsaveis((prev) => prev.map((x) => (x.id === resp.id ? { ...x, alunos_ids: novosIds } : x)));
  }

  const selecionarResp = (r: RespMini) => {
    setForm((f) => ({
      ...f,
      responsavel: r.nome,
      telefone: r.telefone || f.telefone,
      respEmail: r.email || f.respEmail,
      respEmergencia: r.telefone_emergencia || f.respEmergencia,
      respAutorizadas: r.pessoas_autorizadas || f.respAutorizadas,
    }));
    setSelectedRespId(r.id);
    setRespSugOpen(false);
  };

  // Cria (ou atualiza) o responsável e vincula ao aluno. Transparente para o usuário.
  async function salvarResponsavel(alunoId: string, respId: string | null): Promise<void> {
    const nome = form.responsavel.trim();
    if (!nome) return;
    const wpp = onlyDigits(form.telefone);
    const dados = {
      nome,
      telefone: form.telefone,
      whatsapp: wpp,
      email: form.respEmail.trim() || null,
      telefone_emergencia: form.respEmergencia.trim() || null,
      pessoas_autorizadas: form.respAutorizadas.trim() || null,
    };

    if (respId) {
      const atual = responsaveis.find((r) => r.id === respId);
      await supabase.from("responsaveis").update(dados).eq("id", respId);
      const atualizado: RespMini = { ...(atual as RespMini), ...dados, endereco: atual?.endereco || "", alunos_ids: atual?.alunos_ids || [] };
      setResponsaveis((prev) => prev.map((x) => (x.id === respId ? atualizado : x)));
      await vincularAlunoAoResponsavel(alunoId, atualizado);
      return;
    }

    const { data, error } = await supabase
      .from("responsaveis")
      .insert({
        user_id: user.id,
        ...dados,
        endereco: form.endereco || "",
        observacoes: "",
        pix: "",
        alunos_ids: [alunoId],
      })
      .select(RESP_COLS)
      .single();
    if (error || !data) {
      toast.error("Aluno salvo, mas não consegui cadastrar o responsável.");
      return;
    }
    const novo = data as unknown as RespMini;
    setResponsaveis((prev) => [...prev, novo].sort((a, b) => a.nome.localeCompare(b.nome)));
    setSelectedRespId(novo.id);
  }

  async function persistirAluno(respId: string | null) {
    setSaving(true);
    if (editingId) {
      const payload = buildPayload(form) as unknown as AlunoUpdate;
      const { data, error } = await supabase
        .from("alunos")
        .update(payload)
        .eq("id", editingId)
        .select("*")
        .single();

      if (error) {
        setSaving(false);
        toast.error("Não foi possível salvar as alterações.");
        return;
      }

      setLista((prev) => prev.map((a) => (a.id === editingId ? fromRow(data) : a)));
      await salvarResponsavel(editingId, respId);
      toast.success(`${form.nome} foi atualizado!`);
    } else {
      const payload = { ...buildPayload(form), user_id: user.id } as unknown as AlunoInsert;
      const { data, error } = await supabase.from("alunos").insert(payload).select("*").single();

      if (error) {
        setSaving(false);
        toast.error("Não foi possível cadastrar o aluno.");
        return;
      }

      const novo = fromRow(data);
      setLista((prev) => [novo, ...prev]);
      await salvarResponsavel(novo.id, respId);
      trackEvent("aluno_cadastrado", `cadastrou ${novo.nome}`);
      toast.success(`${novo.nome} foi cadastrado com o responsável!`);
    }

    setSaving(false);
    setForm(emptyForm);
    setEditingId(null);
    setSelectedRespId(null);
    setDuplicado(null);
    setOpen(false);
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome.trim()) {
      toast.error("Informe o nome do aluno.");
      return;
    }
    if (!form.sexo) {
      toast.error("Selecione o sexo do aluno.");
      return;
    }
    if (!form.responsavel.trim()) {
      toast.error("Informe o nome do responsável.");
      return;
    }
    if (!onlyDigits(form.telefone)) {
      toast.error("Informe o WhatsApp do responsável.");
      return;
    }
    const mensalidade = parseMoney(form.mensalidade);
    if (mensalidade > 0 && !form.vencimento) {
      toast.error("Informe o dia do vencimento da mensalidade.");
      return;
    }

    // Se o WhatsApp já pertence a outro responsável, confirmar vínculo em vez de duplicar.
    const wpp = onlyDigits(form.telefone);
    if (!selectedRespId) {
      const dup = responsaveis.find((r) => (onlyDigits(r.telefone) || r.whatsapp) === wpp);
      if (dup) {
        setDuplicado(dup);
        return;
      }
    }

    await persistirAluno(selectedRespId);
  };



  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">Alunos 👧👦</h1>
          <p className="text-sm text-muted-foreground">{totalAtivos} ativos · {totalArquivados} arquivados.</p>
        </div>
        <Button onClick={openCreate} className="bg-primary text-primary-foreground font-bold">
          <Plus className="mr-2 h-4 w-4" /> Novo aluno
        </Button>
      </div>

      <PreCadastros userId={user.id} onAprovado={() => setReloadKey((k) => k + 1)} />

      <div className="flex flex-wrap items-center gap-3">
        <Tabs value={view} onValueChange={(v) => setView(v as "ativos" | "arquivados")}>
          <TabsList>
            <TabsTrigger value="ativos">Ativos ({totalAtivos})</TabsTrigger>
            <TabsTrigger value="arquivados">🗄️ Arquivados ({totalArquivados})</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="relative flex-1 min-w-[220px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Buscar aluno..." value={q} onChange={(e) => setQ(e.target.value)} className="pl-10" />
        </div>
      </div>


      {loading ? (
        <Card className="p-6 text-center text-sm text-muted-foreground" style={{ boxShadow: "var(--shadow-card)" }}>
          Carregando alunos...
        </Card>
      ) : filtrados.length === 0 ? (
        <Card className="p-6 text-center text-sm text-muted-foreground" style={{ boxShadow: "var(--shadow-card)" }}>
          Nenhum aluno encontrado.
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtrados.map((a) => {
          const s = statusMap[a.statusMensalidade];
          return (
            <Card key={a.id} className="overflow-hidden p-5 transition-all hover:scale-[1.01]" style={{ boxShadow: "var(--shadow-card)" }}>
              <div className="flex items-start gap-3">
                <AlunoAvatar nome={a.nome} fotoUrl={a.fotoUrl} avatar={a.avatar} sexo={a.sexo} size={56} />
                <div className="min-w-0 flex-1">
                  <div className="font-bold leading-tight">{a.nome}</div>
                  <div className="text-xs text-muted-foreground">{a.escola}</div>
                  <Badge variant="outline" className={`mt-1 ${s.className}`}>{s.label}</Badge>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-8 w-8 shrink-0 text-muted-foreground hover:text-primary"
                  onClick={() => openEdit(a)}
                  aria-label={`Editar ${a.nome}`}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
              </div>

              <div className="mt-4 space-y-1 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground"><MapPin className="h-3.5 w-3.5" /> {a.endereco}</div>
                <div className="flex items-center gap-2 text-muted-foreground"><Phone className="h-3.5 w-3.5" /> {a.responsavel} — {a.telefone}</div>
              </div>

              <div className="mt-4 flex items-center justify-between border-t pt-3 text-xs">
                <span className="text-muted-foreground">Tipo de cobrança</span>
                <Badge variant="outline" className={a.tipoCobranca === "mensal" ? "bg-primary/10 text-primary border-primary/30" : "bg-accent/20 text-accent-foreground border-accent/40"}>
                  {TIPO_COBRANCA_LABEL[a.tipoCobranca]}
                </Badge>
              </div>
              <div className="mt-1 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Mensalidade</span>
                <span className="font-bold text-primary">R$ {a.mensalidade.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>

              <div className="mt-1 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Vencimento</span>
                <span>Todo dia {a.vencimento}</span>
              </div>
              <div className="mt-1 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Ida / Volta</span>
                <span>{a.horarioIda} / {a.horarioVolta}</span>
              </div>
              <ContratoBadge contrato={contratos.find((c) => c.aluno_id === a.id)} />
              <PreCadastroAuditoria ficha={fichasPublicas.find((f) => f.aluno_id === a.id)} />

              <Button
                variant="outline"
                size="sm"
                className="mt-3 w-full font-semibold"
                onClick={() => setHistAluno(a)}
              >
                💰 Histórico de mensalidades
              </Button>

              <Button
                variant="outline"
                size="sm"
                className="mt-2 w-full font-semibold"
                onClick={() => setReservaAluno({ id: a.id, nome: a.nome })}
              >
                🎟️ Histórico de reservas de vaga
              </Button>


              <div className="mt-4 border-t pt-3">
                <ArchiveDeleteActions
                  compact
                  isArchived={!!a.arquivadoEm}
                  hasHistory={(historyByAluno[a.id] || 0) > 0}
                  historyLabel="contratos, recibos ou mensalidades"
                  entityLabel="aluno"
                  entityName={a.nome}
                  onArchive={async () => { await handleArchive(a); }}
                  onRestore={async () => { await handleRestore(a); }}
                  onDelete={async () => { await handleDelete(a); }}

                />
              </div>
            </Card>

          );
        })}
        </div>
      )}

      <HistoricoMensalidades
        open={!!histAluno}
        onOpenChange={(v) => { if (!v) setHistAluno(null); }}
        user={user}
        aluno={histAluno ? {
          id: histAluno.id,
          nome: histAluno.nome,
          mensalidade: Number(histAluno.mensalidade),
          vencimento: histAluno.vencimento,
          responsavel: histAluno.responsavel,
          whatsapp: histAluno.whatsapp || histAluno.telefone,
          escola: histAluno.escola,
          created_at: histAluno.createdAt,
          arquivado_em: histAluno.arquivadoEm,
          multa_atraso: histAluno.multaAtraso,
          multa_tipo: histAluno.multaTipo,
          juros_dia: histAluno.jurosDia,
          juros_tipo: histAluno.jurosTipo,
        } : null}
      />

      <HistoricoReservasVaga
        open={!!reservaAluno}
        onOpenChange={(v) => { if (!v) setReservaAluno(null); }}
        user={user}
        aluno={reservaAluno}
      />

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingId ? "Editar aluno" : "Novo aluno"} 👧👦</DialogTitle>
            <DialogDescription>
              Preencha tudo aqui: o responsável é cadastrado junto, sem precisar trocar de tela.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-4">
            {/* ===== Seção 1: dados do aluno ===== */}
            <div className="rounded-xl border bg-secondary/30 p-3">
              <h3 className="mb-3 text-sm font-extrabold">👦 Dados do aluno</h3>
              <div className="space-y-3">
                <div>
                  <Label>Foto do aluno</Label>
                  <div className="mt-1">
                    <FotoPicker
                      value={form.fotoUrl}
                      onChange={(v) => setForm({ ...form, fotoUrl: v })}
                      fallbackAvatar={form.sexo ? avatarPorSexo(form.sexo as Sexo) : undefined}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="nome">Nome completo *</Label>
                  <Input id="nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} autoFocus />
                </div>
                <div>
                  <Label htmlFor="sexo">Sexo *</Label>
                  <Select value={form.sexo} onValueChange={(v) => setForm({ ...form, sexo: v as "masculino" | "feminino" })}>
                    <SelectTrigger id="sexo"><SelectValue placeholder="Selecione" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="masculino">👦 Masculino</SelectItem>
                      <SelectItem value="feminino">👧 Feminino</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="aniversario">Data de nascimento 🎂</Label>
                  <DateInputBR
                    id="aniversario"
                    value={form.aniversario}
                    onChange={(iso) => setForm({ ...form, aniversario: iso })}
                  />
                  <p className="mt-1 text-xs text-muted-foreground">Aparecerá em "Aniversariantes do mês" no painel inicial.</p>
                </div>
                <div>
                  <Label htmlFor="escola">Escola</Label>
                  <Input
                    id="escola"
                    list="escolas-cadastradas-aluno"
                    value={form.escola}
                    onChange={(e) => setForm({ ...form, escola: e.target.value })}
                    placeholder="Selecione ou digite o nome da escola"
                  />
                  <datalist id="escolas-cadastradas-aluno">
                    {escolasCad.map((e) => (
                      <option key={e.id} value={e.nome} />
                    ))}
                  </datalist>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Vincule à escola cadastrada — o endereço dela é usado no pino da escola no rastreio.
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <Label htmlFor="rua">Rua</Label>
                    <Input id="rua" value={form.rua} onChange={(e) => setForm({ ...form, rua: e.target.value })} />
                  </div>
                  <div>
                    <Label htmlFor="numero">Número</Label>
                    <Input id="numero" value={form.numero} onChange={(e) => setForm({ ...form, numero: e.target.value })} />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="bairro">Bairro</Label>
                    <Input id="bairro" value={form.bairro} onChange={(e) => setForm({ ...form, bairro: e.target.value })} />
                  </div>
                  <div>
                    <Label htmlFor="cep">CEP</Label>
                    <Input id="cep" value={form.cep} onChange={(e) => setForm({ ...form, cep: e.target.value })} placeholder="00000-000" />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="cidade">Cidade</Label>
                    <Input id="cidade" value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} />
                  </div>
                  <div>
                    <Label htmlFor="estado">Estado/UF</Label>
                    <Input
                      id="estado"
                      value={form.estado}
                      onChange={(e) => setForm({ ...form, estado: e.target.value.toUpperCase() })}
                      placeholder="SP"
                      maxLength={2}
                    />
                  </div>

                  <p className="col-span-3 text-xs text-muted-foreground">
                    Endereço residencial completo — usado no pino da casa no rastreio.
                  </p>
                </div>
              </div>
            </div>

            {/* ===== Seção 2: responsável (cadastro automático) ===== */}
            <div className="rounded-xl border bg-secondary/30 p-3">
              <h3 className="text-sm font-extrabold">👩 Responsável</h3>
              <p className="mb-3 text-xs text-muted-foreground">
                Cadastrado automaticamente ao salvar o aluno.
              </p>
              <div className="space-y-3">
                <div>
                  <Label htmlFor="responsavel">Nome do responsável *</Label>
                  <div className="relative">
                    <Input
                      id="responsavel"
                      value={form.responsavel}
                      onChange={(e) => {
                        setForm({ ...form, responsavel: e.target.value });
                        setSelectedRespId(null);
                        setRespSugOpen(true);
                      }}
                      onFocus={() => setRespSugOpen(true)}
                      onBlur={() => setTimeout(() => setRespSugOpen(false), 150)}
                      placeholder="Digite o nome"
                      autoComplete="off"
                    />
                    {respSugOpen && (() => {
                      const termo = form.responsavel.trim().toLowerCase();
                      const sugest = responsaveis
                        .filter((r) => !termo || r.nome.toLowerCase().includes(termo))
                        .filter((r) => r.nome.toLowerCase() !== termo)
                        .slice(0, 6);
                      if (sugest.length === 0) return null;
                      return (
                        <div className="absolute z-50 mt-1 w-full overflow-hidden rounded-md border bg-popover shadow-lg">
                          <div className="max-h-48 overflow-y-auto">
                            {sugest.map((r) => (
                              <button
                                key={r.id}
                                type="button"
                                onMouseDown={(e) => e.preventDefault()}
                                onClick={() => selecionarResp(r)}
                                className="block w-full px-3 py-2 text-left text-sm hover:bg-accent"
                              >
                                <div className="font-medium">{r.nome}</div>
                                {r.telefone && <div className="text-xs text-muted-foreground">{r.telefone}</div>}
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                  {selectedRespId && (
                    <p className="mt-1 text-xs text-success">✅ Responsável já cadastrado — será vinculado a este aluno.</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="telefone">WhatsApp *</Label>
                  <Input
                    id="telefone"
                    inputMode="numeric"
                    value={form.telefone}
                    onChange={(e) => setForm({ ...form, telefone: maskPhoneBR(e.target.value) })}
                    placeholder="(11) 99999-9999"
                  />
                </div>
                <div>
                  <Label htmlFor="respEmail">E-mail (opcional)</Label>
                  <Input
                    id="respEmail"
                    type="email"
                    value={form.respEmail}
                    onChange={(e) => setForm({ ...form, respEmail: e.target.value })}
                    placeholder="email@exemplo.com"
                  />
                </div>
                <div>
                  <Label htmlFor="respEmergencia">Telefone de emergência</Label>
                  <Input
                    id="respEmergencia"
                    inputMode="numeric"
                    value={form.respEmergencia}
                    onChange={(e) => setForm({ ...form, respEmergencia: maskPhoneBR(e.target.value) })}
                    placeholder="(11) 99999-9999"
                  />
                </div>
                <div>
                  <Label htmlFor="respAutorizadas">Pessoas autorizadas a buscar a criança</Label>
                  <Textarea
                    id="respAutorizadas"
                    rows={2}
                    value={form.respAutorizadas}
                    onChange={(e) => setForm({ ...form, respAutorizadas: e.target.value })}
                    placeholder="Ex.: Avó Maria, tio João"
                  />
                </div>
              </div>
            </div>

            {/* ===== Seção 3: horários e valores ===== */}
            <div className="rounded-xl border bg-secondary/30 p-3">
              <h3 className="mb-3 text-sm font-extrabold">🚐 Rotina e mensalidade</h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="ida">Horário ida</Label>
                    <Input id="ida" type="time" value={form.horarioIda} onChange={(e) => setForm({ ...form, horarioIda: e.target.value })} />
                  </div>
                  <div>
                    <Label htmlFor="volta">Horário volta</Label>
                    <Input id="volta" type="time" value={form.horarioVolta} onChange={(e) => setForm({ ...form, horarioVolta: e.target.value })} />
                  </div>
                </div>
                <div>
                  <Label htmlFor="turno">Turno</Label>
                  <Select
                    value={form.turno || "auto"}
                    onValueChange={(v) => setForm({ ...form, turno: v === "auto" ? "" : (v as "manha" | "tarde" | "integral") })}
                  >
                    <SelectTrigger id="turno"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Automático (pelo horário)</SelectItem>
                      <SelectItem value="manha">Manhã</SelectItem>
                      <SelectItem value="tarde">Tarde</SelectItem>
                      <SelectItem value="integral">Integral</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="tipoCobranca">Tipo de cobrança</Label>
                  <Select
                    value={form.tipoCobranca}
                    onValueChange={(v) => setForm({ ...form, tipoCobranca: v as TipoCobranca })}
                  >
                    <SelectTrigger id="tipoCobranca"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mensal">📆 Mensal (padrão)</SelectItem>
                      <SelectItem value="anual_vista">🗓️ Plano anual — pagamento à vista</SelectItem>
                      <SelectItem value="anual_parcelado">🗓️ Plano anual — parcelado (mensalidades)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {TIPO_COBRANCA_AJUDA[form.tipoCobranca]}
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3">

                  <div>
                    <Label htmlFor="mensalidade">Mensalidade (R$)</Label>
                    <Input id="mensalidade" type="text" inputMode="decimal" placeholder="R$ 450,00" value={form.mensalidade} onChange={(e) => setForm({ ...form, mensalidade: e.target.value })} />
                  </div>
                  <div>
                    <Label htmlFor="vencimento">Dia do vencimento {parseMoney(form.mensalidade) > 0 && <span className="text-destructive">*</span>}</Label>
                    <Select value={form.vencimento} onValueChange={(v) => setForm({ ...form, vencimento: v })}>
                      <SelectTrigger id="vencimento"><SelectValue placeholder="Escolha o dia" /></SelectTrigger>
                      <SelectContent className="max-h-64">
                        {Array.from({ length: 31 }, (_, i) => i + 1).map((d) => (
                          <SelectItem key={d} value={String(d)}>Dia {d}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="rounded-lg border bg-muted/30 p-3">
                  <div className="text-sm font-bold">⚠️ Multa e juros por atraso (opcional)</div>
                  <p className="mb-2 text-xs text-muted-foreground">
                    Usado no contrato e no cálculo do valor atualizado das mensalidades atrasadas.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="multa-aluno">Multa por atraso</Label>
                      <Input id="multa-aluno" type="text" inputMode="decimal" placeholder="Ex.: 2" value={form.multaAtraso} onChange={(e) => setForm({ ...form, multaAtraso: e.target.value })} />
                    </div>
                    <div>
                      <Label>Tipo da multa</Label>
                      <Select value={form.multaTipo} onValueChange={(v) => setForm({ ...form, multaTipo: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="percentual">% sobre a mensalidade</SelectItem>
                          <SelectItem value="reais">R$ (valor fixo)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="juros-aluno">Juros por dia de atraso</Label>
                      <Input id="juros-aluno" type="text" inputMode="decimal" placeholder="Ex.: 0,33" value={form.jurosDia} onChange={(e) => setForm({ ...form, jurosDia: e.target.value })} />
                    </div>
                    <div>
                      <Label>Tipo dos juros</Label>
                      <Select value={form.jurosTipo} onValueChange={(v) => setForm({ ...form, jurosTipo: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="percentual">% ao dia</SelectItem>
                          <SelectItem value="reais">R$ por dia</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="obs">Observações</Label>
                  <Textarea id="obs" rows={3} value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} />
                </div>
              </div>
            </div>

            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saving} className="bg-primary text-primary-foreground font-bold">
                {saving ? "Salvando..." : editingId ? "Salvar alterações" : "Salvar aluno e responsável"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Responsável duplicado: vincular em vez de criar outro cadastro */}
      <Dialog open={!!duplicado} onOpenChange={(v) => { if (!v) setDuplicado(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Responsável já cadastrado</DialogTitle>
            <DialogDescription>
              Encontramos um responsável já cadastrado com esse WhatsApp. Deseja vinculá-lo a este aluno?
            </DialogDescription>
          </DialogHeader>
          {duplicado && (
            <div className="rounded-lg border border-warning/40 bg-warning/10 p-3 text-sm">
              👤 <span className="font-semibold">{duplicado.nome}</span> — {duplicado.telefone}
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDuplicado(null)}>Cancelar</Button>
            <Button
              className="bg-primary text-primary-foreground font-bold"
              disabled={saving}
              onClick={async () => {
                const dup = duplicado;
                if (!dup) return;
                setDuplicado(null);
                setSelectedRespId(dup.id);
                await persistirAluno(dup.id);
              }}
            >
              Vincular responsável existente
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}

