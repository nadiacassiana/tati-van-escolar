import { createFileRoute } from "@tanstack/react-router";
import { AssinaturaPage } from "@/components/assinatura-page";

export const Route = createFileRoute("/_authenticated/assinatura")({
  head: () => ({ meta: [{ title: "Assinatura — Tati Van Escolar" }, { name: "robots", content: "noindex" }] }),
  component: AssinaturaPage,
});
