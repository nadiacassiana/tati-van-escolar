import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertTriangle, CheckCircle2, Clock, Copy, MapPin, MessageCircle, Play, Radio,
  Square, Sun, Sunrise, Sunset, Timer, Users, X, Ban, UserCog, ArrowUp, ArrowDown, ExternalLink, School, Send,
  Bus, Home, UserX,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  atualizarParada, criarParadas, encerrarRota, getRotaAtiva, iniciarRota, listarParadas,
  revogarLink, startWatching, stopWatching, trackingUrl, turnoLabel, momentoLabel, sentidoLabel,
  type RotaAtiva, type RotaParada, type Turno, type Sentido, type ParadaStatus,
} from "@/lib/rota-ativa";

type Chave = `${Turno}-${Sentido}`;
const chave = (t: Turno, s: Sentido): Chave => `${t}-${s}`;
const turnoDaChave = (k: Chave): Turno => k.split("-")[0] as Turno;
const sentidoDaChave = (k: Chave): Sentido => k.split("-")[1] as Sentido;
const vazio = <T,>(v: T): Record<Chave, T> => ({
  "manha-ida": v, "manha-volta": v, "tarde-ida": v, "tarde-volta": v,
  "integral-ida": v, "integral-volta": v,
});
import {
  criarRotaSubstituto, getRotaSubstitutoAtiva, revogarRotaSubstituto, substitutoUrl,
  type ParadaSubstituto, type RotaSubstituto,
} from "@/lib/rota-substituto";
import { listarEscolas, salvarEscolaEndereco, mapaEnderecos, type Escola } from "@/lib/escolas";
import { Input } from "@/components/ui/input";

import { getDisplayName, getMotoristaFromUser } from "@/lib/whatsapp";
import { AlunoAvatar } from "@/components/aluno-avatar";
import { GuiaRotasChecklistButton } from "@/components/guia-rotas-checklist";
import { trackEvent } from "@/lib/track-event";
import type { User } from "@supabase/supabase-js";

export const Route = createFileRoute("/_authenticated/checklist")({
  head: () => ({ meta: [{ title: "Checklist Diário — Tati Van" }] }),
  component: ChecklistPage,
});

type Aluno = {
  id: string;
  nome: string;
  avatar: string;
  foto_url: string | null;
  horario_ida: string;
  horario_volta: string;
  endereco: string;
  responsavel: string | null;
  telefone: string | null;
  whatsapp: string | null;
  turno: string | null;
  escola: string | null;
  turma: string | null;
  ordem_rota: number | null;
};

function hourOf(time: string | null | undefined): number | null {
  if (!time) return null;
  const m = /^(\d{1,2}):?(\d{2})?/.exec(time.trim());
  if (!m) return null;
  const h = parseInt(m[1], 10);
  return isNaN(h) ? null : h;
}

function turnoDoAluno(a: Aluno): Turno {
  if (a.turno === "manha" || a.turno === "tarde" || a.turno === "integral") return a.turno;
  const hi = hourOf(a.horario_ida);
  if (hi !== null) return hi < 12 ? "manha" : "tarde";
  const hv = hourOf(a.horario_volta);
  if (hv !== null) return hv < 12 ? "tarde" : "manha";
  return "manha";
}


function onlyDigits(s: string | null | undefined): string {
  return (s || "").replace(/\D/g, "");
}

function elapsed(from: string): string {
  const start = new Date(from).getTime();
  const diff = Math.max(0, Date.now() - start);
  const min = Math.floor(diff / 60000);
  const sec = Math.floor((diff % 60000) / 1000);
  const h = Math.floor(min / 60);
  const mm = String(min % 60).padStart(2, "0");
  const ss = String(sec).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

/** Formata o tempo que falta para o link expirar: "01h 15min" ou "04min 30s". */
function restanteFormatado(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${String(h).padStart(2, "0")}h ${String(m).padStart(2, "0")}min`;
  if (m > 0) return `${String(m).padStart(2, "0")}min ${String(s).padStart(2, "0")}s`;
  return `${s}s`;
}

function ChecklistPage() {
  const [user, setUser] = useState<User | null>(null);
  const [alunos, setAlunos] = useState<Aluno[]>([]);
  const [loading, setLoading] = useState(true);
  const [marcados, setMarcados] = useState<Record<string, boolean>>({});
  const [tab, setTab] = useState<Turno>(() => (new Date().getHours() < 12 ? "manha" : "tarde"));
  const [sentidos, setSentidos] = useState<Record<Turno, Sentido>>({ manha: "ida", tarde: "ida", integral: "ida" });
  const [concluidoEm, setConcluidoEm] = useState<Record<Chave, string | null>>(() => vazio<string | null>(null));
  const [rotas, setRotas] = useState<Record<Chave, RotaAtiva | null>>(() => vazio<RotaAtiva | null>(null));
  const [rotaFinalizada, setRotaFinalizada] = useState<Record<Chave, boolean>>(() => vazio(false));
  const [enviados, setEnviados] = useState<Record<Chave, string[]>>(() => vazio<string[]>([]));
  const [proximoEnvio, setProximoEnvio] = useState<Record<Chave, string | null>>(() => vazio<string | null>(null));
  const [paradas, setParadas] = useState<Record<string, RotaParada>>({}); // aluno_id -> parada
  const [now, setNow] = useState(() => Date.now());

  // modais
  const [startOpen, setStartOpen] = useState<Chave | null>(null);
  const [endOpen, setEndOpen] = useState<Chave | null>(null);
  const [revokeOpen, setRevokeOpen] = useState<Chave | null>(null);
  // duração obrigatória do link público em horas
  const [duracaoHoras, setDuracaoHoras] = useState<number>(2);
  const [iniciandoRota, setIniciandoRota] = useState(false);

  // rota do motorista substituto (link de 24h)
  const [subOpen, setSubOpen] = useState<Turno | null>(null);
  const [subLinks, setSubLinks] = useState<Record<Turno, RotaSubstituto | null>>({ manha: null, tarde: null, integral: null });
  const [subLoading, setSubLoading] = useState(false);
  const [reordenando, setReordenando] = useState<Turno | null>(null);
  const [escolas, setEscolas] = useState<Escola[]>([]);
  const [escolasDraft, setEscolasDraft] = useState<Record<string, string>>({});

  function registrarParadas(lista: RotaParada[]) {
    if (lista.length === 0) return;
    setParadas((prev) => {
      const next = { ...prev };
      for (const p of lista) if (p.aluno_id) next[p.aluno_id] = p;
      return next;
    });
    setMarcados((m) => {
      const next = { ...m };
      for (const p of lista) if (p.aluno_id) next[p.aluno_id] = p.status === "embarcado" || p.status === "desembarcado";
      return next;
    });
  }

  useEffect(() => {
    (async () => {
      const { data: userData } = await supabase.auth.getUser();
      const u = userData.user;
      setUser(u);
      const { data } = await supabase
        .from("alunos")
        .select("id, nome, avatar, foto_url, horario_ida, horario_volta, endereco, responsavel, telefone, whatsapp, turno, escola, turma, ordem_rota");
      setAlunos(((data as unknown) as Aluno[]) || []);
      if (u) {
        const combos: Chave[] = ["manha-ida", "manha-volta", "tarde-ida", "tarde-volta", "integral-ida", "integral-volta"];
        const encontradas = await Promise.all(
          combos.map((k) => getRotaAtiva(u.id, turnoDaChave(k), sentidoDaChave(k))),
        );
        const mapa = vazio<RotaAtiva | null>(null);
        combos.forEach((k, i) => { mapa[k] = encontradas[i]; });
        setRotas(mapa);
        for (const r of encontradas) {
          if (r) {
            startWatching(r.id, r.expira_em);
            registrarParadas(await listarParadas(r.id));
          }
        }
        const [sm, st, si] = await Promise.all([
          getRotaSubstitutoAtiva(u.id, "manha"),
          getRotaSubstitutoAtiva(u.id, "tarde"),
          getRotaSubstitutoAtiva(u.id, "integral"),
        ]);
        setSubLinks({ manha: sm, tarde: st, integral: si });
        listarEscolas().then(setEscolas).catch(() => {});
      }
      setLoading(false);
      trackEvent("checklist_usado");
    })();
  }, []);

  useEffect(() => {
    const t = setInterval(() => {
      const desejado: Turno = new Date().getHours() < 12 ? "manha" : "tarde";
      setTab((cur) => (cur === "integral" || cur === desejado ? cur : desejado));
    }, 60_000);
    return () => clearInterval(t);
  }, []);

  // relógio para "tempo de rota"
  useEffect(() => {
    if (!Object.values(rotas).some(Boolean)) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [rotas]);

  // Ao atingir o horário escolhido, desliga o GPS imediatamente e avisa o motorista.
  const expiradasRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    for (const r of Object.values(rotas)) {
      if (!r?.expira_em || r.encerrada_em) continue;
      if (new Date(r.expira_em).getTime() > now) continue;
      if (expiradasRef.current.has(r.id)) continue;
      expiradasRef.current.add(r.id);
      stopWatching(r.id);
      toast.warning("⌛ Link de rastreio expirado — o GPS foi desligado automaticamente.");
    }
  }, [rotas, now]);

  const { manha, tarde, integral } = useMemo(() => {
    // Ordem definida pela titular (ordem_rota) tem prioridade; senão, horário de ida.
    const sort = (a: Aluno, b: Aluno) => {
      const oa = a.ordem_rota ?? null;
      const ob = b.ordem_rota ?? null;
      if (oa !== null && ob !== null && oa !== ob) return oa - ob;
      if (oa !== null && ob === null) return -1;
      if (oa === null && ob !== null) return 1;
      return (a.horario_ida || "99:99").localeCompare(b.horario_ida || "99:99");
    };
    return {
      manha: alunos.filter((a) => turnoDoAluno(a) === "manha").sort(sort),
      tarde: alunos.filter((a) => turnoDoAluno(a) === "tarde").sort(sort),
      integral: alunos.filter((a) => turnoDoAluno(a) === "integral").sort(sort),
    };
  }, [alunos]);

  const listaDe = (t: Turno): Aluno[] => (t === "manha" ? manha : t === "tarde" ? tarde : integral);

  /** Move um aluno para cima/baixo e salva a sequência (1º, 2º, 3º...) no banco. */
  async function moverAluno(turno: Turno, index: number, dir: -1 | 1) {
    const lista = [...listaDe(turno)];
    const alvo = index + dir;
    if (alvo < 0 || alvo >= lista.length) return;
    const tmp = lista[index];
    lista[index] = lista[alvo];
    lista[alvo] = tmp;
    const ordenados = lista.map((a, i) => ({ ...a, ordem_rota: i }));
    setAlunos((prev) => prev.map((a) => ordenados.find((o) => o.id === a.id) ?? a));
    const { error } = await supabase
      .from("alunos")
      .upsert(ordenados.map((a) => ({ id: a.id, ordem_rota: a.ordem_rota })) as never, { onConflict: "id" });
    if (error) {
      console.warn("[checklist] falha ao salvar ordem:", error.message);
      toast.error("Não foi possível salvar a nova ordem.");
    }
  }

  /** Gera o link de 24h com a rota (sem nenhum dado financeiro) para o substituto. */
  async function gerarLinkSubstituto(turno: Turno) {
    if (!user) return;
    const lista = listaDe(turno);
    if (lista.length === 0) {
      toast.info("Nenhum aluno neste turno.");
      return;
    }
    setSubLoading(true);
    try {
      const enderecos = mapaEnderecos(escolas);
      const paradasSub: ParadaSubstituto[] = lista.map((a) => ({
        nome: a.nome,
        endereco: a.endereco || "",
        escola: a.escola || "",
        escola_endereco: a.escola ? enderecos[a.escola] || "" : "",
        periodo: turnoLabel[turno],
        responsavel: a.responsavel || "",
        telefone: a.telefone || a.whatsapp || "",
      }));
      const link = await criarRotaSubstituto(
        user.id,
        turno,
        getDisplayName(getMotoristaFromUser(user)),
        paradasSub,
      );
      setSubLinks((s) => ({ ...s, [turno]: link }));
      trackEvent("rota_substituto_gerada", `turno ${turno}`);
      toast.success("Link do substituto gerado! Válido por 24 horas.");
    } catch (e) {
      console.error(e);
      toast.error("Não foi possível gerar o link do substituto.");
    } finally {
      setSubLoading(false);
    }
  }

  const enderecoEscola = useMemo(() => mapaEnderecos(escolas), [escolas]);

  /** Salva o endereço de uma escola (chamado ao sair do campo). */
  async function salvarEnderecoEscola(nome: string, endereco: string) {
    if (!user) return;
    setEscolasDraft((d) => {
      const next = { ...d };
      delete next[nome];
      return next;
    });
    if (endereco.trim() === (enderecoEscola[nome] || "")) return;
    try {
      await salvarEscolaEndereco(user.id, nome, endereco);
      setEscolas(await listarEscolas());
      toast.success(`Endereço de ${nome} salvo.`);
    } catch {
      toast.error("Não foi possível salvar o endereço da escola.");
    }
  }

  async function revogarSubstituto(turno: Turno) {
    const link = subLinks[turno];
    if (!link) return;
    await revogarRotaSubstituto(link.id);
    setSubLinks((s) => ({ ...s, [turno]: null }));
    toast.info("Link do substituto desativado.");
  }

  function copiarLinkSubstituto(turno: Turno) {
    const link = subLinks[turno];
    if (!link) return;
    navigator.clipboard?.writeText(substitutoUrl(link.id)).then(
      () => toast.success("Link copiado!"),
      () => toast.error("Não foi possível copiar."),
    );
  }

  function enviarSubstitutoWhatsapp(turno: Turno) {
    const link = subLinks[turno];
    if (!link) return;
    const texto = `Olá! Segue a rota da ${turnoLabel[turno]} com a ordem das paradas:\n\n${substitutoUrl(link.id)}\n\nO link é válido por 24 horas e mostra apenas as informações da rota.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(texto)}`, "_blank", "noopener");
  }

  /** Define o status da parada de um aluno (embarcado, desembarcado, ausente ou pendente). */
  async function definirStatusAluno(alunoId: string, status: ParadaStatus) {
    const parada = paradas[alunoId];
    if (!parada) {
      if (status === "ausente") toast.info("Inicie a rota para registrar ausências no rastreio.");
      return;
    }
    setParadas((prev) => ({ ...prev, [alunoId]: { ...parada, status } }));
    setMarcados((m) => ({ ...m, [alunoId]: status === "embarcado" || status === "desembarcado" }));
    await atualizarParada(parada.id, status);
    const mensagens: Record<ParadaStatus, string> = {
      pendente: "Status resetado.",
      embarcado: "Aluno embarcado na van.",
      desembarcado: "Aluno desembarcado no destino.",
      ausente: "Aluno marcado como ausente — a parada será pulada.",
    };
    toast.success(mensagens[status]);
  }


  const conferir = (lista: Aluno[], k: Chave) => {
    const turno = turnoDaChave(k);
    const sentido = sentidoDaChave(k);
    if (lista.length === 0) { toast.info("Nenhum aluno neste turno."); return; }
    const faltam = lista.filter((a) => paradas[a.id]?.status === "pendente");
    if (faltam.length === 0) {
      const hora = new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
      setConcluidoEm((c) => ({ ...c, [k]: hora }));
      toast.success(
        `✅ Rota de ${sentidoLabel[sentido]} — ${turnoLabel[turno]} concluída! Todos os ${lista.length} alunos atendidos às ${hora}.`,
      );

    } else {
      toast.warning(`Atenção: ${faltam.length} aluno(s) ainda não foram marcados!`, {
        description: faltam.map((a) => a.nome).join(", "),
      });
    }
  };

  async function pedirPermissaoGeo(): Promise<boolean> {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      toast.error("Seu navegador não suporta geolocalização.");
      return false;
    }
    try {
      await new Promise<GeolocationPosition>((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 15_000 }),
      );
      return true;
    } catch {
      toast.error("Precisamos da sua localização para iniciar o rastreio. Autorize no navegador e tente de novo.");
      return false;
    }
  }

  async function criarRotaSeNecessario(k: Chave): Promise<RotaAtiva | null> {
    if (!user) return null;
    const turno = turnoDaChave(k);
    const sentido = sentidoDaChave(k);
    if (rotas[k]) return rotas[k];
    const ok = await pedirPermissaoGeo();
    if (!ok) return null;
    const nome = getDisplayName(getMotoristaFromUser(user));
    try {
      const rota = await iniciarRota(user.id, turno, nome, duracaoHoras, sentido);
      setRotas((r) => ({ ...r, [k]: rota }));
      setRotaFinalizada((r) => ({ ...r, [k]: false }));
      const novas = await criarParadas(
        rota.id,
        user.id,
        listaDe(turno).map((a) => ({ id: a.id, nome: a.nome })),
      );
      registrarParadas(novas);
      trackEvent("rota_iniciada", `turno ${turno} ${sentido}`);
      return rota;
    } catch (e) {
      console.error(e);
      toast.error("Não foi possível iniciar a rota.");
      return null;
    }
  }


  async function confirmarRevogar(k: Chave) {
    const rota = rotas[k];
    if (!rota) return;
    await revogarLink(rota.id);
    setRotas((r) => ({ ...r, [k]: r[k] ? { ...(r[k] as RotaAtiva), revogada_em: new Date().toISOString() } : r[k] }));
    setRevokeOpen(null);
    toast.info("🚫 Link público revogado. Os responsáveis não conseguirão mais acessar o rastreio.");
  }

  function mensagemRastreio(url: string, k: Chave): string {
    const momento = momentoLabel[turnoDaChave(k)][sentidoDaChave(k)];
    return `Olá! A van escolar iniciou a rota (${momento}). Acompanhe a localização em tempo real através deste link:\n\n${url}\n\nEste link ficará ativo somente durante esta rota.`;
  }

  function abrirWhatsapp(numero: string, texto: string) {
    const num = onlyDigits(numero);
    if (!num) return false;
    const full = num.length <= 11 ? `55${num}` : num;
    const url = `https://wa.me/${full}?text=${encodeURIComponent(texto)}`;
    window.open(url, "_blank", "noopener");
    return true;
  }

  async function apenasIniciar(k: Chave) {
    if (iniciandoRota) return;
    setIniciandoRota(true);
    try {
      const rota = await criarRotaSeNecessario(k);
      if (!rota) return;
      setStartOpen(null);
      toast.success("🚐 Rota iniciada! Envie o rastreio pelos cartões dos alunos ou copie o link geral.");
    } finally {
      setIniciandoRota(false);
    }
  }

  function enviarRastreioAluno(a: Aluno, index: number, lista: Aluno[], rota: RotaAtiva, k: Chave) {
    const parada = paradas[a.id];
    if (!parada) {
      toast.error("O link individual deste aluno ainda não está pronto.");
      return;
    }
    const abriu = abrirWhatsapp(
      a.whatsapp || a.telefone || "",
      mensagemRastreio(trackingUrl(rota.id, parada.id), k),
    );
    if (!abriu) {
      toast.info("Cadastre o WhatsApp do responsável para enviar o rastreio.");
      return;
    }
    const jaEnviados = new Set([...enviados[k], a.id]);
    setEnviados((atual) => ({ ...atual, [k]: [...jaEnviados] }));
    const candidatos = [...lista.slice(index + 1), ...lista.slice(0, index)]
      .filter((aluno) => (aluno.whatsapp || aluno.telefone) && !jaEnviados.has(aluno.id));
    setProximoEnvio((atual) => ({ ...atual, [k]: candidatos[0]?.id ?? null }));
    trackEvent("link_compartilhado", "rastreio individual");
    trackEvent("whatsapp_enviado", a.nome);
  }

  async function confirmarEncerrar(k: Chave) {
    const rota = rotas[k];
    if (!rota) return;
    await encerrarRota(rota.id);
    setRotas((r) => ({ ...r, [k]: null }));
    setRotaFinalizada((r) => ({ ...r, [k]: true }));
    setEnviados((c) => ({ ...c, [k]: [] }));
    setProximoEnvio((c) => ({ ...c, [k]: null }));
    setEndOpen(null);
    toast.info(`Rota ${momentoLabel[turnoDaChave(k)][sentidoDaChave(k)]} encerrada. Links desativados.`);
  }


  function copiarLink(rota: RotaAtiva) {
    const url = trackingUrl(rota.id);
    navigator.clipboard?.writeText(url).then(
      () => toast.success("Link de rastreio copiado!"),
      () => toast.error("Não foi possível copiar."),
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h1 className="text-2xl font-extrabold">Checklist Diário ✅</h1>
          <p className="text-sm text-muted-foreground">
            A Tati separa automaticamente os alunos por turno. Marque cada um conforme entrar na van.
          </p>
        </div>
        <GuiaRotasChecklistButton />
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as Turno)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="manha" className="gap-2">
            <Sunrise className="h-4 w-4" /> Manhã ({manha.length})
          </TabsTrigger>
          <TabsTrigger value="tarde" className="gap-2">
            <Sunset className="h-4 w-4" /> Tarde ({tarde.length})
          </TabsTrigger>
          <TabsTrigger value="integral" className="gap-2">
            <Sun className="h-4 w-4" /> Integral ({integral.length})
          </TabsTrigger>
        </TabsList>

        {(["manha", "tarde", "integral"] as Turno[]).map((turno) => {
          const sentido = sentidos[turno];
          const k = chave(turno, sentido);
          const lista = listaDe(turno);
          const total = lista.length;
          const marcadosCount = lista.filter((a) => marcados[a.id]).length;
          const titulo = `Rota de ${momentoLabel[turno][sentido]}`;
          const concluida = concluidoEm[k];
          const rota = rotas[k];
          const finalizada = rotaFinalizada[k];
          const compartilhadosCount = enviados[k].length;

          return (
            <TabsContent key={turno} value={turno}>
              <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
                {/* Seletor do sentido do percurso */}
                <div className="mb-4 grid grid-cols-2 gap-2 rounded-xl bg-secondary/50 p-1">
                  {(["ida", "volta"] as Sentido[]).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setSentidos((cur) => ({ ...cur, [turno]: s }))}
                      className={`rounded-lg px-2 py-2 text-xs font-bold transition-all ${
                        sentido === s ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:bg-secondary"
                      }`}
                    >
                      {s === "ida" ? "🚌 " : "🏠 "}{sentidoLabel[s]}
                    </button>
                  ))}
                </div>
                <div className="mb-4 flex items-center justify-between rounded-xl bg-secondary/60 px-4 py-3">
                  <div className="text-sm">
                    <div className="font-bold">{titulo} — {new Date().toLocaleDateString("pt-BR")}</div>
                    <div className="text-muted-foreground">{marcadosCount} de {total} alunos atendidos</div>
                  </div>
                  <div className="text-3xl font-extrabold text-primary">{marcadosCount}/{total}</div>
                </div>

                {/* ================= CENTRO DE CONTROLE DA ROTA ================= */}
                <CentroDeControle
                  turno={turno}
                  sentido={sentido}
                  rota={rota}
                  finalizada={finalizada}
                  compartilhados={compartilhadosCount}
                  marcadosCount={marcadosCount}
                  total={total}
                  now={now}
                  onIniciar={() => {
                    setDuracaoHoras(2);
                    setStartOpen(k);
                  }}
                  onCopiar={() => rota && copiarLink(rota)}
                  onRevogar={() => setRevokeOpen(k)}
                  onEncerrar={() => setEndOpen(k)}
                  onDismissFinalizada={() => setRotaFinalizada((r) => ({ ...r, [k]: false }))}
                />

                {concluida && total > 0 && marcadosCount === total && (
                  <div className="mb-4 rounded-xl border border-success/30 bg-success/10 p-4 text-sm font-medium text-success animate-fade-in">
                    ✅ {titulo} concluída! Todos os {total} alunos foram atendidos com sucesso às {concluida}.
                  </div>
                )}

                {loading ? (
                  <div className="py-6 text-center text-sm text-muted-foreground">Carregando...</div>
                ) : lista.length === 0 ? (
                  <div className="py-6 text-center text-sm text-muted-foreground">
                    Nenhum aluno cadastrado para o turno da {turnoLabel[turno]}.
                  </div>
                ) : (
                  <ul className="space-y-3">
                    {lista.map((a, idx) => {
                      const status = paradas[a.id]?.status ?? "pendente";
                      const ordenando = reordenando === turno;
                      const statusConfig: Record<ParadaStatus, { label: string; cor: string; icone: React.ReactNode; msg: string }> = {
                        pendente: { label: "Pendente", cor: "text-muted-foreground", icone: null, msg: "" },
                        embarcado: { label: "Embarcou", cor: "text-primary", icone: <Bus className="h-3.5 w-3.5" />, msg: "Embarcou na van" },
                        desembarcado: { label: "Desembarcou", cor: "text-success", icone: <Home className="h-3.5 w-3.5" />, msg: "Chegou ao destino" },
                        ausente: { label: "Ausente", cor: "text-destructive", icone: <UserX className="h-3.5 w-3.5" />, msg: "Não fará a rota hoje" },
                      };
                      const cfg = statusConfig[status];
                      const cardBase = "rounded-2xl border p-4 transition-all";
                      const cardClasse =
                        status === "ausente"
                          ? `${cardBase} bg-destructive/5 border-destructive/20 opacity-80`
                          : status === "embarcado"
                            ? `${cardBase} bg-primary/5 border-primary/30`
                            : status === "desembarcado"
                              ? `${cardBase} bg-success/5 border-success/30`
                              : `${cardBase} bg-card hover:bg-secondary/40`;

                      return (
                        <li
                          key={a.id}
                          data-aluno-id={a.id}
                          className={`${cardClasse} ${proximoEnvio[k] === a.id ? "ring-2 ring-success ring-offset-2 ring-offset-background" : ""}`}
                        >
                          {proximoEnvio[k] === a.id && (
                            <div className="mb-3 flex items-center gap-2 rounded-lg bg-success/10 px-3 py-2 text-xs font-extrabold text-success">
                              <MessageCircle className="h-4 w-4" /> Próximo envio sugerido
                            </div>
                          )}
                          {ordenando ? (
                            <div className="flex items-center gap-3">
                              <span className="grid h-8 w-8 shrink-0 place-content-center rounded-full bg-accent text-xs font-extrabold text-accent-foreground">
                                {idx + 1}º
                              </span>
                              <AlunoAvatar nome={a.nome} foto_url={a.foto_url} avatar={a.avatar} size={44} />
                              <div className="flex-1 min-w-0">
                                <div className="font-bold truncate">{a.nome}</div>
                                <div className="text-xs text-muted-foreground truncate">{a.endereco}</div>
                              </div>
                              <div className="flex flex-col gap-1">
                                <button type="button" title="Subir" disabled={idx === 0}
                                  onClick={() => void moverAluno(turno, idx, -1)}
                                  className="rounded-lg border px-2 py-1 hover:bg-secondary disabled:opacity-30">
                                  <ArrowUp className="h-4 w-4" />
                                </button>
                                <button type="button" title="Descer" disabled={idx === lista.length - 1}
                                  onClick={() => void moverAluno(turno, idx, 1)}
                                  className="rounded-lg border px-2 py-1 hover:bg-secondary disabled:opacity-30">
                                  <ArrowDown className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                          ) : (
                            <>
                              <div className="flex items-start gap-3">
                                <AlunoAvatar nome={a.nome} foto_url={a.foto_url} avatar={a.avatar} size={52} />
                                <div className="min-w-0 flex-1">
                                  <div className="font-bold text-base leading-tight">{a.nome}</div>
                                  <div className="mt-0.5 text-xs text-muted-foreground flex items-center gap-1">
                                    <Clock className="h-3 w-3" />{" "}
                                    {sentido === "volta" ? a.horario_volta || a.horario_ida : a.horario_ida}
                                  </div>
                                  <div className="text-xs text-muted-foreground truncate">{a.endereco}</div>
                                  {status !== "pendente" && (
                                    <div className={`mt-1 flex items-center gap-1 text-[11px] font-bold ${cfg.cor}`}>
                                      {cfg.icone} {cfg.msg}
                                    </div>
                                  )}
                                </div>
                              </div>

                              <div className="mt-3 grid grid-cols-3 gap-2">
                                <button
                                  type="button"
                                  onClick={() => void definirStatusAluno(a.id, status === "embarcado" ? "pendente" : "embarcado")}
                                  className={`flex h-10 items-center justify-center gap-1 rounded-xl text-[11px] font-extrabold transition-all ${
                                    status === "embarcado"
                                      ? "bg-primary text-primary-foreground shadow-sm ring-2 ring-primary/40"
                                      : "border border-primary/40 text-primary hover:bg-primary/10"
                                  }`}
                                >
                                  <Bus className="h-3.5 w-3.5" /> Embarcou
                                </button>
                                <button
                                  type="button"
                                  onClick={() => void definirStatusAluno(a.id, status === "desembarcado" ? "pendente" : "desembarcado")}
                                  className={`flex h-10 items-center justify-center gap-1 rounded-xl text-[11px] font-extrabold transition-all ${
                                    status === "desembarcado"
                                      ? "bg-success text-success-foreground shadow-sm ring-2 ring-success/40"
                                      : "border border-success/40 text-success hover:bg-success/10"
                                  }`}
                                >
                                  <Home className="h-3.5 w-3.5" /> Desembarcou
                                </button>
                                <button
                                  type="button"
                                  onClick={() => void definirStatusAluno(a.id, status === "ausente" ? "pendente" : "ausente")}
                                  className={`flex h-10 items-center justify-center gap-1 rounded-xl text-[11px] font-extrabold transition-all ${
                                    status === "ausente"
                                      ? "bg-destructive text-destructive-foreground shadow-sm ring-2 ring-destructive/40"
                                      : "border border-destructive/40 text-destructive hover:bg-destructive/10"
                                  }`}
                                >
                                  <UserX className="h-3.5 w-3.5" /> Ausente
                                </button>
                              </div>
                              <Button
                                type="button"
                                onClick={() => rota && enviarRastreioAluno(a, idx, lista, rota, k)}
                                disabled={!rota || !!rota.revogada_em || !(a.whatsapp || a.telefone) || !paradas[a.id]}
                                className="mt-2 h-10 w-full bg-success font-extrabold text-success-foreground hover:bg-success/90"
                                title={a.whatsapp || a.telefone ? "Enviar link individual pelo WhatsApp" : "Responsável sem WhatsApp cadastrado"}
                              >
                                <MessageCircle className="h-4 w-4" />
                                {enviados[k].includes(a.id) ? "Rastreio enviado — enviar novamente" : "Enviar Rastreio"}
                              </Button>
                            </>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                )}

                {/* ============ ROTA PARA MOTORISTA SUBSTITUTO ============ */}
                <div className="mt-6 rounded-2xl border-2 border-dashed border-accent/40 bg-accent/5 p-4">
                  <div className="flex items-start gap-3">
                    <div className="grid h-10 w-10 shrink-0 place-content-center rounded-full bg-accent/20 text-accent-foreground">
                      <UserCog className="h-5 w-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-extrabold">🧑‍✈️ Motorista substituto</div>
                      <p className="mt-0.5 text-xs text-muted-foreground leading-relaxed">
                        Gere um link de 24h com a sequência de paradas, endereços e telefones de emergência.
                        Nenhum dado financeiro é exibido.
                      </p>
                    </div>
                  </div>

                  <div className="mt-3 flex flex-col gap-2 sm:grid sm:grid-cols-2">
                    <Button
                      variant={reordenando === turno ? "default" : "outline"}
                      className="w-full font-bold h-10"
                      onClick={() => setReordenando(reordenando === turno ? null : turno)}
                    >
                      {reordenando === turno ? "✔ Concluir ordem" : "↕ Reordenar paradas"}
                    </Button>
                    <Button
                      className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-bold h-10"
                      disabled={subLoading}
                      onClick={() => void gerarLinkSubstituto(turno)}
                    >
                      <Send className="h-4 w-4" /> {subLinks[turno] ? "Gerar novo link" : "Enviar Rota para Substituto"}
                    </Button>
                  </div>

                  {subLinks[turno] && (
                    <div className="mt-3 rounded-xl border bg-card p-3">
                      <div className="text-xs font-semibold flex items-center gap-1.5">
                        <Timer className="h-3.5 w-3.5 text-primary" />
                        Link ativo até {new Date(subLinks[turno]!.expira_em).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}
                      </div>
                      <div className="mt-2 grid grid-cols-2 gap-2">
                        <Button variant="outline" className="h-9 font-bold" onClick={() => enviarSubstitutoWhatsapp(turno)}>
                          <Send className="h-4 w-4" /> WhatsApp
                        </Button>
                        <Button variant="outline" className="h-9 font-bold" onClick={() => copiarLinkSubstituto(turno)}>
                          <Copy className="h-4 w-4" /> Copiar link
                        </Button>
                        <Button variant="outline" className="h-9 font-bold" asChild>
                          <a href={substitutoUrl(subLinks[turno]!.id)} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4" /> Abrir
                          </a>
                        </Button>
                        <Button variant="destructive" className="h-9 font-bold" onClick={() => setSubOpen(turno)}>
                          <Ban className="h-4 w-4" /> Desativar
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Endereços das escolas desta rota (aparecem no link do substituto) */}
                  {[...new Set(lista.map((a) => a.escola).filter((e): e is string => !!e))].length > 0 && (
                    <div className="mt-3 rounded-xl border bg-card p-3 space-y-2">
                      <div className="text-xs font-semibold flex items-center gap-1.5">
                        <School className="h-3.5 w-3.5 text-primary" /> Endereços das escolas desta rota
                      </div>
                      <p className="text-[11px] text-muted-foreground leading-relaxed">
                        Preencha uma vez — o endereço aparece no link do substituto com botão de navegação até a escola.
                      </p>
                      {[...new Set(lista.map((a) => a.escola).filter((e): e is string => !!e))].map((nome) => (
                        <div key={nome}>
                          <label className="text-[11px] font-medium">{nome}</label>
                          <Input
                            className="mt-1 h-9 text-sm"
                            placeholder="Rua, número, bairro, cidade"
                            value={escolasDraft[nome] ?? enderecoEscola[nome] ?? ""}
                            onChange={(e) => setEscolasDraft((d) => ({ ...d, [nome]: e.target.value }))}
                            onBlur={(e) => void salvarEnderecoEscola(nome, e.target.value)}
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <Button onClick={() => conferir(lista, k)}
                  className="mt-6 w-full bg-accent text-accent-foreground hover:bg-accent/90 font-bold text-base h-12">
                  <AlertTriangle className="mr-2 h-4 w-4" />{" "}
                  {sentido === "volta" ? "Conferir: todos embarcaram na escola?" : "Conferir: todos foram buscados?"}
                </Button>
              </Card>
            </TabsContent>
          );
        })}
      </Tabs>

      {/* ================= MODAL: INICIAR ROTA ================= */}
      <Dialog open={startOpen !== null} onOpenChange={(o) => !o && setStartOpen(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl">
              Iniciar Rota de {startOpen ? momentoLabel[turnoDaChave(startOpen)][sentidoDaChave(startOpen)] : ""} 🚐
            </DialogTitle>
            <DialogDescription>
              {startOpen && sentidoDaChave(startOpen) === "volta"
                ? "Percurso da volta: embarque na escola e desembarque nas casas dos alunos."
                : "Percurso da ida: recolhimento nas casas e entrega na escola."}{" "}
              O rastreamento ficará ativo apenas durante este percurso.
            </DialogDescription>
          </DialogHeader>
          <div className="rounded-xl border bg-secondary/40 p-3 mb-2">
            <div className="text-xs font-semibold flex items-center gap-1.5">
              <Timer className="h-3.5 w-3.5 text-primary" />
              Por quanto tempo o link ficará ativo?
            </div>
            <div className="mt-2 grid grid-cols-3 gap-1.5">
              {[
                { label: "1h", v: 1 },
                { label: "2h", v: 2 },
                { label: "3h", v: 3 },
              ].map((o) => (
                <button
                  key={o.label}
                  type="button"
                  onClick={() => setDuracaoHoras(o.v)}
                  className={`rounded-lg border px-2 py-1.5 text-xs font-bold transition-all ${
                    duracaoHoras === o.v
                      ? "border-primary bg-primary text-primary-foreground"
                      : "bg-card hover:bg-secondary"
                  }`}
                >
                  {o.label}
                </button>
              ))}
            </div>
            <div className="text-[10px] text-muted-foreground mt-2">
              Ao terminar esse tempo, o link deixa de funcionar e o envio da localização é desligado automaticamente — mesmo se você esquecer de encerrar a rota.
            </div>

          </div>
          <Button
            onClick={() => startOpen && apenasIniciar(startOpen)}
            disabled={iniciandoRota}
            className="h-12 w-full text-base font-extrabold"
          >
            <Play className="h-5 w-5" /> {iniciandoRota ? "Iniciando..." : "Iniciar Rota"}
          </Button>
        </DialogContent>
      </Dialog>

      {/* ================= MODAL: ENCERRAR ROTA ================= */}
      <Dialog open={endOpen !== null} onOpenChange={(o) => !o && setEndOpen(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Encerrar rota?</DialogTitle>
            <DialogDescription>
              O rastreamento será finalizado e o link deixará de funcionar para todos os responsáveis.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEndOpen(null)}>Cancelar</Button>
            <Button
              variant="destructive"
              onClick={() => endOpen && confirmarEncerrar(endOpen)}
              className="font-bold"
            >
              <Square className="mr-2 h-4 w-4" /> Encerrar rota
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ================= MODAL: REVOGAR LINK ================= */}
      <Dialog open={revokeOpen !== null} onOpenChange={(o) => !o && setRevokeOpen(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Revogar link público?</DialogTitle>
            <DialogDescription>
              O link deixa de funcionar imediatamente para todos os responsáveis. A rota permanece ativa para você — se quiser gerar um novo link, encerre e reinicie a rota.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRevokeOpen(null)}>Cancelar</Button>
            <Button
              variant="destructive"
              onClick={() => revokeOpen && confirmarRevogar(revokeOpen)}
              className="font-bold"
            >
              <Ban className="mr-2 h-4 w-4" /> Revogar agora
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={subOpen !== null} onOpenChange={(o) => !o && setSubOpen(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Desativar link do substituto?</DialogTitle>
            <DialogDescription>
              O link para o motorista substituto deixa de funcionar imediatamente. Você pode gerar um novo quando quiser.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSubOpen(null)}>Cancelar</Button>
            <Button
              variant="destructive"
              className="font-bold"
              onClick={() => {
                if (subOpen) void revogarSubstituto(subOpen);
                setSubOpen(null);
              }}
            >
              <Ban className="mr-2 h-4 w-4" /> Desativar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================================
// Centro de Controle da Rota — card superior com 3 estados
// ============================================================================

type CentroProps = {
  turno: Turno;
  sentido: Sentido;
  rota: RotaAtiva | null;
  finalizada: boolean;
  compartilhados: number;
  marcadosCount: number;
  total: number;
  now: number;
  onIniciar: () => void;
  onCopiar: () => void;
  onRevogar: () => void;
  onEncerrar: () => void;
  onDismissFinalizada: () => void;
};

function CentroDeControle(p: CentroProps) {
  const { rota, finalizada, compartilhados, marcadosCount, total, now, turno, sentido } = p;
  // referência para evitar warning de 'now' não usado
  const nowRef = useRef(now);
  nowRef.current = now;
  const restanteMs = rota?.expira_em ? new Date(rota.expira_em).getTime() - now : null;
  const expirado = restanteMs != null && restanteMs <= 0;

  // Estado: rota concluída
  if (finalizada) {
    return (
      <div className="mb-4 rounded-2xl border-2 border-success/40 bg-gradient-to-br from-success/10 to-success/5 p-5 animate-fade-in">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-content-center rounded-full bg-success text-white">
              <CheckCircle2 className="h-6 w-6" />
            </div>
            <div>
              <div className="text-base font-extrabold text-success">✅ Rota concluída com sucesso</div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Todos os links de rastreamento foram desativados automaticamente.
              </div>
            </div>
          </div>
          <button onClick={p.onDismissFinalizada} className="text-muted-foreground hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  // Estado: rota ativa
  if (rota) {
    return (
      <div className="mb-4 rounded-2xl border-2 border-primary bg-gradient-to-br from-primary to-primary/80 p-5 text-primary-foreground shadow-lg animate-fade-in">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="relative grid h-11 w-11 place-content-center rounded-full bg-white/20">
              <Radio className="h-5 w-5" />
              <span className="absolute inset-0 rounded-full bg-white/30 animate-ping" aria-hidden />
            </div>
            <div>
              <div className="text-base font-extrabold flex items-center gap-2">
                🟢 Rota em andamento
              </div>
              <div className="text-xs flex items-center gap-1.5 text-primary-foreground/90 mt-0.5">
                <span className="inline-flex h-2 w-2 rounded-full bg-white animate-pulse" aria-hidden />
                <span className="font-medium animate-pulse">📍 Rastreamento ativo</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] uppercase tracking-wide text-primary-foreground/70">Tempo de rota</div>
            <div className="text-xl font-extrabold tabular-nums">{elapsed(rota.iniciada_em)}</div>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2">
          <div className="rounded-xl bg-white/15 backdrop-blur px-3 py-2">
            <div className="text-[10px] uppercase tracking-wide text-primary-foreground/70 flex items-center gap-1">
              <Users className="h-3 w-3" /> Responsáveis
            </div>
            <div className="text-lg font-extrabold">{compartilhados}</div>
          </div>
          <div className="rounded-xl bg-white/15 backdrop-blur px-3 py-2">
            <div className="text-[10px] uppercase tracking-wide text-primary-foreground/70 flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" /> Alunos embarcados
            </div>
            <div className="text-lg font-extrabold">{marcadosCount}/{total}</div>
          </div>
        </div>

        {rota.revogada_em ? (
          <div className="mt-3 rounded-xl bg-white/15 px-3 py-2 text-xs font-semibold flex items-center gap-1.5">
            <Ban className="h-3.5 w-3.5" /> Link público revogado — responsáveis não conseguem mais abrir o rastreio.
          </div>
        ) : rota.expira_em ? (
          <div className={`mt-3 rounded-xl px-3 py-2 text-xs font-semibold flex items-center gap-1.5 ${expirado ? "bg-destructive/80" : "bg-white/15"}`}>
            <Timer className="h-3.5 w-3.5" />
            {expirado ? (
              <>Link expirado ⌛ — o GPS foi desligado e os responsáveis não acessam mais o rastreio.</>
            ) : (
              <>
                <span className="tabular-nums">Link expira em: {restanteFormatado(restanteMs!)}</span>
                <span className="font-normal opacity-80">
                  (às {new Date(rota.expira_em).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })})
                </span>
              </>
            )}
          </div>
        ) : (
          <div className="mt-3 rounded-xl bg-white/15 px-3 py-2 text-xs font-medium flex items-center gap-1.5">
            <Timer className="h-3.5 w-3.5" /> Link expira quando você encerrar a rota.
          </div>
        )}

        <div className="mt-4 grid grid-cols-2 gap-2">
          <Button
            onClick={p.onCopiar}
            disabled={!!rota.revogada_em}
            variant="outline"
            className="col-span-2 bg-white text-primary hover:bg-white/90 font-bold h-10 disabled:opacity-60"
          >
            <Copy className="h-4 w-4" /> Copiar Link Geral
          </Button>
          <Button
            onClick={p.onRevogar}
            disabled={!!rota.revogada_em}
            variant="outline"
            className="bg-white/10 border-white/40 text-white hover:bg-white/20 hover:text-white font-bold h-10 disabled:opacity-60"
          >
            <Ban className="h-4 w-4" /> Revogar link
          </Button>
          <Button
            onClick={p.onEncerrar}
            variant="destructive"
            className="font-bold h-10"
          >
            <Square className="h-4 w-4" /> Encerrar
          </Button>
        </div>
      </div>
    );
  }

  // Estado: não iniciado
  return (
    <div className="mb-4 rounded-2xl border-2 border-dashed border-primary/30 bg-gradient-to-br from-secondary/40 to-secondary/10 p-5 animate-fade-in">
      <div className="flex items-start gap-3">
        <div className="grid h-11 w-11 place-content-center rounded-full bg-primary/10 text-primary shrink-0">
          <MapPin className="h-6 w-6" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-base font-extrabold">🚐 Rastreamento em tempo real</div>
          <div className="text-xs text-muted-foreground mt-0.5">
            Status: <span className="font-semibold text-foreground">Não iniciado</span>
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Percurso: <span className="font-semibold text-foreground">{sentidoLabel[sentido]}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
            Ao iniciar a rota, a Tati criará um link temporário de rastreamento que poderá ser compartilhado com
            os responsáveis. O link será encerrado automaticamente quando a rota terminar.
          </p>
        </div>
      </div>
      <Button
        onClick={p.onIniciar}
        className="mt-4 w-full bg-primary font-bold h-11 text-base transition-transform hover:scale-[1.01]"
      >
        <Play className="h-4 w-4" /> Iniciar Rota de {momentoLabel[turno][sentido]}
      </Button>
    </div>
  );
}
