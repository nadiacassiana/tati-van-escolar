import { createFileRoute, Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { ChevronRight, Rocket, Settings } from "lucide-react";
import { DadosBasicosForm } from "@/components/dados-basicos-form";

export const Route = createFileRoute("/_authenticated/comece-aqui")({
  head: () => ({
    meta: [
      { title: "Comece por aqui — Tati Van Escolar" },
      { name: "description", content: "Preencha seus dados básicos. Eles serão usados automaticamente nos recibos, contratos e mensagens enviadas aos responsáveis." },
      { property: "og:title", content: "Comece por aqui — Tati Van Escolar" },
      { property: "og:description", content: "Preencha seus dados básicos para começar a usar o sistema." },
    ],
  }),
  component: ComecePage,
});

function ComecePage() {
  const { user } = Route.useRouteContext();

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">Comece por aqui 🚀</h1>
        <p className="text-sm text-muted-foreground">
          Preencha seus dados básicos. Eles serão usados automaticamente nos recibos,
          contratos e mensagens enviadas aos responsáveis.
        </p>
      </div>

      <Card className="flex items-start gap-3 bg-accent/30 p-4" style={{ boxShadow: "var(--shadow-card)" }}>
        <Rocket className="mt-0.5 h-5 w-5 text-accent-foreground" />
        <p className="text-sm text-muted-foreground">
          Primeiro acesso? Complete esta página e depois cadastre seus alunos em <strong>Meus Alunos</strong>.
        </p>
      </Card>

      <DadosBasicosForm user={user} />

      <Link to="/configuracoes">
        <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold">
              <Settings className="h-4 w-4" /> Logotipo, backup e outras configurações
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
          <p className="mt-1 text-sm text-muted-foreground">Ajustes secundários ficam em Conta → Configurações.</p>
        </Card>
      </Link>
    </div>
  );
}
