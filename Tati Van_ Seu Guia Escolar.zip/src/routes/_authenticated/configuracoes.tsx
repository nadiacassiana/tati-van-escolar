import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Download, FileSpreadsheet, FileText, Heart, LogOut, Loader2, Trash2, AlertTriangle, Smartphone, ChevronRight, HelpCircle, ImagePlus, Eye, Route as RouteIcon } from "lucide-react";
import { downloadBackup } from "@/lib/backup";
import { fileToLogoDataUrl } from "@/lib/image";
import { saveVanLogo, useVanLogo } from "@/lib/logo-store";
import { IdentidadePreviewDialog } from "@/components/identidade-preview";
import { PushAtivarCard } from "@/components/push-ativar-card";
import { EscolasManager } from "@/components/escolas-manager";
import { Switch } from "@/components/ui/switch";
import { sonsAtivos, setSonsAtivos, tocarSucesso } from "@/lib/sons";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { deleteAccount } from "@/lib/delete-account.functions";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const MOTIVOS_EXCLUSAO: { value: string; label: string }[] = [
  { value: "preco", label: "O preço da assinatura não atendeu às minhas expectativas." },
  { value: "funcionalidades", label: "Não encontrei as funcionalidades que precisava." },
  { value: "dificuldade", label: "Achei a plataforma difícil de utilizar." },
  { value: "parou_atividade", label: "Vou parar de trabalhar com transporte escolar." },
  { value: "outro_sistema", label: "Estou utilizando outro sistema." },
  { value: "problemas_tecnicos", label: "Tive problemas técnicos." },
  { value: "outro", label: "Outro motivo (posso escrever abaixo)." },
];

export const Route = createFileRoute("/_authenticated/configuracoes")({
  head: () => ({ meta: [{ title: "Configurações — Tati Van" }] }),
  component: ConfigPage,
});

function ConfigPage() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const [sons, setSons] = useState(true);
  useEffect(() => setSons(sonsAtivos()), []);
  const TRIAL_DAYS = 10;
  const createdAt = user?.created_at ? new Date(user.created_at).getTime() : Date.now();
  const elapsed = Math.floor((Date.now() - createdAt) / (1000 * 60 * 60 * 24));
  const remaining = Math.max(0, TRIAL_DAYS - elapsed);

  const meta = (user?.user_metadata || {}) as { nome_completo?: string; empresa?: string };
  const nomeCompleto = meta.nome_completo || "";
  const empresa = meta.empresa || "";
  const logo = useVanLogo();
  const [logoBusy, setLogoBusy] = useState(false);
  const [previewDocs, setPreviewDocs] = useState(false);

  const handleLogoFile = async (file: File | null | undefined) => {
    if (!file) return;
    if (!/^image\/(png|jpe?g)$/i.test(file.type)) {
      toast.error("Envie uma imagem PNG ou JPG.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("A imagem deve ter no máximo 5 MB.");
      return;
    }
    setLogoBusy(true);
    try {
      const dataUrl = await fileToLogoDataUrl(file);
      // O logotipo vai para o perfil (banco). Nunca para os dados de login.
      const { error } = await saveVanLogo(dataUrl);
      if (error) {
        toast.error("Não foi possível salvar o logotipo.", { description: error });
        return;
      }
      toast.success("Logotipo salvo! Já será usado nos seus documentos.");
    } catch (e) {
      console.error("[logo] erro no envio:", e);
      toast.error("Não foi possível processar a imagem.", { description: e instanceof Error ? e.message : undefined });
    } finally {
      setLogoBusy(false);
    }
  };

  const handleRemoveLogo = async () => {
    setLogoBusy(true);
    const { error } = await saveVanLogo("");
    setLogoBusy(false);
    if (error) return toast.error("Não foi possível remover o logotipo.", { description: error });
    toast.success("Logotipo removido. Os documentos voltam a usar apenas o nome da van.");
  };




  const [exporting, setExporting] = useState<"pdf" | "xlsx" | null>(null);
  const [deleteStep, setDeleteStep] = useState<"reason" | "confirm" | null>(null);
  const [deleteMotivo, setDeleteMotivo] = useState<string>("");
  const [deleteMotivoTexto, setDeleteMotivoTexto] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState("");
  const [deleting, setDeleting] = useState(false);
  const runDeleteAccount = useServerFn(deleteAccount);

  const openDeleteFlow = () => {
    setDeleteMotivo("");
    setDeleteMotivoTexto("");
    setDeleteConfirm("");
    setDeleteStep("reason");
  };

  const handleDeleteAccount = async () => {
    if (deleteConfirm !== "EXCLUIR") return;
    setDeleting(true);
    const tid = toast.loading("Excluindo sua conta e todos os dados...");
    try {
      await runDeleteAccount({
        data: {
          motivo: deleteMotivo || null,
          motivo_texto: deleteMotivoTexto.trim() || null,
        },
      });
      await supabase.auth.signOut();
      toast.success("Conta excluída. Sentiremos sua falta 💛", { id: tid });
      navigate({ to: "/", replace: true });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Erro desconhecido";
      toast.error("Não foi possível excluir a conta.", { id: tid, description: msg });
      setDeleting(false);
    }
  };

  const exportar = async (fmt: "pdf" | "xlsx") => {
    if (!user?.id || exporting) return;
    setExporting(fmt);
    const tid = toast.loading("Gerando seu backup...");
    try {
      await downloadBackup(user.id, fmt);
      toast.success("✅ Backup gerado com sucesso.", { id: tid });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Erro desconhecido";
      toast.error("Não foi possível gerar o backup. Tente novamente.", { id: tid, description: msg });
    } finally {
      setExporting(null);
    }
  };




  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">Configurações ⚙️</h1>
        <p className="text-sm text-muted-foreground">Seus dados, PIX e plano.</p>
      </div>

      {/* Identidade da Van */}
      <div className="space-y-3">
        <div className="font-bold">Identidade da Van</div>
        <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center gap-2 font-bold">
            <ImagePlus className="h-4 w-4" /> 🚐 Logotipo da Van
          </div>

          <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="flex h-28 w-full items-center justify-center rounded-2xl border bg-muted/30 sm:w-48">
              {logo ? (
                <img src={logo} alt="Logotipo da van" className="max-h-24 max-w-[85%] object-contain" />
              ) : (
                <span className="text-3xl">🚐</span>
              )}
            </div>
            <div className="flex flex-1 flex-col gap-2">
              <label>
                <input
                  type="file"
                  accept="image/png,image/jpeg"
                  className="hidden"
                  disabled={logoBusy}
                  onChange={(e) => { void handleLogoFile(e.target.files?.[0]); e.target.value = ""; }}
                />
                <Button asChild variant="outline" className="w-full justify-start" disabled={logoBusy}>
                  <span>
                    {logoBusy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ImagePlus className="mr-2 h-4 w-4" />}
                    {logo ? "Trocar imagem" : "Enviar logotipo (PNG ou JPG, até 5 MB)"}
                  </span>
                </Button>
              </label>
              {logo && (
                <Button variant="ghost" className="w-full justify-start text-destructive" disabled={logoBusy} onClick={handleRemoveLogo}>
                  <Trash2 className="mr-2 h-4 w-4" /> Remover imagem
                </Button>
              )}
              <Button variant="outline" className="w-full justify-start" onClick={() => setPreviewDocs(true)}>
                <Eye className="mr-2 h-4 w-4" /> 👁️ Visualizar documentos
              </Button>
            </div>
          </div>

          <p className="mt-4 rounded-xl bg-muted/40 p-3 text-xs text-muted-foreground">
            Este logotipo será utilizado nos documentos emitidos pela sua empresa, como recibos, contratos,
            reserva de vagas e outros documentos em PDF. O logotipo é opcional — sem ele, os documentos
            continuam usando apenas o nome da sua van.
          </p>

          <div className="mt-4 rounded-xl border border-dashed p-3 text-xs text-muted-foreground">
            🚐 Nome da van, contato, PIX e cidade agora ficam em{" "}
            <Link to="/comece-aqui" className="font-semibold text-primary underline">Comece por aqui</Link>.
          </div>
        </Card>
      </div>

      {/* Escolas */}
      <div className="space-y-3">
        <div className="font-bold">Escolas 🏫</div>
        <EscolasManager userId={user?.id} />
      </div>

      {/* Notificações */}
      <div className="space-y-3">
        <div className="font-bold">Notificações</div>
        <PushAtivarCard />
      </div>

      {/* Efeitos sonoros */}
      <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center justify-between gap-4">
          <div>
            <div className="font-bold">🔊 Efeitos Sonoros do App</div>
            <p className="mt-1 text-sm text-muted-foreground">
              Buzina de boas-vindas ao abrir o painel e som de confirmação nos recebimentos.
            </p>
          </div>
          <Switch
            checked={sons}
            onCheckedChange={(v) => {
              setSons(v);
              setSonsAtivos(v);
              if (v) tocarSucesso();
              toast.success(v ? "Efeitos sonoros ativados 🔊" : "Efeitos sonoros desativados 🔇");
            }}
            aria-label="Efeitos sonoros do app"
          />
        </div>
      </Card>


      <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold">
          <Heart className="h-4 w-4 text-accent-foreground" /> Seu plano
        </div>
        <div className="mt-2 rounded-2xl bg-accent/30 p-4">
          <div className="text-sm font-semibold">🎁 Teste gratuito ativo</div>
          <div className="text-xs text-muted-foreground">Restam {remaining} {remaining === 1 ? "dia" : "dias"} de teste. Depois apenas R$ 29,90/mês. Cancele quando quiser.</div>
        </div>
      </Card>




      <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold">
          <Download className="h-4 w-4" /> Backup e exportação
        </div>
        <p className="mt-1 text-sm text-muted-foreground">Seus dados são seus. Exporte tudo quando quiser.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Button onClick={() => exportar("pdf")} disabled={exporting !== null} variant="outline" className="justify-start">
            {exporting === "pdf" ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4 text-destructive" />}
            {exporting === "pdf" ? "Gerando seu backup..." : "Backup em PDF"}
          </Button>
          <Button onClick={() => exportar("xlsx")} disabled={exporting !== null} variant="outline" className="justify-start">
            {exporting === "xlsx" ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileSpreadsheet className="mr-2 h-4 w-4 text-success" />}
            {exporting === "xlsx" ? "Gerando seu backup..." : "Backup em Excel"}
          </Button>
        </div>
      </Card>

      <Link to="/quilometragem">
        <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold">
              <RouteIcon className="h-4 w-4" /> Cálculo de distância
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
          <p className="mt-1 text-sm text-muted-foreground">Veja a distância entre a escola e a casa de um possível novo aluno.</p>
        </Card>
      </Link>

      <Link to="/ajuda">

        <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold">
              <HelpCircle className="h-4 w-4" /> Central de Ajuda
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
          <p className="mt-1 text-sm text-muted-foreground">FAQ, novidades, sugestões e contato direto com o suporte.</p>
        </Card>
      </Link>

      <Link to="/instalar-app">
        <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold">
              <Smartphone className="h-4 w-4" /> Como instalar o aplicativo
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
          <p className="mt-1 text-sm text-muted-foreground">Veja como adicionar a Tati Van na tela inicial do seu celular.</p>
        </Card>
      </Link>


      <Separator />

      <Button onClick={handleLogout} variant="outline" className="w-full">
        <LogOut className="mr-2 h-4 w-4" /> Sair da conta
      </Button>

      <Card className="border-destructive/40 p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold text-destructive">
          <Trash2 className="h-4 w-4" /> Excluir conta e dados
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          Remove permanentemente sua conta e todos os dados cadastrados (alunos, responsáveis, financeiro, gastos, documentos, contratos, agenda, mensagens e histórico). Essa ação não pode ser desfeita.
        </p>
        <div className="mt-4">
          <Button variant="destructive" onClick={openDeleteFlow}>
            <Trash2 className="mr-2 h-4 w-4" /> Excluir minha conta
          </Button>
        </div>
      </Card>

      {/* Etapa 1 — motivo da saída (opcional) */}
      <Dialog open={deleteStep === "reason"} onOpenChange={(o) => { if (!o && !deleting) setDeleteStep(null); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-destructive" /> Antes de você ir...
            </DialogTitle>
            <DialogDescription>
              Lamentamos que você esteja deixando a Tati Van Escolar. Sua opinião é muito importante
              para continuarmos melhorando nossa plataforma. Se quiser, conte o motivo — ou pule
              essa etapa.
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-[50vh] space-y-3 overflow-y-auto">
            <RadioGroup value={deleteMotivo} onValueChange={setDeleteMotivo} className="space-y-2">
              {MOTIVOS_EXCLUSAO.map((m) => (
                <label key={m.value} htmlFor={`motivo-${m.value}`} className="flex items-start gap-2 rounded-lg border p-2.5 text-sm cursor-pointer hover:bg-muted/40">
                  <RadioGroupItem id={`motivo-${m.value}`} value={m.value} className="mt-0.5" />
                  <span>{m.label}</span>
                </label>
              ))}
            </RadioGroup>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Quer nos contar mais? (opcional)</Label>
              <Textarea
                value={deleteMotivoTexto}
                onChange={(e) => setDeleteMotivoTexto(e.target.value.slice(0, 1000))}
                placeholder="Escreva aqui o que quiser — sua resposta ajuda muito a Tati."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setDeleteStep(null)}>Cancelar</Button>
            <Button variant="outline" onClick={() => { setDeleteMotivo(""); setDeleteMotivoTexto(""); setDeleteStep("confirm"); }}>Pular</Button>
            <Button variant="destructive" onClick={() => setDeleteStep("confirm")}>Continuar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Etapa 2 — confirmação final */}
      <Dialog open={deleteStep === "confirm"} onOpenChange={(o) => { if (!o && !deleting) setDeleteStep(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" /> Excluir conta permanentemente
            </DialogTitle>
            <DialogDescription>
              Esta ação é <strong>permanente e irreversível</strong>. Todos os dados do motorista,
              alunos, responsáveis, financeiro, gastos, documentos, contratos, agenda e mensagens
              serão removidos. Você não poderá recuperá-los depois.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Para confirmar, digite <span className="font-mono font-bold">EXCLUIR</span> abaixo:</Label>
            <Input value={deleteConfirm} onChange={(e) => setDeleteConfirm(e.target.value)} placeholder="EXCLUIR" autoFocus />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteStep("reason")} disabled={deleting}>Voltar</Button>
            <Button variant="destructive" onClick={handleDeleteAccount} disabled={deleteConfirm !== "EXCLUIR" || deleting}>
              {deleting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Excluindo...</> : <><Trash2 className="mr-2 h-4 w-4" /> Excluir definitivamente</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <IdentidadePreviewDialog
        open={previewDocs}
        onOpenChange={setPreviewDocs}
        nome={empresa.trim() || nomeCompleto.trim() || "Transporte Escolar"}
        logo={logo || undefined}
      />
    </div>
  );
}
