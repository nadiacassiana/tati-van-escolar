import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import {
  Plus, Search, Pencil, FileDown, MessageCircle, Trash2, Mail, Archive, CheckCircle2, History, Eye,
} from "lucide-react";
import { toast } from "sonner";
import { trackEvent } from "@/lib/track-event";
import { parseMoney, formatBRL } from "@/lib/format";
import { htmlToPdfBlob, pdfFilename, downloadBlob } from "@/lib/contrato-pdf";
import { getMarca } from "@/lib/marca";
import { useVanLogo } from "@/lib/logo-store";
import { SignaturePadDialog } from "@/components/signature-pad";
import { DocumentoViewerDialog } from "@/components/documento-viewer";
import { buildContratoHTML, clausulasBase, type Clausula, type ContratoDoc } from "@/lib/documento-html";
import { buildWhatsAppUrl } from "@/lib/whatsapp";
import {
  parseAssinatura, novaAssinatura, statusAssinaturas, STATUS_ASSINATURA_LABEL, linkAssinatura,
} from "@/lib/assinatura";


export const Route = createFileRoute("/_authenticated/contratos")({
  head: () => ({ meta: [{ title: "Contratos — Tati Van" }] }),
  component: ContratosPage,
});

type ContratoRow = Tables<"contratos">;
type Aluno = Pick<Tables<"alunos">, "id" | "nome" | "escola" | "endereco" | "responsavel" | "telefone" | "mensalidade" | "horario_ida" | "horario_volta" | "autoriza_imagem">;
type Responsavel = Pick<Tables<"responsaveis">, "id" | "nome" | "telefone" | "whatsapp" | "email" | "pessoas_autorizadas" | "telefone_emergencia" | "alunos_ids">;

type StatusContrato = "ativo" | "renovacao" | "encerrado";

type HistEntry = { at: string; type: string; label: string };

const statusMap: Record<StatusContrato, { label: string; emoji: string; className: string }> = {
  ativo: { label: "Ativo", emoji: "🟢", className: "bg-success/15 text-success border-success/30" },
  renovacao: { label: "Renovação Pendente", emoji: "🟡", className: "bg-warning/20 text-warning-foreground border-warning/40" },
  encerrado: { label: "Encerrado", emoji: "🔴", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

const emptyForm = {
  aluno_id: "",
  aluno_nome: "",
  responsavel: "",
  escola: "",
  endereco: "",
  telefone: "",
  email_responsavel: "",
  mensalidade: "",
  dia_vencimento: "5",
  data_inicio: "",
  data_termino: "",
  turno: "Manhã",
  horario_ida: "",
  horario_volta: "",
  forma_pagamento: "PIX",
  pix_motorista: "",
  pessoas_autorizadas: "",
  telefone_emergencia: "",
  observacoes_importantes: "",
  observacoes: "",
  multa_atraso: "",
  multa_tipo: "percentual",
  juros_dia: "",
  juros_tipo: "percentual",
  clausulas_adicionais: "",
  autoriza_imagem: "" as "" | "sim" | "nao",
  status: "ativo" as StatusContrato,
};


function normalizeStatus(s: string): StatusContrato {
  return s === "renovacao" || s === "encerrado" ? s : "ativo";
}

function computeStatus(row: ContratoRow): StatusContrato {
  if (row.arquivado_em) return "encerrado";
  const base = normalizeStatus(row.status);
  if (base === "encerrado") return "encerrado";
  if (row.data_termino) {
    const end = new Date(row.data_termino).getTime();
    const now = Date.now();
    if (end < now) return "encerrado";
    const days = (end - now) / 86400000;
    if (days <= 30) return "renovacao";
  }
  return base;
}

function parseHist(v: ContratoRow["historico"]): HistEntry[] {
  if (!Array.isArray(v)) return [];
  return v as unknown as HistEntry[];
}

function ContratosPage() {
  const { user } = Route.useRouteContext();
  const [lista, setLista] = useState<ContratoRow[]>([]);
  const [alunos, setAlunos] = useState<Aluno[]>([]);
  const [responsaveis, setResponsaveis] = useState<Responsavel[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState("");
  const [filtro, setFiltro] = useState<"todos" | StatusContrato>("todos");
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [histOpen, setHistOpen] = useState<ContratoRow | null>(null);
  const [noEmailContrato, setNoEmailContrato] = useState<ContratoRow | null>(null);
  const [preview, setPreview] = useState<{ contrato: ContratoRow; html: string } | null>(null);
  const [assinarAlvo, setAssinarAlvo] = useState<ContratoRow | null>(null);
  const [assinando, setAssinando] = useState(false);
  const [clausulasEdit, setClausulasEdit] = useState<{ contrato: ContratoRow; lista: Clausula[] } | null>(null);
  const [salvandoClausulas, setSalvandoClausulas] = useState(false);



  const vanLogo = useVanLogo();
  const motorista = useMemo(() => {
    const md = (user.user_metadata || {}) as Record<string, string>;
    const oficial = md.nome_completo || md.full_name || user.email || "Motorista";
    const exibicao = md.apelido || oficial;
    return {
      nome_completo: oficial,
      apelido: exibicao,
      empresa: md.empresa || "",
      pix: md.pix || "",
      logo: vanLogo,
    };
  }, [user, vanLogo]);

  const load = async () => {
    setLoading(true);
    const [c, a, r] = await Promise.all([
      supabase.from("contratos").select("*").order("created_at", { ascending: false }),
      supabase.from("alunos").select("id, nome, escola, endereco, responsavel, telefone, mensalidade, horario_ida, horario_volta, autoriza_imagem").order("nome"),
      supabase.from("responsaveis").select("id, nome, telefone, whatsapp, email, pessoas_autorizadas, telefone_emergencia, alunos_ids"),
    ]);
    if (c.error) toast.error("Não foi possível carregar contratos.");
    setLista(c.data || []);
    setAlunos((a.data as Aluno[]) || []);
    setResponsaveis((r.data as unknown as Responsavel[]) || []);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtrados = useMemo(() => {
    const term = q.toLowerCase();
    return lista
      .map((c) => ({ ...c, _status: computeStatus(c) }))
      .filter((c) => (filtro === "todos" ? true : c._status === filtro))
      .filter((c) =>
        !term
          ? true
          : c.aluno_nome.toLowerCase().includes(term) ||
            c.responsavel.toLowerCase().includes(term) ||
            c.escola.toLowerCase().includes(term),
      );
  }, [lista, q, filtro]);

  const openCreate = () => {
    setEditingId(null);
    setForm({ ...emptyForm, pix_motorista: motorista.pix });
    setOpen(true);
  };

  const openEdit = (c: ContratoRow) => {
    setEditingId(c.id);
    setForm({
      aluno_id: c.aluno_id || "",
      aluno_nome: c.aluno_nome,
      responsavel: c.responsavel,
      escola: c.escola,
      endereco: c.endereco,
      telefone: c.telefone,
      email_responsavel: c.email_responsavel || "",
      mensalidade: c.mensalidade ? String(c.mensalidade) : "",
      dia_vencimento: String(c.dia_vencimento || 5),
      data_inicio: c.data_inicio || "",
      data_termino: c.data_termino || "",
      turno: c.turno || "Manhã",
      horario_ida: c.horario_ida || "",
      horario_volta: c.horario_volta || "",
      forma_pagamento: c.forma_pagamento || "PIX",
      pix_motorista: c.pix_motorista || motorista.pix,
      pessoas_autorizadas: c.pessoas_autorizadas || "",
      telefone_emergencia: c.telefone_emergencia || "",
      observacoes_importantes: c.observacoes_importantes || "",
      observacoes: c.observacoes || "",
      multa_atraso: Number(c.multa_atraso) > 0 ? String(c.multa_atraso) : "",
      multa_tipo: c.multa_tipo || "percentual",
      juros_dia: Number(c.juros_dia) > 0 ? String(c.juros_dia) : "",
      juros_tipo: c.juros_tipo || "percentual",
      clausulas_adicionais: c.clausulas_adicionais || "",
      autoriza_imagem: c.autoriza_imagem === null || c.autoriza_imagem === undefined ? "" : c.autoriza_imagem ? "sim" : "nao",
      status: normalizeStatus(c.status),
    });

    setOpen(true);
  };

  const handleAlunoSelect = (id: string) => {
    const al = alunos.find((a) => a.id === id);
    if (!al) {
      setForm((f) => ({ ...f, aluno_id: id }));
      return;
    }
    const resp = responsaveis.find((r) => (r.alunos_ids || []).includes(al.id));
    setForm((f) => ({
      ...f,
      aluno_id: al.id,
      aluno_nome: al.nome,
      escola: al.escola === "—" ? "" : al.escola,
      endereco: al.endereco === "—" ? "" : al.endereco,
      responsavel: resp?.nome || (al.responsavel === "—" ? "" : al.responsavel),
      telefone: resp?.telefone || (al.telefone === "—" ? "" : al.telefone),
      email_responsavel: resp?.email || f.email_responsavel,
      pessoas_autorizadas: resp?.pessoas_autorizadas || f.pessoas_autorizadas,
      telefone_emergencia: resp?.telefone_emergencia || f.telefone_emergencia,
      horario_ida: al.horario_ida || f.horario_ida,
      horario_volta: al.horario_volta || f.horario_volta,
      mensalidade: al.mensalidade ? String(al.mensalidade) : f.mensalidade,
      autoriza_imagem:
        al.autoriza_imagem === null || al.autoriza_imagem === undefined ? f.autoriza_imagem : al.autoriza_imagem ? "sim" : "nao",
    }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.aluno_nome.trim()) {
      toast.error("Informe o nome do aluno.");
      return;
    }
    setSaving(true);
    const payload = {
      aluno_id: form.aluno_id || null,
      aluno_nome: form.aluno_nome.trim(),
      responsavel: form.responsavel,
      escola: form.escola,
      endereco: form.endereco,
      telefone: form.telefone,
      email_responsavel: form.email_responsavel || null,
      mensalidade: parseMoney(form.mensalidade),
      dia_vencimento: parseInt(form.dia_vencimento, 10) || 5,
      data_inicio: form.data_inicio || null,
      data_termino: form.data_termino || null,
      turno: form.turno,
      horario_ida: form.horario_ida || null,
      horario_volta: form.horario_volta || null,
      forma_pagamento: form.forma_pagamento || null,
      pix_motorista: form.pix_motorista || null,
      pessoas_autorizadas: form.pessoas_autorizadas || null,
      telefone_emergencia: form.telefone_emergencia || null,
      observacoes_importantes: form.observacoes_importantes || null,
      observacoes: form.observacoes,
      multa_atraso: parseMoney(form.multa_atraso),
      multa_tipo: form.multa_tipo,
      juros_dia: parseMoney(form.juros_dia),
      juros_tipo: form.juros_tipo,
      clausulas_adicionais: form.clausulas_adicionais,
      autoriza_imagem: form.autoriza_imagem === "" ? null : form.autoriza_imagem === "sim",
      status: form.status,
    };


    if (editingId) {
      const cur = lista.find((c) => c.id === editingId);
      const hist = parseHist(cur?.historico ?? []);
      hist.unshift({ at: new Date().toISOString(), type: "edit", label: "Contrato editado." });
      const { error } = await supabase
        .from("contratos")
        .update({ ...(payload as TablesUpdate<"contratos">), historico: hist as unknown as TablesUpdate<"contratos">["historico"] })
        .eq("id", editingId);
      setSaving(false);
      if (error) return toast.error("Erro ao salvar contrato.");
      toast.success("Contrato atualizado!");
    } else {
      const hist: HistEntry[] = [{ at: new Date().toISOString(), type: "create", label: "Contrato criado." }];
      const { error } = await supabase
        .from("contratos")
        .insert({ ...payload, user_id: user.id, historico: hist as unknown as TablesInsert<"contratos">["historico"] } as TablesInsert<"contratos">);
      setSaving(false);
      if (error) return toast.error("Erro ao criar contrato.");
      trackEvent("contrato_gerado", `${payload.aluno_nome || "contrato"}`);
      toast.success("Contrato criado!");
    }
    setOpen(false);
    setForm(emptyForm);
    setEditingId(null);
    load();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Excluir este contrato?")) return;
    const { error } = await supabase.from("contratos").delete().eq("id", id);
    if (error) return toast.error("Erro ao excluir.");
    toast.success("Contrato excluído.");
    setLista((l) => l.filter((c) => c.id !== id));
  };

  const appendHistAndUpdate = async (c: ContratoRow, patch: TablesUpdate<"contratos">, entry: HistEntry) => {
    const hist = parseHist(c.historico);
    hist.unshift(entry);
    const { data, error } = await supabase
      .from("contratos")
      .update({ ...patch, historico: hist as unknown as TablesUpdate<"contratos">["historico"] })
      .eq("id", c.id)
      .select("*")
      .single();
    if (error || !data) {
      toast.error("Não foi possível registrar a ação.");
      return null;
    }
    setLista((l) => l.map((x) => (x.id === c.id ? (data as ContratoRow) : x)));
    return data as ContratoRow;
  };

  /** HTML legível do contrato (mesmo conteúdo do PDF e da imagem do WhatsApp). */
  const contratoHTML = (c: ContratoRow) =>
    buildContratoHTML(c as unknown as ContratoDoc, motorista.nome_completo, getMarca(motorista));

  const buildPdfBlob = async (c: ContratoRow): Promise<Blob | null> => {
    try {
      return await htmlToPdfBlob(contratoHTML(c));
    } catch (err) {
      console.error(err);
      toast.error("Não foi possível gerar o PDF.");
      return null;
    }
  };

  /** Etapa 1 e 4: leitura do documento na tela, sem baixar nada. */
  const abrirPreview = (c: ContratoRow) => {
    setPreview({ contrato: c, html: contratoHTML(c) });
    void appendHistAndUpdate(c, {}, {
      at: new Date().toISOString(),
      type: "preview",
      label: "Contrato visualizado na tela.",
    });
  };

  const closePreview = () => setPreview(null);

  /** Editar/remover as cláusulas do contrato antes de exportar. */
  const abrirEditorClausulas = () => {
    if (!preview) return;
    setClausulasEdit({
      contrato: preview.contrato,
      lista: clausulasBase(preview.contrato as unknown as ContratoDoc),
    });
  };

  const patchClausula = (i: number, patch: Partial<Clausula>) =>
    setClausulasEdit((s) =>
      s ? { ...s, lista: s.lista.map((cl, idx) => (idx === i ? { ...cl, ...patch } : cl)) } : s,
    );

  const removerClausula = (i: number) =>
    setClausulasEdit((s) => (s ? { ...s, lista: s.lista.filter((_, idx) => idx !== i) } : s));

  const adicionarClausula = () =>
    setClausulasEdit((s) => (s ? { ...s, lista: [...s.lista, { titulo: "Nova cláusula", texto: "" }] } : s));

  const restaurarClausulas = () =>
    setClausulasEdit((s) =>
      s ? { ...s, lista: clausulasBase({ ...s.contrato, clausulas_custom: null } as unknown as ContratoDoc) } : s,
    );

  const salvarClausulas = async () => {
    if (!clausulasEdit) return;
    const lista = clausulasEdit.lista
      .map((cl) => ({ titulo: cl.titulo.trim(), texto: cl.texto.trim() }))
      .filter((cl) => cl.titulo || cl.texto);
    setSalvandoClausulas(true);
    const atualizado = await appendHistAndUpdate(
      clausulasEdit.contrato,
      { clausulas_custom: lista as unknown as TablesUpdate<"contratos">["clausulas_custom"] },
      { at: new Date().toISOString(), type: "edit", label: "Cláusulas do contrato personalizadas." },
    );
    setSalvandoClausulas(false);
    if (!atualizado) return;
    setClausulasEdit(null);
    setPreview({ contrato: atualizado, html: contratoHTML(atualizado) });
    toast.success("Cláusulas atualizadas!");
  };


  const baixarPDF = async (c: ContratoRow) => {
    const t = toast.loading("Gerando PDF...");
    const blob = await buildPdfBlob(c);
    toast.dismiss(t);
    if (!blob) return;
    downloadBlob(blob, pdfFilename(c));
    toast.success("✅ PDF baixado!");
    await appendHistAndUpdate(c, {}, {
      at: new Date().toISOString(),
      type: "generated",
      label: "Contrato baixado em PDF.",
    });
  };

  const mensagemWhatsApp = (c: ContratoRow) => {
    const linhas = [
      "Olá! 😊",
      "",
      `Segue o contrato de prestação de serviço de transporte escolar referente ao aluno(a) ${c.aluno_nome}.`,
      "",
      "Peço a gentileza de acessar o link abaixo para realizar a leitura completa do documento e, estando de acordo, assinar digitalmente.",
      "",
      "Qualquer dúvida estou à disposição.",
      "",
      `Atenciosamente,\n${motorista.apelido}${motorista.empresa ? `\n${motorista.empresa}` : ""}`,
      "",
      "🔗 Ler e assinar o contrato:",
      linkAssinatura("contrato", c.id),
    ];
    return linhas.join("\n");
  };

  /** Etapa 3: apenas mensagem de texto + link do contrato (sem imagens/anexos). */
  const sendWhatsApp = async (c: ContratoRow) => {
    if (!parseAssinatura(c.assinatura_motorista)) {
      toast.warning("Assine o documento antes de enviar ao responsável.");
    }
    const mensagem = mensagemWhatsApp(c);
    window.open(buildWhatsAppUrl(c.telefone || "", mensagem), "_blank", "noopener,noreferrer");
    await appendHistAndUpdate(
      c,
      { enviado_whatsapp_em: new Date().toISOString() },
      { at: new Date().toISOString(), type: "whatsapp", label: "Contrato enviado por WhatsApp (link)." },
    );
  };



  const sendEmail = async (c: ContratoRow) => {
    if (!c.email_responsavel) {
      setNoEmailContrato(c);
      return;
    }
    const t = toast.loading("Gerando PDF do contrato...");
    const blob = await buildPdfBlob(c);
    toast.dismiss(t);
    if (!blob) return;
    const filename = pdfFilename(c);

    const subject = "Contrato de Transporte Escolar";
    const body = `Olá!\n\nSegue em anexo o contrato de prestação de serviço de transporte escolar.\n\nPeço a gentileza de realizar a leitura completa.\n\nQualquer dúvida estou à disposição.\n\nAtenciosamente,\n${motorista.apelido}${motorista.empresa ? `\n${motorista.empresa}` : ""}`;

    // mailto can't attach files: download the PDF so the user attaches it.
    downloadBlob(blob, filename);
    window.location.href = `mailto:${c.email_responsavel}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    toast.info("PDF baixado. Anexe-o no e-mail que será aberto.");
    await appendHistAndUpdate(
      c,
      { enviado_email_em: new Date().toISOString() },
      { at: new Date().toISOString(), type: "email", label: `Contrato (PDF) enviado por e-mail para ${c.email_responsavel}.` },
    );
  };

  const arquivar = async (c: ContratoRow) => {
    if (!confirm(c.arquivado_em ? "Reabrir este contrato?" : "Arquivar este contrato?")) return;
    const isArchive = !c.arquivado_em;
    await appendHistAndUpdate(
      c,
      { arquivado_em: isArchive ? new Date().toISOString() : null },
      { at: new Date().toISOString(), type: "archive", label: isArchive ? "Contrato arquivado." : "Contrato reaberto." },
    );
  };

  const marcarAssinado = async (c: ContratoRow) => {
    if (c.assinado_em) return;
    await appendHistAndUpdate(
      c,
      { assinado_em: new Date().toISOString() },
      { at: new Date().toISOString(), type: "signed", label: "Contrato marcado como assinado." },
    );
    toast.success("Contrato marcado como assinado.");
  };

  /** Assinatura visual da tia/tio da van (imagem desenhada na tela). */
  const salvarAssinaturaMotorista = async (dados: { imagem: string; nome: string }) => {
    const c = assinarAlvo;
    if (!c) return;
    setAssinando(true);
    const assinatura = novaAssinatura(dados.imagem, dados.nome, "motorista");
    const ok = await appendHistAndUpdate(
      c,
      { assinatura_motorista: assinatura as unknown as TablesUpdate<"contratos">["assinatura_motorista"] },
      { at: new Date().toISOString(), type: "sign", label: `Contrato assinado digitalmente por ${assinatura.nome}.` },
    );
    setAssinando(false);
    if (ok) {
      setAssinarAlvo(null);
      toast.success("Assinatura registrada! Agora envie o link para o responsável assinar.");
    }
  };

  const copiarLinkAssinatura = async (c: ContratoRow) => {
    const link = linkAssinatura("contrato", c.id);
    try {
      await navigator.clipboard.writeText(link);
      toast.success("Link de assinatura copiado.");
    } catch {
      toast.info(link);
    }
  };


  const renovacaoPendente = lista.filter((c) => computeStatus(c) === "renovacao").length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">Centro de Contratos 📄</h1>
          <p className="text-sm text-muted-foreground">
            {lista.length} contrato(s).{" "}
            {renovacaoPendente > 0 && (
              <span className="font-semibold text-warning-foreground">
                {renovacaoPendente} precisam ser renovados.
              </span>
            )}
          </p>
        </div>
        <Button onClick={openCreate} className="bg-primary text-primary-foreground font-bold">
          <Plus className="mr-2 h-4 w-4" /> Novo Contrato
        </Button>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar por aluno, responsável ou escola..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {(["todos", "ativo", "renovacao", "encerrado"] as const).map((f) => (
            <Button
              key={f}
              size="sm"
              variant={filtro === f ? "default" : "outline"}
              onClick={() => setFiltro(f)}
              className={filtro === f ? "bg-primary text-primary-foreground" : ""}
            >
              {f === "todos" ? "Todos" : statusMap[f].label}
            </Button>
          ))}
        </div>
      </div>

      {loading ? (
        <Card className="p-6 text-center text-sm text-muted-foreground">Carregando...</Card>
      ) : filtrados.length === 0 ? (
        <Card className="p-6 text-center text-sm text-muted-foreground">
          Nenhum contrato encontrado.
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtrados.map((c) => {
            const s = statusMap[c._status];
            const hist = parseHist(c.historico);
            const ultima = hist[0];
            return (
              <Card key={c.id} className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="font-bold leading-tight truncate">{c.aluno_nome}</div>
                    <div className="text-xs text-muted-foreground truncate">{c.escola || "—"}</div>
                    <Badge variant="outline" className={`mt-2 ${s.className}`}>
                      {s.emoji} {s.label}
                    </Badge>
                  </div>
                  <div className="flex flex-col gap-1">
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(c)} aria-label="Editar">
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => handleDelete(c.id)} aria-label="Excluir">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="mt-4 space-y-1 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Responsável</span><span className="truncate">{c.responsavel || "—"}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Mensalidade</span><span className="font-bold text-primary">R$ {formatBRL(Number(c.mensalidade))}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Vencimento</span><span>Dia {c.dia_vencimento}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Turno</span><span>{c.turno}{c.horario_ida ? ` • ${c.horario_ida}` : ""}{c.horario_volta ? ` / ${c.horario_volta}` : ""}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Vigência</span>
                    <span className="text-xs">
                      {c.data_inicio ? new Date(c.data_inicio).toLocaleDateString("pt-BR") : "—"} →{" "}
                      {c.data_termino ? new Date(c.data_termino).toLocaleDateString("pt-BR") : "—"}
                    </span>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-1 border-t pt-3 text-[11px]">
                  <Badge variant="outline" className="bg-success/10 text-success border-success/30">🟢 Gerado</Badge>
                  {c.enviado_whatsapp_em && <Badge variant="outline" className="bg-success/10 text-success border-success/30">🟢 WhatsApp</Badge>}
                  {c.enviado_email_em && <Badge variant="outline" className="bg-success/10 text-success border-success/30">🟢 E-mail</Badge>}
                  {c.assinado_em && <Badge variant="outline" className="bg-success/10 text-success border-success/30">🟢 Assinado</Badge>}
                  {c.arquivado_em && <Badge variant="outline" className="bg-muted text-muted-foreground">📦 Arquivado</Badge>}
                  <Badge variant="outline">
                    {STATUS_ASSINATURA_LABEL[statusAssinaturas(c.assinatura_motorista, c.assinatura_responsavel)]}
                  </Badge>
                </div>
                <div className="mt-2 text-[11px] text-muted-foreground space-y-0.5">
                  <div>Gerado em: {new Date(c.created_at).toLocaleString("pt-BR")}</div>
                  {ultima && <div>Última: {ultima.label} — {new Date(ultima.at).toLocaleString("pt-BR")}</div>}
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2 border-t pt-3">
                  <Button size="sm" className="bg-primary text-primary-foreground font-bold" onClick={() => abrirPreview(c)}>
                    <Eye className="mr-1 h-3 w-3" /> Pré-visualizar
                  </Button>
                  <Button size="sm" variant="outline" className="text-success border-success/40" onClick={() => sendWhatsApp(c)}>
                    <MessageCircle className="mr-1 h-3 w-3" /> WhatsApp
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => sendEmail(c)}>
                    <Mail className="mr-1 h-3 w-3" /> E-mail
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => baixarPDF(c)}>
                    <FileDown className="mr-1 h-3 w-3" /> PDF
                  </Button>
                  {!parseAssinatura(c.assinatura_motorista) ? (
                    <Button size="sm" variant="outline" className="col-span-2 border-primary/40 text-primary" onClick={() => setAssinarAlvo(c)}>
                      ✍️ Assinar documento
                    </Button>
                  ) : !parseAssinatura(c.assinatura_responsavel) ? (
                    <Button size="sm" variant="outline" className="col-span-2" onClick={() => copiarLinkAssinatura(c)}>
                      🔗 Copiar link de assinatura
                    </Button>
                  ) : null}
                  {!c.assinado_em && (
                    <Button size="sm" variant="ghost" onClick={() => marcarAssinado(c)} className="col-span-2">
                      <CheckCircle2 className="mr-1 h-3 w-3" /> Marcar como assinado
                    </Button>
                  )}

                  <Button size="sm" variant="ghost" onClick={() => setHistOpen(c)}>
                    <History className="mr-1 h-3 w-3" /> Histórico
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => arquivar(c)}>
                    <Archive className="mr-1 h-3 w-3" /> {c.arquivado_em ? "Reabrir" : "Arquivar"}
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingId ? "Editar contrato" : "Novo contrato"} 📄</DialogTitle>
            <DialogDescription>Preencha os dados do contrato do aluno.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <Label>Aluno cadastrado (opcional — preenche os campos)</Label>
              <Select value={form.aluno_id} onValueChange={handleAlunoSelect}>
                <SelectTrigger><SelectValue placeholder="Selecione um aluno..." /></SelectTrigger>
                <SelectContent>
                  {alunos.map((a) => (
                    <SelectItem key={a.id} value={a.id}>{a.nome}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="aluno_nome">Nome do aluno *</Label>
              <Input id="aluno_nome" value={form.aluno_nome} onChange={(e) => setForm({ ...form, aluno_nome: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="responsavel">Responsável</Label>
                <Input id="responsavel" value={form.responsavel} onChange={(e) => setForm({ ...form, responsavel: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="telefone">Telefone</Label>
                <Input id="telefone" value={form.telefone} onChange={(e) => setForm({ ...form, telefone: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="email_resp">E-mail do responsável</Label>
                <Input id="email_resp" type="email" value={form.email_responsavel} onChange={(e) => setForm({ ...form, email_responsavel: e.target.value })} placeholder="responsavel@email.com" />
              </div>
              <div>
                <Label htmlFor="emerg">Telefone de emergência</Label>
                <Input id="emerg" value={form.telefone_emergencia} onChange={(e) => setForm({ ...form, telefone_emergencia: e.target.value })} />
              </div>
            </div>
            <div>
              <Label htmlFor="escola">Escola</Label>
              <Input id="escola" value={form.escola} onChange={(e) => setForm({ ...form, escola: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="endereco">Endereço</Label>
              <Input id="endereco" value={form.endereco} onChange={(e) => setForm({ ...form, endereco: e.target.value })} />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label htmlFor="mens">Mensalidade (R$)</Label>
                <Input id="mens" type="text" inputMode="decimal" placeholder="R$ 150,00" value={form.mensalidade} onChange={(e) => setForm({ ...form, mensalidade: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="dia">Dia do vencimento</Label>
                <Input id="dia" type="number" min={1} max={31} value={form.dia_vencimento} onChange={(e) => setForm({ ...form, dia_vencimento: e.target.value })} />
              </div>
              <div>
                <Label>Turno</Label>
                <Select value={form.turno} onValueChange={(v) => setForm({ ...form, turno: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Manhã">Manhã</SelectItem>
                    <SelectItem value="Tarde">Tarde</SelectItem>
                    <SelectItem value="Integral">Integral</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="hi">Horário de ida</Label>
                <Input id="hi" type="time" value={form.horario_ida} onChange={(e) => setForm({ ...form, horario_ida: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="hv">Horário de volta</Label>
                <Input id="hv" type="time" value={form.horario_volta} onChange={(e) => setForm({ ...form, horario_volta: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Forma de pagamento</Label>
                <Select value={form.forma_pagamento} onValueChange={(v) => setForm({ ...form, forma_pagamento: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PIX">PIX</SelectItem>
                    <SelectItem value="Dinheiro">Dinheiro</SelectItem>
                    <SelectItem value="Transferência">Transferência</SelectItem>
                    <SelectItem value="Cartão">Cartão</SelectItem>
                    <SelectItem value="Boleto">Boleto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="pix">Chave PIX do motorista</Label>
                <Input id="pix" value={form.pix_motorista} onChange={(e) => setForm({ ...form, pix_motorista: e.target.value })} placeholder="CPF, e-mail ou chave aleatória" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="ini">Data de início</Label>
                <Input id="ini" type="date" value={form.data_inicio} onChange={(e) => setForm({ ...form, data_inicio: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="ter">Data de término</Label>
                <Input id="ter" type="date" value={form.data_termino} onChange={(e) => setForm({ ...form, data_termino: e.target.value })} />
              </div>
            </div>

            <div className="rounded-lg border bg-muted/30 p-3">
              <div className="text-sm font-bold">⚠️ Multa e juros por atraso (opcional)</div>
              <p className="mb-2 text-xs text-muted-foreground">
                Se preenchido, entra na cláusula de inadimplência do contrato e no cálculo do
                valor atualizado das parcelas atrasadas.
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="multa">Multa por atraso</Label>
                  <Input id="multa" inputMode="decimal" placeholder="Ex.: 2" value={form.multa_atraso} onChange={(e) => setForm({ ...form, multa_atraso: e.target.value })} />
                </div>
                <div>
                  <Label>Tipo da multa</Label>
                  <Select value={form.multa_tipo} onValueChange={(v) => setForm({ ...form, multa_tipo: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentual">% sobre a mensalidade</SelectItem>
                      <SelectItem value="reais">R$ (valor fixo)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="juros">Juros por dia de atraso</Label>
                  <Input id="juros" inputMode="decimal" placeholder="Ex.: 0,33" value={form.juros_dia} onChange={(e) => setForm({ ...form, juros_dia: e.target.value })} />
                </div>
                <div>
                  <Label>Tipo dos juros</Label>
                  <Select value={form.juros_tipo} onValueChange={(v) => setForm({ ...form, juros_tipo: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentual">% ao dia</SelectItem>
                      <SelectItem value="reais">R$ por dia</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="clau">Cláusulas adicionais / regras especiais (opcional)</Label>
              <Textarea
                id="clau"
                rows={4}
                value={form.clausulas_adicionais}
                onChange={(e) => setForm({ ...form, clausulas_adicionais: e.target.value })}
                placeholder={"Cada cláusula em um parágrafo (separe por uma linha em branco).\n\nEx.: O transporte não será realizado em dias de greve escolar."}
              />
            </div>

            <div>
              <Label>Autorização de uso de imagem (opcional)</Label>
              <Select
                value={form.autoriza_imagem || "nao_informado"}
                onValueChange={(v) => setForm({ ...form, autoriza_imagem: v === "nao_informado" ? "" : (v as "sim" | "nao") })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nao_informado">Não informado</SelectItem>
                  <SelectItem value="sim">Sim — incluir cláusula de autorização</SelectItem>
                  <SelectItem value="nao">Não autorizado</SelectItem>
                </SelectContent>
              </Select>
              <p className="mt-1 text-xs text-muted-foreground">
                Quando "Sim", o contrato inclui a cláusula de autorização de uso de imagem para divulgação do transporte.
              </p>
            </div>

            <div>
              <Label htmlFor="aut">Pessoas autorizadas a buscar o aluno</Label>
              <Textarea id="aut" rows={2} value={form.pessoas_autorizadas} onChange={(e) => setForm({ ...form, pessoas_autorizadas: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="oi">Observações importantes</Label>
              <Textarea id="oi" rows={2} value={form.observacoes_importantes} onChange={(e) => setForm({ ...form, observacoes_importantes: e.target.value })} placeholder="Alergias, medicamentos, restrições, etc." />
            </div>
            <div>
              <Label>Situação</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as StatusContrato })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">🟢 Ativo</SelectItem>
                  <SelectItem value="renovacao">🟡 Renovação Pendente</SelectItem>
                  <SelectItem value="encerrado">🔴 Encerrado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="obs">Observações gerais</Label>
              <Textarea id="obs" rows={3} value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} />
            </div>
            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saving} className="bg-primary text-primary-foreground font-bold">
                {saving ? "Salvando..." : "Salvar contrato"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!histOpen} onOpenChange={(v) => !v && setHistOpen(null)}>
        <DialogContent className="max-h-[80vh] overflow-y-auto sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Histórico do contrato</DialogTitle>
            <DialogDescription>{histOpen?.aluno_nome}</DialogDescription>
          </DialogHeader>
          <ul className="space-y-3 text-sm">
            {parseHist(histOpen?.historico ?? []).length === 0 ? (
              <li className="text-muted-foreground">Nenhum evento registrado ainda.</li>
            ) : (
              parseHist(histOpen?.historico ?? []).map((h, i) => (
                <li key={i} className="border-l-2 border-primary/40 pl-3">
                  <div className="font-medium">{h.label}</div>
                  <div className="text-xs text-muted-foreground">{new Date(h.at).toLocaleString("pt-BR")}</div>
                </li>
              ))
            )}
          </ul>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!noEmailContrato} onOpenChange={(v) => !v && setNoEmailContrato(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sem e-mail cadastrado</AlertDialogTitle>
            <AlertDialogDescription>
              Este responsável ainda não possui um e-mail cadastrado.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (noEmailContrato) { const c = noEmailContrato; setNoEmailContrato(null); openEdit(c); } }}>
              Cadastrar agora
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <DocumentoViewerDialog
        open={!!preview}
        onOpenChange={(v) => { if (!v) closePreview(); }}
        titulo="Contrato de transporte escolar"
        descricao={
          preview
            ? `${preview.contrato.aluno_nome} — ${parseAssinatura(preview.contrato.assinatura_responsavel)
                ? "assinado pelas duas partes."
                : parseAssinatura(preview.contrato.assinatura_motorista)
                ? "já assinado pela van, aguardando o responsável."
                : "ainda sem assinaturas."}`
            : undefined
        }
        html={preview?.html || ""}
        acoes={
          <>
            <Button variant="outline" onClick={closePreview}>Fechar</Button>
            <Button variant="outline" onClick={abrirEditorClausulas}>
              <Pencil className="mr-2 h-4 w-4" /> Editar cláusulas
            </Button>

            {preview && !parseAssinatura(preview.contrato.assinatura_motorista) && (
              <Button
                variant="outline"
                className="border-primary/40 text-primary"
                onClick={() => { const c = preview.contrato; closePreview(); setAssinarAlvo(c); }}
              >
                ✍️ Assinar documento
              </Button>
            )}
            <Button
              className="bg-primary text-primary-foreground font-bold"
              onClick={() => { if (preview) void baixarPDF(preview.contrato); }}
            >
              <FileDown className="mr-2 h-4 w-4" /> Baixar PDF
            </Button>
          </>
        }
      />

      <Dialog open={!!clausulasEdit} onOpenChange={(v) => !v && setClausulasEdit(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar cláusulas do contrato ✍️</DialogTitle>
            <DialogDescription>
              Ajuste a redação, remova o que não usar ou crie novas cláusulas. Vale só para este contrato.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {clausulasEdit?.lista.map((cl, i) => (
              <div key={i} className="rounded-lg border p-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-muted-foreground">{i + 1}.</span>
                  <Input
                    value={cl.titulo}
                    onChange={(e) => patchClausula(i, { titulo: e.target.value })}
                    placeholder="Título da cláusula"
                  />
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => removerClausula(i)} aria-label="Remover cláusula">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <Textarea
                  className="mt-2"
                  rows={3}
                  value={cl.texto}
                  onChange={(e) => patchClausula(i, { texto: e.target.value })}
                  placeholder="Texto da cláusula"
                />
              </div>
            ))}
            <div className="flex flex-wrap gap-2">
              <Button type="button" variant="outline" onClick={adicionarClausula}>
                <Plus className="mr-1 h-4 w-4" /> Adicionar cláusula
              </Button>
              <Button type="button" variant="ghost" onClick={restaurarClausulas}>
                Restaurar padrão
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              A frase de multa e juros e as cláusulas adicionais do formulário continuam sendo
              incluídas automaticamente no documento.
            </p>
          </div>
          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={() => setClausulasEdit(null)}>Cancelar</Button>
            <Button onClick={salvarClausulas} disabled={salvandoClausulas} className="bg-primary text-primary-foreground font-bold">
              {salvandoClausulas ? "Salvando..." : "Salvar cláusulas"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>



      <SignaturePadDialog
        open={!!assinarAlvo}
        onOpenChange={(v) => !v && setAssinarAlvo(null)}
        papel="motorista"
        nomePadrao={motorista.nome_completo}
        documentoLabel={assinarAlvo ? `Contrato — ${assinarAlvo.aluno_nome}` : undefined}
        saving={assinando}
        onAceitar={salvarAssinaturaMotorista}
      />
    </div>

  );
}

