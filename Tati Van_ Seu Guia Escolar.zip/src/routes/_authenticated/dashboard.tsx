import { createFileRoute, Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Users, Wallet, AlertTriangle, Fuel, Wrench, Calendar, CheckSquare, Cake, FileText, UserCog, MessageCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { formatBRL, currentMonthRef } from "@/lib/format";
import { buildCompetencias } from "@/lib/mensalidades";
import { geraMensalidades } from "@/lib/tipo-cobranca";

import { getMotoristaFromUser, getDisplayName, getGreeting } from "@/lib/whatsapp";
import { useVanLogo } from "@/lib/logo-store";
import { VanLogo } from "@/components/van-logo";

import { AlunoAvatar } from "@/components/aluno-avatar";
import { ProfileCompletionPrompt } from "@/components/profile-completion-prompt";
import { RetentionSurveyPrompt } from "@/components/retention-survey-prompt";
import { TrialEndingBanner } from "@/components/trial-ending-banner";
import { PushAtivarCard } from "@/components/push-ativar-card";
import {
  AniversarioWhatsAppDialog,
  type ResponsavelContato,
} from "@/components/aniversario-whatsapp-dialog";
import { formatDiaMes, parseAniversario, hojeBrasil } from "@/lib/aniversarios";
import { tocarBoasVindas, precarregarSons } from "@/lib/sons";
import dashboardPattern from "@/assets/tati-dashboard-pattern-v2.jpg.asset.json";


export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Painel — Tati Van" }] }),
  component: Dashboard,
});

type Aluno = { id: string; nome: string; avatar: string; mensalidade: number; vencimento: number; aniversario: string; created_at?: string; arquivado_em?: string | null };
type Gasto = { id: string; data: string; categoria: string; valor: number; km: number | null };
type Documento = { id: string; nome: string; vencimento: string | null };
type Pagamento = { id: string; aluno_id: string; mes_referencia: string; valor: number };

type Contrato = { id: string; aluno_nome: string; status: string; data_termino: string | null };
type ResponsavelRow = { id: string; nome: string; telefone: string | null; whatsapp: string | null; alunos_ids: string[] | null };

/** Responsáveis com telefone vinculados ao aluno (somente da própria conta, por RLS). */
function contatosDoAluno(alunoId: string, responsaveis: ResponsavelRow[]): ResponsavelContato[] {
  return responsaveis
    .filter((r) => (r.alunos_ids || []).includes(alunoId))
    .map((r) => ({ id: r.id, nome: r.nome, telefone: (r.whatsapp || r.telefone || "").trim() }))
    .filter((r) => r.telefone.replace(/\D/g, "").length >= 10);
}

function Dashboard() {
  const { user } = Route.useRouteContext();
  useVanLogo();
  const motorista = getMotoristaFromUser(user);
  const displayName = getDisplayName(motorista);
  const greeting = getGreeting();
  const greetEmoji = new Date().getHours() < 12 ? "☀️" : new Date().getHours() < 18 ? "🌤️" : "🌙";
  const mesRef = currentMonthRef();
  const firstAccessKey = `tati:first-access:${user?.id ?? "anon"}`;
  const [isFirstAccess, setIsFirstAccess] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return !window.localStorage.getItem(firstAccessKey);
  });
  const [alunos, setAlunos] = useState<Aluno[]>([]);
  const [gastos, setGastos] = useState<Gasto[]>([]);
  const [docs, setDocs] = useState<Documento[]>([]);
  const [pagamentos, setPagamentos] = useState<Pagamento[]>([]);
  const [contratos, setContratos] = useState<Contrato[]>([]);
  const [responsaveis, setResponsaveis] = useState<ResponsavelRow[]>([]);
  const [aniversarioAlvo, setAniversarioAlvo] = useState<Aluno | null>(null);

  useEffect(() => {
    if (isFirstAccess && typeof window !== "undefined") {
      window.localStorage.setItem(firstAccessKey, new Date().toISOString());
    }
  }, [isFirstAccess, firstAccessKey]);

  // 🔊 Buzina de boas-vindas a cada acesso ao painel (com preload dos efeitos).
  useEffect(() => {
    if (typeof window === "undefined") return;
    precarregarSons();
    const t = setTimeout(() => tocarBoasVindas(), 400);
    return () => clearTimeout(t);
  }, []);



  useEffect(() => {
    (async () => {
      const [a, g, d, p, c, r] = await Promise.all([
        supabase.from("alunos").select("id, nome, avatar, mensalidade, vencimento, aniversario, created_at, arquivado_em, tipo_cobranca"),
        supabase.from("gastos").select("id, data, categoria, valor, km").order("data", { ascending: false }).limit(5),
        supabase.from("documentos").select("id, nome, vencimento"),
        supabase.from("pagamentos").select("id, aluno_id, mes_referencia, valor"),
        supabase.from("contratos").select("id, aluno_nome, status, data_termino"),
        supabase.from("responsaveis").select("id, nome, telefone, whatsapp, alunos_ids"),
      ]);
      setAlunos(((a.data as unknown) as Aluno[]) || []);
      setGastos(((g.data as unknown) as Gasto[]) || []);
      setDocs(((d.data as unknown) as Documento[]) || []);
      setPagamentos(((p.data as unknown) as Pagamento[]) || []);
      setContratos(((c.data as unknown) as Contrato[]) || []);
      setResponsaveis(((r.data as unknown) as ResponsavelRow[]) || []);
    })();
  }, [mesRef]);

  const competencias = buildCompetencias(
    alunos.filter((a) => geraMensalidades((a as Aluno & { tipo_cobranca?: string }).tipo_cobranca)),
    pagamentos,
  );
  const doMes = competencias.filter((c) => c.mes === mesRef);
  const vencidas = competencias.filter((c) => c.status === "vencido");
  const totalAtraso = vencidas.reduce((s, c) => s + c.valor, 0);
  const recebidas = doMes.filter((c) => c.status === "pago").length;
  const atrasadas = vencidas.length;
  const recebido = doMes.filter((c) => c.status === "pago").reduce((s, c) => s + c.valor, 0);


  const docsVencidos = docs.filter((d) => d.vencimento && new Date(d.vencimento) < new Date()).length;
  const docsProximos = docs.filter((d) => {
    if (!d.vencimento) return false;
    const dias = Math.ceil((new Date(d.vencimento + "T00:00:00").getTime() - Date.now()) / 86400000);
    return dias >= 0 && dias <= 30;
  }).length;
  const semDadosVan = docs.length === 0 && gastos.length === 0;
  const scoreDocs = docs.length === 0 ? 0 : Math.max(0, 100 - docsVencidos * 25 - docsProximos * 8);
  const scoreFin = alunos.length === 0 ? 100 : Math.max(0, 100 - atrasadas * 15);
  const saudeVan = semDadosVan ? null : Math.round((scoreDocs + scoreFin) / 2);


  const ultimoAbast = gastos.find((g) => g.categoria === "Combustível");
  const hoje = hojeBrasil();
  const aniversariantes = alunos
    .filter((a) => !a.arquivado_em)
    .map((a) => ({ aluno: a, dm: parseAniversario(a.aniversario) }))
    .filter((x): x is { aluno: Aluno; dm: { dia: number; mes: number } } => !!x.dm && x.dm.mes === hoje.mes)
    .map((x) => ({ ...x, hoje: x.dm.dia === hoje.dia }))
    .sort((a, b) => a.dm.dia - b.dm.dia);


  const proximosDocs = docs
    .filter((d) => d.vencimento)
    .map((d) => ({ ...d, ts: new Date(d.vencimento!).getTime() }))
    .filter((d) => d.ts >= Date.now() - 86400000)
    .sort((a, b) => a.ts - b.ts)
    .slice(0, 3);

  const contratosRenovar = contratos.filter((c) => {
    if (c.status === "encerrado") return false;
    if (!c.data_termino) return false;
    const days = (new Date(c.data_termino).getTime() - Date.now()) / 86400000;
    return days >= 0 && days <= 30;
  });

  return (
    <div className="relative -mx-4 -mt-4 space-y-6 overflow-hidden px-4 pt-8 sm:-mx-6 sm:-mt-6 sm:px-6 sm:pt-10">
      <div className="pointer-events-none absolute inset-x-0 top-0 z-0 h-[25rem] overflow-hidden" aria-hidden="true">
        <img
          src={dashboardPattern.url}
          alt=""
          className="h-full w-full object-cover object-top opacity-60 saturate-125"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/15 via-background/30 to-background" />
      </div>

      <div className="relative z-10 flex items-center gap-3">
        <VanLogo logo={motorista.logo} alt={motorista.empresa || "Logotipo da van"} />

        <div className="flex flex-col gap-1 rounded-md border border-slate-200 bg-white px-3 py-2 text-slate-800 shadow-sm">
          {isFirstAccess ? (
            <>
              <h1 className="text-2xl font-extrabold">Bem-vindo(a) à Tati Van Escolar! 🎉</h1>
              <p className="text-sm text-slate-800">É um prazer ter você aqui, {displayName}! Vamos configurar seu sistema para começar.</p>
            </>
          ) : (
            <>
              <h1 className="text-2xl font-extrabold">{greeting}, {displayName}! {greetEmoji}</h1>
              <p className="text-sm text-slate-800">Que bom ter você de volta! Aqui está o resumo da sua van hoje.</p>
            </>
          )}
        </div>
      </div>

      <div className="relative z-10 contents">
        <TrialEndingBanner />
        <ProfileCompletionPrompt user={user} firstAccess={isFirstAccess} />
        <RetentionSurveyPrompt user={user} />
        <PushAtivarCard compacto />
      </div>



      <Card className="relative z-10 overflow-hidden border-0 p-6 text-primary-foreground" style={{ background: "var(--gradient-hero)" }}>
        {saudeVan === null ? (
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="text-sm uppercase tracking-wider opacity-80">🚐 Saúde da Van</div>
              <div className="mt-1 text-2xl font-extrabold">Ainda não avaliada</div>
              <div className="mt-1 text-sm opacity-90">
                Cadastre seus documentos e manutenções para acompanhar a saúde da sua van.
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <Link to="/documentos"><Button size="sm" variant="secondary">Cadastrar documentos</Button></Link>
                <Link to="/gastos"><Button size="sm" variant="outline" className="bg-white/10 border-white/30 text-white hover:bg-white/20">Adicionar primeira manutenção</Button></Link>
              </div>
            </div>
            <div className="text-right">
              <div className="text-5xl">⚪</div>
              <div className="text-xs uppercase tracking-wider opacity-80 mt-1">sem dados</div>
            </div>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="text-sm uppercase tracking-wider opacity-80">🚐 Saúde da Van</div>
                <div className="mt-1 text-3xl font-extrabold">
                  {saudeVan >= 80 ? "Pronta para rodar com segurança" : saudeVan >= 50 ? "Atenção em alguns pontos" : "Precisa de ajustes urgentes"}
                </div>
                <div className="mt-1 text-sm opacity-90">
                  {docsVencidos > 0 ? `${docsVencidos} documento(s) vencido(s). ` : "Documentos em dia. "}
                  {atrasadas > 0 ? `${atrasadas} mensalidade(s) em atraso.` : "Financeiro em dia."}
                </div>
              </div>
              <div className="text-right">
                <div className="text-6xl font-extrabold">{saudeVan}</div>
                <div className="text-xs uppercase tracking-wider opacity-80">de 100</div>
              </div>
            </div>
            <Progress value={saudeVan} className="mt-4 bg-white/20" />
          </>
        )}
      </Card>

      {atrasadas > 0 && (
        <Link to="/financeiro" hash="atraso">
          <Card className="p-5 border-destructive/40 bg-destructive/10 flex flex-wrap items-center justify-between gap-3 hover:bg-destructive/15 transition-colors">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-destructive/20 text-2xl">🔴</div>
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-destructive">Mensalidades em atraso</div>
                <div className="mt-1 text-2xl font-extrabold text-destructive">
                  {atrasadas} cobrança{atrasadas === 1 ? "" : "s"} · R$ {formatBRL(totalAtraso)}
                </div>
                <div className="text-xs text-muted-foreground">Toque para ver quem está devendo e cobrar.</div>
              </div>
            </div>
            <Button size="sm" variant="outline">Ver lista</Button>
          </Card>
        </Link>
      )}


      {contratosRenovar.length > 0 && (
        <Link to="/contratos">
          <Card className="p-4 border-warning/40 bg-warning/10 flex items-center justify-between gap-3 hover:bg-warning/15 transition-colors">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-warning/30 text-xl">📄</div>
              <div>
                <div className="font-bold text-warning-foreground">
                  {contratosRenovar.length} contrato(s) precisam ser renovados.
                </div>
                <div className="text-xs text-muted-foreground">Vencem nos próximos 30 dias. Clique para revisar.</div>
              </div>
            </div>
            <Button size="sm" variant="outline">Ver contratos</Button>
          </Card>
        </Link>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Users} label="Total de alunos" value={alunos.length} tone="primary" />
        <StatCard icon={Wallet} label="Mensalidades pagas" value={recebidas} tone="success" />
        <StatCard icon={AlertTriangle} label="Em atraso" value={atrasadas} tone="destructive" />
        <StatCard icon={Wallet} label="Recebido no mês" value={`R$ ${formatBRL(recebido)}`} tone="accent" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-2" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-accent-foreground">
                <CheckSquare className="h-4 w-4" /> Checklist diário
              </div>
              <h3 className="mt-1 text-lg font-bold">Garanta que nenhum aluno foi esquecido</h3>
              <p className="text-sm text-muted-foreground">Marque os alunos conforme você vai buscando.</p>
            </div>
            <Link to="/checklist"><Button className="bg-accent text-accent-foreground hover:bg-accent/90 font-bold">Abrir checklist</Button></Link>
          </div>
        </Card>

        <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
            <Fuel className="h-4 w-4" /> Último abastecimento
          </div>
          {ultimoAbast ? (
            <>
              <div className="mt-2 text-2xl font-bold">R$ {formatBRL(Number(ultimoAbast.valor))}</div>
              <div className="text-sm text-muted-foreground">
                {new Date(ultimoAbast.data + "T00:00:00").toLocaleDateString("pt-BR")}
                {ultimoAbast.km ? ` • ${ultimoAbast.km.toLocaleString("pt-BR")} km` : ""}
              </div>
            </>
          ) : (
            <div className="mt-2 text-sm text-muted-foreground">Nenhum registro ainda.</div>
          )}
        </Card>

        <Card className="p-6 lg:col-span-2" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-muted-foreground">
            <Calendar className="h-4 w-4" /> Próximos vencimentos
          </div>
          {proximosDocs.length === 0 ? (
            <div className="text-sm text-muted-foreground">Nenhum compromisso próximo.</div>
          ) : (
            <ul className="space-y-2">
              {proximosDocs.map((d) => (
                <li key={d.id} className="flex items-center justify-between rounded-lg bg-secondary/60 px-3 py-2">
                  <span className="text-sm font-medium flex items-center gap-2"><FileText className="h-3 w-3" /> {d.nome}</span>
                  <span className="text-xs text-muted-foreground">{new Date(d.vencimento!).toLocaleDateString("pt-BR")}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-muted-foreground">
            <Wrench className="h-4 w-4" /> Últimos gastos
          </div>
          {gastos.length === 0 ? (
            <div className="text-sm text-muted-foreground">Sem gastos.</div>
          ) : (
            <ul className="space-y-2">
              {gastos.slice(0, 4).map((g) => (
                <li key={g.id} className="flex items-center justify-between text-sm">
                  <span className="truncate">{g.categoria}</span>
                  <span className="font-semibold">R$ {formatBRL(Number(g.valor))}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card id="aniversariantes" className="scroll-mt-24 p-6 lg:col-span-3" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-muted-foreground">
            <Cake className="h-4 w-4" /> Aniversariantes do mês
          </div>
          {aniversariantes.length === 0 ? (
            <div className="text-sm text-muted-foreground">Nenhum aniversariante este mês.</div>
          ) : (
            <div className="flex flex-wrap gap-3">
              {aniversariantes.map(({ aluno, dm, hoje: ehHoje }) => (
                <div
                  key={aluno.id}
                  className={`flex items-center gap-3 rounded-xl border bg-card px-4 py-3 ${ehHoje ? "border-primary bg-primary/5" : ""}`}
                >
                  <AlunoAvatar nome={aluno.nome} avatar={aluno.avatar} size={36} />
                  <div>
                    <div className="flex items-center gap-2 text-sm font-bold">
                      {aluno.nome}
                      {ehHoje && (
                        <span className="rounded-full bg-primary px-2 py-0.5 text-[10px] font-extrabold uppercase text-primary-foreground">
                          Hoje 🎉
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">{formatDiaMes(dm)}</div>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => setAniversarioAlvo(aluno)}>
                    <MessageCircle className="h-4 w-4" /> Parabenizar
                  </Button>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      <AniversarioWhatsAppDialog
        open={!!aniversarioAlvo}
        onOpenChange={(v) => !v && setAniversarioAlvo(null)}
        alunoNome={aniversarioAlvo?.nome ?? ""}
        responsaveis={aniversarioAlvo ? contatosDoAluno(aniversarioAlvo.id, responsaveis) : []}
        assinatura={displayName}
      />
    </div>
  );
}


function StatCard({ icon: Icon, label, value, tone }: { icon: React.ElementType; label: string; value: string | number; tone: "primary" | "success" | "destructive" | "accent" }) {
  const toneClass = {
    primary: "bg-primary/10 text-primary",
    success: "bg-success/10 text-success",
    destructive: "bg-destructive/10 text-destructive",
    accent: "bg-accent/40 text-accent-foreground",
  }[tone];
  return (
    <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
      <div className={`mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl ${toneClass}`}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-extrabold">{value}</div>
    </Card>
  );
}
