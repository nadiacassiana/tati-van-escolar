import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import {
  FileText, Plus, Pencil, Trash2, CheckCircle2, AlertTriangle, Clock, AlertCircle,
  Upload, RotateCw, History, Search, Sparkles, Paperclip, Eye, Download,
  ClipboardCheck, Star, Shield, Phone, Copy, AlertOctagon,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { fileToCompressedDataUrl } from "@/lib/image";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/_authenticated/documentos")({
  head: () => ({ meta: [{ title: "Documentos da Van — Tati Van" }] }),
  component: DocumentosPage,
});

type HistoricoItem = { ts: string; tipo: string; descricao: string };
type SeguroInfo = {
  seguradora?: string;
  apolice?: string;
  corretor?: string;
  tel_corretor?: string;
  tel_24h?: string;
  cobertura?: string;
  franquia?: string;
};
type Documento = {
  id: string;
  nome: string;
  numero: string;
  vencimento: string | null;
  observacoes: string;
  categoria: string;
  arquivo: string | null;
  arquivo_nome: string | null;
  arquivo_tipo: string | null;
  historico: HistoricoItem[];
  vistoria_checklist: Record<string, boolean> | null;
  vistoria_concluida_em: string | null;
  vistoria_parabens_exibido: boolean;
  seguro_info: SeguroInfo | null;
  created_at: string;
  updated_at: string;
};

const ITENS_VISTORIA = [
  "Pneus em boas condições",
  "Freios revisados",
  "Faróis funcionando",
  "Lanternas funcionando",
  "Setas funcionando",
  "Luz de freio funcionando",
  "Limpadores de para-brisa funcionando",
  "Cintos de segurança em perfeito estado",
  "Tacógrafo regularizado",
  "Licenciamento válido",
  "Seguro atualizado",
  "Equipamentos obrigatórios conferidos",
  "Interior do veículo limpo",
  "Exterior do veículo em boas condições",
];

const ITENS_TACOGRAFO = [
  "Verificar prazo da aferição",
  "Conferir funcionamento do equipamento",
  "Conferir lacres",
  "Conferir alimentação elétrica",
  "Verificar registro das velocidades",
  "Conferir certificado de aferição",
  "Verificar se o equipamento apresenta falhas",
  "Confirmar que a documentação está anexada",
];

const ITENS_CRLV = [
  "Verificar se não existem débitos pendentes",
  "Conferir IPVA",
  "Conferir multas",
  "Conferir taxa de licenciamento",
  "Emitir o CRLV Digital após a quitação",
  "Baixar o documento atualizado",
  "Confirmar que o documento foi anexado na Tati Van Escolar",
];

const ITENS_SEGURO = [
  "Conferir a data de vencimento da apólice",
  "Verificar se o pagamento está em dia",
  "Confirmar a cobertura contratada",
  "Conferir assistência 24 horas",
  "Conferir cobertura para terceiros",
  "Conferir cobertura para passageiros",
  "Verificar carro reserva (quando houver)",
  "Atualizar telefone da seguradora",
  "Anexar a apólice atual",
];

type ChecklistKind = "vistoria" | "tacografo" | "crlv" | "seguro";

const isVistoria = (d: Documento) => (d.categoria || "").toLowerCase().includes("inmetro");
const isTacografo = (d: Documento) => {
  const c = (d.categoria || "").toLowerCase();
  return c.includes("tacógrafo") || c.includes("tacografo");
};
const isCRLV = (d: Documento) => {
  const c = (d.categoria || "").toLowerCase();
  return c.includes("crlv") || c.includes("licenciamento");
};
const isSeguro = (d: Documento) => (d.categoria || "").toLowerCase().includes("seguro");
const kindOf = (d: Documento): ChecklistKind | null =>
  isVistoria(d) ? "vistoria" : isTacografo(d) ? "tacografo" : isCRLV(d) ? "crlv" : isSeguro(d) ? "seguro" : null;
const itensOf = (k: ChecklistKind) =>
  k === "vistoria" ? ITENS_VISTORIA : k === "tacografo" ? ITENS_TACOGRAFO : k === "crlv" ? ITENS_CRLV : ITENS_SEGURO;
const tituloCard = (k: ChecklistKind) =>
  k === "vistoria" ? "Preparação para a Vistoria" : k === "tacografo" ? "Preparação do Tacógrafo" : k === "crlv" ? "Preparação do Licenciamento" : "Conferência do Seguro";
const tituloBotao = (k: ChecklistKind) =>
  k === "vistoria" ? "Checklist da Vistoria" : k === "tacografo" ? "Checklist do Tacógrafo" : k === "crlv" ? "Checklist do Licenciamento" : "Checklist do Seguro";
const tituloDialog = (k: ChecklistKind) =>
  k === "vistoria" ? "Checklist da Vistoria do INMETRO" : k === "tacografo" ? "Checklist do Tacógrafo" : k === "crlv" ? "Checklist do Licenciamento (CRLV)" : "Checklist do Seguro da Van";
const parabensTexto = (k: ChecklistKind) =>
  k === "vistoria"
    ? "Sua van está preparada para a vistoria do INMETRO. Desejamos uma excelente inspeção!"
    : k === "tacografo"
      ? "O tacógrafo está conferido e pronto para a aferição. Boa sorte!"
      : k === "crlv"
        ? "Licenciamento conferido! O CRLV da sua van está em ordem. 🚐💙"
        : "Seguro conferido! Sua van está protegida e você tem tranquilidade para rodar. 🛡️💙";

const checklistProgress = (
  state: Record<string, boolean> | null | undefined,
  itens: readonly string[] = ITENS_VISTORIA,
) => {
  const done = itens.filter((i) => state?.[i]).length;
  return { done, total: itens.length, pct: Math.round((done / itens.length) * 100) };
};
const stars = (pct: number) => Math.max(0, Math.min(5, Math.round(pct / 20)));

const CATEGORIAS = [
  "Licenciamento (CRLV)",
  "Seguro da Van",
  "Vistoria do INMETRO",
  "Aferição do Tacógrafo",
  "Revisão Geral",
  "Troca de Óleo",
  "Troca de Pneus",
  "Alinhamento e Balanceamento",
  "Extintor",
  "Outros",
];

const SUGESTOES = [
  { nome: "Licenciamento (CRLV)", categoria: "Licenciamento (CRLV)" },
  { nome: "Seguro da Van", categoria: "Seguro da Van" },
  { nome: "Vistoria do INMETRO", categoria: "Vistoria do INMETRO" },
  { nome: "Aferição do Tacógrafo", categoria: "Aferição do Tacógrafo" },
  { nome: "Revisão Geral", categoria: "Revisão Geral" },
  { nome: "Troca de Óleo", categoria: "Troca de Óleo" },
  { nome: "Troca de Pneus", categoria: "Troca de Pneus" },
  { nome: "Alinhamento e Balanceamento", categoria: "Alinhamento e Balanceamento" },
  { nome: "Extintor", categoria: "Extintor" },
];

const emptySeguro: SeguroInfo = {
  seguradora: "", apolice: "", corretor: "", tel_corretor: "", tel_24h: "", cobertura: "", franquia: "",
};

const emptyForm = {
  nome: "",
  categoria: "Licenciamento (CRLV)",
  numero: "",
  vencimento: "",
  observacoes: "",
  arquivo: null as string | null,
  arquivo_nome: null as string | null,
  arquivo_tipo: null as string | null,
  seguro_info: { ...emptySeguro } as SeguroInfo,
};

type Situacao = "valido" | "mes" | "semana" | "vencido" | "sem";

function situacaoOf(venc: string | null): Situacao {
  if (!venc) return "sem";
  const d = new Date(venc + "T00:00:00").getTime();
  const dias = Math.ceil((d - Date.now()) / (1000 * 60 * 60 * 24));
  if (dias < 0) return "vencido";
  if (dias <= 7) return "semana";
  if (dias <= 30) return "mes";
  return "valido";
}

const statusMap: Record<Situacao, { label: string; icon: any; className: string; dot: string }> = {
  valido: { label: "Em dia", icon: CheckCircle2, className: "bg-success/15 text-success border-success/30", dot: "🟢" },
  mes: { label: "Vence em 30 dias", icon: Clock, className: "bg-warning/20 text-warning-foreground border-warning/40", dot: "🟡" },
  semana: { label: "Vence esta semana", icon: AlertCircle, className: "bg-orange-500/15 text-orange-600 border-orange-500/30", dot: "🟠" },
  vencido: { label: "Vencido", icon: AlertTriangle, className: "bg-destructive/15 text-destructive border-destructive/30", dot: "🔴" },
  sem: { label: "Sem data", icon: FileText, className: "bg-muted text-muted-foreground", dot: "⚪" },
};

function alertaTexto(venc: string | null): string | null {
  if (!venc) return null;
  const dias = Math.ceil((new Date(venc + "T00:00:00").getTime() - Date.now()) / 86400000);
  if (dias < 0) return `Vencido há ${-dias} dia(s)`;
  if (dias === 0) return "Vence hoje!";
  if (dias === 1) return "Vence amanhã";
  if (dias <= 7) return `Vence em ${dias} dias`;
  if (dias <= 15) return `Vence em ${dias} dias`;
  if (dias <= 30) return `Vence em ${dias} dias`;
  return null;
}

function pushHist(arr: HistoricoItem[], tipo: string, descricao: string): HistoricoItem[] {
  return [{ ts: new Date().toISOString(), tipo, descricao }, ...(arr || [])];
}

async function fileToDataUrl(file: File): Promise<string> {
  if (file.type.startsWith("image/")) {
    return await fileToCompressedDataUrl(file, 1400, 0.85);
  }
  return await new Promise<string>((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(r.error);
    r.readAsDataURL(file);
  });
}

function DocumentosPage() {
  const { user } = Route.useRouteContext();
  const [lista, setLista] = useState<Documento[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [busca, setBusca] = useState("");
  const [filtroSit, setFiltroSit] = useState<string>("todos");
  const [ordem, setOrdem] = useState<string>("vencimento");
  const [histDoc, setHistDoc] = useState<Documento | null>(null);
  const [renovDoc, setRenovDoc] = useState<Documento | null>(null);
  const [renovForm, setRenovForm] = useState({ vencimento: "", arquivo: null as string | null, arquivo_nome: null as string | null, arquivo_tipo: null as string | null });
  const [viewArq, setViewArq] = useState<Documento | null>(null);
  const [checklistDoc, setChecklistDoc] = useState<Documento | null>(null);
  const [checklistKind, setChecklistKind] = useState<ChecklistKind>("vistoria");
  const [checklistState, setChecklistState] = useState<Record<string, boolean>>({});
  const [showParabens, setShowParabens] = useState(false);
  const [parabensKind, setParabensKind] = useState<ChecklistKind>("vistoria");
  const [emergDoc, setEmergDoc] = useState<Documento | null>(null);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("documentos").select("*").order("vencimento", { ascending: true, nullsFirst: false });
    setLista(((data as unknown) as Documento[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditingId(null); setForm(emptyForm); setOpen(true); };
  const openEdit = (d: Documento) => {
    setEditingId(d.id);
    setForm({
      nome: d.nome, categoria: d.categoria || "Outros", numero: d.numero,
      vencimento: d.vencimento || "", observacoes: d.observacoes,
      arquivo: d.arquivo, arquivo_nome: d.arquivo_nome, arquivo_tipo: d.arquivo_tipo,
      seguro_info: { ...emptySeguro, ...(d.seguro_info || {}) },
    });
    setOpen(true);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, target: "form" | "renov") => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 4 * 1024 * 1024) return toast.error("Arquivo muito grande (máx 4MB).");
    try {
      const url = await fileToDataUrl(f);
      if (target === "form") setForm((p) => ({ ...p, arquivo: url, arquivo_nome: f.name, arquivo_tipo: f.type }));
      else setRenovForm((p) => ({ ...p, arquivo: url, arquivo_nome: f.name, arquivo_tipo: f.type }));
      toast.success("Arquivo anexado.");
    } catch {
      toast.error("Não foi possível ler o arquivo.");
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome.trim()) return toast.error("Informe o nome do documento.");
    setSaving(true);
    const base = {
      nome: form.nome.trim(),
      categoria: form.categoria,
      numero: form.numero,
      vencimento: form.vencimento || null,
      observacoes: form.observacoes,
      arquivo: form.arquivo,
      arquivo_nome: form.arquivo_nome,
      arquivo_tipo: form.arquivo_tipo,
      seguro_info: form.categoria.toLowerCase().includes("seguro") ? form.seguro_info : {},
    };
    if (editingId) {
      const orig = lista.find((x) => x.id === editingId);
      let hist = orig?.historico || [];
      hist = pushHist(hist, "editado", "Documento editado");
      if (orig && orig.vencimento !== base.vencimento && base.vencimento)
        hist = pushHist(hist, "vencimento", `Novo vencimento: ${new Date(base.vencimento + "T00:00:00").toLocaleDateString("pt-BR")}`);
      if (orig && orig.arquivo !== base.arquivo && base.arquivo)
        hist = pushHist(hist, "arquivo", `Arquivo atualizado: ${base.arquivo_nome || "anexo"}`);
      const { error } = await supabase.from("documentos").update({ ...base, historico: hist }).eq("id", editingId);
      setSaving(false);
      if (error) return toast.error("Erro ao salvar.");
      toast.success("Documento atualizado!");
    } else {
      const hist = pushHist([], "criado", `Documento "${base.nome}" cadastrado`);
      const { error } = await supabase.from("documentos").insert({ ...base, user_id: user.id, historico: hist });
      setSaving(false);
      if (error) return toast.error("Erro ao cadastrar.");
      toast.success("Documento cadastrado!");
    }
    setOpen(false);
    load();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("documentos").delete().eq("id", id);
    if (error) return toast.error("Erro ao excluir.");
    setLista((p) => p.filter((d) => d.id !== id));
    toast.success("Documento excluído.");
  };

  const openRenov = (d: Documento) => {
    setRenovDoc(d);
    setRenovForm({ vencimento: "", arquivo: null, arquivo_nome: null, arquivo_tipo: null });
  };

  const handleRenovar = async () => {
    if (!renovDoc) return;
    if (!renovForm.vencimento) return toast.error("Informe a nova data de vencimento.");
    let hist = renovDoc.historico || [];
    hist = pushHist(hist, "renovado", `Renovado — novo vencimento ${new Date(renovForm.vencimento + "T00:00:00").toLocaleDateString("pt-BR")}`);
    const patch: any = { vencimento: renovForm.vencimento, historico: hist };
    if (renovForm.arquivo) {
      patch.arquivo = renovForm.arquivo;
      patch.arquivo_nome = renovForm.arquivo_nome;
      patch.arquivo_tipo = renovForm.arquivo_tipo;
      hist = pushHist(hist, "arquivo", `Novo arquivo: ${renovForm.arquivo_nome}`);
      patch.historico = hist;
    }
    const { error } = await supabase.from("documentos").update(patch).eq("id", renovDoc.id);
    if (error) return toast.error("Erro ao renovar.");
    toast.success("Documento renovado!");
    setRenovDoc(null);
    load();
  };

  const openChecklist = (d: Documento) => {
    const k = kindOf(d);
    if (!k) return;
    setChecklistDoc(d);
    setChecklistKind(k);
    setChecklistState((d.vistoria_checklist as Record<string, boolean>) || {});
    const tag = k === "vistoria" ? "checklist_vistoria_iniciado" : k === "tacografo" ? "checklist_tacografo_iniciado" : k === "crlv" ? "checklist_crlv_iniciado" : "checklist_seguro_iniciado";
    if (!(d.historico || []).some((h) => h.tipo === tag || h.tipo === "checklist_iniciado")) {
      const desc = k === "vistoria" ? "Checklist da vistoria iniciado" : k === "tacografo" ? "Checklist do tacógrafo iniciado" : k === "crlv" ? "Checklist do licenciamento iniciado" : "Checklist do seguro iniciado";
      const hist = pushHist(d.historico || [], tag, desc);
      supabase.from("documentos").update({ historico: hist }).eq("id", d.id).then(() => load());
    }
  };

  const toggleItem = async (item: string, val: boolean) => {
    if (!checklistDoc) return;
    const next = { ...checklistState, [item]: val };
    setChecklistState(next);
    const itens = itensOf(checklistKind);
    const prog = checklistProgress(next, itens);
    let hist = checklistDoc.historico || [];
    const patch: any = { vistoria_checklist: next };
    let parabens = false;
    if (prog.pct === 100 && !checklistDoc.vistoria_parabens_exibido) {
      patch.vistoria_concluida_em = new Date().toISOString();
      patch.vistoria_parabens_exibido = true;
      const tag = checklistKind === "vistoria" ? "checklist_vistoria_concluido" : checklistKind === "tacografo" ? "checklist_tacografo_concluido" : checklistKind === "crlv" ? "checklist_crlv_concluido" : "checklist_seguro_concluido";
      const desc = checklistKind === "vistoria"
        ? "Checklist da vistoria concluído (100%)"
        : checklistKind === "tacografo"
          ? "Checklist do tacógrafo concluído (100%)"
          : checklistKind === "crlv"
            ? "Checklist do licenciamento concluído (100%)"
            : "Checklist do seguro concluído (100%)";
      hist = pushHist(hist, tag, desc);
      patch.historico = hist;
      parabens = true;
    }
    const { error } = await supabase.from("documentos").update(patch).eq("id", checklistDoc.id);
    if (error) return toast.error("Erro ao salvar checklist.");
    if (parabens) { setParabensKind(checklistKind); setShowParabens(true); }
    setChecklistDoc({ ...checklistDoc, ...patch, vistoria_checklist: next });
    setLista((p) => p.map((x) => (x.id === checklistDoc.id ? { ...x, ...patch, vistoria_checklist: next } as Documento : x)));
  };

  const proximaVistoria = useMemo(() => {
    const vs = lista.filter((d) => isVistoria(d) && d.vencimento);
    vs.sort((a, b) => (a.vencimento || "").localeCompare(b.vencimento || ""));
    return vs[0] || null;
  }, [lista]);

  const diasParaVistoria = proximaVistoria?.vencimento
    ? Math.ceil((new Date(proximaVistoria.vencimento + "T00:00:00").getTime() - Date.now()) / 86400000)
    : null;

  const proximoTacografo = useMemo(() => {
    const vs = lista.filter((d) => isTacografo(d) && d.vencimento);
    vs.sort((a, b) => (a.vencimento || "").localeCompare(b.vencimento || ""));
    return vs[0] || null;
  }, [lista]);

  const diasParaTacografo = proximoTacografo?.vencimento
    ? Math.ceil((new Date(proximoTacografo.vencimento + "T00:00:00").getTime() - Date.now()) / 86400000)
    : null;

  const proximoCRLV = useMemo(() => {
    const vs = lista.filter((d) => isCRLV(d) && d.vencimento);
    vs.sort((a, b) => (a.vencimento || "").localeCompare(b.vencimento || ""));
    return vs[0] || null;
  }, [lista]);

  const diasParaCRLV = proximoCRLV?.vencimento
    ? Math.ceil((new Date(proximoCRLV.vencimento + "T00:00:00").getTime() - Date.now()) / 86400000)
    : null;

  const proximoSeguro = useMemo(() => {
    const vs = lista.filter((d) => isSeguro(d) && d.vencimento);
    vs.sort((a, b) => (a.vencimento || "").localeCompare(b.vencimento || ""));
    return vs[0] || null;
  }, [lista]);

  const diasParaSeguro = proximoSeguro?.vencimento
    ? Math.ceil((new Date(proximoSeguro.vencimento + "T00:00:00").getTime() - Date.now()) / 86400000)
    : null;




  const addSugestoes = async () => {
    const rows = SUGESTOES.map((s) => ({
      user_id: user.id, nome: s.nome, categoria: s.categoria, numero: "", observacoes: "",
      historico: [{ ts: new Date().toISOString(), tipo: "criado", descricao: `Sugestão "${s.nome}" adicionada` }],
    }));
    const { error } = await supabase.from("documentos").insert(rows);
    if (error) return toast.error("Erro ao adicionar sugestões.");
    toast.success("Documentos sugeridos adicionados!");
    load();
  };

  const stats = useMemo(() => {
    const s = { total: lista.length, valido: 0, atencao: 0, vencido: 0 };
    lista.forEach((d) => {
      const x = situacaoOf(d.vencimento);
      if (x === "valido") s.valido++;
      else if (x === "mes" || x === "semana") s.atencao++;
      else if (x === "vencido") s.vencido++;
    });
    return s;
  }, [lista]);

  const filtrados = useMemo(() => {
    let arr = [...lista];
    const q = busca.trim().toLowerCase();
    if (q) arr = arr.filter((d) =>
      d.nome.toLowerCase().includes(q) ||
      (d.categoria || "").toLowerCase().includes(q) ||
      (d.numero || "").toLowerCase().includes(q)
    );
    if (filtroSit !== "todos") arr = arr.filter((d) => situacaoOf(d.vencimento) === filtroSit);
    arr.sort((a, b) => {
      if (ordem === "nome") return a.nome.localeCompare(b.nome);
      if (ordem === "tipo") return (a.categoria || "").localeCompare(b.categoria || "");
      if (ordem === "recente") return b.created_at.localeCompare(a.created_at);
      if (ordem === "situacao") {
        const w: Record<Situacao, number> = { vencido: 0, semana: 1, mes: 2, valido: 3, sem: 4 };
        return w[situacaoOf(a.vencimento)] - w[situacaoOf(b.vencimento)];
      }
      // vencimento
      if (!a.vencimento && !b.vencimento) return 0;
      if (!a.vencimento) return 1;
      if (!b.vencimento) return -1;
      return a.vencimento.localeCompare(b.vencimento);
    });
    return arr;
  }, [lista, busca, filtroSit, ordem]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">Documentos da Van 📄</h1>
          <p className="text-sm text-muted-foreground">Central de controle documental — sempre em dia.</p>
        </div>
        <div className="flex gap-2">
          {lista.length === 0 && !loading && (
            <Button variant="outline" onClick={addSugestoes}>
              <Sparkles className="mr-2 h-4 w-4" /> Adicionar sugeridos
            </Button>
          )}
          <Button onClick={openCreate} className="bg-primary text-primary-foreground font-bold">
            <Plus className="mr-2 h-4 w-4" /> Novo documento
          </Button>
        </div>
      </div>

      {/* Dashboard */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">📄 Total</div>
          <div className="text-2xl font-extrabold">{stats.total}</div>
        </Card>
        <Card className="p-4 border-success/30">
          <div className="text-xs text-muted-foreground">🟢 Em dia</div>
          <div className="text-2xl font-extrabold text-success">{stats.valido}</div>
        </Card>
        <Card className="p-4 border-warning/40">
          <div className="text-xs text-muted-foreground">🟡 Próximos</div>
          <div className="text-2xl font-extrabold text-warning-foreground">{stats.atencao}</div>
        </Card>
        <Card className="p-4 border-destructive/30">
          <div className="text-xs text-muted-foreground">🔴 Vencidos</div>
          <div className="text-2xl font-extrabold text-destructive">{stats.vencido}</div>
        </Card>
      </div>

      {/* Alerta Vistoria INMETRO */}
      {proximaVistoria && diasParaVistoria !== null && (diasParaVistoria <= 30) && (() => {
        const prog = checklistProgress(proximaVistoria.vistoria_checklist);
        const vencida = diasParaVistoria < 0;
        return (
          <Card className={`p-4 ${vencida ? "border-destructive/40 bg-destructive/10" : "border-warning/40 bg-warning/10"}`}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="text-2xl">{vencida ? "🔴" : "🟡"}</div>
                <div className="min-w-0">
                  <div className="font-bold">
                    {vencida ? "Vistoria do INMETRO vencida!" : "Vistoria do INMETRO em breve"}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {vencida
                      ? `Vencida há ${-diasParaVistoria} dia(s). Atualize a data o quanto antes.`
                      : diasParaVistoria === 0
                        ? "Vence hoje! Prepare a van."
                        : `Vence em ${diasParaVistoria} dia(s). Preparação: ${prog.pct}%`}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="hidden sm:flex items-center gap-1 text-warning-foreground">
                  {[1,2,3,4,5].map((n) => (
                    <Star key={n} className={`h-4 w-4 ${n <= stars(prog.pct) ? "fill-warning text-warning" : "text-muted-foreground/40"}`} />
                  ))}
                </div>
                <Button size="sm" onClick={() => openChecklist(proximaVistoria)} className="bg-primary text-primary-foreground font-bold">
                  <ClipboardCheck className="mr-1 h-4 w-4" /> Abrir Checklist
                </Button>
              </div>
            </div>
          </Card>
        );
      })()}

      {/* Alerta Tacógrafo */}
      {proximoTacografo && diasParaTacografo !== null && (diasParaTacografo <= 30) && (() => {
        const prog = checklistProgress(proximoTacografo.vistoria_checklist, ITENS_TACOGRAFO);
        const vencida = diasParaTacografo < 0;
        return (
          <Card className={`p-4 ${vencida ? "border-destructive/40 bg-destructive/10" : "border-warning/40 bg-warning/10"}`}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="text-2xl">{vencida ? "🔴" : "🟡"}</div>
                <div className="min-w-0">
                  <div className="font-bold">
                    {vencida ? "Aferição do Tacógrafo vencida!" : "Tacógrafo próximo do vencimento"}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {vencida
                      ? `Vencida há ${-diasParaTacografo} dia(s). Renove o quanto antes.`
                      : diasParaTacografo === 0
                        ? "Vence hoje! Providencie a aferição."
                        : `A aferição do tacógrafo vence em ${diasParaTacografo} dia(s). Preparação: ${prog.pct}%`}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="hidden sm:flex items-center gap-1 text-warning-foreground">
                  {[1,2,3,4,5].map((n) => (
                    <Star key={n} className={`h-4 w-4 ${n <= stars(prog.pct) ? "fill-warning text-warning" : "text-muted-foreground/40"}`} />
                  ))}
                </div>
                <Button size="sm" onClick={() => openChecklist(proximoTacografo)} className="bg-primary text-primary-foreground font-bold">
                  <ClipboardCheck className="mr-1 h-4 w-4" /> 🛞 Abrir Checklist
                </Button>
              </div>
            </div>
          </Card>
        );
      })()}

      {/* Alerta CRLV / Licenciamento */}
      {proximoCRLV && diasParaCRLV !== null && (diasParaCRLV <= 30) && (() => {
        const prog = checklistProgress(proximoCRLV.vistoria_checklist, ITENS_CRLV);
        const vencida = diasParaCRLV < 0;
        return (
          <Card className={`p-4 ${vencida ? "border-destructive/40 bg-destructive/10" : "border-warning/40 bg-warning/10"}`}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="text-2xl">{vencida ? "🔴" : "🟡"}</div>
                <div className="min-w-0">
                  <div className="font-bold">
                    {vencida ? "Licenciamento (CRLV) vencido!" : "Licenciamento próximo do vencimento"}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {vencida
                      ? `Vencido há ${-diasParaCRLV} dia(s). Regularize o quanto antes para circular legalmente.`
                      : diasParaCRLV === 0
                        ? "Vence hoje! Providencie a renovação."
                        : `O CRLV vence em ${diasParaCRLV} dia(s). Preparação: ${prog.pct}%`}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="hidden sm:flex items-center gap-1 text-warning-foreground">
                  {[1,2,3,4,5].map((n) => (
                    <Star key={n} className={`h-4 w-4 ${n <= stars(prog.pct) ? "fill-warning text-warning" : "text-muted-foreground/40"}`} />
                  ))}
                </div>
                <Button size="sm" onClick={() => openChecklist(proximoCRLV)} className="bg-primary text-primary-foreground font-bold">
                  <ClipboardCheck className="mr-1 h-4 w-4" /> 📋 Abrir Checklist
                </Button>
              </div>
            </div>
          </Card>
        );
      })()}

      {/* Alerta Seguro */}
      {proximoSeguro && diasParaSeguro !== null && (diasParaSeguro <= 30) && (() => {
        const prog = checklistProgress(proximoSeguro.vistoria_checklist, ITENS_SEGURO);
        const vencida = diasParaSeguro < 0;
        return (
          <Card className={`p-4 ${vencida ? "border-destructive/40 bg-destructive/10" : "border-warning/40 bg-warning/10"}`}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="text-2xl">{vencida ? "🔴" : "🟡"}</div>
                <div className="min-w-0">
                  <div className="font-bold">
                    {vencida ? "Seguro da Van vencido!" : "Seguro próximo do vencimento"}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {vencida
                      ? `Vencido há ${-diasParaSeguro} dia(s). Renove o seguro o quanto antes.`
                      : diasParaSeguro === 0
                        ? "Vence hoje! Providencie a renovação."
                        : `O seguro da sua van vence em ${diasParaSeguro} dia(s). Preparação: ${prog.pct}%`}
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button size="sm" variant="outline" onClick={() => setEmergDoc(proximoSeguro)}>
                  <AlertOctagon className="mr-1 h-4 w-4 text-destructive" /> 🚨 Acionar
                </Button>
                <Button size="sm" onClick={() => openChecklist(proximoSeguro)} className="bg-primary text-primary-foreground font-bold">
                  <Shield className="mr-1 h-4 w-4" /> 🛡️ Abrir Seguro
                </Button>
              </div>
            </div>
          </Card>
        );
      })()}






      {/* Filtros */}
      <Card className="p-3 flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-8" placeholder="Pesquisar por nome, tipo, número..." value={busca} onChange={(e) => setBusca(e.target.value)} />
        </div>
        <Select value={filtroSit} onValueChange={setFiltroSit}>
          <SelectTrigger className="w-[170px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todas situações</SelectItem>
            <SelectItem value="valido">🟢 Em dia</SelectItem>
            <SelectItem value="mes">🟡 Até 30 dias</SelectItem>
            <SelectItem value="semana">🟠 Esta semana</SelectItem>
            <SelectItem value="vencido">🔴 Vencidos</SelectItem>
            <SelectItem value="sem">⚪ Sem data</SelectItem>
          </SelectContent>
        </Select>
        <Select value={ordem} onValueChange={setOrdem}>
          <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="vencimento">Mais próximo do vencimento</SelectItem>
            <SelectItem value="recente">Mais recente</SelectItem>
            <SelectItem value="nome">Nome</SelectItem>
            <SelectItem value="tipo">Tipo</SelectItem>
            <SelectItem value="situacao">Situação</SelectItem>
          </SelectContent>
        </Select>
      </Card>

      {loading ? (
        <Card className="p-6 text-center text-sm text-muted-foreground">Carregando...</Card>
      ) : lista.length === 0 ? (
        <Card className="p-8 text-center space-y-3">
          <div className="text-4xl">📄</div>
          <div className="font-bold">Nenhum documento cadastrado</div>
          <div className="text-sm text-muted-foreground">Comece adicionando os principais documentos da sua van.</div>
          <Button onClick={addSugestoes} className="bg-primary text-primary-foreground font-bold">
            <Sparkles className="mr-2 h-4 w-4" /> Adicionar sugeridos
          </Button>
        </Card>
      ) : filtrados.length === 0 ? (
        <Card className="p-6 text-center text-sm text-muted-foreground">Nenhum documento corresponde aos filtros.</Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {filtrados.map((d) => {
            const sit = situacaoOf(d.vencimento);
            const s = statusMap[sit];
            const alerta = alertaTexto(d.vencimento);
            return (
              <Card key={d.id} className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary text-lg">
                      {s.dot}
                    </div>
                    <div className="min-w-0">
                      <div className="font-bold truncate">{d.nome}</div>
                      <div className="text-xs text-muted-foreground truncate">
                        {d.categoria}{d.numero ? ` • Nº ${d.numero}` : ""}
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline" className={s.className}>
                    <s.icon className="mr-1 h-3 w-3" /> {s.label}
                  </Badge>
                </div>
                <div className="mt-3 text-sm">
                  <span className="text-muted-foreground">Vencimento: </span>
                  <span className="font-semibold">
                    {d.vencimento ? new Date(d.vencimento + "T00:00:00").toLocaleDateString("pt-BR") : "—"}
                  </span>
                  {alerta && (
                    <Badge variant="outline" className={`ml-2 ${s.className}`}>⏰ {alerta}</Badge>
                  )}
                </div>
                {d.observacoes && (
                  <div className="mt-2 rounded-lg bg-secondary/60 p-2 text-xs text-muted-foreground">{d.observacoes}</div>
                )}
                {d.arquivo && (
                  <div className="mt-2 flex items-center gap-2 text-xs">
                    <Paperclip className="h-3 w-3 text-primary" />
                    <span className="truncate">{d.arquivo_nome || "anexo"}</span>
                    <Button size="sm" variant="ghost" className="h-6 px-2" onClick={() => setViewArq(d)}>
                      <Eye className="h-3 w-3" />
                    </Button>
                    <a href={d.arquivo} download={d.arquivo_nome || "documento"}>
                      <Button size="sm" variant="ghost" className="h-6 px-2">
                        <Download className="h-3 w-3" />
                      </Button>
                    </a>
                  </div>
                )}
                {(() => {
                  const k = kindOf(d);
                  if (!k) return null;
                  const itens = itensOf(k);
                  const prog = checklistProgress(d.vistoria_checklist, itens);
                  const emoji = k === "vistoria" ? "✅" : k === "tacografo" ? "🛞" : k === "crlv" ? "📋" : "🛡️";
                  return (
                    <div className="mt-3 rounded-lg border border-primary/30 bg-primary/5 p-3 space-y-2">
                      <div className="flex items-center justify-between gap-2 text-xs font-semibold">
                        <span className="flex items-center gap-1"><ClipboardCheck className="h-3 w-3" /> {tituloCard(k)}</span>
                        <span className="flex items-center gap-1">
                          {[1,2,3,4,5].map((n) => (
                            <Star key={n} className={`h-3 w-3 ${n <= stars(prog.pct) ? "fill-warning text-warning" : "text-muted-foreground/30"}`} />
                          ))}
                          <span className="ml-1">{prog.pct}%</span>
                        </span>
                      </div>
                      <Progress value={prog.pct} />
                      <Button size="sm" className="w-full bg-primary text-primary-foreground font-bold" onClick={() => openChecklist(d)}>
                        {emoji} {tituloBotao(k)} ({prog.done}/{prog.total})
                      </Button>
                    </div>
                  );
                })()}
                {isSeguro(d) && (
                  <div className="mt-3">
                    <Button size="sm" variant="outline" className="w-full border-destructive/40 text-destructive hover:bg-destructive/10" onClick={() => setEmergDoc(d)}>
                      <AlertOctagon className="mr-1 h-4 w-4" /> 🚨 Acionar Seguro
                    </Button>
                  </div>
                )}
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => openEdit(d)}>
                    <Pencil className="mr-1 h-3 w-3" /> Editar
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => openRenov(d)}>
                    <RotateCw className="mr-1 h-3 w-3" /> Renovar
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setHistDoc(d)}>
                    <History className="mr-1 h-3 w-3" /> Histórico
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button size="sm" variant="outline" className="text-destructive">
                        <Trash2 className="mr-1 h-3 w-3" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Excluir documento?</AlertDialogTitle>
                        <AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(d.id)}>Excluir</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Form Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingId ? "Editar documento" : "Novo documento"}</DialogTitle>
            <DialogDescription>Mantenha seus documentos sempre em dia.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <Label>Tipo / Categoria</Label>
              <Select value={form.categoria} onValueChange={(v) => setForm({ ...form, categoria: v, nome: form.nome || v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIAS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="nome">Nome do documento *</Label>
              <Input id="nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex.: CRLV 2026" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="num">Número (opcional)</Label>
                <Input id="num" value={form.numero} onChange={(e) => setForm({ ...form, numero: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="venc">Vencimento</Label>
                <Input id="venc" type="date" value={form.vencimento} onChange={(e) => setForm({ ...form, vencimento: e.target.value })} />
              </div>
            </div>
            <div>
              <Label htmlFor="obs">Observações</Label>
              <Textarea id="obs" rows={2} value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} />
            </div>
            {form.categoria.toLowerCase().includes("seguro") && (
              <div className="rounded-xl border border-primary/30 bg-primary/5 p-3 space-y-2">
                <div className="text-sm font-bold flex items-center gap-1">
                  <Shield className="h-4 w-4 text-primary" /> Informações da Apólice (opcional)
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label className="text-xs">Seguradora</Label>
                    <Input value={form.seguro_info.seguradora || ""} onChange={(e) => setForm({ ...form, seguro_info: { ...form.seguro_info, seguradora: e.target.value } })} />
                  </div>
                  <div>
                    <Label className="text-xs">Nº da Apólice</Label>
                    <Input value={form.seguro_info.apolice || ""} onChange={(e) => setForm({ ...form, seguro_info: { ...form.seguro_info, apolice: e.target.value } })} />
                  </div>
                  <div>
                    <Label className="text-xs">Corretor</Label>
                    <Input value={form.seguro_info.corretor || ""} onChange={(e) => setForm({ ...form, seguro_info: { ...form.seguro_info, corretor: e.target.value } })} />
                  </div>
                  <div>
                    <Label className="text-xs">Tel. do Corretor</Label>
                    <Input value={form.seguro_info.tel_corretor || ""} onChange={(e) => setForm({ ...form, seguro_info: { ...form.seguro_info, tel_corretor: e.target.value } })} />
                  </div>
                  <div>
                    <Label className="text-xs">Tel. 24h da Seguradora</Label>
                    <Input value={form.seguro_info.tel_24h || ""} onChange={(e) => setForm({ ...form, seguro_info: { ...form.seguro_info, tel_24h: e.target.value } })} />
                  </div>
                  <div>
                    <Label className="text-xs">Franquia (opcional)</Label>
                    <Input value={form.seguro_info.franquia || ""} onChange={(e) => setForm({ ...form, seguro_info: { ...form.seguro_info, franquia: e.target.value } })} />
                  </div>
                  <div className="col-span-2">
                    <Label className="text-xs">Cobertura contratada</Label>
                    <Textarea rows={2} value={form.seguro_info.cobertura || ""} onChange={(e) => setForm({ ...form, seguro_info: { ...form.seguro_info, cobertura: e.target.value } })} />
                  </div>
                </div>
              </div>
            )}
            <div>
              <Label>Anexar arquivo (foto, imagem ou PDF — máx 4MB)</Label>
              <div className="flex items-center gap-2">
                <Input type="file" accept="image/*,application/pdf" onChange={(e) => handleFileChange(e, "form")} />
                {form.arquivo && (
                  <Button type="button" size="sm" variant="ghost" onClick={() => setForm({ ...form, arquivo: null, arquivo_nome: null, arquivo_tipo: null })}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                )}
              </div>
              {form.arquivo_nome && (
                <div className="mt-1 text-xs text-muted-foreground flex items-center gap-1">
                  <Paperclip className="h-3 w-3" /> {form.arquivo_nome}
                </div>
              )}
            </div>
            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saving} className="bg-primary text-primary-foreground font-bold">
                {saving ? "Salvando..." : "Salvar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Renovar Dialog */}
      <Dialog open={!!renovDoc} onOpenChange={(o) => !o && setRenovDoc(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>🔄 Renovar documento</DialogTitle>
            <DialogDescription>{renovDoc?.nome}</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Nova data de vencimento *</Label>
              <Input type="date" value={renovForm.vencimento} onChange={(e) => setRenovForm({ ...renovForm, vencimento: e.target.value })} />
            </div>
            <div>
              <Label>Novo arquivo (opcional)</Label>
              <Input type="file" accept="image/*,application/pdf" onChange={(e) => handleFileChange(e, "renov")} />
              {renovForm.arquivo_nome && (
                <div className="mt-1 text-xs text-muted-foreground flex items-center gap-1">
                  <Paperclip className="h-3 w-3" /> {renovForm.arquivo_nome}
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground">O histórico anterior será mantido e a renovação registrada automaticamente.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRenovDoc(null)}>Cancelar</Button>
            <Button onClick={handleRenovar} className="bg-primary text-primary-foreground font-bold">
              <RotateCw className="mr-2 h-4 w-4" /> Renovar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Histórico Dialog */}
      <Dialog open={!!histDoc} onOpenChange={(o) => !o && setHistDoc(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>📜 Linha do tempo</DialogTitle>
            <DialogDescription>{histDoc?.nome}</DialogDescription>
          </DialogHeader>
          <div className="max-h-[400px] overflow-y-auto space-y-2">
            {(histDoc?.historico || []).length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">Sem registros ainda.</p>
            ) : (
              (histDoc?.historico || []).map((h, i) => (
                <div key={i} className="flex gap-3 rounded-lg border p-3">
                  <div className="text-xl">📅</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold">{h.descricao}</div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(h.ts).toLocaleString("pt-BR")}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Visualizar arquivo */}
      <Dialog open={!!viewArq} onOpenChange={(o) => !o && setViewArq(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{viewArq?.arquivo_nome || "Arquivo"}</DialogTitle>
          </DialogHeader>
          {viewArq?.arquivo && (
            viewArq.arquivo_tipo?.startsWith("image/") ? (
              <img src={viewArq.arquivo} alt={viewArq.nome} className="w-full rounded-lg" />
            ) : (
              <iframe src={viewArq.arquivo} className="w-full h-[70vh] rounded-lg border" title={viewArq.nome} />
            )
          )}
        </DialogContent>
      </Dialog>

      {/* Checklist da Vistoria */}
      <Dialog open={!!checklistDoc} onOpenChange={(o) => !o && setChecklistDoc(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ClipboardCheck className="h-5 w-5 text-primary" /> {tituloDialog(checklistKind)}
            </DialogTitle>
            <DialogDescription>{checklistDoc?.nome}</DialogDescription>
          </DialogHeader>
          {checklistDoc && (() => {
            const itens = itensOf(checklistKind);
            const prog = checklistProgress(checklistState, itens);
            return (
              <div className="space-y-4">
                <div className="rounded-xl border bg-secondary/40 p-3 space-y-2">
                  <div className="flex items-center justify-between text-sm font-semibold">
                    <span>{tituloCard(checklistKind)}</span>
                    <span>{prog.done}/{prog.total} • {prog.pct}%</span>
                  </div>
                  <Progress value={prog.pct} />
                  <div className="flex items-center gap-1">
                    {[1,2,3,4,5].map((n) => (
                      <Star key={n} className={`h-4 w-4 ${n <= stars(prog.pct) ? "fill-warning text-warning" : "text-muted-foreground/30"}`} />
                    ))}
                    {prog.pct === 100 && <span className="ml-2 text-success font-bold text-sm">🟢 100% concluído</span>}
                  </div>
                </div>
                <div className="space-y-2">
                  {itens.map((item) => (
                    <label key={item} className="flex items-center gap-3 rounded-lg border p-3 cursor-pointer hover:bg-accent/30">
                      <Checkbox
                        checked={!!checklistState[item]}
                        onCheckedChange={(v) => toggleItem(item, !!v)}
                      />
                      <span className={`text-sm flex-1 ${checklistState[item] ? "line-through text-muted-foreground" : ""}`}>{item}</span>
                    </label>
                  ))}
                </div>
              </div>
            );
          })()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setChecklistDoc(null)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Parabéns */}
      <Dialog open={showParabens} onOpenChange={setShowParabens}>
        <DialogContent className="sm:max-w-md text-center">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">🎉 Parabéns!</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="text-5xl">🚐💙</div>
            <p className="font-semibold">Seu checklist foi concluído com sucesso.</p>
            <p className="text-sm text-muted-foreground">
              {parabensTexto(parabensKind)}
            </p>
            <div className="flex items-center justify-center gap-1 pt-2">
              {[1,2,3,4,5].map((n) => (
                <Star key={n} className="h-6 w-6 fill-warning text-warning" />
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button className="w-full bg-primary text-primary-foreground font-bold" onClick={() => setShowParabens(false)}>
              Obrigada, Tati! 💙
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Emergência Seguro */}
      <Dialog open={!!emergDoc} onOpenChange={(o) => !o && setEmergDoc(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive">
              <AlertOctagon className="h-5 w-5" /> 🚨 Acionar Seguro
            </DialogTitle>
            <DialogDescription>Informações rápidas para emergência — {emergDoc?.nome}</DialogDescription>
          </DialogHeader>
          {emergDoc && (() => {
            const si = (emergDoc.seguro_info || {}) as SeguroInfo;
            const linhas: { label: string; value?: string; tel?: boolean; copy?: boolean }[] = [
              { label: "Seguradora", value: si.seguradora },
              { label: "Telefone 24h", value: si.tel_24h, tel: true },
              { label: "Corretor", value: si.corretor },
              { label: "Tel. do Corretor", value: si.tel_corretor, tel: true },
              { label: "Nº da Apólice", value: si.apolice, copy: true },
              { label: "Cobertura", value: si.cobertura },
            ];
            const anyData = linhas.some((l) => l.value);
            if (!anyData) {
              return (
                <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground text-center">
                  Cadastre as informações da apólice no documento para acessá-las em segundos durante uma emergência.
                </div>
              );
            }
            return (
              <div className="space-y-2">
                {linhas.filter((l) => l.value).map((l) => (
                  <div key={l.label} className="flex items-center justify-between gap-2 rounded-lg border p-3">
                    <div className="min-w-0">
                      <div className="text-xs text-muted-foreground">{l.label}</div>
                      <div className="font-semibold text-sm break-words">{l.value}</div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      {l.tel && (
                        <a href={`tel:${(l.value || "").replace(/\D/g, "")}`}>
                          <Button size="sm" className="bg-success text-success-foreground"><Phone className="h-3 w-3" /></Button>
                        </a>
                      )}
                      {l.copy && (
                        <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(l.value || ""); toast.success("Apólice copiada!"); }}>
                          <Copy className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEmergDoc(null)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
