import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Send, Sparkles, Lightbulb } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SugerirMelhoriaDialog } from "@/components/sugerir-melhoria-dialog";
import { useTatiAcesso } from "@/hooks/use-tati-acesso";
import { perguntarTati } from "@/lib/tati.functions";
import type { Mensagem } from "@/lib/tati-conhecimento";

export const Route = createFileRoute("/_authenticated/fale-com-a-tati")({
  head: () => ({
    meta: [
      { title: "Fale com a Tati — Assistente com IA" },
      { name: "description", content: "Assistente com IA que tira dúvidas sobre o app e consulta os dados da sua van em tempo real." },
      { property: "og:title", content: "Fale com a Tati — Assistente com IA" },
      { property: "og:description", content: "Tire dúvidas sobre alunos, mensalidades e rotas com a assistente da Tati Van Escolar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: FaleComATatiPage,
});

const SUGESTOES = [
  "Quanto tenho a receber este mês?",
  "Quais alunos estão com a mensalidade em aberto?",
  "Como faço para antecipar mensalidades?",
  "Como envio o contrato pelo WhatsApp?",
];

const MARCA_FORA = "[FORA_DO_APP]";

type Bolha = { role: "user" | "assistant"; content: string; foraDoApp?: boolean };

function FaleComATatiPage() {
  const liberado = useTatiAcesso();
  const perguntar = useServerFn(perguntarTati);
  const [bolhas, setBolhas] = useState<Bolha[]>([
    {
      role: "assistant",
      content:
        "Oi! Eu sou a Tati 💛 Posso te ajudar com o app e também olhar os dados da sua van em tempo real. O que você quer saber?",
    },
  ]);
  const [texto, setTexto] = useState("");
  const [carregando, setCarregando] = useState(false);
  const fimRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    fimRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [bolhas, carregando]);

  const enviar = async (pergunta: string) => {
    const msg = pergunta.trim();
    if (!msg || carregando) return;
    setTexto("");
    const historico: Mensagem[] = [...bolhas, { role: "user" as const, content: msg }].map((b) => ({
      role: b.role,
      content: b.content,
    }));
    setBolhas((prev) => [...prev, { role: "user", content: msg }]);
    setCarregando(true);
    try {
      const res = await perguntar({ data: { mensagens: historico } });
      if (res.erro || !res.resposta) {
        setBolhas((prev) => [...prev, { role: "assistant", content: res.erro || "Não consegui responder agora." }]);
      } else {
        const foraDoApp = res.resposta.includes(MARCA_FORA);
        setBolhas((prev) => [
          ...prev,
          { role: "assistant", content: res.resposta.replace(MARCA_FORA, "").trim(), foraDoApp },
        ]);
      }
    } catch {
      setBolhas((prev) => [...prev, { role: "assistant", content: "Não consegui responder agora. Tente novamente." }]);
    } finally {
      setCarregando(false);
    }
  };

  if (!liberado) {
    return (
      <div className="mx-auto max-w-md py-12 text-center">
        <h1 className="text-lg font-semibold">Recurso em teste</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          A assistente Tati ainda está em fase de testes e não está disponível na sua conta.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-4">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-accent text-accent-foreground">
          <Sparkles className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-lg font-bold leading-tight">Fale com a Tati</h1>
          <p className="text-xs text-muted-foreground">Assistente com IA · em teste</p>
        </div>
      </div>

      <Card className="flex min-h-[55vh] flex-col gap-3 p-3 sm:p-4">
        <div className="flex-1 space-y-3 overflow-y-auto">
          {bolhas.map((b, i) => (
            <div key={i} className={b.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div
                className={
                  b.role === "user"
                    ? "max-w-[85%] rounded-2xl rounded-br-sm bg-primary px-3 py-2 text-sm text-primary-foreground"
                    : "max-w-[90%] space-y-2 rounded-2xl rounded-bl-sm bg-muted px-3 py-2 text-sm"
                }
              >
                <p className="whitespace-pre-wrap">{b.content}</p>
                {b.foraDoApp && (
                  <SugerirMelhoriaDialog>
                    <Button size="sm" variant="secondary" className="gap-2">
                      <Lightbulb className="h-4 w-4" />
                      Sugerir Melhorias
                    </Button>
                  </SugerirMelhoriaDialog>
                )}
              </div>
            </div>
          ))}
          {carregando && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> A Tati está digitando…
            </div>
          )}
          <div ref={fimRef} />
        </div>

        {bolhas.length <= 1 && (
          <div className="flex flex-wrap gap-2">
            {SUGESTOES.map((s) => (
              <Button key={s} size="sm" variant="outline" className="text-xs" onClick={() => void enviar(s)}>
                {s}
              </Button>
            ))}
          </div>
        )}

        <form
          className="flex items-center gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            void enviar(texto);
          }}
        >
          <Input
            value={texto}
            onChange={(e) => setTexto(e.target.value)}
            placeholder="Escreva sua dúvida…"
            disabled={carregando}
          />
          <Button type="submit" size="icon" disabled={carregando || !texto.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </Card>
    </div>
  );
}
