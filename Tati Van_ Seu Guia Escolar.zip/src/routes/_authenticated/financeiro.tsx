import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { normalizeTipoCobranca } from "@/lib/tipo-cobranca";
import { trackEvent } from "@/lib/track-event";
import { MessageCircle, CheckCircle2, AlertTriangle } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { formatBRL, currentMonthRef, parseMoney } from "@/lib/format";
import { ReciboActions } from "@/components/recibo-actions";
import type { Recibo } from "@/lib/recibo";
import { buildWhatsAppUrl, getMotoristaFromUser, applyVariables } from "@/lib/whatsapp";
import { AlunoAvatar } from "@/components/aluno-avatar";
import {
  buildCompetencias, formatMesRef, formatDataBR, STATUS_UI,
  type AlunoMensalidade, type Competencia, type PagamentoMini,
} from "@/lib/mensalidades";
import {
  TIPO_LABEL, TIPO_UI, STATUS_LANC_LABEL, regraLabel,
  creditosDoAluno, saldoCreditoAluno, creditoAutoAplicavel,
  aplicarCredito, receberGarantia,
  type Lancamento, type TipoLancamento, type StatusLancamento,
} from "@/lib/lancamentos";
import { calcularEncargos, temEncargos, type EncargoConfig } from "@/lib/encargos";
import { DetalheEncargos } from "@/components/detalhe-encargos";

export const Route = createFileRoute("/_authenticated/financeiro")({
  head: () => ({ meta: [{ title: "Financeiro — Tati Van" }] }),
  component: FinanceiroPage,
});

const METODOS = [
  { v: "pix", label: "PIX" },
  { v: "dinheiro", label: "Dinheiro" },
  { v: "transferencia", label: "Transferência" },
  { v: "cartao", label: "Cartão" },
  { v: "outro", label: "Outro" },
];

import { CobrarButton } from "@/components/cobrar-button";
import { feedbackSucesso } from "@/lib/sons";
import { AnteciparMensalidades } from "@/components/antecipar-mensalidades";

function FinanceiroPage() {
  const { user } = Route.useRouteContext();
  const mesRef = currentMonthRef();
  const motorista = getMotoristaFromUser(user);
  const [alunos, setAlunos] = useState<AlunoMensalidade[]>([]);
  const [pagamentos, setPagamentos] = useState<PagamentoMini[]>([]);
  const [lancamentos, setLancamentos] = useState<Lancamento[]>([]);
  const [recibosCount, setRecibosCount] = useState({ mes: 0, ano: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [target, setTarget] = useState<Competencia | null>(null);
  const [form, setForm] = useState({ valor: "", metodo: "pix", data: new Date().toISOString().slice(0, 10) });
  const [creditoTarget, setCreditoTarget] = useState<Lancamento | null>(null);
  const [usarCredito, setUsarCredito] = useState(false);
  const [saving, setSaving] = useState(false);
  const [reciboOpen, setReciboOpen] = useState(false);
  const [reciboAtivo, setReciboAtivo] = useState<Recibo | null>(null);
  const [garantiaTarget, setGarantiaTarget] = useState<Lancamento | null>(null);
  const [garantiaData, setGarantiaData] = useState(new Date().toISOString().slice(0, 10));
  const [garantiaOpen, setGarantiaOpen] = useState(false);
  const [tipoCobrancaMap, setTipoCobrancaMap] = useState<Record<string, string>>({});
  const [anualOpen, setAnualOpen] = useState(false);
  const [anualAluno, setAnualAluno] = useState<AlunoMensalidade | null>(null);
  const [anualForm, setAnualForm] = useState({ valor: "", ano: String(new Date().getFullYear()) });

  const load = async () => {
    setLoading(true);
    const [{ data: as }, { data: ps }, { data: rs }, { data: ls }] = await Promise.all([
      supabase.from("alunos").select("id, nome, avatar, foto_url, sexo, mensalidade, vencimento, whatsapp, escola, turma, responsavel, created_at, arquivado_em, tipo_cobranca, multa_atraso, multa_tipo, juros_dia, juros_tipo").order("nome"),
      supabase.from("pagamentos").select("id, aluno_id, mes_referencia, valor, metodo, data_pagamento"),
      supabase.from("recibos").select("id, created_at"),
      supabase.from("lancamentos_financeiros").select("*").order("created_at", { ascending: false }),
    ]);
    const alunosData = (((as as unknown) as (AlunoMensalidade & { foto_url?: string; tipo_cobranca?: string })[]) || []).map((a) => ({
      ...a,
      fotoUrl: a.foto_url || "",
    }));
    setAlunos(alunosData);
    setTipoCobrancaMap(
      Object.fromEntries(alunosData.map((a) => [a.id, normalizeTipoCobranca(a.tipo_cobranca)])),
    );
    setPagamentos(((ps as unknown) as PagamentoMini[]) || []);
    setLancamentos(((ls as unknown) as Lancamento[]) || []);

    const all = (rs as { id: string; created_at: string }[] | null) || [];
    const now = new Date();
    setRecibosCount({
      mes: all.filter((r) => { const d = new Date(r.created_at); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); }).length,
      ano: all.filter((r) => new Date(r.created_at).getFullYear() === now.getFullYear()).length,
      total: all.length,
    });
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    if (loading) return;
    if (typeof window === "undefined") return;
    if (window.location.hash !== "#atraso") return;
    document.getElementById("atraso")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [loading]);

  // Alunos com plano anual à vista não geram mensalidades (evita duplicidade).
  const alunosMensalistas = alunos.filter((a) => tipoCobrancaMap[a.id] !== "anual_vista");
  const competencias = buildCompetencias(alunosMensalistas, pagamentos);
  const doMes = competencias.filter((c) => c.mes === mesRef);
  const emAtraso = competencias
    .filter((c) => c.status === "vencido")
    .sort((a, b) => (a.mes === b.mes ? a.aluno.nome.localeCompare(b.aluno.nome) : a.mes.localeCompare(b.mes)));

  const ativos = alunosMensalistas.filter((a) => !a.arquivado_em);
  const total = ativos.reduce((s, a) => s + Number(a.mensalidade), 0);
  const recebido = doMes.filter((c) => c.status === "pago").reduce((s, c) => s + c.valor, 0);
  const pendente = Math.max(0, total - recebido);
  /** Multa/juros configurados no cadastro do aluno (opcionais). */
  const encargosDe = (aluno: AlunoMensalidade): EncargoConfig => aluno as unknown as EncargoConfig;
  const atualizadoDe = (c: Competencia) => calcularEncargos(c.valor, c.diasAtraso, encargosDe(c.aluno));
  const totalAtraso = emAtraso.reduce((s, c) => s + atualizadoDe(c).total, 0);

  const garantias = lancamentos.filter((l) => l.tipo === "garantia");
  const garantiasAReceber = garantias.filter((l) => l.status === "a_receber");
  const totalGarantiasAReceber = garantiasAReceber.reduce((s, l) => s + Number(l.valor), 0);
  const creditos = lancamentos.filter((l) => l.tipo === "credito" && Number(l.saldo_restante) > 0);
  const totalCreditos = creditos.reduce((s, l) => s + Number(l.saldo_restante), 0);

  /** Primeira competência ainda em aberto de cada aluno (base da regra "primeira mensalidade"). */
  const primeiraEmAbertoDe = (alunoId: string): string | null => {
    const abertas = competencias
      .filter((c) => c.aluno.id === alunoId && c.status !== "pago")
      .map((c) => c.mes)
      .sort();
    return abertas[0] ?? null;
  };

  const descontoMax = target && creditoTarget && usarCredito
    ? Math.min(Number(creditoTarget.saldo_restante), Number(target.valor))
    : 0;

  const openBaixa = (c: Competencia) => {
    setTarget(c);
    const disponiveis = creditosDoAluno(lancamentos, c.aluno.id);
    const auto = disponiveis.find((cr) => creditoAutoAplicavel(cr, c.mes, primeiraEmAbertoDe(c.aluno.id)));
    const escolhido = auto ?? disponiveis[0] ?? null;
    setCreditoTarget(escolhido);
    setUsarCredito(!!auto);
    const enc = calcularEncargos(c.valor, c.diasAtraso, encargosDe(c.aluno));
    setForm({ valor: String(enc.total), metodo: "pix", data: new Date().toISOString().slice(0, 10) });
    setOpen(true);
  };

  const abrirRecebimentoGarantia = (l: Lancamento) => {
    setGarantiaTarget(l);
    setGarantiaData(new Date().toISOString().slice(0, 10));
    setGarantiaOpen(true);
  };

  const confirmarRecebimentoGarantia = async () => {
    if (!garantiaTarget) return;
    setSaving(true);
    const { credito } = await receberGarantia(user.id, garantiaTarget, garantiaData);
    setSaving(false);
    setGarantiaOpen(false);
    const ehPlano = garantiaTarget.tipo === "plano_anual";
    trackEvent(ehPlano ? "plano_anual_recebido" : "garantia_recebida", `${garantiaTarget.aluno_nome} — ${garantiaTarget.ano_referencia ?? ""}`);
    feedbackSucesso();
    toast.success(
      ehPlano
        ? "Plano anual recebido! ✅"
        : credito
          ? "Reserva recebida! Crédito do aluno gerado. 💚"
          : "Reserva de vaga recebida! ✅",
    );

    load();
  };

  // 🗓️ Planos anuais — cobrança única, nunca somada à mensalidade
  const planosAnuais = lancamentos.filter((l) => l.tipo === "plano_anual");
  const anoAtual = new Date().getFullYear();
  const alunosAnuais = alunos.filter(
    (a) =>
      !a.arquivado_em &&
      tipoCobrancaMap[a.id] === "anual_vista" &&
      !planosAnuais.some((l) => l.aluno_id === a.id && l.ano_referencia === anoAtual),
  );
  const totalPlanosAReceber = planosAnuais
    .filter((l) => l.status === "a_receber")
    .reduce((s, l) => s + Number(l.valor), 0);

  const abrirPlanoAnual = (a: AlunoMensalidade) => {
    setAnualAluno(a);
    setAnualForm({ valor: "", ano: String(new Date().getFullYear()) });
    setAnualOpen(true);
  };

  const criarPlanoAnual = async () => {
    if (!anualAluno) return;
    const valor = parseMoney(anualForm.valor);
    const ano = parseInt(anualForm.ano, 10);
    if (!(valor > 0)) return toast.error("Informe o valor da cobrança anual.");
    if (!Number.isFinite(ano)) return toast.error("Informe o ano de referência.");
    // Regra de não duplicidade: um plano anual por aluno + ano
    const dup = planosAnuais.some((l) => l.aluno_id === anualAluno.id && l.ano_referencia === ano);
    if (dup) return toast.error("Já existe uma cobrança anual desse aluno para este ano.");
    setSaving(true);
    const { error } = await supabase.from("lancamentos_financeiros").insert({
      user_id: user.id,
      aluno_id: anualAluno.id,
      aluno_nome: anualAluno.nome,
      tipo: "plano_anual",
      descricao: `Plano anual ${ano}`,
      valor,
      status: "a_receber",
      ano_referencia: ano,
      origem: "Cobrança única do plano anual",
      historico: [{ em: new Date().toISOString(), evento: "Cobrança única anual criada" }],
    });
    setSaving(false);
    if (error) return toast.error("Não foi possível criar a cobrança anual.");
    setAnualOpen(false);
    toast.success(`Cobrança anual de ${anualAluno.nome} criada. 🗓️`);
    load();
  };



  const handleBaixa = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!target) return;
    const aluno = target.aluno;
    const competencia = target.mes;
    setSaving(true);
    const valorBruto = parseMoney(form.valor);
    const desconto = creditoTarget && usarCredito
      ? Math.min(Number(creditoTarget.saldo_restante), valorBruto)
      : 0;
    const valor = Math.max(0, valorBruto - desconto);
    const obs = desconto > 0 ? `Desconto aplicado: Reserva de vaga (R$ ${formatBRL(desconto)})` : "";
    const { data: pagData, error } = await supabase.from("pagamentos").insert({
      user_id: user.id,
      aluno_id: aluno.id,
      mes_referencia: competencia,
      valor,
      metodo: form.metodo,
      data_pagamento: form.data,
      observacoes: obs,
    }).select().single();
    if (error) { setSaving(false); return toast.error("Erro ao dar baixa."); }
    if (desconto > 0 && creditoTarget) {
      await aplicarCredito(creditoTarget, desconto, competencia);
      trackEvent("credito_aplicado", `${aluno.nome} — ${competencia}`);
    }
    if (competencia === mesRef) {
      await supabase.from("alunos").update({ status_mensalidade: "pago" }).eq("id", aluno.id);
    }

    // Busca responsável vinculado (por nome do responsável no aluno)
    let respDados: { nome?: string; cpf?: string; telefone?: string; whatsapp?: string; email?: string } = {};
    if (aluno.responsavel) {
      const { data: resp } = await supabase
        .from("responsaveis")
        .select("nome, cpf, telefone, whatsapp, email")
        .ilike("nome", aluno.responsavel)
        .maybeSingle();
      if (resp) respDados = resp as typeof respDados;
    }

    const { data: recData, error: recErr } = await supabase.from("recibos").insert({
      user_id: user.id,
      numero: "",
      pagamento_id: pagData?.id,
      aluno_id: aluno.id,
      aluno_nome: aluno.nome,
      escola: aluno.escola || null,
      turma: aluno.turma || null,
      periodo: null,
      responsavel_nome: respDados.nome || aluno.responsavel || null,
      responsavel_cpf: respDados.cpf || null,
      responsavel_telefone: respDados.telefone || aluno.whatsapp || null,
      responsavel_whatsapp: respDados.whatsapp || aluno.whatsapp || null,
      responsavel_email: respDados.email || null,
      mes_referencia: competencia,
      valor,
      data_vencimento: target.vencimentoISO,
      data_pagamento: form.data,
      metodo: form.metodo,
      observacoes: obs || null,
    }).select().single();

    setSaving(false);
    feedbackSucesso();
    toast.success(
      desconto > 0
        ? `Mensalidade de ${aluno.nome} recebida com desconto de R$ ${formatBRL(desconto)} (reserva de vaga). ✅`
        : `Mensalidade de ${aluno.nome} (${formatMesRef(competencia)}) recebida! ✅`,
    );
    setOpen(false);
    load();

    if (!recErr && recData) {
      trackEvent("recibo_emitido", `${aluno.nome} — ${competencia}`);
      setReciboAtivo(recData as unknown as Recibo);
      setReciboOpen(true);
    }
  };

  const verRecibo = async (c: Competencia) => {
    if (!c.pagamento) return;
    const { data } = await supabase.from("recibos").select("*").eq("pagamento_id", c.pagamento.id).maybeSingle();
    if (data) { setReciboAtivo(data as unknown as Recibo); setReciboOpen(true); }
    else toast.info("Recibo não emitido para este pagamento.");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">Financeiro 💰</h1>
        <p className="text-sm text-muted-foreground">Mensalidades de {new Date().toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="p-5"><div className="text-xs uppercase tracking-wider text-muted-foreground">Previsto</div><div className="mt-1 text-2xl font-extrabold">R$ {formatBRL(total)}</div></Card>
        <Card className="p-5"><div className="text-xs uppercase tracking-wider text-success">Recebido</div><div className="mt-1 text-2xl font-extrabold text-success">R$ {formatBRL(recebido)}</div></Card>
        <Card className="p-5"><div className="text-xs uppercase tracking-wider text-destructive">A receber</div><div className="mt-1 text-2xl font-extrabold text-destructive">R$ {formatBRL(pendente)}</div></Card>
      </div>

      {/* Mensalidades em atraso — todos os meses */}
      <Card id="atraso" className="overflow-hidden border-destructive/40" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex flex-wrap items-center justify-between gap-3 border-b bg-destructive/10 px-5 py-3">
          <div className="flex items-center gap-2 font-bold text-destructive">
            <AlertTriangle className="h-4 w-4" /> 🔴 Mensalidades em atraso
          </div>
          <div className="text-sm font-bold text-destructive">
            {emAtraso.length} cobrança{emAtraso.length === 1 ? "" : "s"} · R$ {formatBRL(totalAtraso)}
          </div>
        </div>
        {loading ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : emAtraso.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Nenhuma mensalidade em atraso. Tudo em dia! 🎉</div>
        ) : (
          <ul className="divide-y">
            {emAtraso.map((c) => (
              <li key={c.key} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                <div className="flex min-w-0 items-center gap-3">
                  <AlunoAvatar nome={c.aluno.nome} fotoUrl={c.aluno.fotoUrl} avatar={c.aluno.avatar} sexo={c.aluno.sexo as never} size={36} />
                  <div className="min-w-0">
                    <div className="truncate font-semibold">{c.aluno.nome}</div>
                    {c.aluno.responsavel && c.aluno.responsavel !== "—" && (
                      <div className="truncate text-xs text-muted-foreground">Responsável: {c.aluno.responsavel}</div>
                    )}
                    <div className="text-xs text-muted-foreground">
                      {formatMesRef(c.mes)} · venceu em {formatDataBR(c.vencimentoISO)} ·{" "}
                      <span className="font-semibold text-destructive">{c.diasAtraso} dia{c.diasAtraso === 1 ? "" : "s"} em atraso</span>
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {(() => {
                    const enc = atualizadoDe(c);
                    return enc.encargos > 0 ? (
                      <span className="text-right">
                        <span className="block text-[11px] text-muted-foreground line-through">R$ {formatBRL(c.valor)}</span>
                        <span className="block font-bold text-destructive">R$ {formatBRL(enc.total)}</span>
                        <span className="block text-[11px] text-muted-foreground">
                          + multa R$ {formatBRL(enc.multa)} · juros R$ {formatBRL(enc.juros)}
                        </span>
                      </span>
                    ) : (
                      <span className="font-bold">R$ {formatBRL(c.valor)}</span>
                    );
                  })()}
                  <DetalheEncargos competencia={c} encargos={encargosDe(c.aluno)} onConfirmar={openBaixa} />
                  <Button size="sm" onClick={() => openBaixa(c)} className="bg-success text-success-foreground hover:bg-success/90 font-bold">
                    <CheckCircle2 className="mr-1 h-3 w-3" /> Dar baixa
                  </Button>
                  {c.aluno.whatsapp && (
                    <CobrarButton competencia={c} motorista={motorista} encargos={encargosDe(c.aluno)} />
                  )}
                  <AnteciparMensalidades aluno={c.aluno} userId={user.id} onDone={load} maxMesRef="2026-12" motorista={motorista} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* 🗓️ Planos anuais — contrato anual com cobrança única (opcional) */}
      {(alunosAnuais.length > 0 || planosAnuais.length > 0) && (
        <Card className="overflow-hidden" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3">
            <div className="font-bold">🗓️ Planos anuais</div>
            {totalPlanosAReceber > 0 && (
              <div className="text-sm font-bold text-destructive">
                A receber: R$ {formatBRL(totalPlanosAReceber)}
              </div>
            )}
          </div>
          <ul className="divide-y">
            {planosAnuais.map((l) => (
              <li key={l.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="truncate font-semibold">{l.aluno_nome}</span>
                    <Badge variant="outline" className={TIPO_UI["plano_anual"]}>{TIPO_LABEL["plano_anual"]}</Badge>
                    <Badge
                      variant="outline"
                      className={l.status === "recebido"
                        ? "bg-success/15 text-success border-success/30"
                        : "bg-warning/20 text-warning-foreground border-warning/40"}
                    >
                      {STATUS_LANC_LABEL[l.status as StatusLancamento]}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Ano {l.ano_referencia} · {l.origem}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold">R$ {formatBRL(Number(l.valor))}</span>
                  {l.status === "a_receber" && (
                    <Button
                      size="sm"
                      onClick={() => abrirRecebimentoGarantia(l)}
                      className="bg-success text-success-foreground hover:bg-success/90 font-bold"
                    >
                      <CheckCircle2 className="mr-1 h-3 w-3" /> Receber
                    </Button>
                  )}
                </div>
              </li>
            ))}
            {alunosAnuais.map((a) => (
              <li key={`novo-${a.id}`} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                <div className="min-w-0">
                  <div className="truncate font-semibold">{a.nome}</div>
                  <div className="text-xs text-muted-foreground">
                    Plano anual — pagamento à vista · não gera mensalidades
                  </div>
                </div>
                <Button size="sm" variant="outline" onClick={() => abrirPlanoAnual(a)}>
                  Criar cobrança única {anoAtual}
                </Button>
              </li>
            ))}
          </ul>
        </Card>
      )}


      {/* 🎟️ Reservas de vaga — lançamentos separados das mensalidades */}
      {garantias.length > 0 && (
        <Card className="overflow-hidden" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3">
            <div className="font-bold">🎟️ Reservas de vaga</div>
            <div className="text-sm font-bold text-destructive">
              A receber: R$ {formatBRL(totalGarantiasAReceber)}
            </div>
          </div>
          <ul className="divide-y">
            {garantias.map((l) => (
              <li key={l.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="truncate font-semibold">{l.aluno_nome}</span>
                    <Badge variant="outline" className={TIPO_UI["garantia"]}>{TIPO_LABEL["garantia"]}</Badge>
                    <Badge
                      variant="outline"
                      className={l.status === "recebido"
                        ? "bg-success/15 text-success border-success/30"
                        : "bg-warning/20 text-warning-foreground border-warning/40"}
                    >
                      {STATUS_LANC_LABEL[l.status as StatusLancamento]}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Ano {l.ano_referencia} · Gerado pela Reserva de Vaga
                    {l.regra_abatimento ? ` · ${regraLabel(l.regra_abatimento)}` : ""}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold">R$ {formatBRL(Number(l.valor))}</span>
                  {l.status === "a_receber" && (
                    <Button
                      size="sm"
                      onClick={() => abrirRecebimentoGarantia(l)}
                      className="bg-success text-success-foreground hover:bg-success/90 font-bold"
                    >
                      <CheckCircle2 className="mr-1 h-3 w-3" /> Receber
                    </Button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {/* 💚 Créditos disponíveis */}
      {creditos.length > 0 && (
        <Card className="overflow-hidden border-success/40" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex flex-wrap items-center justify-between gap-3 border-b bg-success/10 px-5 py-3">
            <div className="font-bold text-success">💚 Créditos de alunos</div>
            <div className="text-sm font-bold text-success">R$ {formatBRL(totalCreditos)}</div>
          </div>
          <ul className="divide-y">
            {creditos.map((l) => (
              <li key={l.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="truncate font-semibold">{l.aluno_nome}</span>
                    <Badge variant="outline" className={TIPO_UI["credito"]}>{TIPO_LABEL["credito"]}</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Gerado pela Reserva de Vaga · {regraLabel(l.regra_abatimento)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-success">R$ {formatBRL(Number(l.saldo_restante))}</div>
                  <div className="text-xs text-muted-foreground">de R$ {formatBRL(Number(l.valor))}</div>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">📄 Recibos emitidos</div>
            <div className="mt-1 flex gap-4 text-sm">
              <span><span className="font-extrabold text-lg">{recibosCount.mes}</span> no mês</span>
              <span><span className="font-extrabold text-lg">{recibosCount.ano}</span> no ano</span>
              <span><span className="font-extrabold text-lg">{recibosCount.total}</span> no total</span>
            </div>
          </div>
          <a href="/recibos"><Button variant="outline" size="sm">Ver histórico</Button></a>
        </div>
      </Card>

      <Card className="overflow-hidden" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="border-b px-5 py-3 font-bold">Mensalidades de {formatMesRef(mesRef)}</div>
        {loading ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : doMes.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Cadastre alunos para começar.</div>
        ) : (
          <ul className="divide-y">
            {doMes.map((c) => {
              const s = STATUS_UI[c.status];
              const saldo = saldoCreditoAluno(lancamentos, c.aluno.id);
              return (
                <li key={c.key} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <AlunoAvatar nome={c.aluno.nome} fotoUrl={c.aluno.fotoUrl} avatar={c.aluno.avatar} sexo={c.aluno.sexo as never} size={36} />
                    <div className="min-w-0">
                      <div className="font-semibold truncate">{c.aluno.nome}</div>
                      <div className="text-xs text-muted-foreground">Vence dia {c.aluno.vencimento}</div>
                      {c.status !== "pago" && saldo > 0 && (
                        <div className="text-xs font-semibold text-success">
                          Crédito disponível: R$ {formatBRL(saldo)}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold">R$ {formatBRL(c.valor)}</span>
                    <Badge variant="outline" className={TIPO_UI["mensalidade"]}>{TIPO_LABEL["mensalidade"]}</Badge>
                    <Badge variant="outline" className={s.className}>{s.emoji} {s.label}</Badge>
                    {c.status !== "pago" ? (
                      <Button size="sm" onClick={() => openBaixa(c)} className="bg-success text-success-foreground hover:bg-success/90 font-bold">
                        <CheckCircle2 className="mr-1 h-3 w-3" /> Dar baixa
                      </Button>
                    ) : (
                      <Button size="sm" variant="outline" onClick={() => verRecibo(c)}>📄 Ver recibo</Button>
                    )}
                    {c.status !== "pago" && c.aluno.whatsapp && (
                      <CobrarButton competencia={c} motorista={motorista} encargos={encargosDe(c.aluno)} />
                    )}
                    <AnteciparMensalidades aluno={c.aluno} userId={user.id} onDone={load} maxMesRef="2026-12" motorista={motorista} />
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Card>

      <ReciboActions open={reciboOpen} onOpenChange={setReciboOpen} recibo={reciboAtivo} motorista={motorista} showSuccessTitle onChanged={load} />

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Dar baixa — {target?.aluno.nome}</DialogTitle>
            <DialogDescription>
              Registre o recebimento da mensalidade de {target ? formatMesRef(target.mes) : ""}.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleBaixa} className="space-y-3">
            <div>
              <Label>Forma de recebimento</Label>
              <Select value={form.metodo} onValueChange={(v) => setForm({ ...form, metodo: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {METODOS.map((m) => <SelectItem key={m.v} value={m.v}>{m.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="v">Valor (R$)</Label>
                <Input id="v" type="text" inputMode="decimal" value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} />
                {target && temEncargos(encargosDe(target.aluno)) && target.diasAtraso > 0 && (() => {
                  const enc = calcularEncargos(target.valor, target.diasAtraso, encargosDe(target.aluno));
                  return enc.encargos > 0 ? (
                    <p className="mt-1 text-xs text-muted-foreground">
                      Mensalidade R$ {formatBRL(target.valor)} + multa R$ {formatBRL(enc.multa)} + juros R$ {formatBRL(enc.juros)} ({target.diasAtraso} dia{target.diasAtraso === 1 ? "" : "s"}) = <b>R$ {formatBRL(enc.total)}</b>. Você pode editar o valor.
                    </p>
                  ) : null;
                })()}
              </div>
              <div>
                <Label htmlFor="d">Data</Label>
                <Input id="d" type="date" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} />
              </div>
            </div>

            {creditoTarget && (
              <div className="rounded-xl border border-success/40 bg-success/10 p-3 text-sm">
                <label className="flex items-start gap-2">
                  <input
                    type="checkbox"
                    className="mt-1"
                    checked={usarCredito}
                    onChange={(e) => setUsarCredito(e.target.checked)}
                  />
                  <span>
                    <span className="font-semibold text-success">
                      Aplicar crédito de R$ {formatBRL(Number(creditoTarget.saldo_restante))}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      Gerado pela Reserva de Vaga · {regraLabel(creditoTarget.regra_abatimento)}
                    </span>
                  </span>
                </label>
                {usarCredito && (
                  <div className="mt-2 space-y-0.5 border-t border-success/30 pt-2 text-xs">
                    <div>Mensalidade: R$ {formatBRL(parseMoney(form.valor))}</div>
                    <div className="text-success">Desconto aplicado: Reserva de vaga −R$ {formatBRL(descontoMax)}</div>
                    <div className="font-bold">
                      Total a receber: R$ {formatBRL(Math.max(0, parseMoney(form.valor) - descontoMax))}
                    </div>
                  </div>
                )}
              </div>
            )}

            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saving} className="bg-success text-success-foreground font-bold">
                {saving ? "Salvando..." : "Confirmar recebimento"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={garantiaOpen} onOpenChange={setGarantiaOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {garantiaTarget?.tipo === "plano_anual" ? "Receber plano anual" : "Receber reserva"} — {garantiaTarget?.aluno_nome}
            </DialogTitle>
            <DialogDescription>
              {garantiaTarget?.tipo === "plano_anual"
                ? `Cobrança única do plano anual (ano ${garantiaTarget?.ano_referencia}). Não substitui nem soma às mensalidades.`
                : `Lançamento do tipo Reserva de vaga (ano ${garantiaTarget?.ano_referencia}). Não gera mensalidade.`}
            </DialogDescription>

          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-xl border bg-muted/40 px-4 py-3 text-sm">
              <div className="font-bold">R$ {formatBRL(Number(garantiaTarget?.valor ?? 0))}</div>
              <div className="text-xs text-muted-foreground">
                {garantiaTarget?.tipo === "plano_anual"
                  ? "Cobrança única do plano anual."
                  : garantiaTarget?.regra_abatimento
                    ? `Ao receber, será gerado um crédito do aluno — ${regraLabel(garantiaTarget.regra_abatimento)}`
                    : "Sem abatimento: nenhum crédito será gerado."}
              </div>

            </div>
            <div>
              <Label htmlFor="gd">Data do recebimento</Label>
              <Input id="gd" type="date" value={garantiaData} onChange={(e) => setGarantiaData(e.target.value)} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setGarantiaOpen(false)}>Cancelar</Button>
            <Button
              onClick={confirmarRecebimentoGarantia}
              disabled={saving}
              className="bg-success text-success-foreground font-bold"
            >
              {saving ? "Salvando..." : "Confirmar recebimento"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={anualOpen} onOpenChange={setAnualOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Cobrança única anual — {anualAluno?.nome}</DialogTitle>
            <DialogDescription>
              Cria um lançamento do tipo Plano Anual. Não gera mensalidades e nunca é somado a elas.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <Label htmlFor="anoPlano">Ano de referência</Label>
              <Input
                id="anoPlano"
                inputMode="numeric"
                value={anualForm.ano}
                onChange={(e) => setAnualForm({ ...anualForm, ano: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="valorPlano">Valor total (R$)</Label>
              <Input
                id="valorPlano"
                inputMode="decimal"
                placeholder="R$ 4.500,00"
                value={anualForm.valor}
                onChange={(e) => setAnualForm({ ...anualForm, valor: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAnualOpen(false)}>Cancelar</Button>
            <Button onClick={criarPlanoAnual} disabled={saving} className="font-bold">
              {saving ? "Salvando..." : "Criar cobrança"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>

  );
}
