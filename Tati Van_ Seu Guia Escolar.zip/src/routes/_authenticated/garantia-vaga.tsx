import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import type { TablesUpdate } from "@/integrations/supabase/types";
import { Plus, Pencil, Trash2, MessageCircle, FileText, Search } from "lucide-react";
import { parseMoney, formatBRL } from "@/lib/format";
import { buildWhatsAppUrl, getMotoristaFromUser } from "@/lib/whatsapp";
import { SignaturePadDialog } from "@/components/signature-pad";
import { DateInputBR } from "@/components/date-input-br";
import {
  linkAssinatura, novaAssinatura, parseAssinatura, statusAssinaturas, STATUS_ASSINATURA_LABEL,
} from "@/lib/assinatura";

import { useVanLogo } from "@/lib/logo-store";
import { getMarca } from "@/lib/marca";
import { downloadBlob } from "@/lib/contrato-pdf";
import { garantiaFilename, garantiaToPdfBlob } from "@/lib/garantia-pdf";
import { DocumentoViewerDialog } from "@/components/documento-viewer";
import {
  buildGarantiaHTML, type GarantiaDoc,
} from "@/lib/documento-html";
import {
  ABATER_OPCOES,
  TIPO_OPCOES,
  abatimentoLabel,
  buildGarantiaMessage,
  formatDataBR,
  formatDataHora,
  parseHistorico,
  pushHistorico,
  tipoLabel,
  valorLabel,
  type GarantiaStatus,
  type GarantiaVaga,
} from "@/lib/garantia-vaga";
import { syncGarantiaLancamento } from "@/lib/lancamentos";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ListaEsperaTab, periodoLabel, type ListaEsperaItem } from "@/components/lista-espera";

export const Route = createFileRoute("/_authenticated/garantia-vaga")({
  head: () => ({
    meta: [
      { title: "Reserva de Vaga — Tati Van Escolar" },
      {
        name: "description",
        content:
          "Gerencie rematrículas e reservas de vaga dos alunos: valor, abatimento, envio ao responsável e confirmação.",
      },
      { property: "og:title", content: "Reserva de Vaga — Tati Van Escolar" },
      {
        property: "og:description",
        content: "Controle a continuidade dos alunos com rematrícula e reserva de vaga.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GarantiaVagaPage,
});

type AlunoOpt = {
  id: string;
  nome: string;
  escola: string | null;
  responsavel: string | null;
  whatsapp: string | null;
  telefone: string | null;
};

type Form = {
  aluno_id: string;
  ano_referencia: string;
  tipo: string;
  tipo_outro: string;
  cobrar: "sim" | "nao";
  valor: string;
  abater: "sim" | "nao";
  abater_em: string;
  abater_outro: string;
  status: GarantiaStatus;
  prazo_resposta: string;
  observacoes: string;
  mensalidade: string;
  /** Preenchido quando a reserva vem da lista de espera (aluno ainda não cadastrado). */
  espera_id: string;
  /** Aluno digitado à mão (sem cadastro vinculado). */
  manual: boolean;
  aluno_nome_manual: string;
  responsavel_manual: string;
  whatsapp_manual: string;
  escola_manual: string;
};

const emptyForm = (): Form => ({
  aluno_id: "",
  ano_referencia: String(new Date().getFullYear() + 1),
  tipo: "rematricula",
  tipo_outro: "",
  cobrar: "nao",
  valor: "",
  abater: "nao",
  abater_em: "primeira",
  abater_outro: "",
  status: "pendente",
  prazo_resposta: "",
  observacoes: "",
  mensalidade: "",
  espera_id: "",
  manual: false,
  aluno_nome_manual: "",
  responsavel_manual: "",
  whatsapp_manual: "",
  escola_manual: "",
});

function GarantiaVagaPage() {
  const { user } = Route.useRouteContext();
  const logo = useVanLogo();
  const motoristaBase = getMotoristaFromUser(user);
  const motorista = { ...motoristaBase, logo: logo || motoristaBase.logo };
  const marca = getMarca(motorista);

  const [itens, setItens] = useState<GarantiaVaga[]>([]);
  const [alunos, setAlunos] = useState<AlunoOpt[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtro, setFiltro] = useState<"todos" | GarantiaStatus>("todos");
  const [q, setQ] = useState("");

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<GarantiaVaga | null>(null);
  const [form, setForm] = useState<Form>(emptyForm());
  const [saving, setSaving] = useState(false);

  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewTarget, setPreviewTarget] = useState<GarantiaVaga | null>(null);
  const [mensagem, setMensagem] = useState("");

  const [histOpen, setHistOpen] = useState(false);
  const [histTarget, setHistTarget] = useState<GarantiaVaga | null>(null);

  const [assinarAlvo, setAssinarAlvo] = useState<GarantiaVaga | null>(null);
  const [assinando, setAssinando] = useState(false);

  const [docTarget, setDocTarget] = useState<GarantiaVaga | null>(null);

  const [aba, setAba] = useState<"reservas" | "espera">("reservas");
  const [esperaKey, setEsperaKey] = useState(0);



  const load = async () => {
    setLoading(true);
    const [g, a] = await Promise.all([
      supabase.from("garantias_vaga").select("*").order("created_at", { ascending: false }),
      supabase
        .from("alunos")
        .select("id, nome, escola, responsavel, whatsapp, telefone")
        .is("arquivado_em", null)
        .order("nome"),
    ]);
    setItens((g.data as GarantiaVaga[]) || []);
    setAlunos((a.data as AlunoOpt[]) || []);
    setLoading(false);
  };
  useEffect(() => {
    void load();
  }, []);

  const resumo = useMemo(
    () => ({
      total: itens.length,
      pendente: itens.filter((i) => i.status === "pendente").length,
      confirmado: itens.filter((i) => i.status === "confirmado").length,
      recusado: itens.filter((i) => i.status === "recusado").length,
    }),
    [itens],
  );

  const filtrados = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return itens.filter((i) => {
      if (filtro !== "todos" && i.status !== filtro) return false;
      if (!needle) return true;
      return [i.aluno_nome, i.responsavel_nome, i.escola, String(i.ano_referencia), tipoLabel(i)]
        .join(" ")
        .toLowerCase()
        .includes(needle);
    });
  }, [itens, filtro, q]);

  const openNovo = () => {
    setEditing(null);
    setForm(emptyForm());
    setFormOpen(true);
  };

  const openEditar = (g: GarantiaVaga) => {
    setEditing(g);
    const vinculado = g.aluno_id ? alunos.some((a) => a.id === g.aluno_id) : false;
    setForm({
      aluno_id: vinculado ? g.aluno_id! : "",
      ano_referencia: String(g.ano_referencia),
      tipo: g.tipo,
      tipo_outro: g.tipo_outro || "",
      cobrar: g.cobrar ? "sim" : "nao",
      valor: g.cobrar ? formatBRL(Number(g.valor || 0)) : "",
      abater: g.abater ? "sim" : "nao",
      abater_em: g.abater_em || "primeira",
      abater_outro: g.abater_outro || "",
      status: g.status as GarantiaStatus,
      prazo_resposta: g.prazo_resposta || "",
      observacoes: g.observacoes || "",
      mensalidade: Number(g.mensalidade_prevista || 0) > 0 ? formatBRL(Number(g.mensalidade_prevista)) : "",
      espera_id: "",
      manual: !vinculado,
      aluno_nome_manual: vinculado ? "" : g.aluno_nome || "",
      responsavel_manual: vinculado ? "" : g.responsavel_nome || "",
      whatsapp_manual: vinculado ? "" : g.responsavel_whatsapp || "",
      escola_manual: vinculado ? "" : g.escola || "",
    });

    setFormOpen(true);
  };

  /** Lista de espera → nova reserva já pré-preenchida. */
  const moverParaReserva = (i: ListaEsperaItem) => {
    setEditing(null);
    const endereco = [i.endereco, i.numero].filter(Boolean).join(", ");
    const extras = [
      endereco ? `Endereço: ${endereco}` : "",
      i.periodo ? `Período: ${periodoLabel(i.periodo)}` : "",
      i.observacoes ? `Rota: ${i.observacoes}` : "",
    ].filter(Boolean);
    setForm({
      ...emptyForm(),
      tipo: "reserva",
      espera_id: i.id,
      manual: true,
      aluno_nome_manual: i.aluno_nome,
      responsavel_manual: i.responsavel_nome,
      whatsapp_manual: i.responsavel_whatsapp,
      escola_manual: i.escola || "",
      observacoes: extras.join(" • "),
    });
    setFormOpen(true);
  };

  const salvar = async () => {
    const daEspera = !!form.espera_id;
    const manual = form.manual;
    const aluno = alunos.find((a) => a.id === form.aluno_id);
    if (!manual && !aluno) return toast.error("Selecione o aluno.");
    if (manual && !form.aluno_nome_manual.trim()) return toast.error("Informe o nome do aluno.");
    if (daEspera && parseMoney(form.mensalidade) <= 0)
      return toast.error("Informe o valor da mensalidade do próximo ano.");
    const ano = Number(form.ano_referencia);
    if (!ano || ano < 2000 || ano > 2100) return toast.error("Informe um ano de referência válido.");
    if (form.tipo === "outro" && !form.tipo_outro.trim())
      return toast.error("Descreva o tipo da reserva.");
    if (form.cobrar === "sim" && form.abater === "sim" && form.abater_em === "outro" && !form.abater_outro.trim())
      return toast.error("Descreva como o valor será abatido.");
    if (
      form.cobrar === "sim" && form.abater === "sim" && form.abater_em === "mes" &&
      !/^\d{4}-\d{2}$/.test(form.abater_outro.trim())
    )
      return toast.error("Escolha o mês em que o valor será abatido.");

    // Uma garantia ativa por aluno e ano — só é possível editar ou cancelar a existente.
    if (aluno) {
      const duplicada = itens.find(
        (i) => i.aluno_id === aluno.id && i.ano_referencia === ano && i.id !== editing?.id,
      );
      if (duplicada) {
        return toast.error(`${aluno.nome} já possui uma reserva para ${ano}.`, {
          description: "Edite ou exclua a reserva existente.",
        });
      }
    }

    const cobrar = form.cobrar === "sim";
    const abater = cobrar && form.abater === "sim";
    const payload = {
      aluno_id: aluno?.id ?? null,
      aluno_nome: aluno?.nome ?? form.aluno_nome_manual.trim(),
      escola: aluno ? aluno.escola || "" : form.escola_manual.trim(),
      responsavel_nome: aluno ? aluno.responsavel || "" : form.responsavel_manual.trim(),
      responsavel_whatsapp: aluno
        ? aluno.whatsapp || aluno.telefone || ""
        : form.whatsapp_manual.trim(),
      mensalidade_prevista: parseMoney(form.mensalidade),
      ano_referencia: ano,
      tipo: form.tipo,
      tipo_outro: form.tipo === "outro" ? form.tipo_outro.trim() : "",
      cobrar,
      valor: cobrar ? parseMoney(form.valor) : 0,
      abater,
      abater_em: abater ? form.abater_em : "",
      abater_outro:
        abater && (form.abater_em === "outro" || form.abater_em === "mes")
          ? form.abater_outro.trim()
          : "",
      status: form.status,
      prazo_resposta: form.prazo_resposta || null,
      observacoes: form.observacoes.trim(),
    };

    setSaving(true);
    if (editing) {
      const mudouStatus = editing.status !== form.status;
      const patch: TablesUpdate<"garantias_vaga"> = {
        ...payload,
        historico: pushHistorico(
          editing.historico,
          mudouStatus ? `Status alterado para ${form.status}` : "Reserva editada",
        ),
      };
      if (mudouStatus) {
        patch.confirmado_em = form.status === "confirmado" ? new Date().toISOString() : null;
        patch.recusado_em = form.status === "recusado" ? new Date().toISOString() : null;
      }
      const { error } = await supabase.from("garantias_vaga").update(patch).eq("id", editing.id);
      setSaving(false);
      if (error) return toast.error("Não foi possível salvar.");
      await syncFinanceiro(editing.id);
      toast.success("Reserva atualizada.");
    } else {
      const { data: nova, error } = await supabase
        .from("garantias_vaga")
        .insert({
          ...payload,
          user_id: user!.id,
          historico: pushHistorico([], "Reserva criada"),
        })
        .select()
        .single();
      setSaving(false);
      if (error) {
        return toast.error(
          error.code === "23505"
            ? "Este aluno já possui uma reserva para esse ano."
            : "Não foi possível salvar.",
        );
      }
      if (nova) await syncGarantiaLancamento(user!.id, nova as GarantiaVaga);
      if (daEspera) {
        await supabase
          .from("lista_espera")
          .update({ convertido_em: new Date().toISOString() })
          .eq("id", form.espera_id);
        setEsperaKey((k) => k + 1);
        setAba("reservas");
      }
      toast.success("Reserva de vaga criada.");
    }
    setFormOpen(false);
    void load();
  };

  /** Mantém o lançamento financeiro da garantia em dia (sem duplicar cobranças). */
  const syncFinanceiro = async (id: string) => {
    const { data } = await supabase.from("garantias_vaga").select("*").eq("id", id).maybeSingle();
    if (data) await syncGarantiaLancamento(user!.id, data as GarantiaVaga);
  };

  const excluir = async (g: GarantiaVaga) => {
    if (!confirm(`Excluir a reserva de vaga de ${g.aluno_nome} (${g.ano_referencia})?`)) return;
    const { error } = await supabase.from("garantias_vaga").delete().eq("id", g.id);
    if (error) return toast.error("Não foi possível excluir.");
    toast.success("Reserva excluída.");
    void load();
  };

  const abrirPreview = (g: GarantiaVaga) => {
    if (!parseAssinatura(g.assinatura_motorista)) {
      toast.warning("Assine o documento antes de enviar ao responsável.");
    }
    setPreviewTarget(g);
    const base = buildGarantiaMessage(g, marca.nome);
    setMensagem(
      `${base}\n\n🔗 Ler e assinar o documento:\n${linkAssinatura("garantia", g.id)}`,
    );

    setPreviewOpen(true);
  };

  /** Documento legível (mesmo conteúdo do PDF e da imagem enviada). */
  const garantiaHTML = (g: GarantiaVaga) =>
    buildGarantiaHTML(g as unknown as GarantiaDoc, marca);




  const confirmarEnvio = async () => {
    const g = previewTarget;
    if (!g) return;
    const fone = g.responsavel_whatsapp;
    if (!fone) {
      toast.error("O responsável não tem WhatsApp cadastrado.");
      return;
    }

    // Somente texto + link: o documento completo fica na página de leitura/assinatura.
    window.open(buildWhatsAppUrl(fone, mensagem), "_blank", "noopener,noreferrer");
    const { error } = await supabase
      .from("garantias_vaga")
      .update({
        enviado_em: new Date().toISOString(),
        historico: pushHistorico(g.historico, "Enviado ao responsável pelo WhatsApp"),
      })
      .eq("id", g.id);
    if (!error) void load();
    setPreviewOpen(false);
  };



  const mudarStatus = async (g: GarantiaVaga, status: GarantiaStatus) => {
    const patch: TablesUpdate<"garantias_vaga"> = {
      status,
      historico: pushHistorico(
        g.historico,
        status === "confirmado"
          ? "Confirmação registrada"
          : status === "recusado"
          ? "Recusa registrada"
          : "Status voltou para pendente",
      ),
      confirmado_em: status === "confirmado" ? new Date().toISOString() : null,
      recusado_em: status === "recusado" ? new Date().toISOString() : null,
    };
    const { error } = await supabase.from("garantias_vaga").update(patch).eq("id", g.id);
    if (error) return toast.error("Não foi possível atualizar o status.");
    await syncFinanceiro(g.id);
    toast.success(
      status === "confirmado" ? "Vaga confirmada! 🎉" : status === "recusado" ? "Recusa registrada." : "Voltou para pendente.",
    );
    void load();
  };

  /** Confirmação manual do status (a assinatura em si é feita pelo link). */
  const confirmarVaga = (g: GarantiaVaga) => void mudarStatus(g, "confirmado");


  /** Assinatura visual da tia/tio da van no documento de garantia. */
  const salvarAssinaturaMotorista = async (dados: { imagem: string; nome: string }) => {
    const g = assinarAlvo;
    if (!g) return;
    setAssinando(true);
    const assinatura = novaAssinatura(dados.imagem, dados.nome, "motorista");
    const { error } = await supabase
      .from("garantias_vaga")
      .update({
        assinatura_motorista: assinatura as unknown as TablesUpdate<"garantias_vaga">["assinatura_motorista"],
        historico: pushHistorico(g.historico, `Documento assinado digitalmente por ${assinatura.nome}`),
      })
      .eq("id", g.id);
    setAssinando(false);
    if (error) {
      toast.error("Não foi possível salvar a assinatura.");
      return;
    }

    setAssinarAlvo(null);
    toast.success("Assinatura registrada! Agora envie o link para o responsável assinar.");
    void load();
  };

  const copiarLinkAssinatura = async (g: GarantiaVaga) => {
    const link = linkAssinatura("garantia", g.id);
    try {
      await navigator.clipboard.writeText(link);
      toast.success("Link de assinatura copiado.");
    } catch {
      toast.info(link);
    }
  };





  const gerarPdf = (g: GarantiaVaga, acao: "ver" | "baixar") => {
    if (acao === "ver") {
      setDocTarget(g);
      return;
    }
    try {
      const blob = garantiaToPdfBlob(g, motorista);
      downloadBlob(blob, garantiaFilename(g));
    } catch (e) {
      console.error("[garantia-vaga] falha ao gerar PDF", e);
      toast.error("Não foi possível gerar o documento.");
    }
  };

  const statusBadge = (s: string) =>
    s === "confirmado" ? (
      <Badge className="border-success/30 bg-success/15 text-success" variant="outline">✅ Confirmado</Badge>
    ) : s === "recusado" ? (
      <Badge variant="outline" className="border-destructive/30 bg-destructive/10 text-destructive">❌ Recusado</Badge>
    ) : (
      <Badge variant="outline" className="border-warning/30 bg-warning/15 text-warning-foreground">⏳ Pendente</Badge>
    );

  const filtros: { v: "todos" | GarantiaStatus; label: string }[] = [
    { v: "todos", label: "Todos" },
    { v: "pendente", label: "⏳ Pendentes" },
    { v: "confirmado", label: "✅ Confirmados" },
    { v: "recusado", label: "❌ Recusados" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">🎟️ Reserva de Vaga</h1>
          <p className="text-sm text-muted-foreground">
            Organize a rematrícula e a reserva de vaga dos seus alunos. Não gera mensalidade automática.
          </p>
        </div>
        {aba === "reservas" && (
          <Button className="font-bold" onClick={openNovo}>
            <Plus className="mr-1 h-4 w-4" /> Nova reserva
          </Button>
        )}
      </div>

      <Tabs value={aba} onValueChange={(v) => setAba(v as "reservas" | "espera")}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="reservas">Reservas Confirmadas</TabsTrigger>
          <TabsTrigger value="espera">Lista de Espera</TabsTrigger>
        </TabsList>

        <TabsContent value="espera" className="mt-4">
          <ListaEsperaTab
            userId={user!.id}
            reloadKey={esperaKey}
            onMoverParaReserva={moverParaReserva}
          />
        </TabsContent>

        <TabsContent value="reservas" className="mt-4 space-y-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "Total", v: resumo.total, cls: "" },
          { label: "Pendentes", v: resumo.pendente, cls: "text-warning" },
          { label: "Confirmados", v: resumo.confirmado, cls: "text-success" },
          { label: "Recusados", v: resumo.recusado, cls: "text-destructive" },
        ].map((c) => (
          <Card key={c.label} className="p-4">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{c.label}</div>
            <div className={`mt-1 text-2xl font-extrabold ${c.cls}`}>{c.v}</div>
          </Card>
        ))}
      </div>

      <Card className="p-4" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar por aluno, responsável, escola ou ano"
            className="pl-9"
          />
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {filtros.map((f) => (
            <Button
              key={f.v}
              size="sm"
              variant={filtro === f.v ? "default" : "outline"}
              onClick={() => setFiltro(f.v)}
            >
              {f.label}
            </Button>
          ))}
        </div>
      </Card>

      <Card className="overflow-hidden" style={{ boxShadow: "var(--shadow-card)" }}>
        {loading ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : filtrados.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            Nenhuma reserva por aqui ainda. Clique em <strong>Nova reserva</strong> para começar.
          </div>
        ) : (
          <ul className="divide-y">
            {filtrados.map((g) => (
              <li key={g.id} className="space-y-3 px-4 py-4 sm:px-5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-bold">{g.aluno_nome}</span>
                  <Badge variant="outline" className="bg-primary/10 text-primary">{g.ano_referencia}</Badge>
                  <Badge variant="outline">{tipoLabel(g)}</Badge>
                  {statusBadge(g.status)}
                  <Badge variant="outline">
                    {STATUS_ASSINATURA_LABEL[statusAssinaturas(g.assinatura_motorista, g.assinatura_responsavel)]}
                  </Badge>

                </div>
                <div className="text-xs text-muted-foreground">
                  {g.responsavel_nome || "Responsável não informado"}
                  {g.escola ? ` • ${g.escola}` : ""} • {valorLabel(g)}
                  {g.cobrar && g.abater ? ` • ${abatimentoLabel(g)}` : ""}
                </div>
                <div className="text-[11px] text-muted-foreground">
                  Criado em {formatDataHora(g.created_at)} • Enviado: {formatDataHora(g.enviado_em)} • Confirmado:{" "}
                  {formatDataHora(g.confirmado_em)}
                </div>
                {parseAssinatura(g.assinatura_responsavel) && (
                  <div className="rounded-lg border border-success/30 bg-success/10 px-3 py-2 text-[11px] text-muted-foreground">
                    ✍️ Assinado digitalmente pelo responsável em{" "}
                    {formatDataHora(parseAssinatura(g.assinatura_responsavel)?.em)}
                  </div>
                )}

                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => abrirPreview(g)}>
                    <MessageCircle className="mr-1 h-3 w-3" /> Enviar para responsável
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => gerarPdf(g, "ver")}>
                    <FileText className="mr-1 h-3 w-3" /> Pré-visualizar
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => gerarPdf(g, "baixar")}>
                    ⬇️ PDF
                  </Button>
                  {!parseAssinatura(g.assinatura_motorista) ? (
                    <Button size="sm" variant="outline" className="border-primary/40 text-primary" onClick={() => setAssinarAlvo(g)}>
                      ✍️ Assinar documento
                    </Button>
                  ) : !parseAssinatura(g.assinatura_responsavel) ? (
                    <Button size="sm" variant="outline" onClick={() => copiarLinkAssinatura(g)}>
                      🔗 Copiar link de assinatura
                    </Button>
                  ) : null}

                  {g.status !== "confirmado" && (
                    <Button size="sm" variant="outline" onClick={() => confirmarVaga(g)}>
                      ✅ Confirmar
                    </Button>
                  )}

                  {g.status !== "recusado" && (
                    <Button size="sm" variant="outline" onClick={() => mudarStatus(g, "recusado")}>
                      ❌ Recusar
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setHistTarget(g);
                      setHistOpen(true);
                    }}
                  >
                    🕘 Histórico
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => openEditar(g)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => excluir(g)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
        </TabsContent>
      </Tabs>

      {/* ---------- Cadastro / edição ---------- */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar reserva de vaga" : "Nova reserva de vaga"}</DialogTitle>
            <DialogDescription>
              Cada aluno pode ter apenas uma reserva por ano. Nenhuma mensalidade é gerada automaticamente.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Aluno</Label>
                {form.manual ? (
                  <>
                    <Input
                      value={form.aluno_nome_manual}
                      onChange={(e) => setForm({ ...form, aluno_nome_manual: e.target.value })}
                    />
                    {alunos.length > 0 && (
                      <Select
                        value={form.aluno_id}
                        onValueChange={(v) => setForm({ ...form, aluno_id: v, manual: false })}
                      >
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue placeholder="Vincular a um aluno cadastrado (opcional)" />
                        </SelectTrigger>
                        <SelectContent>
                          {alunos.map((a) => (
                            <SelectItem key={a.id} value={a.id}>{a.nome}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </>
                ) : (
                  <Select value={form.aluno_id} onValueChange={(v) => setForm({ ...form, aluno_id: v })}>
                    <SelectTrigger><SelectValue placeholder="Selecione o aluno" /></SelectTrigger>
                    <SelectContent>
                      {alunos.map((a) => (
                        <SelectItem key={a.id} value={a.id}>{a.nome}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="gv-ano">Ano de referência</Label>
                <Input
                  id="gv-ano"
                  inputMode="numeric"
                  value={form.ano_referencia}
                  onChange={(e) =>
                    setForm({ ...form, ano_referencia: e.target.value.replace(/\D/g, "").slice(0, 4) })
                  }
                />
              </div>
            </div>

            {form.manual && (
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="gv-resp">Responsável</Label>
                  <Input
                    id="gv-resp"
                    value={form.responsavel_manual}
                    onChange={(e) => setForm({ ...form, responsavel_manual: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="gv-zap">WhatsApp do responsável</Label>
                  <Input
                    id="gv-zap"
                    value={form.whatsapp_manual}
                    onChange={(e) => setForm({ ...form, whatsapp_manual: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="gv-escola">Escola</Label>
                  <Input
                    id="gv-escola"
                    value={form.escola_manual}
                    onChange={(e) => setForm({ ...form, escola_manual: e.target.value })}
                  />
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="gv-mensalidade">
                Valor da mensalidade (próximo ano){form.espera_id ? " *" : " — opcional"}
              </Label>
              <Input
                id="gv-mensalidade"
                inputMode="decimal"
                placeholder="0,00"
                value={form.mensalidade}
                onChange={(e) => setForm({ ...form, mensalidade: e.target.value })}
              />
            </div>

            <div className="space-y-1.5">
              <Label>Tipo</Label>
              <Select value={form.tipo} onValueChange={(v) => setForm({ ...form, tipo: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TIPO_OPCOES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {form.tipo === "outro" && (
                <Input
                  className="mt-2"
                  placeholder="Descreva o tipo"
                  value={form.tipo_outro}
                  onChange={(e) => setForm({ ...form, tipo_outro: e.target.value })}
                />
              )}
            </div>

            <div className="rounded-xl border p-3">
              <Label className="text-sm font-bold">Cobrar valor?</Label>
              <RadioGroup
                className="mt-2 flex gap-6"
                value={form.cobrar}
                onValueChange={(v) => setForm({ ...form, cobrar: v as "sim" | "nao" })}
              >
                <div className="flex items-center gap-2">
                  <RadioGroupItem value="sim" id="gv-cobrar-sim" />
                  <Label htmlFor="gv-cobrar-sim" className="font-normal">Sim</Label>
                </div>
                <div className="flex items-center gap-2">
                  <RadioGroupItem value="nao" id="gv-cobrar-nao" />
                  <Label htmlFor="gv-cobrar-nao" className="font-normal">Não</Label>
                </div>
              </RadioGroup>
              {form.cobrar === "sim" && (
                <div className="mt-3 space-y-1.5">
                  <Label htmlFor="gv-valor">Valor (R$) — pode ser zero</Label>
                  <Input
                    id="gv-valor"
                    inputMode="decimal"
                    placeholder="0,00"
                    value={form.valor}
                    onChange={(e) => setForm({ ...form, valor: e.target.value })}
                  />
                </div>
              )}
            </div>

            {form.cobrar === "sim" && (
              <div className="rounded-xl border p-3">
                <Label className="text-sm font-bold">Abater depois?</Label>
                <RadioGroup
                  className="mt-2 flex gap-6"
                  value={form.abater}
                  onValueChange={(v) => setForm({ ...form, abater: v as "sim" | "nao" })}
                >
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="sim" id="gv-abater-sim" />
                    <Label htmlFor="gv-abater-sim" className="font-normal">Sim</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="nao" id="gv-abater-nao" />
                    <Label htmlFor="gv-abater-nao" className="font-normal">Não</Label>
                  </div>
                </RadioGroup>
                {form.abater === "sim" && (
                  <div className="mt-3 space-y-1.5">
                    <Label>Abater em</Label>
                    <Select
                      value={form.abater_em}
                      onValueChange={(v) => setForm({ ...form, abater_em: v, abater_outro: "" })}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {ABATER_OPCOES.map((a) => (
                          <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {form.abater_em === "mes" && (
                      <Input
                        className="mt-2"
                        type="month"
                        value={form.abater_outro}
                        onChange={(e) => setForm({ ...form, abater_outro: e.target.value })}
                      />
                    )}
                    {form.abater_em === "outro" && (
                      <Input
                        className="mt-2"
                        placeholder="Ex.: abatido em duas parcelas"
                        value={form.abater_outro}
                        onChange={(e) => setForm({ ...form, abater_outro: e.target.value })}
                      />
                    )}
                  </div>
                )}
              </div>
            )}

            <div className="space-y-1.5">
              <Label>Status</Label>
              <Select
                value={form.status}
                onValueChange={(v) => setForm({ ...form, status: v as GarantiaStatus })}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pendente">⏳ Pendente</SelectItem>
                  <SelectItem value="confirmado">✅ Confirmado</SelectItem>
                  <SelectItem value="recusado">❌ Recusado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="gv-prazo">Prazo para resposta do responsável (opcional)</Label>
              <DateInputBR
                id="gv-prazo"
                value={form.prazo_resposta}
                onChange={(iso) => setForm({ ...form, prazo_resposta: iso })}
                fromYear={new Date().getFullYear()}
                toYear={new Date().getFullYear() + 3}
              />
              <p className="text-xs text-muted-foreground">
                Aparece no documento e na mensagem: "Responder até {form.prazo_resposta ? formatDataBR(form.prazo_resposta) : "DD/MM/AAAA"}".
              </p>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="gv-obs">Observações (opcional)</Label>
              <Textarea
                id="gv-obs"
                rows={2}
                value={form.observacoes}
                onChange={(e) => setForm({ ...form, observacoes: e.target.value })}
                placeholder="Ex.: vaga garantida até o fim de janeiro."
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>Cancelar</Button>
            <Button className="font-bold" onClick={salvar} disabled={saving}>
              {saving ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---------- Pré-visualização do envio ---------- */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Enviar para o responsável</DialogTitle>
            <DialogDescription>
              Revise a mensagem antes de abrir o WhatsApp. Você pode editar o texto.
            </DialogDescription>
          </DialogHeader>
          {previewTarget && (
            <div className="rounded-xl border bg-muted/40 p-3 text-xs text-muted-foreground">
              Para <strong className="text-foreground">{previewTarget.responsavel_nome || "responsável"}</strong>
              {previewTarget.responsavel_whatsapp ? ` • ${previewTarget.responsavel_whatsapp}` : " • sem WhatsApp cadastrado"}
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="gv-msg">Mensagem</Label>
            <Textarea id="gv-msg" rows={12} value={mensagem} onChange={(e) => setMensagem(e.target.value)} />
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => previewTarget && setMensagem(buildGarantiaMessage(previewTarget, marca.nome))}
            >
              ✏️ Restaurar texto
            </Button>
            <Button className="font-bold" onClick={confirmarEnvio}>
              <MessageCircle className="mr-1 h-4 w-4" /> Confirmar envio
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---------- Histórico ---------- */}
      <Dialog open={histOpen} onOpenChange={setHistOpen}>
        <DialogContent className="max-h-[80vh] overflow-y-auto sm:max-w-md">
          <DialogHeader>
            <DialogTitle>🕘 Histórico</DialogTitle>
            <DialogDescription>{histTarget?.aluno_nome} — {histTarget?.ano_referencia}</DialogDescription>
          </DialogHeader>
          <ul className="space-y-2 text-sm">
            {parseHistorico(histTarget?.historico).length === 0 && (
              <li className="text-muted-foreground">Sem registros ainda.</li>
            )}
            {parseHistorico(histTarget?.historico)
              .slice()
              .reverse()
              .map((h, i) => (
                <li key={i} className="rounded-lg border px-3 py-2">
                  <div className="font-semibold">{h.evento}</div>
                  <div className="text-xs text-muted-foreground">{formatDataHora(h.em)}</div>
                </li>
              ))}
          </ul>
        </DialogContent>
      </Dialog>

      {/* ---------- Leitura do documento na tela ---------- */}
      <DocumentoViewerDialog
        open={!!docTarget}
        onOpenChange={(v) => !v && setDocTarget(null)}
        titulo="Reserva de vaga"
        descricao={
          docTarget
            ? `${docTarget.aluno_nome} — ${
                parseAssinatura(docTarget.assinatura_responsavel)
                  ? "assinado pelas duas partes."
                  : parseAssinatura(docTarget.assinatura_motorista)
                  ? "já assinado pela van, aguardando o responsável."
                  : "ainda sem assinaturas."
              }`
            : undefined
        }
        html={docTarget ? garantiaHTML(docTarget) : ""}
        acoes={
          <>
            <Button variant="outline" onClick={() => setDocTarget(null)}>Fechar</Button>
            {docTarget && !parseAssinatura(docTarget.assinatura_motorista) && (
              <Button
                variant="outline"
                className="border-primary/40 text-primary"
                onClick={() => { const g = docTarget; setDocTarget(null); setAssinarAlvo(g); }}
              >
                ✍️ Assinar documento
              </Button>
            )}
            <Button
              className="font-bold"
              onClick={() => { if (docTarget) gerarPdf(docTarget, "baixar"); }}
            >
              ⬇️ Baixar PDF
            </Button>
          </>
        }
      />

      <SignaturePadDialog
        open={!!assinarAlvo}
        onOpenChange={(v) => !v && setAssinarAlvo(null)}
        papel="motorista"
        nomePadrao={motorista.nome_completo}
        documentoLabel={assinarAlvo ? `Reserva de vaga — ${assinarAlvo.aluno_nome}` : undefined}
        saving={assinando}
        onAceitar={salvarAssinaturaMotorista}
      />
    </div>

  );
}
