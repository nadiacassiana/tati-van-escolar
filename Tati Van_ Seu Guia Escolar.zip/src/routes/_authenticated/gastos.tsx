import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Fuel, Droplet, Disc, Shield, Wrench, Trash2, Pencil, Car, Circle, FileText, Settings, Snowflake, Zap } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { parseMoney, formatBRL } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/gastos")({
  head: () => ({ meta: [{ title: "Gastos da Van — Tati Van" }] }),
  component: GastosPage,
});

type Gasto = {
  id: string; data: string; categoria: string; valor: number;
  descricao: string; km: number | null; observacoes: string;
};

const CATEGORIAS = [
  "Combustível",
  "Troca de Óleo",
  "Pneus (compra e troca de pneus novos)",
  "Borracharia (conserto de pneus, remendos, vulcanização, troca de válvula e serviços de borracheiro)",
  "Mecânica",
  "Funilaria",
  "Elétrica",
  "Ar-condicionado",
  "Lavagem",
  "Seguro",
  "Documentação e Taxas",
  "Manutenção Geral",
  "Multa",
  "Outros",
];

const categoriaIcon: Record<string, React.ElementType> = {
  "Combustível": Fuel,
  "Troca de Óleo": Droplet,
  "Pneus (compra e troca de pneus novos)": Disc,
  "Borracharia (conserto de pneus, remendos, vulcanização, troca de válvula e serviços de borracheiro)": Circle,
  "Mecânica": Wrench,
  "Funilaria": Car,
  "Elétrica": Zap,
  "Ar-condicionado": Snowflake,
  "Lavagem": Droplet,
  "Seguro": Shield,
  "Documentação e Taxas": FileText,
  "Manutenção Geral": Settings,
};

const emptyForm = {
  data: new Date().toISOString().slice(0, 10),
  categoria: "Combustível",
  valor: "",
  descricao: "",
  km: "",
  observacoes: "",
};

function GastosPage() {
  const { user } = Route.useRouteContext();
  const [lista, setLista] = useState<Gasto[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("gastos").select("*").order("data", { ascending: false });
    setLista((data as unknown as Gasto[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const valor = parseMoney(form.valor);
    if (valor <= 0) return toast.error("Informe o valor.");
    setSaving(true);
    const payload = {
      user_id: user.id,
      data: form.data,
      categoria: form.categoria,
      valor,
      descricao: form.descricao,
      km: form.km ? parseInt(form.km.replace(/\D/g, ""), 10) || null : null,
      observacoes: form.observacoes,
    };
    const { error } = editingId
      ? await supabase.from("gastos").update(payload).eq("id", editingId)
      : await supabase.from("gastos").insert(payload);
    setSaving(false);
    if (error) return toast.error("Erro ao salvar gasto.");
    toast.success(editingId ? "Gasto atualizado!" : "Gasto registrado!");
    setForm(emptyForm);
    setEditingId(null);
    setOpen(false);
    load();
  };

  const handleEdit = (g: Gasto) => {
    setEditingId(g.id);
    setForm({
      data: g.data,
      categoria: g.categoria,
      valor: String(g.valor).replace(".", ","),
      descricao: g.descricao || "",
      km: g.km ? String(g.km) : "",
      observacoes: g.observacoes || "",
    });
    setOpen(true);
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("gastos").delete().eq("id", id);
    if (error) return toast.error("Erro ao excluir.");
    setLista((p) => p.filter((g) => g.id !== id));
    toast.success("Gasto excluído.");
  };

  const total = lista.reduce((s, g) => s + Number(g.valor), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold">Gastos da Van ⛽</h1>
          <p className="text-sm text-muted-foreground">Combustível, manutenção, taxas e outros.</p>
        </div>
        <Button onClick={() => { setForm(emptyForm); setEditingId(null); setOpen(true); }} className="bg-primary text-primary-foreground font-bold">
          <Plus className="mr-2 h-4 w-4" /> Novo gasto
        </Button>
      </div>

      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">Total registrado</div>
        <div className="mt-1 text-3xl font-extrabold text-primary">R$ {formatBRL(total)}</div>
      </Card>

      <Card className="overflow-hidden" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="border-b px-5 py-3 font-bold">Lançamentos</div>
        {loading ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : lista.length === 0 ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Nenhum gasto registrado ainda.</div>
        ) : (
          <ul className="divide-y">
            {lista.map((g) => {
              const Icon = categoriaIcon[g.categoria] ?? Fuel;
              return (
                <li key={g.id} className="flex items-center gap-4 px-5 py-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/40 text-accent-foreground">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold">{g.categoria}{g.descricao ? ` — ${g.descricao}` : ""}</div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(g.data + "T00:00:00").toLocaleDateString("pt-BR")}
                      {g.km ? ` • ${g.km.toLocaleString("pt-BR")} km` : ""}
                      {g.observacoes ? ` • ${g.observacoes}` : ""}
                    </div>
                  </div>
                  <div className="font-extrabold">R$ {formatBRL(Number(g.valor))}</div>
                  <Button size="icon" variant="ghost" className="h-8 w-8" aria-label="Editar" onClick={() => handleEdit(g)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" aria-label="Excluir">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Excluir gasto?</AlertDialogTitle>
                        <AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(g.id)}>Excluir</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </li>
              );
            })}
          </ul>
        )}
      </Card>

      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setEditingId(null); setForm(emptyForm); } }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingId ? "Editar gasto" : "Novo gasto"}</DialogTitle>
            <DialogDescription>{editingId ? "Atualize os dados do lançamento." : "Registre um lançamento da van."}</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="data">Data *</Label>
                <Input id="data" type="date" value={form.data} onChange={(e) => setForm({ ...form, data: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="cat">Categoria *</Label>
                <Select value={form.categoria} onValueChange={(v) => setForm({ ...form, categoria: v })}>
                  <SelectTrigger id="cat"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIAS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="valor">Valor (R$) *</Label>
                <Input id="valor" type="text" inputMode="decimal" placeholder="R$ 280,00" value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} />
              </div>
              <div>
                <Label htmlFor="km">Quilometragem</Label>
                <Input id="km" type="text" inputMode="numeric" placeholder="opcional" value={form.km} onChange={(e) => setForm({ ...form, km: e.target.value })} />
              </div>
            </div>
            <div>
              <Label htmlFor="desc">Descrição</Label>
              <Input id="desc" value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} placeholder="Ex.: Posto Shell — 38L" />
            </div>
            <div>
              <Label htmlFor="obs">Observações</Label>
              <Textarea id="obs" rows={2} value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} />
            </div>
            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saving} className="bg-primary text-primary-foreground font-bold">
                {saving ? "Salvando..." : editingId ? "Salvar alterações" : "Salvar gasto"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
