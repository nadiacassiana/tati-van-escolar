import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CalendarDays, Download, History, Loader2, Sun, Sunrise, Sunset } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { turnoLabel, type Turno } from "@/lib/rota-ativa";
import {
  dataBR, historicoToPdfBlob, horaBR, listarHistorico, resumoRota, statusLabel,
  type RotaHistorico,
} from "@/lib/rota-historico";
import { getMotoristaFromUser } from "@/lib/whatsapp";
import type { User } from "@supabase/supabase-js";

export const Route = createFileRoute("/_authenticated/historico-rotas")({
  head: () => ({
    meta: [
      { title: "Histórico de Rotas — Tati Van Escolar" },
      { name: "description", content: "Consulte as rotas finalizadas, presenças e ausências dos alunos e exporte o relatório em PDF." },
      { property: "og:title", content: "Histórico de Rotas — Tati Van Escolar" },
      { property: "og:description", content: "Rotas finalizadas com horários de embarque, presenças e ausências." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HistoricoRotasPage,
});

const turnoIcon: Record<Turno, React.ElementType> = {
  manha: Sunrise,
  tarde: Sunset,
  integral: Sun,
};

function mesAtual(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function HistoricoRotasPage() {
  const [user, setUser] = useState<User | null>(null);
  const [mes, setMes] = useState<string>(mesAtual);
  const [dia, setDia] = useState<string>("");
  const [rotas, setRotas] = useState<RotaHistorico[]>([]);
  const [loading, setLoading] = useState(true);

  const periodo = useMemo(() => {
    if (dia) {
      const inicio = new Date(`${dia}T00:00:00`);
      const fim = new Date(`${dia}T23:59:59.999`);
      return { inicio, fim, label: inicio.toLocaleDateString("pt-BR") };
    }
    const [y, m] = mes.split("-").map(Number);
    const inicio = new Date(y, (m || 1) - 1, 1, 0, 0, 0);
    const fim = new Date(y, m || 1, 0, 23, 59, 59, 999);
    return {
      inicio,
      fim,
      label: inicio.toLocaleDateString("pt-BR", { month: "long", year: "numeric" }),
    };
  }, [mes, dia]);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
  }, []);

  const carregar = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const lista = await listarHistorico(
        user.id,
        periodo.inicio.toISOString(),
        periodo.fim.toISOString(),
      );
      setRotas(lista);
    } catch (e) {
      console.error(e);
      toast.error("Não foi possível carregar o histórico.");
    } finally {
      setLoading(false);
    }
  }, [user, periodo]);

  useEffect(() => {
    void carregar();
  }, [carregar]);

  function exportar() {
    if (!user) return;
    if (rotas.length === 0) {
      toast.info("Nenhuma rota finalizada no período selecionado.");
      return;
    }
    try {
      const blob = historicoToPdfBlob(rotas, periodo.label, getMotoristaFromUser(user));
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `relatorio-rotas-${dia || mes}.pdf`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      toast.success("Relatório gerado! 📄");
    } catch (e) {
      console.error(e);
      toast.error("Não foi possível gerar o PDF.");
    }
  }

  const totalGeral = rotas.reduce(
    (acc, r) => {
      const s = resumoRota(r);
      acc.embarcados += s.embarcados;
      acc.desembarcados += s.desembarcados;
      acc.ausentes += s.ausentes;
      return acc;
    },
    { embarcados: 0, desembarcados: 0, ausentes: 0 },
  );

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-extrabold">
          <History className="h-6 w-6 text-primary" /> Histórico de Rotas
        </h1>
        <p className="text-sm text-muted-foreground">
          Consulte as rotas já finalizadas, com presenças, faltas e horários de embarque.
        </p>
      </div>

      <Card className="p-4" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1">
            <Label htmlFor="mes">Mês / Ano</Label>
            <Input
              id="mes"
              type="month"
              value={mes}
              onChange={(e) => { setMes(e.target.value); setDia(""); }}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="dia">Data específica</Label>
            <Input id="dia" type="date" value={dia} onChange={(e) => setDia(e.target.value)} />
          </div>
          <div className="flex items-end gap-2">
            {dia && (
              <Button variant="outline" className="flex-1" onClick={() => setDia("")}>
                Ver mês
              </Button>
            )}
            <Button className="flex-1 gap-2" onClick={exportar}>
              <Download className="h-4 w-4" /> Exportar PDF
            </Button>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <CalendarDays className="h-4 w-4" />
          <span className="capitalize">{periodo.label}</span>
          <span>•</span>
          <span>{rotas.length} rota(s)</span>
          <span>•</span>
          <span className="text-primary">{totalGeral.embarcados} embarque(s)</span>
          <span>•</span>
          <span className="text-success">{totalGeral.desembarcados} desembarque(s)</span>
          <span>•</span>
          <span className="text-destructive">{totalGeral.ausentes} ausência(s)</span>
        </div>
      </Card>

      {loading ? (
        <div className="flex justify-center py-10 text-muted-foreground">
          <Loader2 className="h-6 w-6 animate-spin" />
        </div>
      ) : rotas.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">
          Nenhuma rota finalizada neste período. Assim que você iniciar e encerrar uma rota no
          Checklist Diário, ela aparecerá aqui. 🚐
        </Card>
      ) : (
        <div className="space-y-4">
          {rotas.map((r) => {
            const s = resumoRota(r);
            const Icon = turnoIcon[r.turno] || Sunrise;
            return (
              <Card key={r.id} className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 font-bold">
                      <Icon className="h-4 w-4 text-primary" />
                      <span className="capitalize">Rota da {turnoLabel[r.turno]}</span>
                      <span className="text-muted-foreground">• {dataBR(r.iniciada_em)}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Início {horaBR(r.iniciada_em)} · Fim {horaBR(r.encerrada_em)}
                    </div>
                  </div>
                  <div className="text-right text-xs">
                    <div className="text-lg font-extrabold text-primary">
                      {s.embarcados + s.desembarcados}/{s.total}
                    </div>
                    <div className="text-muted-foreground">
                      {s.ausentes} ausente(s) · {s.pendentes} pendente(s)
                    </div>
                  </div>
                </div>

                {r.paradas.length > 0 && (
                  <ul className="mt-3 divide-y rounded-xl border">
                    {r.paradas.map((p) => {
                      const statusClasse =
                        p.status === "embarcado"
                          ? "text-primary"
                          : p.status === "desembarcado"
                            ? "text-success"
                            : p.status === "ausente"
                              ? "text-destructive"
                              : "text-muted-foreground";
                      let hora = "";
                      if (p.status === "embarcado" && p.embarcado_em) hora = ` às ${horaBR(p.embarcado_em)}`;
                      if (p.status === "desembarcado" && p.desembarcado_em) hora = ` às ${horaBR(p.desembarcado_em)}`;
                      return (
                        <li key={p.id} className="flex items-center justify-between px-3 py-2 text-sm">
                          <span className="font-medium">{p.aluno_nome}</span>
                          <span className={statusClasse}>
                            {statusLabel[p.status]}{hora}
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
