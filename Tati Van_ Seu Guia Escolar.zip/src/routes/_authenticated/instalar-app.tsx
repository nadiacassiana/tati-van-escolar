import { createFileRoute, Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, Smartphone, Apple, Chrome } from "lucide-react";

export const Route = createFileRoute("/_authenticated/instalar-app")({
  head: () => ({
    meta: [{ title: "Como instalar o aplicativo — Tati Van" }],
  }),
  component: InstallAppPage,
});

function InstallAppPage() {
  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link to="/configuracoes">
            <ChevronLeft className="h-4 w-4" /> Voltar
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-2xl font-extrabold">📲 Como instalar o aplicativo</h1>
        <p className="text-sm text-muted-foreground">
          A Tati Van é um app web instalável. Você adiciona ele diretamente na tela inicial do celular, sem precisar baixar nada da loja.
        </p>
      </div>

      <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold">
          <Apple className="h-4 w-4" /> iPhone (iOS)
        </div>
        <ol className="mt-3 list-decimal space-y-2 pl-4 text-sm text-muted-foreground">
          <li>
            Abra o <strong>Safari</strong> e acesse{" "}
            <strong>tatiassistentevirtual.com.br</strong>.
          </li>
          <li>
            Toque no botão <strong>Compartilhar</strong> (quadrado com seta para cima, na barra inferior).
          </li>
          <li>
            Role para baixo e selecione <strong>Adicionar à Tela de Início</strong>.
          </li>
          <li>
            Toque em <strong>Adicionar</strong>. Pronto: o ícone da Tati Van aparece junto com seus outros apps.
          </li>
        </ol>
      </Card>

      <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold">
          <Chrome className="h-4 w-4" /> Android
        </div>
        <ol className="mt-3 list-decimal space-y-2 pl-4 text-sm text-muted-foreground">
          <li>
            Abra o <strong>Chrome</strong> e acesse{" "}
            <strong>tatiassistentevirtual.com.br</strong>.
          </li>
          <li>
            Toque no menu <strong>⋮</strong> (três pontinhos) no canto superior direito.
          </li>
          <li>
            Selecione <strong>Adicionar à tela inicial</strong> ou{" "}
            <strong>Instalar aplicativo</strong>.
          </li>
          <li>
            Confirme em <strong>Adicionar</strong> ou <strong>Instalar</strong>. Pronto: o ícone da Tati Van fica disponível como um app.
          </li>
        </ol>
      </Card>

      <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center gap-2 font-bold">
          <Smartphone className="h-4 w-4" /> Dica importante
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          Não precisa procurar na App Store ou Play Store. Como a Tati Van é um aplicativo web progressivo (PWA), ele é leve, sempre atualizado e abre em tela cheia, igual a um app nativo.
        </p>
      </Card>
    </div>
  );
}
