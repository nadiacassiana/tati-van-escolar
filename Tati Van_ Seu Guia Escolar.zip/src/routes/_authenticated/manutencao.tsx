import { createFileRoute, Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Wrench } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { formatBRL } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/manutencao")({
  head: () => ({ meta: [{ title: "Manutenção — Tati Van" }] }),
  component: ManutencaoPage,
});

type Gasto = { id: string; data: string; categoria: string; valor: number; km: number | null; descricao: string };

const CATS = ["Troca de óleo", "Pneus", "Manutenção"];

function ManutencaoPage() {
  const [itens, setItens] = useState<Gasto[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("gastos").select("id, data, categoria, valor, km, descricao").in("categoria", CATS).order("data", { ascending: false });
      setItens(((data as unknown) as Gasto[]) || []);
      setLoading(false);
    })();
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">Manutenção 🔧</h1>
        <p className="text-sm text-muted-foreground">Histórico de manutenções (vindo dos seus gastos).</p>
      </div>

      {loading ? (
        <Card className="p-6 text-center text-sm text-muted-foreground">Carregando...</Card>
      ) : itens.length === 0 ? (
        <Card className="p-6 text-center text-sm text-muted-foreground space-y-3">
          <p>Nenhuma manutenção registrada ainda.</p>
          <Link to="/gastos">
            <Button variant="outline">Lançar em Gastos</Button>
          </Link>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {itens.map((m) => (
            <Card key={m.id} className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Wrench className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-bold">{m.categoria}</div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(m.data + "T00:00:00").toLocaleDateString("pt-BR")}
                      {m.km ? ` • ${m.km.toLocaleString("pt-BR")} km` : ""}
                    </div>
                  </div>
                </div>
                <div className="font-extrabold">R$ {formatBRL(Number(m.valor))}</div>
              </div>
              {m.descricao && (
                <div className="mt-3 rounded-lg bg-secondary/60 px-3 py-2 text-sm">{m.descricao}</div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
