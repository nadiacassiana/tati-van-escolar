import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Star, Send, History, MessageCircle, Users, Megaphone, Search, Copy, Sparkles, Package, X } from "lucide-react";
import { WhatsAppSender, type SenderAluno, type SenderResponsavel } from "@/components/whatsapp-sender";
import { MassCommDialog } from "@/components/mass-comm-dialog";
import { PACOTES_MENSAGENS, CATEGORIAS, VARIAVEIS_DISPONIVEIS } from "@/lib/whatsapp";

export const Route = createFileRoute("/_authenticated/mensagens")({
  head: () => ({ meta: [{ title: "Mensagens — Tati Van" }] }),
  component: MensagensPage,
});

type Mensagem = { id: string; nome: string; emoji: string; texto: string; favorito: boolean; ordem: number; categoria: string };
type Historico = { id: string; mensagem_nome: string; emoji: string; texto: string; destinatario: string; created_at: string; canal: string; status: string; aluno_id: string | null };

const EMOJIS = ["💬","🚐","🏫","🏠","💰","🚦","❌","🎂","🎄","📚","🙏","🎉","☀️","🌧️","⏰","📢","✨","🎁","🚌","🚏","🔧","🚨","🔑","✅","⚠️","💙","❤️","🎒","🕐","🎆","🌴","❓","📚"];

const WELCOME_KEY = "tati_msg_welcome_dismissed";

function MensagensPage() {
  const { user } = Route.useRouteContext();
  const [aba, setAba] = useState("biblioteca");
  const [msgs, setMsgs] = useState<Mensagem[]>([]);
  const [hist, setHist] = useState<Historico[]>([]);
  const [resps, setResps] = useState<SenderResponsavel[]>([]);
  const [alunos, setAlunos] = useState<SenderAluno[]>([]);
  const [loading, setLoading] = useState(true);

  const [edOpen, setEdOpen] = useState(false);
  const [edId, setEdId] = useState<string | null>(null);
  const [form, setForm] = useState({ nome: "", emoji: "💬", texto: "", categoria: "Transporte Diário" });

  const [senderOpen, setSenderOpen] = useState(false);
  const [grupoSel, setGrupoSel] = useState<{ resps: SenderResponsavel[]; label: string } | null>(null);
  const [massOpen, setMassOpen] = useState(false);

  const [filtroGrupo, setFiltroGrupo] = useState<string>("todos");
  const [busca, setBusca] = useState("");
  const [catFiltro, setCatFiltro] = useState<string>("todas");
  const [pacoteOpen, setPacoteOpen] = useState(false);
  const [pacotesSel, setPacotesSel] = useState<Record<string, boolean>>({});
  const [welcomeOpen, setWelcomeOpen] = useState(false);
  const [autoSeeded, setAutoSeeded] = useState(false);

  const load = async () => {
    setLoading(true);
    const [{ data: ms }, { data: hs }, { data: rs }, { data: as }] = await Promise.all([
      supabase.from("mensagens").select("*").order("favorito", { ascending: false }).order("ordem", { ascending: true }),
      supabase.from("mensagens_historico").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("responsaveis").select("id, nome, whatsapp, telefone, alunos_ids"),
      supabase.from("alunos").select("id, nome, escola, mensalidade, vencimento, horario_ida, status_mensalidade"),
    ]);
    let list = (ms as Mensagem[]) || [];
    // Primeiro acesso: semear biblioteca inicial automaticamente
    if (list.length === 0 && !autoSeeded) {
      setAutoSeeded(true);
      const rows = Object.values(PACOTES_MENSAGENS).flat().map((m, i) => ({
        nome: m.nome, emoji: m.emoji, texto: m.texto, favorito: !!m.favorito,
        categoria: m.categoria, ordem: i, user_id: user.id,
      }));
      const { data: inserted } = await supabase.from("mensagens").insert(rows).select("*");
      list = (inserted as Mensagem[]) || [];
      if (!localStorage.getItem(WELCOME_KEY)) setWelcomeOpen(true);
    } else if (list.length > 0) {
      // Sincroniza novos modelos padrão que ainda não existem na biblioteca do usuário
      const existentes = new Set(list.map((m) => `${(m.categoria || "").toLowerCase()}|${m.nome.toLowerCase()}`));
      const faltando = Object.values(PACOTES_MENSAGENS).flat().filter(
        (m) => !existentes.has(`${m.categoria.toLowerCase()}|${m.nome.toLowerCase()}`)
      );
      if (faltando.length > 0) {
        const baseOrdem = (list[list.length - 1]?.ordem ?? 0) + 1;
        const { data: novos } = await supabase.from("mensagens").insert(
          faltando.map((m, i) => ({
            nome: m.nome, emoji: m.emoji, texto: m.texto, favorito: !!m.favorito,
            categoria: m.categoria, ordem: baseOrdem + i, user_id: user.id,
          }))
        ).select("*");
        if (novos?.length) list = [...list, ...(novos as Mensagem[])];
      }
    }
    setMsgs(list);
    setHist((hs as Historico[]) || []);
    setResps((rs as SenderResponsavel[]) || []);
    setAlunos((as as SenderAluno[]) || []);
    setLoading(false);
  };

  useEffect(() => { void load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  const openNew = () => { setEdId(null); setForm({ nome: "", emoji: "💬", texto: "", categoria: "Transporte Diário" }); setEdOpen(true); };
  const openEdit = (m: Mensagem) => { setEdId(m.id); setForm({ nome: m.nome, emoji: m.emoji, texto: m.texto, categoria: m.categoria || "Transporte Diário" }); setEdOpen(true); };

  const salvar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome.trim() || !form.texto.trim()) { toast.error("Preencha nome e texto."); return; }
    if (edId) {
      const { error } = await supabase.from("mensagens").update(form).eq("id", edId);
      if (error) return toast.error("Erro ao salvar.");
      toast.success("Mensagem atualizada!");
    } else {
      const ordem = (msgs[msgs.length - 1]?.ordem ?? 0) + 1;
      const { error } = await supabase.from("mensagens").insert({ ...form, ordem, user_id: user.id });
      if (error) return toast.error("Erro ao criar.");
      toast.success("Mensagem criada!");
    }
    setEdOpen(false);
    void load();
  };

  const excluir = async (id: string) => {
    const { error } = await supabase.from("mensagens").delete().eq("id", id);
    if (error) return toast.error("Erro ao excluir.");
    setMsgs((p) => p.filter((m) => m.id !== id));
    toast.success("Mensagem excluída.");
  };

  const duplicar = async (m: Mensagem) => {
    const ordem = (msgs[msgs.length - 1]?.ordem ?? 0) + 1;
    const { error } = await supabase.from("mensagens").insert({
      nome: `${m.nome} (cópia)`, emoji: m.emoji, texto: m.texto,
      favorito: false, categoria: m.categoria || "Geral", ordem, user_id: user.id,
    });
    if (error) return toast.error("Erro ao duplicar.");
    toast.success("Mensagem duplicada!");
    void load();
  };

  const favoritar = async (m: Mensagem) => {
    await supabase.from("mensagens").update({ favorito: !m.favorito }).eq("id", m.id);
    void load();
  };

  const importarPacotes = async () => {
    const escolhidos = Object.entries(pacotesSel).filter(([, v]) => v).map(([k]) => k);
    if (escolhidos.length === 0) { toast.error("Selecione ao menos um pacote."); return; }
    const baseOrdem = (msgs[msgs.length - 1]?.ordem ?? 0) + 1;
    const rows: Array<{ nome: string; emoji: string; texto: string; favorito: boolean; categoria: string; ordem: number; user_id: string }> = [];
    let i = 0;
    for (const cat of escolhidos) {
      for (const m of PACOTES_MENSAGENS[cat] || []) {
        rows.push({
          nome: m.nome, emoji: m.emoji, texto: m.texto, favorito: !!m.favorito,
          categoria: m.categoria, ordem: baseOrdem + i, user_id: user.id,
        });
        i++;
      }
    }
    const { error } = await supabase.from("mensagens").insert(rows);
    if (error) return toast.error("Erro ao importar.");
    toast.success(`${rows.length} mensagem(ns) importadas!`);
    setPacoteOpen(false);
    setPacotesSel({});
    void load();
  };

  // Grupos
  const alunosComExtras = alunos as (SenderAluno & { horario_ida: string; status_mensalidade: string })[];
  const respsPorFiltro = (key: string): { resps: SenderResponsavel[]; label: string } => {
    if (key === "todos") return { resps, label: "Todos os responsáveis" };
    if (key === "manha") {
      const ids = alunosComExtras.filter((a) => /[0-9]{1,2}:?[0-9]{0,2}/.test(a.horario_ida || "") && parseInt(a.horario_ida || "0") < 12).map((a) => a.id);
      return { resps: resps.filter((r) => (r.alunos_ids || []).some((id) => ids.includes(id))), label: "Alunos da manhã" };
    }
    if (key === "tarde") {
      const ids = alunosComExtras.filter((a) => parseInt(a.horario_ida || "0") >= 12).map((a) => a.id);
      return { resps: resps.filter((r) => (r.alunos_ids || []).some((id) => ids.includes(id))), label: "Alunos da tarde" };
    }
    if (key === "inadimplentes") {
      const ids = alunosComExtras.filter((a) => a.status_mensalidade === "atrasado" || a.status_mensalidade === "pendente").map((a) => a.id);
      return { resps: resps.filter((r) => (r.alunos_ids || []).some((id) => ids.includes(id))), label: "Inadimplentes" };
    }
    return { resps, label: "Todos" };
  };

  const enviarGrupo = () => {
    const grupo = respsPorFiltro(filtroGrupo);
    if (grupo.resps.length === 0) { toast.error("Nenhum responsável encontrado neste grupo."); return; }
    setGrupoSel(grupo);
    setSenderOpen(true);
  };

  const variaveisInfo = useMemo(() => VARIAVEIS_DISPONIVEIS, []);
  const enviosHoje = hist.filter((h) => new Date(h.created_at).toDateString() === new Date().toDateString());

  // Mais utilizadas: top 5 nomes do histórico
  const maisUsadasNomes = useMemo(() => {
    const cnt = new Map<string, number>();
    hist.forEach((h) => { if (h.mensagem_nome) cnt.set(h.mensagem_nome, (cnt.get(h.mensagem_nome) || 0) + 1); });
    return [...cnt.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([n]) => n);
  }, [hist]);

  // Filtro: busca + categoria
  const filtradas = useMemo(() => {
    const q = busca.trim().toLowerCase();
    let list = msgs;
    if (catFiltro === "favoritas") list = list.filter((m) => m.favorito);
    else if (catFiltro === "mais") list = list.filter((m) => maisUsadasNomes.includes(m.nome))
      .sort((a, b) => maisUsadasNomes.indexOf(a.nome) - maisUsadasNomes.indexOf(b.nome));
    else if (catFiltro !== "todas") list = list.filter((m) => (m.categoria || "Geral") === catFiltro);
    if (q) list = list.filter((m) =>
      m.nome.toLowerCase().includes(q) ||
      m.texto.toLowerCase().includes(q) ||
      (m.categoria || "").toLowerCase().includes(q) ||
      m.emoji.includes(q)
    );
    return list;
  }, [msgs, busca, catFiltro, maisUsadasNomes]);

  const grupos = useMemo(() => {
    if (catFiltro !== "todas" || busca) return null;
    const out: Array<{ cat: string; label: string; items: Mensagem[] }> = [];
    if (maisUsadasNomes.length) {
      const items = msgs.filter((m) => maisUsadasNomes.includes(m.nome))
        .sort((a, b) => maisUsadasNomes.indexOf(a.nome) - maisUsadasNomes.indexOf(b.nome));
      if (items.length) out.push({ cat: "mais", label: "🔥 Mais utilizadas", items });
    }
    const favs = msgs.filter((m) => m.favorito);
    if (favs.length) out.push({ cat: "fav", label: "⭐ Favoritas", items: favs });
    for (const c of CATEGORIAS) {
      const items = msgs.filter((m) => (m.categoria || "Geral") === c.id);
      if (items.length) out.push({ cat: c.id, label: c.label, items });
    }
    const outras = msgs.filter((m) => !CATEGORIAS.find((c) => c.id === (m.categoria || "Geral")));
    if (outras.length) out.push({ cat: "outras", label: "📝 Outras", items: outras });
    return out;
  }, [msgs, maisUsadasNomes, catFiltro, busca]);

  const dismissWelcome = () => {
    localStorage.setItem(WELCOME_KEY, "1");
    setWelcomeOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">Central de Mensagens 💬</h1>
          <p className="text-sm text-muted-foreground">Biblioteca pronta, envios em grupo e histórico — tudo num lugar.</p>
        </div>
        <Button onClick={() => setMassOpen(true)} className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold shadow-md">
          <Megaphone className="mr-2 h-4 w-4" /> 📢 Comunicação em Massa
        </Button>
      </div>

      <Tabs value={aba} onValueChange={setAba}>
        <TabsList>
          <TabsTrigger value="biblioteca"><MessageCircle className="mr-2 h-4 w-4" /> Biblioteca</TabsTrigger>
          <TabsTrigger value="grupo"><Users className="mr-2 h-4 w-4" /> Enviar em grupo</TabsTrigger>
          <TabsTrigger value="historico"><History className="mr-2 h-4 w-4" /> Histórico</TabsTrigger>
        </TabsList>

        <TabsContent value="biblioteca" className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm text-muted-foreground">{msgs.length} mensagem(ns) na biblioteca.</p>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" onClick={() => setPacoteOpen(true)}>
                <Package className="mr-2 h-4 w-4" /> Adicionar pacote pronto
              </Button>
              <Button onClick={openNew} className="bg-primary text-primary-foreground font-bold">
                <Plus className="mr-2 h-4 w-4" /> Nova mensagem
              </Button>
            </div>
          </div>

          {/* Busca */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input className="pl-9" placeholder="Buscar por nome, categoria, texto ou emoji..." value={busca} onChange={(e) => setBusca(e.target.value)} />
          </div>

          {/* Chips de categoria */}
          <div className="flex flex-wrap gap-1.5">
            {[
              { id: "todas", label: "Todas" },
              { id: "favoritas", label: "⭐ Favoritas" },
              { id: "mais", label: "🔥 Mais utilizadas" },
              ...CATEGORIAS.map((c) => ({ id: c.id, label: c.label })),
            ].map((c) => (
              <button key={c.id} type="button" onClick={() => setCatFiltro(c.id)}
                className={`rounded-full border px-3 py-1 text-xs font-semibold transition-colors ${catFiltro === c.id ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-accent/40"}`}>
                {c.label}
              </button>
            ))}
          </div>

          <Card className="p-3 bg-accent/20 border-accent/40">
            <p className="text-xs font-semibold mb-2">💡 Variáveis disponíveis (clique para copiar):</p>
            <div className="flex flex-wrap gap-1.5">
              {variaveisInfo.map((v) => (
                <button key={v.key} onClick={() => { navigator.clipboard.writeText(v.key); toast.success(`${v.key} copiada!`); }}
                  className="rounded-full bg-background border px-2.5 py-1 text-xs font-mono hover:bg-accent/40">
                  {v.key}
                </button>
              ))}
            </div>
          </Card>

          {loading ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">Carregando...</Card>
          ) : msgs.length === 0 ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">
              Nenhuma mensagem ainda. Use "Adicionar pacote pronto" ou crie uma nova.
            </Card>
          ) : grupos ? (
            <div className="space-y-5">
              {grupos.map((g) => (
                <section key={g.cat} className="space-y-2">
                  <h3 className="text-sm font-bold text-muted-foreground">{g.label} <span className="text-xs font-normal">({g.items.length})</span></h3>
                  <div className="grid gap-2">
                    {g.items.map((m) => <MensagemRow key={m.id} m={m} onEdit={openEdit} onDel={excluir} onFav={favoritar} onDup={duplicar} />)}
                  </div>
                </section>
              ))}
            </div>
          ) : filtradas.length === 0 ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">Nenhuma mensagem encontrada.</Card>
          ) : (
            <div className="grid gap-2">
              {filtradas.map((m) => <MensagemRow key={m.id} m={m} onEdit={openEdit} onDel={excluir} onFav={favoritar} onDup={duplicar} />)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="grupo" className="space-y-4">
          <Card className="p-6 space-y-4">
            <div>
              <h2 className="font-bold">📢 Enviar para vários responsáveis</h2>
              <p className="text-sm text-muted-foreground">Ideal para chuva, trânsito, feriado ou aviso geral.</p>
            </div>
            <div className="space-y-2">
              <Label>Selecione o grupo</Label>
              <Select value={filtroGrupo} onValueChange={setFiltroGrupo}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">📢 Todos os responsáveis ({resps.length})</SelectItem>
                  <SelectItem value="manha">🌅 Apenas alunos da manhã</SelectItem>
                  <SelectItem value="tarde">🌇 Apenas alunos da tarde</SelectItem>
                  <SelectItem value="inadimplentes">💰 Apenas inadimplentes</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={enviarGrupo} className="w-full bg-success text-success-foreground hover:bg-success/90 font-bold">
              <Send className="mr-2 h-4 w-4" /> Escolher mensagem e enviar
            </Button>
            <p className="text-xs text-muted-foreground">
              ⚠️ O WhatsApp abrirá uma aba por responsável. Em alguns navegadores você precisa permitir pop-ups.
            </p>
          </Card>
        </TabsContent>

        <TabsContent value="historico" className="space-y-3">
          <p className="text-sm text-muted-foreground">{enviosHoje.length} envio(s) hoje · {hist.length} no total.</p>
          {hist.length === 0 ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">Nenhum envio ainda.</Card>
          ) : (
            <div className="grid gap-2">
              {hist.map((h) => (
                <Card key={h.id} className="p-3">
                  <div className="flex items-start gap-3">
                    <div className="text-xl">{h.emoji}</div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2 text-sm">
                        <span className="font-semibold">{h.mensagem_nome || "Personalizada"}</span>
                        <span className="text-muted-foreground">para {h.destinatario}</span>
                        <Badge variant="outline" className="text-[10px]">{h.canal === "email" ? "✉️ E-mail" : "💬 WhatsApp"}</Badge>
                        <Badge variant="outline" className="text-[10px]">{h.status === "enviado" ? "✅ Enviado" : h.status}</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground line-clamp-2">{h.texto}</div>
                      <div className="text-[10px] text-muted-foreground mt-1">
                        {new Date(h.created_at).toLocaleString("pt-BR")}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Editor */}
      <Dialog open={edOpen} onOpenChange={setEdOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{edId ? "Editar mensagem" : "Nova mensagem"}</DialogTitle>
            <DialogDescription>Use variáveis como {"{aluno}"}, {"{responsavel}"}, {"{pix}"}.</DialogDescription>
          </DialogHeader>
          <form onSubmit={salvar} className="space-y-3">
            <div className="grid grid-cols-[80px_1fr] gap-3">
              <div>
                <Label>Emoji</Label>
                <Select value={form.emoji} onValueChange={(v) => setForm({ ...form, emoji: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {EMOJIS.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="nome">Nome da mensagem *</Label>
                <Input id="nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex: Chegada, Cobrança..." autoFocus />
              </div>
            </div>
            <div>
              <Label>Categoria</Label>
              <Select value={form.categoria} onValueChange={(v) => setForm({ ...form, categoria: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIAS.map((c) => <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>)}
                  <SelectItem value="Geral">📝 Geral</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="texto">Texto *</Label>
              <Textarea id="texto" rows={6} value={form.texto} onChange={(e) => setForm({ ...form, texto: e.target.value })}
                placeholder="Bom dia, {responsavel}! Estou chegando para buscar {aluno} 🚐" />
              <div className="mt-2 flex flex-wrap gap-1.5">
                {variaveisInfo.map((v) => (
                  <button type="button" key={v.key}
                    onClick={() => setForm((f) => ({ ...f, texto: f.texto + " " + v.key }))}
                    className="rounded-full border bg-background px-2 py-0.5 text-[10px] font-mono hover:bg-accent/40">
                    {v.key}
                  </button>
                ))}
              </div>
            </div>
            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setEdOpen(false)}>Cancelar</Button>
              <Button type="submit" className="bg-primary font-bold">Salvar</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Importar pacotes */}
      <Dialog open={pacoteOpen} onOpenChange={setPacoteOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>✨ Adicionar pacote pronto</DialogTitle>
            <DialogDescription>Selecione os pacotes que deseja importar para sua biblioteca.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            {CATEGORIAS.map((c) => {
              const total = PACOTES_MENSAGENS[c.id].length;
              const checked = !!pacotesSel[c.id];
              return (
                <label key={c.id} className="flex items-start gap-3 rounded-lg border p-3 cursor-pointer hover:bg-accent/30">
                  <Checkbox checked={checked} onCheckedChange={(v) => setPacotesSel((p) => ({ ...p, [c.id]: !!v }))} className="mt-0.5" />
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold text-sm">{c.label}</div>
                    <div className="text-xs text-muted-foreground">{total} mensagens prontas</div>
                  </div>
                </label>
              );
            })}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setPacoteOpen(false)}>Cancelar</Button>
            <Button onClick={importarPacotes} className="bg-primary font-bold">
              <Package className="mr-2 h-4 w-4" /> Importar mensagens
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Boas-vindas */}
      <Dialog open={welcomeOpen} onOpenChange={(v) => { if (!v) dismissWelcome(); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-accent" /> Bem-vindo à Central de Mensagens!</DialogTitle>
            <DialogDescription>
              Preparamos uma biblioteca com mensagens profissionais organizadas por categoria
              (Transporte, Financeiro, Escola, Relacionamento e Emergências) para facilitar
              sua comunicação com as famílias.
              <br /><br />
              Você pode <b>utilizar, editar, duplicar, favoritar ou excluir</b> qualquer
              mensagem quando quiser. As variáveis como <code className="text-xs">{"{aluno}"}</code>
              e <code className="text-xs">{"{responsavel}"}</code> são preenchidas automaticamente
              no envio. 💙
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button onClick={dismissWelcome} className="bg-primary font-bold w-full">
              <X className="mr-2 h-4 w-4" /> Começar a usar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {grupoSel && (
        <WhatsAppSender
          open={senderOpen}
          onOpenChange={(v) => { setSenderOpen(v); if (!v) { setGrupoSel(null); void load(); } }}
          user={user}
          responsaveis={grupoSel.resps}
          alunos={alunos}
          grupo
          grupoLabel={grupoSel.label}
        />
      )}

      <MassCommDialog
        open={massOpen}
        onOpenChange={(v) => { setMassOpen(v); if (!v) void load(); }}
        user={user}
        responsaveis={resps}
        alunos={alunos}
      />
    </div>
  );
}

function MensagemRow({ m, onEdit, onDel, onFav, onDup }: {
  m: Mensagem;
  onEdit: (m: Mensagem) => void;
  onDel: (id: string) => void;
  onFav: (m: Mensagem) => void;
  onDup: (m: Mensagem) => void;
}) {
  return (
    <Card className="p-4">
      <div className="flex items-start gap-3">
        <div className="text-2xl">{m.emoji}</div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2 font-semibold">
            {m.nome}
            {m.favorito && <Star className="h-3.5 w-3.5 fill-accent text-accent" />}
            {m.categoria && <Badge variant="outline" className="text-[10px] font-normal">{m.categoria}</Badge>}
          </div>
          <div className="mt-1 text-sm text-muted-foreground whitespace-pre-wrap">{m.texto}</div>
        </div>
        <div className="flex flex-wrap gap-1 justify-end">
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onFav(m)} aria-label="Favoritar">
            <Star className={`h-4 w-4 ${m.favorito ? "fill-accent text-accent" : ""}`} />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onDup(m)} aria-label="Duplicar"><Copy className="h-3.5 w-3.5" /></Button>
          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onEdit(m)} aria-label="Editar"><Pencil className="h-3.5 w-3.5" /></Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" aria-label="Excluir"><Trash2 className="h-3.5 w-3.5" /></Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Excluir mensagem?</AlertDialogTitle>
                <AlertDialogDescription>"{m.nome}" será removida da biblioteca.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={() => onDel(m.id)}>Excluir</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </Card>
  );
}
