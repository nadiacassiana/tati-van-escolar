import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ChevronLeft, Loader2, MapPin, Route as RouteIcon, School, Timer } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  calcularDistancia,
  calcularDistanciaPorCoordenadas,
  type DistanciaResultado,
} from "@/lib/distancia.functions";

/** Coordenadas fixas de validação (formato lon, lat — o OSRM recebe longitude primeiro). */
const TESTE_ORIGEM = { lon: -46.7903, lat: -23.6754, label: "Rua Professor Gastão Ramos (teste)" };
const TESTE_DESTINO = { lon: -46.7027, lat: -23.6212, label: "Av. João Dias, 76 (teste)" };

export const Route = createFileRoute("/_authenticated/quilometragem")({
  head: () => ({
    meta: [
      { title: "Cálculo de distância — Tati Van" },
      { name: "description", content: "Consulte a distância por ruas entre a escola e a casa de um possível novo aluno." },
    ],
  }),
  component: QuilometragemPage,
});

function QuilometragemPage() {
  const [escolas, setEscolas] = useState<string[]>([]);
  const [escola, setEscola] = useState("");
  const [residencia, setResidencia] = useState("");
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<DistanciaResultado | null>(null);
  const run = useServerFn(calcularDistancia);
  const runCoords = useServerFn(calcularDistanciaPorCoordenadas);

  useEffect(() => {
    let ativo = true;
    void (async () => {
      const { data } = await supabase.from("alunos").select("escola").not("escola", "is", null);
      if (!ativo || !data) return;
      const nomes = Array.from(
        new Set(data.map((a: { escola: string | null }) => (a.escola || "").trim()).filter(Boolean)),
      ).sort((a, b) => a.localeCompare(b, "pt-BR"));
      setEscolas(nomes);
    })();
    return () => {
      ativo = false;
    };
  }, []);

  const calcular = async () => {
    setLoading(true);
    setResultado(null);
    try {
      const r = await run({ data: { origem: escola, destino: residencia } });
      setResultado(r);
    } catch (e) {
      toast.error("Não foi possível calcular", {
        description: e instanceof Error ? e.message : "Tente novamente em instantes.",
      });
    } finally {
      setLoading(false);
    }
  };

  const calcularComCoordenadasTeste = async () => {
    setLoading(true);
    setResultado(null);
    setEscola(TESTE_ORIGEM.label);
    setResidencia(TESTE_DESTINO.label);
    try {
      const r = await runCoords({ data: { origem: TESTE_ORIGEM, destino: TESTE_DESTINO } });
      setResultado(r);
    } catch (e) {
      toast.error("Não foi possível calcular", {
        description: e instanceof Error ? e.message : "Tente novamente em instantes.",
      });
    } finally {
      setLoading(false);
    }
  };


  const km = resultado ? resultado.distanciaKm.toLocaleString("pt-BR", { maximumFractionDigits: 1 }) : "";
  const min = resultado ? Math.max(1, Math.round(resultado.duracaoMin)) : 0;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" asChild>
          <Link to="/configuracoes">
            <ChevronLeft className="h-4 w-4" /> Voltar
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-2xl font-extrabold">📏 Cálculo de distância</h1>
        <p className="text-sm text-muted-foreground">
          Consulte a distância por ruas entre a escola e a casa de um possível novo aluno antes de incluí-lo na rota.
        </p>
      </div>

      <Card className="space-y-4 p-6" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="space-y-1.5">
          <Label htmlFor="escola" className="flex items-center gap-2">
            <School className="h-4 w-4" /> Endereço da escola
          </Label>
          <Input
            id="escola"
            list="escolas-cadastradas"
            value={escola}
            onChange={(e) => setEscola(e.target.value)}
            placeholder="Ex.: Escola Municipal João Silva, Rua das Flores, 100, São Paulo - SP"
          />
          <datalist id="escolas-cadastradas">
            {escolas.map((e) => (
              <option key={e} value={e} />
            ))}
          </datalist>
          {escolas.length > 0 && (
            <p className="text-xs text-muted-foreground">
              Você pode escolher uma escola já cadastrada e completar com a rua e a cidade.
            </p>
          )}
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="residencia" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" /> Endereço da residência do aluno
          </Label>
          <Input
            id="residencia"
            value={residencia}
            onChange={(e) => setResidencia(e.target.value)}
            placeholder="Ex.: Rua Bela Vista, 250, Bairro Centro, São Paulo - SP"
          />
        </div>

        <Button className="w-full" onClick={calcular} disabled={loading || !escola.trim() || !residencia.trim()}>
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RouteIcon className="mr-2 h-4 w-4" />}
          {loading ? "Calculando..." : "Calcular distância"}
        </Button>

        <Button variant="outline" className="w-full" onClick={calcularComCoordenadasTeste} disabled={loading}>
          <MapPin className="mr-2 h-4 w-4" /> Usar coordenadas reais de teste
        </Button>
        <p className="text-xs text-muted-foreground">
          Ignora a busca por endereço e envia as coordenadas fixas (Rua Professor Gastão Ramos → Av. João Dias, 76)
          direto para o serviço de rotas.
        </p>
      </Card>

      {resultado && (
        <Card className="p-6" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="text-sm font-semibold text-muted-foreground">Distância aproximada</div>
          <div className="mt-1 flex flex-wrap items-baseline gap-3">
            <span className="text-4xl font-extrabold text-primary">{km} km</span>
            <span className="flex items-center gap-1 text-sm font-semibold text-muted-foreground">
              <Timer className="h-4 w-4" /> aproximadamente {min} {min === 1 ? "minuto" : "minutos"}
            </span>
          </div>
          <div className="mt-4 space-y-1 rounded-xl bg-muted/40 p-3 text-xs text-muted-foreground">
            <div>
              🏫 {resultado.origem.label}{" "}
              <span className="opacity-70">
                ({resultado.origem.lat.toFixed(6)}, {resultado.origem.lon.toFixed(6)} • {resultado.origem.provedor})
              </span>
            </div>
            {resultado.origem.alternativaLabel && (
              <div className="opacity-70">↳ outro provedor sugeriu: {resultado.origem.alternativaLabel}</div>
            )}
            <div>
              🏠 {resultado.destino.label}{" "}
              <span className="opacity-70">
                ({resultado.destino.lat.toFixed(6)}, {resultado.destino.lon.toFixed(6)} • {resultado.destino.provedor})
              </span>
            </div>
            {resultado.destino.alternativaLabel && (
              <div className="opacity-70">↳ outro provedor sugeriu: {resultado.destino.alternativaLabel}</div>
            )}
            <div className="pt-1">
              Rota usada: {resultado.provedorRota}
              {resultado.osrm && ` • OSRM: ${resultado.osrm.distanciaKm.toFixed(2)} km / ${Math.round(resultado.osrm.duracaoMin)} min`}
              {resultado.valhalla && ` • Valhalla: ${resultado.valhalla.distanciaKm.toFixed(2)} km / ${Math.round(resultado.valhalla.duracaoMin)} min`}
              {` • linha reta: ${resultado.linhaRetaKm.toFixed(2)} km`}
            </div>
            {resultado.avisos.map((a) => (
              <div key={a} className="pt-1 font-semibold text-destructive">⚠️ {a}</div>
            ))}
            <div className="pt-1">Trajeto de ida de carro, calculado por ruas. Os valores são aproximados.</div>
          </div>
        </Card>
      )}
    </div>
  );
}
