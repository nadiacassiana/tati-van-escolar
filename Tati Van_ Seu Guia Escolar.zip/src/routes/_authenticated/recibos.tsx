import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { Search, Star, FileText, Trash2, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { formatBRL } from "@/lib/format";
import { formatDateBR, formatMesReferencia, METODO_LABEL, type Recibo } from "@/lib/recibo";
import { getMotoristaFromUser } from "@/lib/whatsapp";
import { useVanLogo } from "@/lib/logo-store";
import { ReciboActions } from "@/components/recibo-actions";
import { estornarRecebimento } from "@/lib/estorno";

export const Route = createFileRoute("/_authenticated/recibos")({
  head: () => ({ meta: [{ title: "Recibos — Tati Van" }] }),
  component: RecibosPage,
});

type Filtro = "hoje" | "semana" | "mes" | "ano" | "todos" | "favoritos";

function RecibosPage() {
  const { user } = Route.useRouteContext();
  useVanLogo();
  const motorista = getMotoristaFromUser(user);
  const [recibos, setRecibos] = useState<Recibo[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [filtro, setFiltro] = useState<Filtro>("mes");
  const [open, setOpen] = useState(false);
  const [target, setTarget] = useState<Recibo | null>(null);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("recibos").select("*").order("created_at", { ascending: false });
    setRecibos(((data as unknown) as Recibo[]) || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const openRecibo = (r: Recibo) => { setTarget(r); setOpen(true); };

  const handleDelete = async (r: Recibo) => {
    if (!confirm(`Excluir o recibo ${r.numero}? Essa ação não pode ser desfeita.`)) return;
    const { error } = await supabase.from("recibos").delete().eq("id", r.id);
    if (error) return toast.error("Erro ao excluir.");
    toast.success("Recibo excluído.");
    load();
  };

  const handleEstorno = async (r: Recibo) => {
    if (!confirm(`Deseja realmente desfazer este recebimento (${r.numero})? A cobrança voltará para em aberto.`)) return;
    const res = await estornarRecebimento(r);
    if (!res.ok) return toast.error(res.erro || "Não foi possível desfazer.");
    toast.success("Recebimento desfeito. A cobrança voltou para em aberto. ↩️");
    load();
  };

  const filtered = useMemo(() => {
    const now = new Date();
    const today0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const week0 = today0 - 6 * 86400000;
    const month0 = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    const year0 = new Date(now.getFullYear(), 0, 1).getTime();
    return recibos.filter((r) => {
      if (filtro === "favoritos" && !r.favorito) return false;
      const ts = new Date(r.created_at).getTime();
      if (filtro === "hoje" && ts < today0) return false;
      if (filtro === "semana" && ts < week0) return false;
      if (filtro === "mes" && ts < month0) return false;
      if (filtro === "ano" && ts < year0) return false;
      if (q.trim()) {
        const needle = q.toLowerCase();
        const hay = [r.numero, r.aluno_nome, r.responsavel_nome, r.mes_referencia, formatMesReferencia(r.mes_referencia)].join(" ").toLowerCase();
        if (!hay.includes(needle)) return false;
      }
      return true;
    });
  }, [recibos, filtro, q]);

  const validos = recibos.filter((r) => !r.estornado_em);
  const totalMes = validos.filter((r) => {
    const d = new Date(r.created_at);
    const n = new Date();
    return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear();
  }).length;
  const totalAno = validos.filter((r) => new Date(r.created_at).getFullYear() === new Date().getFullYear()).length;
  const valorFiltrado = filtered.reduce((s, r) => s + (r.estornado_em ? 0 : Number(r.valor)), 0);

  const filtros: { v: Filtro; label: string }[] = [
    { v: "hoje", label: "Hoje" },
    { v: "semana", label: "Esta semana" },
    { v: "mes", label: "Este mês" },
    { v: "ano", label: "Este ano" },
    { v: "todos", label: "Todos" },
    { v: "favoritos", label: "⭐ Favoritos" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">📄 Histórico de Recibos</h1>
        <p className="text-sm text-muted-foreground">Visualize, reenvie e imprima recibos quando precisar.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="p-5"><div className="text-xs uppercase tracking-wider text-muted-foreground">Recibos no mês</div><div className="mt-1 text-2xl font-extrabold">{totalMes}</div></Card>
        <Card className="p-5"><div className="text-xs uppercase tracking-wider text-muted-foreground">No ano</div><div className="mt-1 text-2xl font-extrabold">{totalAno}</div></Card>
        <Card className="p-5"><div className="text-xs uppercase tracking-wider text-muted-foreground">Total geral</div><div className="mt-1 text-2xl font-extrabold">{validos.length}</div></Card>
      </div>

      <Card className="p-4" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por aluno, responsável, número ou mês" className="pl-9" />
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {filtros.map((f) => (
            <Button key={f.v} size="sm" variant={filtro === f.v ? "default" : "outline"} onClick={() => setFiltro(f.v)}>
              {f.label}
            </Button>
          ))}
        </div>
      </Card>

      <Card className="overflow-hidden" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="flex items-center justify-between border-b px-5 py-3">
          <div className="font-bold">{filtered.length} recibo{filtered.length === 1 ? "" : "s"}</div>
          <div className="text-sm font-bold text-success">R$ {formatBRL(valorFiltrado)}</div>
        </div>
        {loading ? (
          <div className="p-6 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            Nenhum recibo por aqui ainda. Ao registrar um pagamento no Financeiro, o recibo aparece automaticamente.
          </div>
        ) : (
          <ul className="divide-y">
            {filtered.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-bold">{r.numero}</span>
                    {r.favorito && <Star className="h-3 w-3 fill-warning text-warning" />}
                    <Badge variant="outline" className="bg-primary/10 text-primary">{formatMesReferencia(r.mes_referencia)}</Badge>
                    {r.metodo && <Badge variant="outline">{METODO_LABEL[r.metodo] || r.metodo}</Badge>}
                    {r.estornado_em && (
                      <Badge variant="outline" className="border-destructive/40 bg-destructive/10 text-destructive">↩️ Estornado</Badge>
                    )}
                    {r.envios && r.envios.length > 0 && (
                      <Badge variant="outline" className="bg-success/15 text-success border-success/30">Enviado</Badge>
                    )}
                  </div>
                  <div className="mt-1 text-sm font-semibold">{r.aluno_nome}</div>
                  <div className="text-xs text-muted-foreground">
                    {r.responsavel_nome || "—"} • Pago em {formatDateBR(r.data_pagamento)}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <div className={`font-extrabold ${r.estornado_em ? "text-muted-foreground line-through" : ""}`}>R$ {formatBRL(Number(r.valor))}</div>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => openRecibo(r)}>
                    <FileText className="mr-1 h-3 w-3" /> Abrir
                  </Button>
                  {!r.estornado_em && (
                    <Button size="icon" variant="ghost" onClick={() => handleEstorno(r)} title="Desfazer recebimento">
                      <Undo2 className="h-4 w-4 text-destructive" />
                    </Button>
                  )}
                  <Button size="icon" variant="ghost" onClick={() => handleDelete(r)} title="Excluir">
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <ReciboActions open={open} onOpenChange={setOpen} recibo={target} motorista={motorista} onChanged={load} />
    </div>
  );
}
