import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle,
} from "@/components/ui/sheet";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { trackEvent } from "@/lib/track-event";
import {
  MessageCircle, Phone, Mail, MapPin, Plus, Pencil, Trash2, ShieldAlert, UserCheck,
  Search, FileText, DollarSign, History, User2, AlertCircle, CheckCircle2, Filter, Eye,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { WhatsAppSender, type SenderAluno } from "@/components/whatsapp-sender";
import { formatBRL } from "@/lib/format";
import { ArchiveDeleteActions } from "@/components/archive-delete-actions";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PreCadastroAuditoria, onlyDigitsPhone, usePreCadastrosAprovados } from "@/components/pre-cadastro-auditoria";


export const Route = createFileRoute("/_authenticated/responsaveis")({
  head: () => ({ meta: [{ title: "Responsáveis — Tati Van" }] }),
  component: ResponsaveisPage,
});

type Responsavel = {
  id: string;
  nome: string;
  telefone: string;
  whatsapp: string;
  email: string | null;
  endereco: string;
  observacoes: string;
  pessoas_autorizadas: string | null;
  telefone_emergencia: string | null;
  alunos_ids: string[];
  created_at?: string;
  arquivado_em?: string | null;
};


type AlunoMini = SenderAluno & { created_at?: string };
type ContratoMini = {
  id: string; aluno_id: string | null; aluno_nome: string; status: string; created_at: string;
  enviado_whatsapp_em: string | null; enviado_email_em: string | null; assinado_em: string | null;
  arquivado_em: string | null; data_termino: string | null;
};
type PagamentoMini = { id: string; aluno_id: string; valor: number; data_pagamento: string; mes_referencia: string };
type MensagemMini = { id: string; responsavel_id: string | null; mensagem_nome: string; emoji: string; created_at: string };

type TimelineEvent = {
  id: string;
  date: string; // ISO
  emoji: string;
  title: string;
  detail?: string;
  category: "alunos" | "contratos" | "financeiro" | "mensagens" | "transporte" | "alteracoes";
};

const emptyForm = {
  nome: "",
  telefone: "",
  email: "",
  endereco: "",
  observacoes: "",
  pessoas_autorizadas: "",
  telefone_emergencia: "",
  alunos_ids: [] as string[],
};

function getCompleteness(r: Responsavel) {
  const checks = [
    { key: "nome", ok: !!r.nome.trim(), label: "Nome" },
    { key: "tel", ok: !!(r.telefone || r.whatsapp), label: "Telefone / WhatsApp" },
    { key: "email", ok: !!r.email, label: "E-mail" },
    { key: "endereco", ok: !!r.endereco?.trim(), label: "Endereço" },
    { key: "aluno", ok: (r.alunos_ids || []).length > 0, label: "Aluno vinculado" },
    { key: "autorizados", ok: !!r.pessoas_autorizadas?.trim(), label: "Pessoas autorizadas" },
    { key: "emergencia", ok: !!r.telefone_emergencia?.trim(), label: "Telefone de emergência" },
  ];
  const done = checks.filter((c) => c.ok).length;
  const total = checks.length;
  const missing = checks.filter((c) => !c.ok).map((c) => c.label);
  let status: "completo" | "parcial" | "incompleto" = "incompleto";
  if (done === total) status = "completo";
  else if (done >= Math.ceil(total * 0.6)) status = "parcial";
  return { status, done, total, missing };
}

function ResponsaveisPage() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const [lista, setLista] = useState<Responsavel[]>([]);
  const [alunosOpts, setAlunosOpts] = useState<AlunoMini[]>([]);
  const [contratos, setContratos] = useState<ContratoMini[]>([]);
  const [pagamentos, setPagamentos] = useState<PagamentoMini[]>([]);
  const [mensagens, setMensagens] = useState<MensagemMini[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [busca, setBusca] = useState("");
  const [view, setView] = useState<"ativos" | "arquivados">("ativos");


  const [senderOpen, setSenderOpen] = useState(false);
  const [senderResp, setSenderResp] = useState<Responsavel | null>(null);

  const [noEmailDialog, setNoEmailDialog] = useState<Responsavel | null>(null);
  const [fichaResp, setFichaResp] = useState<Responsavel | null>(null);
  const fichasPublicas = usePreCadastrosAprovados();
  const [tlFiltro, setTlFiltro] = useState<TimelineEvent["category"] | "todos">("todos");

  const focusEmail = useRef(false);
  const emailInputRef = useRef<HTMLInputElement>(null);

  const load = async () => {
    setLoading(true);
    const [rs, as, cs, ps, ms] = await Promise.all([
      supabase.from("responsaveis").select("*").order("created_at", { ascending: false }),
      supabase.from("alunos").select("id, nome, escola, mensalidade, vencimento, created_at").order("nome"),
      supabase.from("contratos").select("id, aluno_id, aluno_nome, status, created_at, enviado_whatsapp_em, enviado_email_em, assinado_em, arquivado_em, data_termino"),
      supabase.from("pagamentos").select("id, aluno_id, valor, data_pagamento, mes_referencia"),
      supabase.from("mensagens_historico").select("id, responsavel_id, mensagem_nome, emoji, created_at").order("created_at", { ascending: false }),
    ]);
    setLista((rs.data as unknown as Responsavel[]) || []);
    setAlunosOpts((as.data as AlunoMini[]) || []);
    setContratos((cs.data as ContratoMini[]) || []);
    setPagamentos((ps.data as PagamentoMini[]) || []);
    setMensagens((ms.data as MensagemMini[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditingId(null); setForm(emptyForm); setOpen(true); };
  const openEdit = (r: Responsavel, opts?: { focusEmail?: boolean }) => {
    setEditingId(r.id);
    setForm({
      nome: r.nome,
      telefone: r.telefone,
      email: r.email || "",
      endereco: r.endereco,
      observacoes: r.observacoes,
      pessoas_autorizadas: r.pessoas_autorizadas || "",
      telefone_emergencia: r.telefone_emergencia || "",
      alunos_ids: r.alunos_ids || [],
    });
    focusEmail.current = !!opts?.focusEmail;
    setOpen(true);
  };

  useEffect(() => {
    if (open && focusEmail.current) {
      setTimeout(() => { emailInputRef.current?.focus(); emailInputRef.current?.scrollIntoView({ block: "center" }); }, 100);
      focusEmail.current = false;
    }
  }, [open]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome.trim()) { toast.error("Informe o nome do responsável."); return; }
    const wpp = form.telefone.replace(/\D/g, "");
    const emailTrim = form.email.trim().toLowerCase();
    if (!wpp && !emailTrim) {
      toast.error("É necessário informar pelo menos um meio de contato (WhatsApp ou e-mail).");
      return;
    }
    if (emailTrim && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailTrim)) {
      toast.error("E-mail inválido.");
      return;
    }
    if (!editingId) {
      const dupTel = wpp ? lista.find((r) => (r.telefone || "").replace(/\D/g, "") === wpp || r.whatsapp === wpp) : null;
      const dupEmail = emailTrim ? lista.find((r) => (r.email || "").toLowerCase() === emailTrim) : null;
      const dup = dupTel || dupEmail;
      if (dup) {
        const ok = window.confirm(`Já existe um responsável com essas informações: ${dup.nome}.\n\nClique OK para criar mesmo assim ou Cancelar para abrir o existente.`);
        if (!ok) { openEdit(dup); return; }
      }
    }
    setSaving(true);
    const payload = {
      nome: form.nome.trim(),
      telefone: form.telefone,
      whatsapp: wpp,
      email: emailTrim || null,
      endereco: form.endereco,
      observacoes: form.observacoes,
      pessoas_autorizadas: form.pessoas_autorizadas || null,
      telefone_emergencia: form.telefone_emergencia || null,
      alunos_ids: form.alunos_ids,
    };
    if (editingId) {
      const { error } = await supabase.from("responsaveis").update(payload).eq("id", editingId);
      setSaving(false);
      if (error) return toast.error("Erro ao salvar.");
      toast.success("Responsável atualizado!");
    } else {
      const { error } = await supabase.from("responsaveis").insert({ ...payload, user_id: user.id });
      setSaving(false);
      if (error) return toast.error("Erro ao cadastrar.");
      trackEvent("responsavel_cadastrado", `cadastrou ${payload.nome || "responsável"}`);
      toast.success("Responsável cadastrado!");
    }
    setOpen(false);
    load();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("responsaveis").delete().eq("id", id);
    if (error) return toast.error("Erro ao excluir.");
    toast.success("Responsável excluído definitivamente.");
    setLista((p) => p.filter((r) => r.id !== id));
  };

  const handleArchive = async (r: Responsavel) => {
    const now = new Date().toISOString();
    const { error } = await supabase.from("responsaveis").update({ arquivado_em: now } as never).eq("id", r.id);
    if (error) return toast.error("Não foi possível arquivar.");
    setLista((p) => p.map((x) => (x.id === r.id ? { ...x, arquivado_em: now } : x)));
    toast.success(`${r.nome} foi arquivado. Histórico preservado.`);
  };

  const handleRestore = async (r: Responsavel) => {
    const { error } = await supabase.from("responsaveis").update({ arquivado_em: null } as never).eq("id", r.id);
    if (error) return toast.error("Não foi possível restaurar.");
    setLista((p) => p.map((x) => (x.id === r.id ? { ...x, arquivado_em: null } : x)));
    toast.success(`${r.nome} foi restaurado.`);
  };

  const historyCount = (r: Responsavel) => {
    const c = contratos.filter((c) => c.aluno_id && r.alunos_ids.includes(c.aluno_id)).length;
    const p = pagamentos.filter((p) => r.alunos_ids.includes(p.aluno_id)).length;
    const m = mensagens.filter((m) => m.responsavel_id === r.id).length;
    return c + p + m;
  };


  const filhosNomes = (ids: string[]) =>
    alunosOpts.filter((a) => ids.includes(a.id)).map((a) => a.nome);

  const toggleAluno = (id: string) => {
    setForm((f) => ({
      ...f,
      alunos_ids: f.alunos_ids.includes(id) ? f.alunos_ids.filter((x) => x !== id) : [...f.alunos_ids, id],
    }));
  };

  const abrirWhats = (r: Responsavel) => { setSenderResp(r); setSenderOpen(true); };

  const abrirEmail = (r: Responsavel) => {
    if (!r.email) {
      setNoEmailDialog(r);
      return;
    }
    const subject = encodeURIComponent("Comunicado — Tati Van Escolar");
    const body = encodeURIComponent(`Olá, ${r.nome}.\n\n`);
    window.location.href = `mailto:${r.email}?subject=${subject}&body=${body}`;
  };

  // Resumo por responsável
  const resumoDe = (r: Responsavel) => {
    const alunos = alunosOpts.filter((a) => r.alunos_ids.includes(a.id));
    const mensalidadeTotal = alunos.reduce((s, a) => s + (Number(a.mensalidade) || 0), 0);
    const contratosResp = contratos.filter((c) => c.aluno_id && r.alunos_ids.includes(c.aluno_id));
    const contratosAtivos = contratosResp.filter((c) => c.status !== "encerrado" && !c.arquivado_em).length;
    const hoje = new Date();
    const pendencias = alunos.filter((a) => {
      if (!a.vencimento || !a.mensalidade) return false;
      const ref = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, "0")}`;
      const pago = pagamentos.some((p) => p.aluno_id === a.id && p.mes_referencia === ref);
      return !pago && hoje.getDate() > a.vencimento;
    }).length;
    const ultMsg = mensagens.find((m) => m.responsavel_id === r.id);
    const pagosResp = pagamentos.filter((p) => r.alunos_ids.includes(p.aluno_id))
      .sort((a, b) => b.data_pagamento.localeCompare(a.data_pagamento));
    const ultPag = pagosResp[0];
    return { alunos, mensalidadeTotal, contratosAtivos, pendencias, ultMsg, ultPag };
  };

  // Linha do tempo derivada
  const timelineDe = (r: Responsavel): TimelineEvent[] => {
    const ev: TimelineEvent[] = [];
    const alunos = alunosOpts.filter((a) => r.alunos_ids.includes(a.id));
    for (const a of alunos) {
      if (a.created_at) ev.push({ id: `al-${a.id}`, date: a.created_at, emoji: "👦", title: `Aluno cadastrado: ${a.nome}`, category: "alunos" });
    }
    const contratosResp = contratos.filter((c) => c.aluno_id && r.alunos_ids.includes(c.aluno_id));
    for (const c of contratosResp) {
      ev.push({ id: `c-${c.id}`, date: c.created_at, emoji: "📄", title: `Contrato gerado — ${c.aluno_nome}`, category: "contratos" });
      if (c.enviado_whatsapp_em) ev.push({ id: `cw-${c.id}`, date: c.enviado_whatsapp_em, emoji: "📱", title: `Contrato enviado pelo WhatsApp — ${c.aluno_nome}`, category: "contratos" });
      if (c.enviado_email_em) ev.push({ id: `ce-${c.id}`, date: c.enviado_email_em, emoji: "📧", title: `Contrato enviado por e-mail — ${c.aluno_nome}`, category: "contratos" });
      if (c.assinado_em) ev.push({ id: `cs-${c.id}`, date: c.assinado_em, emoji: "✍️", title: `Contrato assinado — ${c.aluno_nome}`, category: "contratos" });
      if (c.arquivado_em) ev.push({ id: `ca-${c.id}`, date: c.arquivado_em, emoji: "📁", title: `Contrato arquivado — ${c.aluno_nome}`, category: "contratos" });
    }
    const pagosResp = pagamentos.filter((p) => r.alunos_ids.includes(p.aluno_id));
    for (const p of pagosResp) {
      const aluno = alunosOpts.find((a) => a.id === p.aluno_id);
      ev.push({ id: `p-${p.id}`, date: p.data_pagamento, emoji: "💰", title: `Mensalidade recebida — ${aluno?.nome ?? ""} (R$ ${formatBRL(p.valor)})`, detail: `Ref: ${p.mes_referencia}`, category: "financeiro" });
    }
    const msgsResp = mensagens.filter((m) => m.responsavel_id === r.id);
    for (const m of msgsResp) {
      ev.push({ id: `m-${m.id}`, date: m.created_at, emoji: m.emoji || "📱", title: `Mensagem enviada: ${m.mensagem_nome}`, category: "mensagens" });
    }
    return ev.sort((a, b) => b.date.localeCompare(a.date));
  };

  // Pesquisa inteligente
  const listaFiltrada = useMemo(() => {
    const q = busca.trim().toLowerCase();
    const byView = lista.filter((r) => (view === "arquivados" ? !!r.arquivado_em : !r.arquivado_em));
    if (!q) return byView;
    return byView.filter((r) => {
      const filhos = alunosOpts.filter((a) => r.alunos_ids.includes(a.id));
      const blob = [
        r.nome, r.telefone, r.whatsapp, r.email || "", r.endereco || "",
        ...filhos.map((a) => `${a.nome} ${a.escola || ""}`),
      ].join(" ").toLowerCase();
      return blob.includes(q);
    });
  }, [busca, lista, alunosOpts, view]);
  const totalAtivos = lista.filter((r) => !r.arquivado_em).length;
  const totalArquivados = lista.filter((r) => !!r.arquivado_em).length;


  const formatDate = (s: string) => new Date(s).toLocaleDateString("pt-BR");
  const formatDateTime = (s: string) => new Date(s).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">Responsáveis 👨‍👩‍👧</h1>
          <p className="text-sm text-muted-foreground">{totalAtivos} ativos · {totalArquivados} arquivados.</p>
        </div>
        <Button onClick={openCreate} className="bg-primary text-primary-foreground font-bold">
          <Plus className="mr-2 h-4 w-4" /> Novo responsável
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Tabs value={view} onValueChange={(v) => setView(v as "ativos" | "arquivados")}>
          <TabsList>
            <TabsTrigger value="ativos">Ativos ({totalAtivos})</TabsTrigger>
            <TabsTrigger value="arquivados">🗄️ Arquivados ({totalArquivados})</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="relative flex-1 min-w-[220px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-9" placeholder="Buscar por nome, aluno, escola, telefone, WhatsApp ou e-mail..." value={busca} onChange={(e) => setBusca(e.target.value)} />
        </div>
      </div>


      {loading ? (
        <Card className="p-6 text-center text-sm text-muted-foreground">Carregando...</Card>
      ) : listaFiltrada.length === 0 ? (
        <Card className="p-6 text-center text-sm text-muted-foreground">
          {lista.length === 0 ? "Nenhum responsável cadastrado. Clique em \"Novo responsável\" para começar." : "Nenhum resultado para a busca."}
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {listaFiltrada.map((r) => {
            const filhos = filhosNomes(r.alunos_ids);
            const comp = getCompleteness(r);
            const resumo = resumoDe(r);
            const alertChips: { icon: string; label: string }[] = [];
            if (!r.email) alertChips.push({ icon: "📧", label: "Falta e-mail" });
            if (!r.telefone && !r.whatsapp) alertChips.push({ icon: "📱", label: "Falta telefone" });
            if (!r.endereco) alertChips.push({ icon: "🏠", label: "Falta endereço" });
            if (r.alunos_ids.length === 0) alertChips.push({ icon: "👦", label: "Sem aluno vinculado" });
            return (
              <Card key={r.id} className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold truncate">{r.nome}</span>
                      <Badge
                        className={
                          comp.status === "completo" ? "bg-success/15 text-success border-success/30"
                          : comp.status === "parcial" ? "bg-accent/20 text-foreground border-accent/40"
                          : "bg-destructive/15 text-destructive border-destructive/30"
                        }
                        variant="outline"
                      >
                        {comp.status === "completo" ? "🟢 Completo" : comp.status === "parcial" ? "🟡 Parcial" : "🔴 Incompleto"}
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {filhos.length > 0 ? `Responsável por: ${filhos.join(", ")}` : "Sem alunos vinculados"}
                    </div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setFichaResp(r)} aria-label="Ficha">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(r)} aria-label="Editar">
                      <Pencil className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="mt-3 flex justify-end">
                  <ArchiveDeleteActions
                    compact
                    isArchived={!!r.arquivado_em}
                    hasHistory={historyCount(r) > 0}
                    historyLabel="contratos, mensalidades ou mensagens"
                    entityLabel="responsável"
                    entityName={r.nome}
                    onArchive={async () => { await handleArchive(r); }}
                    onRestore={async () => { await handleRestore(r); }}
                    onDelete={async () => { await handleDelete(r.id); }}
                  />
                </div>




                {alertChips.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {alertChips.map((c) => (
                      <span key={c.label} className="rounded-full bg-destructive/10 px-2 py-0.5 text-[11px] text-destructive">
                        {c.icon} {c.label}
                      </span>
                    ))}
                  </div>
                )}

                <div className="mt-3 space-y-1.5 text-sm">
                  {r.telefone && <div className="flex items-center gap-2 text-muted-foreground"><Phone className="h-3.5 w-3.5" /> {r.telefone}</div>}
                  {r.email && <div className="flex items-center gap-2 text-muted-foreground"><Mail className="h-3.5 w-3.5" /> {r.email}</div>}
                  {r.endereco && <div className="flex items-center gap-2 text-muted-foreground"><MapPin className="h-3.5 w-3.5" /> {r.endereco}</div>}
                  {r.telefone_emergencia && <div className="flex items-center gap-2 text-destructive"><ShieldAlert className="h-3.5 w-3.5" /> Emergência: {r.telefone_emergencia}</div>}
                  {r.pessoas_autorizadas && <div className="flex items-start gap-2 text-muted-foreground"><UserCheck className="mt-0.5 h-3.5 w-3.5" /> <span>Autorizados: {r.pessoas_autorizadas}</span></div>}
                </div>

                <div className="mt-3 grid grid-cols-2 gap-2 rounded-lg bg-secondary/40 p-2 text-[12px]">
                  <div>💰 <strong>R$ {formatBRL(resumo.mensalidadeTotal)}</strong> /mês</div>
                  <div>📄 {resumo.contratosAtivos} ativo(s)</div>
                  <div className={resumo.pendencias > 0 ? "text-destructive font-semibold" : ""}>⚠️ {resumo.pendencias} pendência(s)</div>
                  <div>💳 {resumo.ultPag ? formatDate(resumo.ultPag.data_pagamento) : "—"}</div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2">
                  {r.whatsapp && (
                    <Button onClick={() => abrirWhats(r)} className="bg-success text-success-foreground hover:bg-success/90 font-bold">
                      <MessageCircle className="mr-1 h-4 w-4" /> WhatsApp
                    </Button>
                  )}
                  <Button onClick={() => abrirEmail(r)} variant="outline" className="font-bold">
                    <Mail className="mr-1 h-4 w-4" /> E-mail
                  </Button>
                  <Button onClick={() => setFichaResp(r)} variant="outline" className="font-bold">
                    <History className="mr-1 h-4 w-4" /> Ficha
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Formulário */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingId ? "Editar responsável" : "Novo responsável"}</DialogTitle>
            <DialogDescription>Dados do pai, mãe ou responsável.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <Label htmlFor="nome">Nome *</Label>
              <Input id="nome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} autoFocus />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <Label htmlFor="tel">Telefone / WhatsApp</Label>
                <Input id="tel" value={form.telefone} onChange={(e) => setForm({ ...form, telefone: e.target.value })} placeholder="(11) 99999-9999" />
              </div>
              <div>
                <Label htmlFor="email">E-mail</Label>
                <Input ref={emailInputRef} id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="responsavel@email.com" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">📧 O e-mail é usado para envio de contratos, recibos e comunicados. Informe pelo menos um meio de contato.</p>
            <div>
              <Label htmlFor="end">Endereço</Label>
              <Input id="end" value={form.endereco} onChange={(e) => setForm({ ...form, endereco: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="emerg">Telefone de emergência</Label>
              <Input id="emerg" value={form.telefone_emergencia} onChange={(e) => setForm({ ...form, telefone_emergencia: e.target.value })} placeholder="(11) 90000-0000" />
            </div>
            <div>
              <Label htmlFor="aut">Pessoas autorizadas a buscar o aluno</Label>
              <Textarea id="aut" rows={2} value={form.pessoas_autorizadas} onChange={(e) => setForm({ ...form, pessoas_autorizadas: e.target.value })} placeholder="Ex: Avó Maria, Tio João" />
            </div>
            <div>
              <Label>Alunos vinculados</Label>
              {alunosOpts.length === 0 ? (
                <p className="mt-1 text-xs text-muted-foreground">Cadastre alunos primeiro para vincular.</p>
              ) : (
                <div className="mt-2 grid gap-2 rounded-lg border p-3 max-h-48 overflow-y-auto">
                  {alunosOpts.map((a) => (
                    <label key={a.id} className="flex items-center gap-2 text-sm cursor-pointer">
                      <Checkbox checked={form.alunos_ids.includes(a.id)} onCheckedChange={() => toggleAluno(a.id)} />
                      {a.nome}
                    </label>
                  ))}
                </div>
              )}
            </div>
            <div>
              <Label htmlFor="obs">Observações</Label>
              <Textarea id="obs" rows={2} value={form.observacoes} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} />
            </div>
            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saving} className="bg-primary text-primary-foreground font-bold">
                {saving ? "Salvando..." : "Salvar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Sem e-mail */}
      <AlertDialog open={!!noEmailDialog} onOpenChange={(v) => !v && setNoEmailDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Sem e-mail cadastrado</AlertDialogTitle>
            <AlertDialogDescription>
              Este responsável ainda não possui um e-mail cadastrado. Deseja cadastrar agora?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (noEmailDialog) { const r = noEmailDialog; setNoEmailDialog(null); openEdit(r, { focusEmail: true }); } }}>
              Cadastrar agora
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ficha (Sheet) */}
      <Sheet open={!!fichaResp} onOpenChange={(v) => !v && setFichaResp(null)}>
        <SheetContent side="right" className="w-full sm:max-w-xl overflow-y-auto">
          {fichaResp && (() => {
            const r = fichaResp;
            const comp = getCompleteness(r);
            const resumo = resumoDe(r);
            const tl = timelineDe(r);
            const tlFiltrada = tlFiltro === "todos" ? tl : tl.filter((e) => e.category === tlFiltro);
            const alunoPrincipal = resumo.alunos[0];
            return (
              <>
                <SheetHeader>
                  <SheetTitle className="flex items-center gap-2 flex-wrap">
                    {r.nome}
                    <Badge
                      className={
                        comp.status === "completo" ? "bg-success/15 text-success border-success/30"
                        : comp.status === "parcial" ? "bg-accent/20 text-foreground border-accent/40"
                        : "bg-destructive/15 text-destructive border-destructive/30"
                      }
                      variant="outline"
                    >
                      {comp.status === "completo" ? "🟢 Completo" : comp.status === "parcial" ? "🟡 Parcial" : "🔴 Incompleto"}
                    </Badge>
                  </SheetTitle>
                  <SheetDescription>Central de relacionamento</SheetDescription>
                </SheetHeader>

                <div className="mt-4 space-y-4">
                  <PreCadastroAuditoria
                    ficha={fichasPublicas.find(
                      (f) =>
                        (onlyDigitsPhone(f.responsavel_whatsapp) &&
                          onlyDigitsPhone(f.responsavel_whatsapp) === onlyDigitsPhone(r.whatsapp || r.telefone)) ||
                        f.responsavel_nome.trim().toLowerCase() === r.nome.trim().toLowerCase(),
                    )}
                  />

                  {comp.missing.length > 0 && (
                    <div className="rounded-lg border border-accent/40 bg-accent/10 p-3 text-sm">
                      <div className="font-semibold flex items-center gap-2"><AlertCircle className="h-4 w-4" /> Falta preencher:</div>
                      <ul className="mt-1 list-disc pl-5 text-xs text-muted-foreground">
                        {comp.missing.map((m) => <li key={m}>{m}</li>)}
                      </ul>
                    </div>
                  )}

                  {/* Resumo */}
                  <div className="grid grid-cols-2 gap-2">
                    <Card className="p-3"><div className="text-[11px] text-muted-foreground">👦 Alunos vinculados</div><div className="text-lg font-extrabold">{resumo.alunos.length}</div></Card>
                    <Card className="p-3"><div className="text-[11px] text-muted-foreground">💰 Mensalidade total</div><div className="text-lg font-extrabold">R$ {formatBRL(resumo.mensalidadeTotal)}</div></Card>
                    <Card className="p-3"><div className="text-[11px] text-muted-foreground">📄 Contratos ativos</div><div className="text-lg font-extrabold">{resumo.contratosAtivos}</div></Card>
                    <Card className={`p-3 ${resumo.pendencias > 0 ? "border-destructive/40" : ""}`}><div className="text-[11px] text-muted-foreground">⚠️ Pendências</div><div className={`text-lg font-extrabold ${resumo.pendencias > 0 ? "text-destructive" : ""}`}>{resumo.pendencias}</div></Card>
                    <Card className="p-3 col-span-2"><div className="text-[11px] text-muted-foreground">📱 Última mensagem</div><div className="text-sm font-semibold">{resumo.ultMsg ? `${resumo.ultMsg.emoji} ${resumo.ultMsg.mensagem_nome} — ${formatDateTime(resumo.ultMsg.created_at)}` : "Nenhuma"}</div></Card>
                    <Card className="p-3 col-span-2"><div className="text-[11px] text-muted-foreground">📅 Último pagamento</div><div className="text-sm font-semibold">{resumo.ultPag ? `R$ ${formatBRL(resumo.ultPag.valor)} — ${formatDate(resumo.ultPag.data_pagamento)} (ref ${resumo.ultPag.mes_referencia})` : "Nenhum"}</div></Card>
                  </div>

                  {/* Atalhos rápidos */}
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {r.whatsapp && (
                      <Button onClick={() => abrirWhats(r)} className="bg-success text-success-foreground hover:bg-success/90 font-bold">
                        <MessageCircle className="mr-1 h-4 w-4" /> WhatsApp
                      </Button>
                    )}
                    <Button onClick={() => abrirEmail(r)} variant="outline" className="font-bold">
                      <Mail className="mr-1 h-4 w-4" /> E-mail
                    </Button>
                    {alunoPrincipal && (
                      <Button onClick={() => navigate({ to: "/alunos" })} variant="outline" className="font-bold">
                        <User2 className="mr-1 h-4 w-4" /> Aluno
                      </Button>
                    )}
                    <Button onClick={() => navigate({ to: "/contratos" })} variant="outline" className="font-bold">
                      <FileText className="mr-1 h-4 w-4" /> Contrato
                    </Button>
                    <Button onClick={() => navigate({ to: "/financeiro" })} variant="outline" className="font-bold">
                      <DollarSign className="mr-1 h-4 w-4" /> Financeiro
                    </Button>
                    <Button onClick={() => openEdit(r)} variant="outline" className="font-bold">
                      <Pencil className="mr-1 h-4 w-4" /> Editar
                    </Button>
                  </div>

                  {/* Linha do tempo */}
                  <div>
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <h3 className="font-bold flex items-center gap-2"><History className="h-4 w-4" /> 📜 Linha do Tempo</h3>
                      <div className="flex items-center gap-1 text-xs">
                        <Filter className="h-3 w-3 text-muted-foreground" />
                        {(["todos","contratos","financeiro","mensagens","alunos","alteracoes"] as const).map((k) => (
                          <button
                            key={k}
                            onClick={() => setTlFiltro(k)}
                            className={`px-2 py-0.5 rounded-full border ${tlFiltro === k ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground"}`}
                          >
                            {k === "todos" ? "Tudo" : k === "contratos" ? "📄" : k === "financeiro" ? "💰" : k === "mensagens" ? "📱" : k === "alunos" ? "👦" : "🚐"}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="mt-2 space-y-2">
                      {tlFiltrada.length === 0 ? (
                        <div className="rounded-lg border border-dashed p-4 text-center text-xs text-muted-foreground">
                          <CheckCircle2 className="mx-auto mb-1 h-4 w-4" /> Sem eventos para este filtro.
                        </div>
                      ) : tlFiltrada.map((e) => (
                        <div key={e.id} className="flex items-start gap-3 rounded-lg border p-2">
                          <div className="text-xl">{e.emoji}</div>
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-semibold">{e.title}</div>
                            <div className="text-[11px] text-muted-foreground">{formatDateTime(e.date)}{e.detail ? ` • ${e.detail}` : ""}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </>
            );
          })()}
        </SheetContent>
      </Sheet>

      {senderResp && (
        <WhatsAppSender
          open={senderOpen}
          onOpenChange={(v) => { setSenderOpen(v); if (!v) setSenderResp(null); }}
          user={user}
          responsaveis={[{ id: senderResp.id, nome: senderResp.nome, whatsapp: senderResp.whatsapp, telefone: senderResp.telefone, alunos_ids: senderResp.alunos_ids }]}
          alunos={alunosOpts}
        />
      )}
    </div>
  );
}
