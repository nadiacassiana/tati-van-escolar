import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { Toaster } from "@/components/ui/sonner";
import { AccountStatusProvider } from "@/hooks/use-account-status";
import { AccountStatusBanner } from "@/components/account-status-banner";
import { HelpFab } from "@/components/help-fab";
import { NotificacoesBell } from "@/components/notificacoes-bell";
import { useEffect } from "react";
import { loadVanLogo } from "@/lib/logo-store";
import { registrarServiceWorker } from "@/lib/push-client";


/** Nenhuma consulta secundária pode travar a entrada: se demorar, seguimos. */
async function comLimite<T>(p: PromiseLike<T>, ms = 8000): Promise<T | null> {
  try {
    return await Promise.race([
      p as Promise<T>,
      new Promise<null>((resolve) => setTimeout(() => resolve(null), ms)),
    ]);
  } catch (e) {
    console.error("[auth] consulta de perfil falhou (ignorada):", e);
    return null;
  }
}

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async ({ location }) => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    // Bloqueio administrativo
    const prof = await comLimite(
      supabase
        .from("profiles" as never)
        .select("blocked_at")
        .eq("user_id", data.user.id)
        .maybeSingle(),
    );
    if ((prof?.data as { blocked_at?: string | null } | null)?.blocked_at) {
      await supabase.auth.signOut();
      throw redirect({ to: "/auth", search: { blocked: 1 } as never });
    }
    // Perfil Administrador: interface própria e isolada.
    // Não acessa telas operacionais da transportadora.
    const adminRes = await comLimite(
      supabase
        .from("user_roles" as never)
        .select("role")
        .eq("user_id", data.user.id)
        .eq("role", "admin")
        .maybeSingle(),
    );
    const isAdmin = !!adminRes?.data;
    if (isAdmin && location.pathname !== "/admin") {
      throw redirect({ to: "/admin" });
    }
    return { user: data.user, isAdmin };
  },
  component: AuthenticatedLayout,
});


function AuthenticatedLayout() {
  const { user, isAdmin } = Route.useRouteContext();
  useEffect(() => {
    // Logotipo fica no perfil (banco), fora do token de login.
    void loadVanLogo();
    // Service Worker de mensageria: só registra, nunca pede permissão sozinho.
    void registrarServiceWorker();
  }, [user?.id]);
  const TRIAL_DAYS = 10;
  const createdAt = user?.created_at ? new Date(user.created_at).getTime() : Date.now();
  const elapsedDays = Math.floor((Date.now() - createdAt) / (1000 * 60 * 60 * 24));
  const remaining = Math.max(0, TRIAL_DAYS - elapsedDays);
  const trialLabel =
    remaining === 0
      ? "⏰ Teste encerrado"
      : remaining === 1
      ? "🎁 1 dia grátis restante"
      : `🎁 ${remaining} dias grátis restantes`;

  return (
    <AccountStatusProvider>
      <SidebarProvider>
        <div className="flex min-h-screen w-full bg-background">
          <AppSidebar />
          <div className="flex flex-1 flex-col">
            <header className="sticky top-0 z-10 border-b bg-background/80 backdrop-blur">
              <div className="flex h-14 items-center gap-2 px-4">
                <SidebarTrigger />
                <div className="flex-1" />
                {!isAdmin && <NotificacoesBell />}

                {!isAdmin && (
                  <div className="hidden items-center gap-2 rounded-full bg-accent/30 px-3 py-1 text-xs font-semibold text-accent-foreground sm:flex">
                    {trialLabel}
                  </div>
                )}
                {isAdmin && (
                  <div className="hidden items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary sm:flex">
                    🛡️ Administrador
                  </div>
                )}
              </div>
              {!isAdmin && <AccountStatusBanner />}
            </header>
            <main className="flex-1 p-4 sm:p-6">
              <Outlet />
            </main>
          </div>
          {!isAdmin && <HelpFab />}
          <Toaster richColors position="top-center" />
        </div>
      </SidebarProvider>
    </AccountStatusProvider>
  );

}

