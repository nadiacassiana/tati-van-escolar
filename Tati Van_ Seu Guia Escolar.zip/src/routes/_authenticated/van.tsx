import { createFileRoute, Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  FileText, Shield, Search, Gauge, Droplet, Disc, Wrench, CalendarClock,
  AlertTriangle, CheckCircle2, ClipboardCheck, History, TrendingUp, PartyPopper,
  Lightbulb, Sparkles, Trophy, Award, Heart, AlertOctagon,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/van")({
  head: () => ({ meta: [{ title: "Saúde da Van — Tati Van" }] }),
  component: VanPage,
});

type Documento = {
  id: string;
  nome: string;
  categoria: string;
  vencimento: string | null;
  historico: { ts: string; tipo: string; descricao: string }[] | null;
};
type Gasto = { id: string; data: string; categoria: string; km: number | null; descricao: string | null };
type Snapshot = { mes_referencia: string; score: number };

type Status = "ok" | "atencao" | "proximo" | "vencido" | "sem";

const STATUS_META: Record<Status, { emoji: string; label: string; cls: string; chip: string }> = {
  ok:       { emoji: "🟢", label: "Em dia",              cls: "text-emerald-700", chip: "bg-emerald-100 text-emerald-700 border-emerald-200" },
  atencao:  { emoji: "🟡", label: "Atenção",             cls: "text-yellow-700",  chip: "bg-yellow-100 text-yellow-700 border-yellow-200" },
  proximo:  { emoji: "🟠", label: "Próximo do vencimento", cls: "text-orange-700",  chip: "bg-orange-100 text-orange-700 border-orange-200" },
  vencido:  { emoji: "🔴", label: "Vencido",             cls: "text-red-700",     chip: "bg-red-100 text-red-700 border-red-200" },
  sem:      { emoji: "⚪", label: "Sem registro",        cls: "text-muted-foreground", chip: "bg-muted text-muted-foreground border-border" },
};

const CHECKLIST_GERAL = [
  "Pneus", "Freios", "Óleo", "Água", "Limpadores", "Faróis", "Lanternas",
  "Setas", "Luz de freio", "Bateria", "Tacógrafo", "Documentação",
  "Limpeza interna", "Limpeza externa", "Equipamentos obrigatórios",
];

const DICAS = [
  "Verifique semanalmente a calibragem dos pneus.",
  "Manter a manutenção em dia reduz gastos inesperados.",
  "Organização hoje evita problemas amanhã.",
  "Uma van bem cuidada transmite confiança aos pais.",
  "Pequenas revisões evitam grandes prejuízos.",
  "Segurança começa antes mesmo de ligar o motor.",
  "Confira os documentos antes de cada viagem longa.",
  "Cintos e travas dos bancos sempre revisados.",
];

const FRASES = [
  "🚐 Quem cuida da van também cuida dos alunos.",
  "💙 Organização é tranquilidade.",
  "⭐ Cada revisão feita hoje evita um problema amanhã.",
  "👏 Seu compromisso com a segurança faz a diferença.",
  "🌟 Uma van organizada transmite confiança para as famílias.",
  "🚐 Seu trabalho leva sonhos para a escola todos os dias.",
];

type Faixa = "perfeito" | "excelente" | "atencao" | "cuidar" | "urgente";
function faixaDoScore(s: number): Faixa {
  if (s >= 100) return "perfeito";
  if (s >= 95) return "excelente";
  if (s >= 80) return "atencao";
  if (s >= 60) return "cuidar";
  return "urgente";
}
const MENSAGENS_TATI: Record<Faixa, {
  emoji: string;
  titulo: string;
  corpo: string;
  cta?: { label: string; icon: typeof AlertTriangle };
  cor: string;
}> = {
  perfeito: {
    emoji: "🎉",
    titulo: "Parabéns! Sua van está 100% em dia.",
    corpo: "Todos os documentos, revisões e manutenções estão organizados. Agora é só focar no que realmente importa: 🚐 transportar seus alunos com segurança.",
    cor: "from-emerald-500/15 to-emerald-500/5 border-emerald-200",
  },
  excelente: {
    emoji: "💚",
    titulo: "🚐 Tudo certo!",
    corpo: "Sua van está organizada, segura e pronta para mais um dia de trabalho. A Tati está acompanhando tudo para você.",
    cor: "from-emerald-500/15 to-emerald-500/5 border-emerald-200",
  },
  atencao: {
    emoji: "💛",
    titulo: "🚐 Atenção!",
    corpo: "Sua van está em boas condições, mas existem alguns itens que merecem atenção. Resolver agora evita problemas no futuro.",
    cta: { label: "Ver Pendências", icon: Search },
    cor: "from-yellow-400/20 to-yellow-400/5 border-yellow-300",
  },
  cuidar: {
    emoji: "🟠",
    titulo: "🚐 Vamos cuidar da sua van!",
    corpo: "Existem documentos ou manutenções próximos do vencimento. Resolver essas pendências agora ajuda a evitar multas, despesas inesperadas e interrupções no trabalho.",
    cta: { label: "Resolver Pendências", icon: AlertTriangle },
    cor: "from-orange-500/15 to-orange-500/5 border-orange-200",
  },
  urgente: {
    emoji: "🔴",
    titulo: "🚐 Sua van precisa de atenção urgente.",
    corpo: "Há documentos vencidos ou manutenções importantes pendentes. Recomendo regularizar essas pendências antes de continuar a operação.",
    cta: { label: "Ver Pendências Urgentes", icon: AlertOctagon },
    cor: "from-red-500/15 to-red-500/5 border-red-200",
  },
};

function pickDaily<T>(arr: T[], seedSalt = 0): T {
  const d = new Date();
  const seed = d.getFullYear() * 1000 + (d.getMonth() + 1) * 50 + d.getDate() + seedSalt;
  return arr[seed % arr.length];
}

function diasAte(dateStr: string | null): number | null {
  if (!dateStr) return null;
  const d = new Date(dateStr + "T00:00:00").getTime();
  return Math.floor((d - Date.now()) / 86400000);
}
function statusPorDias(dias: number | null): Status {
  if (dias === null) return "sem";
  if (dias < 0) return "vencido";
  if (dias <= 7) return "proximo";
  if (dias <= 30) return "atencao";
  return "ok";
}
function scorePorStatus(s: Status): number {
  return s === "ok" ? 100 : s === "atencao" ? 80 : s === "proximo" ? 55 : s === "vencido" ? 0 : 70;
}
function brDate(d: string | null) {
  return d ? new Date(d + "T00:00:00").toLocaleDateString("pt-BR") : "—";
}
function mesAtualRef() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function mesLabel(ref: string) {
  const [y, m] = ref.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString("pt-BR", { month: "short", year: "2-digit" });
}

type Item = {
  key: string;
  nome: string;
  icone: typeof FileText;
  status: Status;
  detalhe: string;
  vencimento?: string | null;
  acao?: { label: string; href: string };
};

function VanPage() {
  const [docs, setDocs] = useState<Documento[]>([]);
  const [gastos, setGastos] = useState<Gasto[]>([]);
  const [snaps, setSnaps] = useState<Snapshot[]>([]);
  const [checklistOpen, setChecklistOpen] = useState(false);
  const [pendOpen, setPendOpen] = useState(false);
  const [checked, setChecked] = useState<Record<string, boolean>>(() => {
    if (typeof window === "undefined") return {};
    try { return JSON.parse(localStorage.getItem("van_checklist_geral") || "{}"); } catch { return {}; }
  });
  const [parabens, setParabens] = useState(false);

  useEffect(() => {
    (async () => {
      const [d, g, s] = await Promise.all([
        supabase.from("documentos").select("id, nome, categoria, vencimento, historico"),
        supabase.from("gastos").select("id, data, categoria, km, descricao").order("data", { ascending: false }),
        supabase.from("saude_van_snapshots").select("mes_referencia, score").order("mes_referencia"),
      ]);
      setDocs(((d.data as unknown) as Documento[]) || []);
      setGastos(((g.data as unknown) as Gasto[]) || []);
      setSnaps(((s.data as unknown) as Snapshot[]) || []);
    })();
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("van_checklist_geral", JSON.stringify(checked));
    }
  }, [checked]);

  const docPor = (regex: RegExp) =>
    docs.find((x) => regex.test((x.categoria || "") + " " + (x.nome || "")));

  const itens: Item[] = useMemo(() => {
    const list: Item[] = [];

    const lic = docPor(/crlv|licenciamento/i);
    const sd1 = diasAte(lic?.vencimento ?? null);
    list.push({
      key: "licenciamento", nome: "Licenciamento", icone: FileText,
      status: statusPorDias(sd1),
      detalhe: lic ? (sd1 !== null && sd1 < 0 ? `Vencido há ${Math.abs(sd1)} dias` : sd1 !== null ? `Vence em ${brDate(lic.vencimento)}` : "Sem data") : "Sem cadastro",
      vencimento: lic?.vencimento,
      acao: { label: "Abrir documento", href: "/documentos" },
    });

    const seg = docPor(/seguro/i);
    const sd2 = diasAte(seg?.vencimento ?? null);
    list.push({
      key: "seguro", nome: "Seguro", icone: Shield,
      status: statusPorDias(sd2),
      detalhe: seg ? (sd2 !== null && sd2 < 0 ? `Vencido há ${Math.abs(sd2)} dias` : sd2 !== null ? `Vence em ${brDate(seg.vencimento)}` : "Sem data") : "Sem cadastro",
      vencimento: seg?.vencimento,
      acao: { label: "Abrir documento", href: "/documentos" },
    });

    const inm = docPor(/inmetro|vistoria/i);
    const sd3 = diasAte(inm?.vencimento ?? null);
    list.push({
      key: "inmetro", nome: "INMETRO", icone: Search,
      status: statusPorDias(sd3),
      detalhe: inm ? (sd3 !== null && sd3 < 0 ? `Vencido há ${Math.abs(sd3)} dias` : sd3 !== null ? `Vence em ${sd3} dias` : "Sem data") : "Sem cadastro",
      vencimento: inm?.vencimento,
      acao: { label: "Abrir documento", href: "/documentos" },
    });

    const taco = docPor(/tac[oó]grafo/i);
    const sd4 = diasAte(taco?.vencimento ?? null);
    list.push({
      key: "tacografo", nome: "Tacógrafo", icone: Gauge,
      status: statusPorDias(sd4),
      detalhe: taco ? (sd4 !== null && sd4 < 0 ? `Vencido há ${Math.abs(sd4)} dias` : sd4 !== null ? `Vence em ${brDate(taco.vencimento)}` : "Sem data") : "Sem cadastro",
      vencimento: taco?.vencimento,
      acao: { label: "Abrir documento", href: "/documentos" },
    });

    // Manutenções derivadas dos gastos
    const ultOleo = gastos.find((g) => /óleo|oleo/i.test(g.categoria));
    const diasOleo = ultOleo ? Math.floor((Date.now() - new Date(ultOleo.data + "T00:00:00").getTime()) / 86400000) : null;
    const statusOleo: Status = diasOleo === null ? "sem" : diasOleo > 180 ? "vencido" : diasOleo > 150 ? "proximo" : diasOleo > 120 ? "atencao" : "ok";
    list.push({
      key: "oleo", nome: "Troca de óleo", icone: Droplet,
      status: statusOleo,
      detalhe: ultOleo ? `Última há ${diasOleo} dias${ultOleo.km ? ` • ${ultOleo.km.toLocaleString("pt-BR")} km` : ""}` : "Sem registro",
      acao: { label: "Lançar gasto", href: "/gastos" },
    });

    const ultPneu = gastos.find((g) => /pneu/i.test(g.categoria));
    const diasPneu = ultPneu ? Math.floor((Date.now() - new Date(ultPneu.data + "T00:00:00").getTime()) / 86400000) : null;
    const statusPneu: Status = diasPneu === null ? "sem" : diasPneu > 365 * 2 ? "proximo" : "ok";
    list.push({
      key: "pneus", nome: "Pneus", icone: Disc,
      status: statusPneu,
      detalhe: ultPneu ? `Última troca há ${diasPneu} dias` : "Em boas condições",
      acao: { label: "Lançar gasto", href: "/gastos" },
    });

    const ultRev = gastos.find((g) => /revis|manuten/i.test(g.categoria));
    const diasRev = ultRev ? Math.floor((Date.now() - new Date(ultRev.data + "T00:00:00").getTime()) / 86400000) : null;
    const statusRev: Status = diasRev === null ? "sem" : diasRev > 365 ? "vencido" : diasRev > 330 ? "proximo" : diasRev > 300 ? "atencao" : "ok";
    list.push({
      key: "revisao", nome: "Revisão Geral", icone: Wrench,
      status: statusRev,
      detalhe: ultRev ? `Última há ${diasRev} dias` : "Sem registro",
      acao: { label: "Lançar gasto", href: "/gastos" },
    });

    return list;
  }, [docs, gastos]);

  const semDados = docs.length === 0 && gastos.length === 0;

  const score = useMemo(() => {
    const ativos = itens.filter((i) => i.status !== "sem");
    if (ativos.length === 0) return 0;
    return Math.round(ativos.reduce((s, i) => s + scorePorStatus(i.status), 0) / ativos.length);
  }, [itens]);


  // Próximo compromisso
  const proximo = useMemo(() => {
    const lista = itens
      .filter((i) => i.vencimento)
      .map((i) => ({ ...i, dias: diasAte(i.vencimento!) ?? 9999 }))
      .filter((i) => i.dias >= -30)
      .sort((a, b) => a.dias - b.dias);
    return lista[0];
  }, [itens]);

  const pendencias = itens.filter((i) => i.status === "vencido" || i.status === "proximo" || i.status === "atencao");

  // Linha do tempo: histórico dos documentos + manutenções (gastos)
  const linhaDoTempo = useMemo(() => {
    const eventos: { ts: string; titulo: string; emoji: string }[] = [];
    docs.forEach((d) => {
      (d.historico || []).forEach((h) => {
        // Ignora entradas automáticas de sugestões (não são eventos reais da van)
        if (/sugest[ãa]o/i.test(h.descricao)) return;
        eventos.push({ ts: h.ts, titulo: `${d.nome}: ${h.descricao}`, emoji: "📄" });
      });
    });
    gastos.forEach((g) => {
      if (/óleo|oleo|pneu|revis|manuten/i.test(g.categoria)) {
        eventos.push({
          ts: new Date(g.data + "T00:00:00").toISOString(),
          titulo: `${g.categoria}${g.km ? ` — ${g.km.toLocaleString("pt-BR")} km` : ""}`,
          emoji: /óleo|oleo/i.test(g.categoria) ? "🛢️" : /pneu/i.test(g.categoria) ? "🛞" : "🔧",
        });
      }
    });
    return eventos.sort((a, b) => (a.ts < b.ts ? 1 : -1)).slice(0, 20);
  }, [docs, gastos]);

  // Snapshot mensal automático
  useEffect(() => {
    if (docs.length === 0 && gastos.length === 0) return;
    const ref = mesAtualRef();
    const atual = snaps.find((s) => s.mes_referencia === ref);
    if (atual && atual.score === score) return;
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return;
      await supabase
        .from("saude_van_snapshots")
        .upsert({ user_id: u.user.id, mes_referencia: ref, score }, { onConflict: "user_id,mes_referencia" });
      const { data } = await supabase.from("saude_van_snapshots").select("mes_referencia, score").order("mes_referencia");
      setSnaps(((data as unknown) as Snapshot[]) || []);
    })();
  }, [score, docs.length, gastos.length]); // eslint-disable-line

  const checklistDone = CHECKLIST_GERAL.filter((i) => checked[i]).length;
  const checklistPct = Math.round((checklistDone / CHECKLIST_GERAL.length) * 100);

  const indicadorTexto = score >= 90 ? "Excelente" : score >= 70 ? "Atenção" : "Crítico";
  const indicadorEmoji = score >= 90 ? "🟢" : score >= 70 ? "🟡" : "🔴";

  const faixa = faixaDoScore(score);
  const tati = MENSAGENS_TATI[faixa];
  const dica = pickDaily(DICAS);
  const frase = pickDaily(FRASES, 7);

  // Conquistas
  const totalDocs = docs.length;
  const docsEmDia = itens.filter((i) => i.status === "ok").length;
  const temRevisao = gastos.some((g) => /revis|manuten|óleo|oleo/i.test(g.categoria));
  const conquistas = [
    { id: "rev1", icon: "🏅", nome: "Primeira Revisão Registrada", ok: temRevisao },
    { id: "docs", icon: "🏅", nome: "Todos os Documentos em Dia", ok: totalDocs > 0 && docsEmDia === itens.length },
    { id: "van100", icon: "🏆", nome: "Van 100%", ok: score >= 100 },
    { id: "6m", icon: "🥈", nome: "Seis Meses Sem Pendências", ok: snaps.filter((s) => s.score >= 95).length >= 6 },
    { id: "1y", icon: "🥇", nome: "Um Ano de Organização", ok: snaps.filter((s) => s.score >= 90).length >= 12 },
  ];


  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">Saúde da Van 🚐</h1>
          <p className="text-sm text-muted-foreground">A Tati cuida da sua van para você cuidar dos alunos.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => setPendOpen(true)} className="gap-2">
            <AlertTriangle className="h-4 w-4" /> Resolver Pendências
            {pendencias.length > 0 && <Badge variant="destructive" className="ml-1">{pendencias.length}</Badge>}
          </Button>
          <Button onClick={() => setChecklistOpen(true)} className="gap-2">
            <ClipboardCheck className="h-4 w-4" /> Checklist Geral
          </Button>
        </div>
      </div>

      {/* Hero score */}
      {semDados ? (
        <Card className="overflow-hidden border-0 p-8 text-center text-primary-foreground" style={{ background: "var(--gradient-hero)" }}>
          <div className="text-sm uppercase tracking-wider opacity-80">🚐 Saúde da Van</div>
          <div className="my-4 text-4xl">⚪</div>
          <div className="text-2xl font-extrabold">Ainda não avaliada</div>
          <p className="mx-auto mt-2 max-w-md text-sm opacity-90">
            Cadastre os documentos, revisões e manutenções para começar o acompanhamento da saúde da sua van.
          </p>
          <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
            <Link to="/documentos"><Button variant="secondary" size="sm">Cadastrar documentos</Button></Link>
            <Link to="/gastos"><Button variant="outline" size="sm" className="bg-white/10 border-white/30 text-white hover:bg-white/20">Adicionar primeira manutenção</Button></Link>
          </div>
        </Card>
      ) : (
        <Card className="overflow-hidden border-0 p-8 text-center text-primary-foreground" style={{ background: "var(--gradient-hero)" }}>
          <div className="text-sm uppercase tracking-wider opacity-80">🚐 Saúde da Van</div>
          <div className="my-3 text-7xl font-extrabold">{score}%</div>
          <div className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1 text-sm">
            <span>{indicadorEmoji}</span> <span className="font-semibold">{indicadorTexto}</span>
          </div>
          <Progress value={score} className="mt-4 bg-white/20" />
          {score < 100 && pendencias.length > 0 && (
            <div className="mt-4 text-sm opacity-90">
              ⚠ Existem {pendencias.length} {pendencias.length === 1 ? "item que precisa" : "itens que precisam"} de atenção.
            </div>
          )}
          {score === 100 && (
            <div className="mt-4 text-sm opacity-90">🎉 Tudo em dia! Sua van está pronta para rodar com segurança.</div>
          )}
        </Card>
      )}

      {/* Mensagem inteligente da Tati */}
      {semDados ? (
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20 p-5" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/70 text-2xl shadow-sm">👋</div>
            <div className="min-w-0 flex-1">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Mensagem da Tati</div>
              <h3 className="mt-0.5 text-lg font-extrabold leading-snug">Vamos começar juntos?</h3>
              <p className="mt-1 text-sm text-foreground/80">
                Sua van ainda não possui informações suficientes para uma avaliação. Cadastre seus documentos e manutenções para que eu possa acompanhar a saúde dela com você.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Link to="/documentos"><Button size="sm" className="gap-2"><FileText className="h-4 w-4" /> Cadastrar documentos</Button></Link>
                <Link to="/gastos"><Button size="sm" variant="outline" className="gap-2"><Wrench className="h-4 w-4" /> Primeira manutenção</Button></Link>
              </div>
            </div>
          </div>
        </Card>
      ) : (
        <Card className={`bg-gradient-to-br p-5 ${tati.cor}`} style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/70 text-2xl shadow-sm">
              {tati.emoji}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Mensagem da Tati</div>
              <h3 className="mt-0.5 text-lg font-extrabold leading-snug">{tati.titulo}</h3>
              <p className="mt-1 text-sm text-foreground/80">{tati.corpo}</p>
              {tati.cta && (
                <Button className="mt-3 gap-2" size="sm" onClick={() => setPendOpen(true)}>
                  <tati.cta.icon className="h-4 w-4" /> {tati.cta.label}
                </Button>
              )}
            </div>
          </div>
        </Card>
      )}


      {/* Dica do dia + frase motivacional */}
      <div className="grid gap-4 sm:grid-cols-2">
        <Card className="flex items-start gap-3 p-4" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent/20 text-accent-foreground">
            <Lightbulb className="h-5 w-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Dica do dia</div>
            <p className="text-sm font-medium">💡 {dica}</p>
          </div>
        </Card>
        <Card className="flex items-start gap-3 p-4" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Inspiração</div>
            <p className="text-sm font-medium">{frase}</p>
          </div>
        </Card>
      </div>

      {/* Próximo compromisso */}
      {proximo && (
        <Card className="flex items-center gap-3 p-4" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent-foreground">
            <CalendarClock className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Próximo compromisso</div>
            <div className="font-bold truncate">
              📅 {proximo.nome} {proximo.dias < 0 ? `venceu há ${Math.abs(proximo.dias)} dias` : `vence em ${proximo.dias} dias`}.
            </div>
          </div>
          {proximo.acao && (
            <Link to={proximo.acao.href}><Button variant="outline" size="sm">{proximo.acao.label}</Button></Link>
          )}
        </Card>
      )}

      {/* Painel Geral */}
      <div>
        <h2 className="mb-3 text-lg font-bold">Painel Geral</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {itens.map((it) => {
            const meta = STATUS_META[it.status];
            return (
              <Card key={it.key} className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <it.icone className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="font-bold">{it.nome}</div>
                      <div className="text-xs text-muted-foreground">{it.detalhe}</div>
                    </div>
                  </div>
                  <Badge variant="outline" className={meta.chip}>{meta.emoji} {meta.label}</Badge>
                </div>
                {it.acao && (
                  <div className="mt-3">
                    <Link to={it.acao.href}>
                      <Button variant="ghost" size="sm" className="h-8 px-2 text-xs">{it.acao.label} →</Button>
                    </Link>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      </div>

      {/* Evolução mensal */}
      {snaps.length > 0 && (
        <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
          <div className="mb-3 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-bold">Evolução da Saúde da Van</h2>
          </div>
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
            {snaps.slice(-6).map((s) => (
              <div key={s.mes_referencia} className="rounded-xl border bg-secondary/40 p-3 text-center">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{mesLabel(s.mes_referencia)}</div>
                <div className="mt-1 text-xl font-extrabold text-primary">🚐 {s.score}%</div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Conquistas */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="mb-3 flex items-center gap-2">
          <Trophy className="h-5 w-5 text-accent-foreground" />
          <h2 className="text-lg font-bold">Conquistas</h2>
          <Badge variant="outline" className="ml-auto">
            {conquistas.filter((c) => c.ok).length}/{conquistas.length}
          </Badge>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {conquistas.map((c) => (
            <div
              key={c.id}
              className={`flex items-center gap-3 rounded-xl border p-3 transition ${
                c.ok ? "bg-accent/10 border-accent/30" : "bg-muted/30 border-border opacity-60"
              }`}
            >
              <div className={`flex h-10 w-10 items-center justify-center rounded-full text-xl ${c.ok ? "bg-accent/30" : "bg-muted"}`}>
                {c.ok ? c.icon : "🔒"}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-bold leading-tight">{c.nome}</div>
                <div className="text-[11px] text-muted-foreground">
                  {c.ok ? "Conquistado!" : "Em progresso"}
                </div>
              </div>
              {c.ok && <Award className="h-4 w-4 text-accent-foreground" />}
            </div>
          ))}
        </div>
        <p className="mt-3 flex items-center gap-1 text-xs text-muted-foreground">
          <Heart className="h-3.5 w-3.5 text-red-400" />
          Pequenas vitórias que mostram o seu cuidado com a van e seus alunos.
        </p>
      </Card>

      {/* Linha do tempo */}
      <Card className="p-5" style={{ boxShadow: "var(--shadow-card)" }}>
        <div className="mb-3 flex items-center gap-2">
          <History className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-bold">Histórico da Van</h2>
        </div>
        {linhaDoTempo.length === 0 ? (
          <p className="text-sm text-muted-foreground">O histórico ainda está vazio. Ele será preenchido automaticamente conforme você usar o sistema — cadastros de documentos, gastos, manutenções, vencimentos e renovações aparecerão aqui.</p>
        ) : (
          <ol className="relative space-y-3 border-l-2 border-primary/20 pl-4">
            {linhaDoTempo.map((e, i) => (
              <li key={i} className="relative">
                <span className="absolute -left-[22px] top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">•</span>
                <div className="text-sm">
                  <span className="mr-1">{e.emoji}</span>
                  <span className="font-medium">{e.titulo}</span>
                </div>
                <div className="text-xs text-muted-foreground">{new Date(e.ts).toLocaleDateString("pt-BR")}</div>
              </li>
            ))}
          </ol>
        )}
      </Card>

      {/* Dialog: Resolver pendências */}
      <Dialog open={pendOpen} onOpenChange={setPendOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-orange-500" /> Resolver Pendências</DialogTitle>
            <DialogDescription>Itens que precisam da sua atenção agora.</DialogDescription>
          </DialogHeader>
          {pendencias.length === 0 ? (
            <div className="rounded-xl bg-emerald-50 p-4 text-center text-emerald-700">
              🎉 Sem pendências! Sua van está em dia.
            </div>
          ) : (
            <div className="space-y-2">
              {pendencias.map((p) => {
                const meta = STATUS_META[p.status];
                return (
                  <div key={p.key} className="flex items-center justify-between gap-2 rounded-xl border p-3">
                    <div>
                      <div className="font-semibold flex items-center gap-2">{meta.emoji} {p.nome}</div>
                      <div className="text-xs text-muted-foreground">{p.detalhe}</div>
                    </div>
                    {p.acao && (
                      <Link to={p.acao.href} onClick={() => setPendOpen(false)}>
                        <Button size="sm" variant="outline">{p.acao.label}</Button>
                      </Link>
                    )}
                  </div>
                );
              })}
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPendOpen(false)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog: Checklist geral */}
      <Dialog open={checklistOpen} onOpenChange={setChecklistOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><ClipboardCheck className="h-5 w-5 text-primary" /> Checklist Geral da Van</DialogTitle>
            <DialogDescription>Confira todos os pontos antes de pegar a estrada.</DialogDescription>
          </DialogHeader>
          <div className="mb-2 flex items-center gap-2">
            <Progress value={checklistPct} className="h-2 flex-1" />
            <span className="text-xs font-bold text-muted-foreground">{checklistDone}/{CHECKLIST_GERAL.length}</span>
          </div>
          <div className="max-h-[60vh] space-y-1 overflow-auto pr-1">
            {CHECKLIST_GERAL.map((item) => (
              <label key={item} className="flex cursor-pointer items-center gap-3 rounded-lg p-2 hover:bg-secondary/60">
                <Checkbox
                  checked={!!checked[item]}
                  onCheckedChange={(v) => {
                    setChecked((s) => ({ ...s, [item]: !!v }));
                    if (!checked[item] && CHECKLIST_GERAL.every((i) => i === item || s_get(checked, i))) {
                      // will check below via effect
                    }
                  }}
                />
                <span className="text-sm">{item}</span>
              </label>
            ))}
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button variant="ghost" onClick={() => { setChecked({}); toast.info("Checklist reiniciado"); }}>Reiniciar</Button>
            <Button onClick={() => {
              if (checklistPct === 100) { setParabens(true); setChecklistOpen(false); }
              else { toast.success("Checklist salvo"); setChecklistOpen(false); }
            }}>
              <CheckCircle2 className="mr-2 h-4 w-4" /> Concluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Parabens dialog */}
      <Dialog open={parabens} onOpenChange={setParabens}>
        <DialogContent className="sm:max-w-md text-center">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-center gap-2 text-2xl">
              <PartyPopper className="h-6 w-6 text-accent" /> Parabéns!
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Você conferiu todos os 15 pontos do checklist. Boa viagem e dirija com segurança! 🚐💙
          </p>
          <DialogFooter>
            <Button className="w-full" onClick={() => setParabens(false)}>Continuar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function s_get(obj: Record<string, boolean>, k: string) { return !!obj[k]; }
