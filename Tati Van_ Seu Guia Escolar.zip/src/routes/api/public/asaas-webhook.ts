import { createFileRoute } from "@tanstack/react-router";

// Webhook do Asaas — receberá eventos de pagamento/assinatura.
// A URL final ainda não está cadastrada no painel do Asaas; o usuário
// informará o domínio definitivo posteriormente.
//
// Segurança: o Asaas envia o token configurado no painel no header
// "asaas-access-token". Comparamos em tempo constante com ASAAS_WEBHOOK_TOKEN.

type AsaasWebhookPayment = {
  id: string;
  subscription?: string;
  customer?: string;
  status?: string;
  billingType?: string;
  invoiceUrl?: string;
  dueDate?: string;
};

type AsaasWebhookBody = {
  event?: string;
  payment?: AsaasWebhookPayment;
  subscription?: { id: string; status?: string; nextDueDate?: string; customer?: string };
};

function timingSafeEqualStr(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export const Route = createFileRoute("/api/public/asaas-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const expected = process.env.ASAAS_WEBHOOK_TOKEN;
        if (!expected) {
          console.error("[asaas-webhook] ASAAS_WEBHOOK_TOKEN não configurado");
          return new Response("Server not configured", { status: 500 });
        }
        const token = request.headers.get("asaas-access-token") ?? "";
        if (!timingSafeEqualStr(token, expected)) {
          return new Response("Unauthorized", { status: 401 });
        }

        let body: AsaasWebhookBody;
        try {
          body = (await request.json()) as AsaasWebhookBody;
        } catch {
          return new Response("Invalid JSON", { status: 400 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const event = body.event ?? "";
        const subId =
          body.subscription?.id ?? body.payment?.subscription ?? null;
        if (!subId) {
          return new Response("ok"); // evento sem assinatura vinculada
        }

        const update: {
          subscription_updated_at: string;
          subscription_status?: string;
          next_due_date?: string;
          asaas_next_due_date?: string;
          payment_method?: string;
          last_invoice_url?: string;
        } = {
          subscription_updated_at: new Date().toISOString(),
        };


        if (body.subscription?.status) update.subscription_status = body.subscription.status;
        if (body.subscription?.nextDueDate) update.next_due_date = body.subscription.nextDueDate;

        if (body.payment) {
          if (body.payment.billingType && body.payment.billingType !== "UNDEFINED") {
            update.payment_method = body.payment.billingType;
          }
          if (body.payment.invoiceUrl) update.last_invoice_url = body.payment.invoiceUrl;

          // Mapeia status do pagamento -> status da assinatura para UI
          if (event.startsWith("PAYMENT_")) {
            const s = body.payment.status ?? "";
            if (s === "CONFIRMED" || s === "RECEIVED" || s === "RECEIVED_IN_CASH") {
              update.subscription_status = "ACTIVE";

              // Reativação após pausa por falta de pagamento:
              // novo ciclo completo de 30 dias a partir da confirmação.
              const { data: perfil } = await supabaseAdmin
                .from("profiles")
                .select("next_due_date, asaas_next_due_date")
                .eq("asaas_subscription_id", subId)
                .maybeSingle();
              const vencimentoAnterior =
                perfil?.asaas_next_due_date ?? perfil?.next_due_date ?? null;
              const { resolverRenovacao } = await import("@/lib/renovacao-assinatura");
              const renovacao = resolverRenovacao(vencimentoAnterior, new Date());
              if (renovacao.reativada && renovacao.novoVencimento) {
                update.next_due_date = renovacao.novoVencimento;
                update.asaas_next_due_date = renovacao.novoVencimento;
                const { atualizarNextDueDateAsaas } = await import("@/lib/asaas-renovacao.server");
                await atualizarNextDueDateAsaas(subId, renovacao.novoVencimento);
              }
            } else if (s === "OVERDUE") {
              update.subscription_status = "OVERDUE";
            } else if (s === "REFUNDED" || s === "REFUND_REQUESTED") {
              update.subscription_status = "REFUNDED";
            }
          }
        }


        const { error } = await supabaseAdmin
          .from("profiles")
          .update(update)
          .eq("asaas_subscription_id", subId);

        if (error) {
          console.error("[asaas-webhook] update falhou:", error.message);
          return new Response("db error", { status: 500 });
        }

        return new Response("ok");
      },
      // Alguns painéis fazem GET para validar disponibilidade
      GET: async () => new Response("ok"),
    },
  },
});
