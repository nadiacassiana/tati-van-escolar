import { createFileRoute } from "@tanstack/react-router";

/** Hora atual (0-23) no fuso de São Paulo. */
function horaBrasil(): number {
  return Number(
    new Intl.DateTimeFormat("en-GB", {
      timeZone: "America/Sao_Paulo",
      hour: "2-digit",
      hour12: false,
    }).format(new Date()),
  );
}

/**
 * Varredura de notificações (chamada por agendador externo/pg_cron a cada
 * poucos minutos). Protegida por token — nenhum dado é exposto sem ele.
 *
 * - Notificações agendadas (teste com o app fechado): sempre processadas.
 * - Aniversários do dia: apenas a partir das 8h de Brasília; a chave de
 *   deduplicação por aluno/dia impede envio repetido nas demais execuções.
 */
async function handler({ request }: { request: Request }) {
  const url = new URL(request.url);
  const token = process.env['NOTIFICACOES_CRON_TOKEN'];
  const enviado =
    request.headers.get("x-cron-token") ?? url.searchParams.get("token") ?? "";
  const apikey = request.headers.get("apikey") ?? "";
  const anon = process.env['SUPABASE_ANON_KEY'] ?? process.env['SUPABASE_PUBLISHABLE_KEY'] ?? "";

  const autorizado =
    (!!token && enviado === token) || (!!anon && apikey === anon);

  if (!autorizado) {
    return new Response("Unauthorized", { status: 401 });
  }

  const { processarNotificacoesAgendadas } = await import(
    "@/lib/notificacoes-agendadas.server"
  );
  const agendadas = await processarNotificacoesAgendadas();

  let aniversarios = { usuarios: 0, notificacoes: 0 };
  const forcar = url.searchParams.get("aniversarios") === "1";
  if (forcar || horaBrasil() >= 8) {
    const { sincronizarAniversariosDeTodos } = await import("@/lib/aniversarios.server");
    aniversarios = await sincronizarAniversariosDeTodos();
  }

  return Response.json({ ok: true, agendadas: agendadas.enviadas, ...aniversarios });
}

export const Route = createFileRoute("/api/public/notificacoes-cron")({
  server: { handlers: { GET: handler, POST: handler } },
});
