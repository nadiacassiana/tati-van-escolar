import { useEffect, useMemo, useState } from "react";
import { createFileRoute, useParams } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { SignaturePadDialog } from "@/components/signature-pad";
import { parseAssinatura, type DocumentoAssinavel } from "@/lib/assinatura";
import {
  buildContratoHTML,
  buildGarantiaHTML,
  compartilharImagensDocumento,
  documentoParaImagens,
  type ContratoDoc,
  type GarantiaDoc,
} from "@/lib/documento-html";
import { htmlToPdfBlob, downloadBlob } from "@/lib/contrato-pdf";

export const Route = createFileRoute("/assinar/$tipo/$id")({
  head: () => ({
    meta: [
      { title: "Assinar documento — Tati Van Escolar" },
      { name: "description", content: "Leia o documento do transporte escolar e assine digitalmente pelo celular." },
      { property: "og:title", content: "Assinar documento do transporte escolar" },
      { property: "og:description", content: "Leia e assine digitalmente o documento enviado pela van escolar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AssinarDocumentoPage,
});

type Doc = Record<string, unknown> & {
  tipo?: string;
  aluno_nome?: string;
  marca?: { nome?: string; logo?: string | null };
};

function texto(v: unknown): string {
  return typeof v === "string" && v.trim() ? v.trim() : "—";
}

function AssinarDocumentoPage() {
  const { tipo, id } = useParams({ from: "/assinar/$tipo/$id" });
  const [doc, setDoc] = useState<Doc | null>(null);
  const [loading, setLoading] = useState(true);
  const [padOpen, setPadOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [baixando, setBaixando] = useState(false);

  const carregar = async () => {
    setLoading(true);
    const { data, error } = await supabase.rpc("get_documento_assinatura", {
      _tipo: tipo,
      _id: id,
    });
    setLoading(false);
    if (error || !data) {
      setDoc(null);
      return;
    }
    setDoc(data as Doc);
  };

  useEffect(() => {
    void carregar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tipo, id]);

  const isGarantia = (doc?.tipo || tipo) === "garantia";

  /** Documento completo, com as assinaturas já registradas. */
  const html = useMemo(() => {
    if (!doc) return "";
    const marca = {
      nome: (doc.marca?.nome || "Transporte Escolar").trim(),
      logo: doc.marca?.logo || undefined,
    };
    if (isGarantia) {
      const g = doc as unknown as GarantiaDoc & { tipo_garantia?: string };
      return buildGarantiaHTML({ ...g, tipo: g.tipo_garantia || "reserva" }, marca);
    }
    const nomeMotorista =
      (typeof (doc.marca as { nome_completo?: string } | undefined)?.nome_completo === "string"
        ? ((doc.marca as { nome_completo?: string }).nome_completo as string)
        : "") || marca.nome;
    return buildContratoHTML(doc as unknown as ContratoDoc, nomeMotorista, marca);
  }, [doc, isGarantia]);

  const nomeArquivo = `${isGarantia ? "reserva-de-vaga" : "contrato"}-${String(doc?.aluno_nome || "documento")
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .toLowerCase()}`;

  const baixarPdf = async () => {
    if (!html) return;
    setBaixando(true);
    try {
      const blob = await htmlToPdfBlob(html);
      downloadBlob(blob, `${nomeArquivo}.pdf`);
    } catch (e) {
      console.error("[assinar] falha ao gerar PDF", e);
      toast.error("Não foi possível gerar o PDF.");
    }
    setBaixando(false);
  };

  const compartilhar = async () => {
    if (!html) return;
    const t = toast.loading("Preparando o documento...");
    const imagens = await documentoParaImagens(html);
    toast.dismiss(t);
    if (!imagens.length) {
      toast.error("Não foi possível preparar o documento.");
      return;
    }
    const r = await compartilharImagensDocumento(imagens, nomeArquivo, {
      title: isGarantia ? "Reserva de vaga" : "Contrato de transporte escolar",
      text: `${isGarantia ? "Reserva de vaga" : "Contrato"} — ${texto(doc?.aluno_nome)}`,
    });
    if (r === "downloaded") toast.success("Documento salvo no seu aparelho.");
  };

  const assinar = async (dados: { imagem: string; nome: string }) => {
    if (dados.imagem.length > 380000) {
      toast.error("A assinatura ficou muito grande. Refaça com traços mais simples.");
      return;
    }
    setSaving(true);
    const { data, error } = await supabase.rpc("assinar_documento_responsavel", {
      _tipo: tipo,
      _id: id,
      _nome: dados.nome,
      _imagem: dados.imagem,
    });
    setSaving(false);
    const res = (data ?? {}) as { ok?: boolean; erro?: string };
    if (error || !res.ok) {
      const msgs: Record<string, string> = {
        nome_invalido: "Digite seu nome completo.",
        imagem_invalida: "Não conseguimos ler a assinatura. Tente novamente.",
        aguardando_motorista: "O documento ainda não foi assinado pela van.",
        ja_assinado: "Este documento já foi assinado.",
        nao_encontrado: "Documento não encontrado.",
      };
      toast.error(msgs[res.erro || ""] || "Não foi possível registrar a assinatura.");
      return;
    }
    setPadOpen(false);
    toast.success("Assinatura registrada. Obrigado! 💙");
    void carregar();
  };

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center p-6 text-muted-foreground">
        Carregando documento…
      </main>
    );
  }

  if (!doc) {
    return (
      <main className="flex min-h-screen items-center justify-center p-6">
        <Card className="max-w-sm p-6 text-center">
          <h1 className="text-lg font-bold">Documento não encontrado</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Confira o link enviado pela van escolar ou peça um novo.
          </p>
        </Card>
      </main>
    );
  }

  const marcaNome = texto(doc.marca?.nome);
  const aMot = parseAssinatura(doc.assinatura_motorista);
  const aResp = parseAssinatura(doc.assinatura_responsavel);

  return (
    <main className="mx-auto min-h-screen w-full max-w-2xl space-y-4 p-4 sm:p-6">
      <header className="flex items-center gap-3">
        {doc.marca?.logo ? (
          <img src={doc.marca.logo} alt={`Logotipo de ${marcaNome}`} className="h-12 w-12 rounded-xl object-contain" />
        ) : (
          <span className="text-3xl" aria-hidden>🚌</span>
        )}
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">
            {isGarantia ? "Reserva de vaga" : "Contrato de transporte escolar"}
          </p>
          <h1 className="text-lg font-bold">{marcaNome}</h1>
        </div>
      </header>

      <Card className="p-4 text-sm">
        <p className="font-semibold">
          {aResp
            ? "✅ Documento assinado pelas duas partes."
            : aMot
            ? "Leia o documento completo abaixo. Ele já está assinado pela van escolar."
            : "Este documento ainda aguarda a assinatura da van escolar."}
        </p>
        <p className="mt-1 text-muted-foreground">
          Aluno(a): <strong className="text-foreground">{texto(doc.aluno_nome)}</strong>
        </p>
      </Card>

      {/* Leitura do documento completo — antes de qualquer assinatura */}
      <Card className="overflow-hidden p-0">
        <iframe
          title={isGarantia ? "Reserva de vaga" : "Contrato de transporte escolar"}
          srcDoc={html}
          className="h-[70vh] w-full bg-white"
          style={{ border: 0 }}
        />
      </Card>

      <div className="grid gap-2 sm:grid-cols-2">
        <Button variant="outline" onClick={() => void baixarPdf()} disabled={baixando}>
          ⬇️ Baixar PDF
        </Button>
        <Button variant="outline" onClick={() => void compartilhar()}>
          📤 Compartilhar
        </Button>
      </div>


      {aResp ? (
        <Card className="border-success/40 bg-success/10 p-4 text-center text-sm font-semibold text-success">
          ✅ Documento assinado. Obrigado!
        </Card>
      ) : !aMot ? (
        <Card className="p-4 text-center text-sm text-muted-foreground">
          Este documento ainda está aguardando a assinatura da van. Tente novamente em instantes.
        </Card>
      ) : (
        <div className="sticky bottom-3 space-y-2">
          <p className="text-center text-xs text-muted-foreground">
            Ao assinar, você declara que leu o documento acima e está de acordo.
          </p>
          <Button className="w-full font-bold" size="lg" onClick={() => setPadOpen(true)}>
            ✍️ Assinar documento
          </Button>
        </div>
      )}

      <SignaturePadDialog
        open={padOpen}
        onOpenChange={setPadOpen}
        papel="responsavel"
        nomePadrao={texto(doc.responsavel_nome ?? doc.responsavel) === "—" ? "" : String(doc.responsavel_nome ?? doc.responsavel)}
        documentoLabel={`${isGarantia ? "Reserva de vaga" : "Contrato"} — ${texto(doc.aluno_nome)}`}
        saving={saving}
        onAceitar={assinar}
      />
    </main>
  );
}

export default AssinarDocumentoPage;

const _tipoCheck: DocumentoAssinavel[] = ["contrato", "garantia"];
void _tipoCheck;
