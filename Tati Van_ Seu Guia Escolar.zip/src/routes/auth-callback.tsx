import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth-callback")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Entrando… — Tati Van Escolar" },
      { name: "description", content: "Finalizando o seu acesso com segurança na Tati Van Escolar." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Entrando na Tati Van Escolar" },
      { property: "og:description", content: "Finalizando o seu acesso com segurança." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthCallback,
});

/** Lê os tokens devolvidos pelo Google, tanto em ?query quanto em #hash. */
export function readTokensFromUrl(href: string) {
  const url = new URL(href);
  const hash = new URLSearchParams(url.hash.replace(/^#/, ""));
  const pick = (k: string) => url.searchParams.get(k) ?? hash.get(k);
  const access_token = pick("access_token");
  const refresh_token = pick("refresh_token");
  const error = pick("error_description") ?? pick("error");
  if (access_token && refresh_token) return { access_token, refresh_token, error: null as string | null };
  return { access_token: null, refresh_token: null, error };
}

function AuthCallback() {
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    let vivo = true;
    (async () => {
      const { access_token, refresh_token, error } = readTokensFromUrl(window.location.href);
      try {
        if (access_token && refresh_token) {
          const { error: e } = await supabase.auth.setSession({ access_token, refresh_token });
          if (e) throw e;
          // Limpa os tokens da barra de endereços.
          window.history.replaceState({}, "", "/auth-callback");
        }
        // A sessão pode levar alguns milissegundos para ficar disponível.
        for (let tentativa = 0; tentativa < 10; tentativa++) {
          const { data } = await supabase.auth.getSession();
          if (!vivo) return;
          if (data.session) {
            // Redirecionamento direto ao painel, sem passar pela landing/login.
            window.location.replace("/dashboard");
            return;
          }
          await new Promise((r) => setTimeout(r, 200));
        }
        if (!vivo) return;
        setErro(error || "Não conseguimos concluir a entrada com o Google.");
      } catch (e) {
        console.error("[auth] callback do Google falhou:", e);
        if (vivo) setErro("Não conseguimos concluir a entrada com o Google.");
      }
    })();
    return () => {
      vivo = false;
    };
  }, []);

  return (
    <div className="flex min-h-screen items-center justify-center p-6 text-center">
      {erro ? (
        <div className="max-w-sm space-y-4">
          <p className="text-sm text-muted-foreground">{erro}</p>
          <a
            href="/auth"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
          >
            Voltar para o login
          </a>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">Entrando… 🚐</p>
      )}
    </div>
  );
}
