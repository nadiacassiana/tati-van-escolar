import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AlertCircle, Eye, EyeOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { trackEvent } from "@/lib/track-event";
import { Checkbox } from "@/components/ui/checkbox";
import { maskPhoneBR, isValidPhoneBR } from "@/lib/phone-mask";
import { forceSignOut, purgeCorruptedSession } from "@/lib/session-guard";
import { PasswordRequirements } from "@/components/password-requirements";
import { firstPasswordError, isStrongPassword } from "@/lib/password-policy";
import { isGoogleOnlyAccount } from "@/lib/auth-provider.functions";

/** Nunca deixa a tela em carregamento infinito: toda chamada tem prazo. */
async function withTimeout<T>(promise: PromiseLike<T>, ms = 20000): Promise<T> {
  return await Promise.race([
    promise as Promise<T>,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error("timeout")), ms),
    ),
  ]);
}

function PasswordInput({
  id,
  value,
  onChange,
  placeholder,
  minLength,
  error,
}: {
  id: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  minLength?: number;
  error?: boolean;
}) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <Input
        id={id}
        type={show ? "text" : "password"}
        required
        minLength={minLength}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`pr-10 ${error ? "border-red-500 focus-visible:ring-red-500 focus-visible:ring-1" : ""}`}
        aria-invalid={error ? "true" : "false"}
      />
      <button
        type="button"
        onClick={() => setShow((s) => !s)}
        className="absolute inset-y-0 right-0 flex items-center px-3 text-muted-foreground hover:text-foreground"
        aria-label={show ? "Ocultar senha" : "Mostrar senha"}
        tabIndex={-1}
      >
        {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </button>
    </div>
  );
}

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Entrar — Tati Van Escolar" }] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [nome, setNome] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [whatsConsent, setWhatsConsent] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotLoading, setForgotLoading] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [passwordError, setPasswordError] = useState(false);
  const [googleOnly, setGoogleOnly] = useState(false);


  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotLoading(true);
    // Uma sessão quebrada não pode impedir a redefinição de senha.
    purgeCorruptedSession();
    let error: { message: string } | null = null;
    try {
      const res = await withTimeout(
        supabase.auth.resetPasswordForEmail(forgotEmail, {
          redirectTo: `${window.location.origin}/reset-password`,
        }),
      );
      error = res.error;
    } catch (e) {
      console.error("[auth] reset de senha falhou:", e);
      error = { message: "timeout" };
    }
    setForgotLoading(false);
    if (error) return toast.error("Não conseguimos enviar o e-mail. Verifique o endereço e tente novamente.");
    toast.success("Enviamos um link para redefinir sua senha 📧");
    setForgotOpen(false);
    setForgotEmail("");
  };

  useEffect(() => {
    // Limpa automaticamente sessões corrompidas (token gigante) antes de qualquer coisa.
    if (purgeCorruptedSession()) {
      toast.info("Sua sessão anterior foi reiniciada. Entre novamente, por favor.");
      return;
    }
    supabase.auth
      .getSession()
      .then(({ data }) => {
        if (data.session) navigate({ to: "/dashboard", replace: true });
      })
      .catch((e) => {
        console.error("[auth] falha ao ler a sessão:", e);
        purgeCorruptedSession();
      });
  }, [navigate]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setPasswordError(false);
    setGoogleOnly(false);
    setLoading(true);
    purgeCorruptedSession();
    let error: { message: string } | null = null;
    try {
      const res = await withTimeout(supabase.auth.signInWithPassword({ email, password }));
      error = res.error;
    } catch (e) {
      console.error("[auth] login falhou:", e);
      setLoading(false);
      setLoginError(
        "Não conseguimos concluir o login agora. Verifique sua internet e tente novamente. Se continuar, use \u201cSair e entrar novamente\u201d abaixo.",
      );
      return;
    }
    setLoading(false);
    if (error) {
      console.error("[auth] login recusado:", error.message);
      setPasswordError(true);
      setLoginError("E-mail ou senha incorretos. Verifique seus dados e tente novamente.");
      try {
        const r = await isGoogleOnlyAccount({ data: { email: email.trim() } });
        if (r.googleOnly) {
          setPasswordError(false);
          setGoogleOnly(true);
          setLoginError("Esta conta foi criada usando o Google. Para entrar, clique em \u201cContinuar com Google\u201d.");
        }
      } catch (e) {
        console.error("[auth] checagem do provedor falhou:", e);
      }
      return;
    }

    toast.success("Bem-vinda(o) de volta! 🚐");
    trackEvent("login");
    navigate({ to: "/dashboard", replace: true });
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValidPhoneBR(whatsapp)) {
      return toast.error("Informe um WhatsApp válido com DDD.");
    }
    const erroSenha = firstPasswordError(password);
    if (erroSenha) return toast.error(erroSenha);
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/dashboard`,
        data: { nome, whatsapp, whatsapp_consent: whatsConsent },
      },
    });
    if (error) {
      setLoading(false);
      return toast.error(error.message);
    }
    // Se a sessão não veio (confirmação de e-mail), tenta logar direto
    if (!data.session) {
      const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (signInError) {
        return toast.success("Conta criada! Verifique seu e-mail para confirmar e entrar 📧");
      }
    } else {
      setLoading(false);
    }
    toast.success("Conta criada! Seu teste grátis de 10 dias começou 🎉");
    trackEvent("login", "primeiro acesso");
    navigate({ to: "/dashboard", replace: true });
  };

  const handleGoogle = async () => {
    // O retorno do Google precisa cair numa página pública que saiba criar a sessão.
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: `${window.location.origin}/auth-callback`,
      extraParams: {
        // Tela do Google em português do Brasil e escolha de conta explícita.
        hl: "pt-BR",
        prompt: "select_account",
      },
    });
    if (result.error) return toast.error("Não consegui entrar com o Google");
    if (result.redirected) return;
    navigate({ to: "/dashboard", replace: true });
  };


  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4" style={{ background: "var(--gradient-hero)" }}>
      <div className="w-full max-w-md rounded-3xl bg-card p-8 shadow-2xl">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-accent text-3xl">
            🚐
          </div>
          <h1 className="text-2xl font-extrabold">Tati Van Escolar</h1>
          <p className="text-sm text-muted-foreground">Sua assistente para a rotina da van</p>
        </div>

        <Tabs defaultValue="signin" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="signin">Entrar</TabsTrigger>
            <TabsTrigger value="signup">Criar conta</TabsTrigger>
          </TabsList>

          <TabsContent value="signin">
            <form onSubmit={handleSignIn} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="email">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setLoginError("");
                    setPasswordError(false);
                    setGoogleOnly(false);
                  }}
                  placeholder="voce@email.com"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Senha</Label>
                  <button
                    type="button"
                    onClick={() => { setForgotEmail(email); setForgotOpen(true); }}
                    className="text-xs font-medium text-primary hover:underline"
                  >
                    Esqueci minha senha
                  </button>
                </div>
                <PasswordInput
                  id="password"
                  value={password}
                  onChange={(v) => {
                    setPassword(v);
                    setLoginError("");
                    setPasswordError(false);
                    setGoogleOnly(false);
                  }}
                  placeholder="••••••••"
                  error={passwordError}
                />
              </div>
              {loginError && (
                googleOnly ? (
                  <div className="space-y-3 rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <span>{loginError}</span>
                    </div>
                    <Button type="button" onClick={handleGoogle} variant="outline" className="w-full">
                      Continuar com Google
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-600 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-400">
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                    <span>{loginError}</span>
                  </div>
                )
              )}

              <Button type="submit" disabled={loading} className="w-full bg-primary text-primary-foreground font-bold">
                {loading ? "Entrando..." : "Entrar"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="signup">
            <form onSubmit={handleSignUp} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="nome">Seu nome</Label>
                <Input id="nome" required value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Como podemos te chamar?" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email2">E-mail</Label>
                <Input id="email2" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@email.com" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="whats">WhatsApp 📱</Label>
                <Input
                  id="whats"
                  type="tel"
                  required
                  inputMode="numeric"
                  value={whatsapp}
                  onChange={(e) => setWhatsapp(maskPhoneBR(e.target.value))}
                  placeholder="(11) 99999-9999"
                />
                <label className="flex items-start gap-2 rounded-lg bg-muted/40 p-2.5 text-xs text-muted-foreground cursor-pointer">
                  <Checkbox
                    checked={whatsConsent}
                    onCheckedChange={(v) => setWhatsConsent(v === true)}
                    className="mt-0.5"
                  />
                  <span>
                    Autorizo a Tati Assistente Virtual a entrar em contato comigo pelo WhatsApp para
                    assuntos relacionados à minha conta, suporte, novidades, atualizações da plataforma,
                    lembretes importantes e comunicações sobre minha assinatura.
                  </span>
                </label>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password2">Senha</Label>
                <PasswordInput id="password2" value={password} onChange={setPassword} minLength={8} placeholder="Ex.: Tati@2026" />
                <PasswordRequirements value={password} />
              </div>
              <Button
                type="submit"
                disabled={loading || !isStrongPassword(password)}
                className="w-full bg-accent text-accent-foreground font-bold hover:bg-accent/90"
              >
                {loading ? "Criando..." : "Começar 10 dias grátis 🎉"}
              </Button>
            </form>
          </TabsContent>
        </Tabs>

        <div className="my-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-border" />
          <span className="text-xs text-muted-foreground">ou</span>
          <div className="h-px flex-1 bg-border" />
        </div>

        <Button onClick={handleGoogle} variant="outline" className="w-full">
          <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
            <path fill="#FBBC05" d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.84z" />
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z" />
          </svg>
          Entrar com Google
        </Button>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          Ao continuar, você concorda com nossos{" "}
          <a href="/termos-de-uso" className="font-medium text-primary hover:underline">
            Termos de Uso
          </a>{" "}
          e nossa{" "}
          <a href="/privacidade" className="font-medium text-primary hover:underline">
            Política de Privacidade
          </a>
          .
        </p>
        <p className="mt-3 text-center text-xs text-muted-foreground">
          Precisa de ajuda?{" "}
          <a href="/suporte" className="font-medium text-primary hover:underline">
            Fale com o Suporte
          </a>{" "}
          ou{" "}
          <a href="/contato" className="font-medium text-primary hover:underline">
            entre em Contato
          </a>
          .
        </p>
      </div>

      <button
        type="button"
        onClick={async () => {
          await forceSignOut();
          toast.success("Sessão limpa. Faça login novamente. 🔄");
          window.location.replace("/auth");
        }}
        className="mt-4 text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground"
      >
        Problemas para entrar? Sair e entrar novamente
      </button>

      <Dialog open={forgotOpen} onOpenChange={setForgotOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Redefinir senha</DialogTitle>
            <DialogDescription>
              Informe o e-mail cadastrado e enviaremos um link seguro para você criar uma nova senha.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleForgotPassword} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="forgot-email">E-mail</Label>
              <Input
                id="forgot-email"
                type="email"
                required
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
                placeholder="voce@email.com"
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setForgotOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={forgotLoading} className="bg-primary text-primary-foreground font-bold">
                {forgotLoading ? "Enviando..." : "Enviar link"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
