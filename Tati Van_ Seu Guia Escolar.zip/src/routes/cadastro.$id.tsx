import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { DateInputBR } from "@/components/date-input-br";
import { maskPhoneBR } from "@/lib/phone-mask";
import { maskCPF } from "@/lib/cpf-cnpj";
import { Bus, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/cadastro/$id")({
  head: () => ({
    meta: [
      { title: "Ficha de cadastro do aluno — Tati Van Escolar" },
      { name: "description", content: "Preencha os dados do aluno para o transporte escolar. Formulário rápido e seguro." },
      { property: "og:title", content: "Ficha de cadastro do aluno — Tati Van Escolar" },
      { property: "og:description", content: "Preencha os dados do aluno para o transporte escolar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: CadastroPublicoPage,
});

const emptyForm = {
  aluno_nome: "",
  data_nascimento: "",
  escola: "",
  serie: "",
  rua: "",
  numero: "",
  bairro: "",
  cidade: "",
  estado: "",
  cep: "",
  referencia: "",
  responsavel_nome: "",
  responsavel_whatsapp: "",
  responsavel_cpf: "",
  responsavel_email: "",
  telefone_emergencia: "",
  pessoas_autorizadas: "",
  observacoes: "",
  autoriza_imagem: "" as "" | "sim" | "nao",
};

function CadastroPublicoPage() {
  const { id } = Route.useParams();
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [enviado, setEnviado] = useState(false);
  const [escolas, setEscolas] = useState<string[]>([]);

  useEffect(() => {
    let ativo = true;
    void (async () => {
      const { data } = await supabase.rpc("get_escolas_publicas", { _user_id: id });
      if (!ativo) return;
      const nomes = ((data as { nome: string }[] | null) || []).map((e) => e.nome).filter(Boolean);
      setEscolas(nomes);
    })();
    return () => {
      ativo = false;
    };
  }, [id]);

  const set = (k: keyof typeof emptyForm, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const enviar = async () => {
    const obrigatorios: [keyof typeof emptyForm, string][] = [
      ["aluno_nome", "Nome completo do aluno"],
      ["data_nascimento", "Data de nascimento"],
      ["escola", "Escola"],
      ["serie", "Série/Ano"],
      ["rua", "Rua"],
      ["numero", "Número"],
      ["bairro", "Bairro"],
      ["cidade", "Cidade"],
      ["estado", "Estado/UF"],
      ["referencia", "Ponto de referência"],
      ["responsavel_nome", "Nome do responsável"],
      ["responsavel_whatsapp", "WhatsApp do responsável"],
    ];
    const faltando = obrigatorios.find(([k]) => !String(form[k]).trim());
    if (faltando) {
      toast.error(`Preencha: ${faltando[1]}`);
      return;
    }
    if (form.responsavel_email && !/^\S+@\S+\.\S+$/.test(form.responsavel_email.trim())) {
      toast.error("E-mail inválido.");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("pre_cadastros").insert({
      user_id: id,
      status: "pendente",
      aluno_nome: form.aluno_nome.trim().slice(0, 120),
      data_nascimento: form.data_nascimento || null,
      escola: form.escola.trim().slice(0, 120),
      serie: form.serie.trim().slice(0, 60),
      rua: form.rua.trim().slice(0, 160),
      numero: form.numero.trim().slice(0, 20),
      bairro: form.bairro.trim().slice(0, 120),
      cidade: form.cidade.trim().slice(0, 120),
      estado: form.estado.trim().toUpperCase().slice(0, 2),
      cep: form.cep.trim().slice(0, 12),
      referencia: form.referencia.trim().slice(0, 200),
      responsavel_nome: form.responsavel_nome.trim().slice(0, 120),
      responsavel_whatsapp: form.responsavel_whatsapp.trim().slice(0, 30),
      responsavel_cpf: form.responsavel_cpf.trim() || null,
      responsavel_email: form.responsavel_email.trim() || null,
      telefone_emergencia: form.telefone_emergencia.trim() || null,
      pessoas_autorizadas: form.pessoas_autorizadas.trim().slice(0, 500) || null,
      observacoes: form.observacoes.trim().slice(0, 500),
      autoriza_imagem: form.autoriza_imagem === "" ? null : form.autoriza_imagem === "sim",
    });
    setSaving(false);
    if (error) {
      toast.error("Não consegui enviar a ficha. Confira o link e tente novamente.");
      return;
    }
    setEnviado(true);
  };

  if (enviado) {
    return (
      <main className="mx-auto flex min-h-screen max-w-md items-center justify-center p-4">
        <Card className="w-full p-6 text-center">
          <CheckCircle2 className="mx-auto h-12 w-12 text-success" />
          <h1 className="mt-3 text-xl font-extrabold">Ficha enviada! 💙</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Recebemos os dados de <strong>{form.aluno_nome}</strong>. A motorista vai revisar e confirmar o cadastro em breve.
          </p>
        </Card>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-md space-y-4 p-4 pb-16">
      <header className="pt-4 text-center">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10">
          <Bus className="h-6 w-6 text-primary" />
        </div>
        <h1 className="mt-3 text-2xl font-extrabold">Ficha do aluno 🚐</h1>
        <p className="text-sm text-muted-foreground">Preencha os dados para o transporte escolar.</p>
      </header>

      <Card className="space-y-4 p-4">
        <div className="text-sm font-bold">Dados do aluno</div>
        <div className="space-y-1">
          <Label htmlFor="aluno_nome">Nome completo do aluno *</Label>
          <Input id="aluno_nome" value={form.aluno_nome} onChange={(e) => set("aluno_nome", e.target.value)} maxLength={120} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="nasc">Data de nascimento *</Label>
          <DateInputBR id="nasc" value={form.data_nascimento} onChange={(v) => set("data_nascimento", v)} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="escola">Escola *</Label>
          {escolas.length > 0 ? (
            <>
              <Input
                id="escola"
                list="escolas-lista"
                value={form.escola}
                onChange={(e) => set("escola", e.target.value)}
                maxLength={120}
                placeholder="Selecione ou digite a escola"
              />
              <datalist id="escolas-lista">
                {escolas.map((nome) => (
                  <option key={nome} value={nome} />
                ))}
              </datalist>
            </>
          ) : (
            <Input id="escola" value={form.escola} onChange={(e) => set("escola", e.target.value)} maxLength={120} />
          )}
        </div>
        <div className="space-y-1">
          <Label htmlFor="serie">Série / Ano *</Label>
          <Input id="serie" value={form.serie} onChange={(e) => set("serie", e.target.value)} maxLength={60} />
        </div>
      </Card>

      <Card className="space-y-4 p-4">
        <div className="text-sm font-bold">Endereço de embarque/desembarque</div>
        <div className="space-y-1">
          <Label htmlFor="rua">Rua *</Label>
          <Input id="rua" value={form.rua} onChange={(e) => set("rua", e.target.value)} maxLength={160} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label htmlFor="numero">Número *</Label>
            <Input id="numero" value={form.numero} onChange={(e) => set("numero", e.target.value)} maxLength={20} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="bairro">Bairro *</Label>
            <Input id="bairro" value={form.bairro} onChange={(e) => set("bairro", e.target.value)} maxLength={120} />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2 space-y-1">
            <Label htmlFor="cidade">Cidade *</Label>
            <Input id="cidade" value={form.cidade} onChange={(e) => set("cidade", e.target.value)} maxLength={120} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="estado">Estado/UF *</Label>
            <Input
              id="estado"
              value={form.estado}
              onChange={(e) => set("estado", e.target.value.replace(/[^a-zA-Z]/g, "").toUpperCase().slice(0, 2))}
              maxLength={2}
              placeholder="SP"
            />
          </div>
        </div>
        <div className="space-y-1">
          <Label htmlFor="cep">CEP (opcional)</Label>
          <Input
            id="cep"
            inputMode="numeric"
            value={form.cep}
            onChange={(e) => {
              const d = e.target.value.replace(/\D/g, "").slice(0, 8);
              set("cep", d.length > 5 ? `${d.slice(0, 5)}-${d.slice(5)}` : d);
            }}
            placeholder="00000-000"
          />
        </div>
        <div className="space-y-1">
          <Label htmlFor="referencia">Ponto de referência *</Label>
          <Input id="referencia" value={form.referencia} onChange={(e) => set("referencia", e.target.value)} maxLength={200} />
        </div>
      </Card>

      <Card className="space-y-4 p-4">
        <div className="text-sm font-bold">Responsável</div>
        <div className="space-y-1">
          <Label htmlFor="resp">Nome do responsável principal *</Label>
          <Input id="resp" value={form.responsavel_nome} onChange={(e) => set("responsavel_nome", e.target.value)} maxLength={120} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="zap">WhatsApp *</Label>
          <Input id="zap" inputMode="tel" value={form.responsavel_whatsapp} onChange={(e) => set("responsavel_whatsapp", maskPhoneBR(e.target.value))} placeholder="(11) 99999-9999" />
        </div>
        <div className="space-y-1">
          <Label htmlFor="cpf">CPF (opcional)</Label>
          <Input id="cpf" inputMode="numeric" value={form.responsavel_cpf} onChange={(e) => set("responsavel_cpf", maskCPF(e.target.value))} placeholder="000.000.000-00" />
        </div>
        <div className="space-y-1">
          <Label htmlFor="email">E-mail (opcional)</Label>
          <Input id="email" type="email" value={form.responsavel_email} onChange={(e) => set("responsavel_email", e.target.value)} maxLength={255} />
        </div>
        <div className="space-y-1">
          <Label htmlFor="emerg">Telefone de emergência (opcional)</Label>
          <Input id="emerg" inputMode="tel" value={form.telefone_emergencia} onChange={(e) => set("telefone_emergencia", maskPhoneBR(e.target.value))} placeholder="(11) 99999-9999" />
        </div>
        <div className="space-y-1">
          <Label htmlFor="autorizadas">Pessoas autorizadas a buscar/receber (opcional)</Label>
          <Textarea
            id="autorizadas"
            value={form.pessoas_autorizadas}
            onChange={(e) => set("pessoas_autorizadas", e.target.value)}
            placeholder="Ex.: Maria Silva — avó; João Souza — tio"
            rows={3}
            maxLength={500}
          />
        </div>
        <div className="space-y-2">
          <Label>Autoriza o uso de imagem do aluno em fotos/vídeos para divulgação do transporte escolar? (opcional)</Label>
          <div className="flex gap-4">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="radio"
                name="autoriza_imagem"
                checked={form.autoriza_imagem === "sim"}
                onChange={() => set("autoriza_imagem", "sim")}
              />
              Sim
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="radio"
                name="autoriza_imagem"
                checked={form.autoriza_imagem === "nao"}
                onChange={() => set("autoriza_imagem", "nao")}
              />
              Não
            </label>
          </div>
        </div>
        <div className="space-y-1">
          <Label htmlFor="obs">Observações / recados (opcional)</Label>
          <Textarea
            id="obs"
            value={form.observacoes}
            onChange={(e) => set("observacoes", e.target.value)}
            placeholder="Ex.: alergias, cuidados especiais, recados para a motorista"
            rows={3}
            maxLength={500}
          />
        </div>
      </Card>

      <Button className="w-full font-bold" size="lg" disabled={saving} onClick={enviar}>
        {saving ? "Enviando..." : "Enviar ficha"}
      </Button>
      <p className="text-center text-xs text-muted-foreground">
        Seus dados serão usados apenas para o cadastro no transporte escolar.
      </p>
    </main>
  );
}
