import { SUPORTE_WHATSAPP, suporteWhatsAppLink } from "@/lib/suporte";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Clock, Mail, MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/contato")({
  head: () => ({
    meta: [
      { title: "Entre em Contato — Tati Van Escolar" },
      {
        name: "description",
        content:
          "Entre em contato com a Tati Van Escolar. Fale conosco pelo WhatsApp Business ou e-mail durante nosso horário de atendimento.",
      },
      { property: "og:title", content: "Entre em Contato — Tati Van Escolar" },
      {
        property: "og:description",
        content:
          "Tem alguma dúvida, sugestão ou precisa falar conosco? Será um prazer atender você.",
      },
    ],
  }),
  component: ContatoPage,
});

const WHATSAPP_NUMBER = SUPORTE_WHATSAPP;
const WHATSAPP_LINK = suporteWhatsAppLink("Olá, Tati Van Escolar! Gostaria de entrar em contato.");
const EMAIL = "tatiassistentevirtualbr@gmail.com";
const MAILTO_LINK = `mailto:${EMAIL}?subject=Contato%20Tati%20Van%20Escolar`;

function ContatoPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header
        className="border-b"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-6 py-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-xl">
              🚐
            </div>
            <div className="text-primary-foreground">
              <div className="text-sm font-extrabold leading-none">Tati Van Escolar</div>
              <div className="mt-1 text-[10px] uppercase tracking-wider opacity-80">
                Assistente do motorista
              </div>
            </div>
          </Link>
          <Link to="/">
            <Button variant="secondary" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
          </Link>
        </div>
      </header>

      {/* Título */}
      <section className="border-b bg-secondary/30">
        <div className="mx-auto max-w-4xl px-6 py-10 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <MessageCircle className="h-7 w-7" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
            Entre em Contato
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Tem alguma dúvida, sugestão ou precisa falar conosco? Será um prazer atender você.
          </p>
        </div>
      </section>

      <main className="mx-auto max-w-4xl px-6 py-10">
        {/* Canais de contato */}
        <section className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {/* WhatsApp */}
          <div
            className="rounded-2xl border bg-card p-6"
            style={{ boxShadow: "var(--shadow-card)" }}
          >
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
              <Phone className="h-6 w-6" />
            </div>
            <h2 className="mb-1 flex items-center gap-2 text-base font-extrabold">
              <MessageCircle className="h-4 w-4 text-green-600" />
              WhatsApp Business
            </h2>
            <p className="mb-4 text-sm text-muted-foreground">+55 (11) 96460-0186</p>
            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
              <Button className="w-full bg-green-600 font-bold text-white hover:bg-green-700">
                Falar pelo WhatsApp
              </Button>
            </a>
          </div>

          {/* E-mail */}
          <div
            className="rounded-2xl border bg-card p-6"
            style={{ boxShadow: "var(--shadow-card)" }}
          >
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <Mail className="h-6 w-6" />
            </div>
            <h2 className="mb-1 text-base font-extrabold">E-mail</h2>
            <p className="mb-4 text-sm text-muted-foreground">{EMAIL}</p>
            <a href={MAILTO_LINK}>
              <Button variant="outline" className="w-full font-bold">
                Enviar e-mail
              </Button>
            </a>
          </div>

          {/* Horário */}
          <div
            className="rounded-2xl border bg-card p-6"
            style={{ boxShadow: "var(--shadow-card)" }}
          >
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-accent/20 text-accent-foreground">
              <Clock className="h-6 w-6" />
            </div>
            <h2 className="mb-1 text-base font-extrabold">Horário de atendimento</h2>
            <p className="mb-1 text-sm font-medium">Segunda a sexta-feira</p>
            <p className="mb-4 text-sm font-semibold">Das 9h às 18h</p>
            <p className="text-xs text-muted-foreground">
              Respondemos o mais rápido possível durante nosso horário de atendimento.
            </p>
          </div>
        </section>

        {/* Voltar para a página inicial */}
        <section className="mt-12 text-center">
          <Link to="/">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Voltar para a página inicial
            </Button>
          </Link>
        </section>
      </main>

      {/* Rodapé */}
      <footer className="border-t bg-secondary/30">
        <div className="mx-auto max-w-4xl px-6 py-10 text-center">
          <div className="mb-4 flex items-center justify-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-xl">
              🚐
            </div>
            <div className="text-left">
              <div className="text-sm font-extrabold leading-none">Tati Assistente Virtual</div>
              <div className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                Ecossistema Tati Van Escolar
              </div>
            </div>
          </div>
          <p className="mx-auto max-w-xl text-sm text-muted-foreground">
            “Cuidando da tecnologia para que você cuide do transporte escolar com mais
            tranquilidade.”
          </p>
          <div className="mt-8 text-xs text-muted-foreground">
            © {new Date().getFullYear()} Tati Assistente Virtual. Todos os direitos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
}
