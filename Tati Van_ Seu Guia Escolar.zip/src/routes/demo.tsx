import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  Bus, CheckCircle2, Home, MapPin, MessageCircle, Receipt, Rocket, School, Users, Wallet,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { formatBRL } from "@/lib/format";
import { SUPORTE_WHATSAPP } from "@/lib/suporte";

const CTA_MSG = "Olá! Testei o simulador do Tati Van Escolar e quero ativar meus 10 dias grátis.";
const CTA_URL = `https://wa.me/${SUPORTE_WHATSAPP}?text=${encodeURIComponent(CTA_MSG)}`;

export const Route = createFileRoute("/demo")({
  head: () => ({
    meta: [
      { title: "Demonstração Interativa — Tati Van Escolar" },
      {
        name: "description",
        content:
          "Teste grátis e sem login o app do motorista escolar: checklist com GPS, visão do pai no mapa, recibos digitais e lembrete de cobrança no WhatsApp.",
      },
      { property: "og:title", content: "Demonstração Interativa — Tati Van Escolar" },
      {
        property: "og:description",
        content:
          "Simule uma rota, dê presença nos alunos, gere recibo e envie lembrete de cobrança. Sem cadastro.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DemoPage,
});

type AlunoDemo = {
  id: string;
  nome: string;
  avatar: string;
  escola: string;
  endereco: string;
  status: "aguardando" | "embarcado" | "entregue" | "ausente";
};

const ALUNOS_INICIAIS: AlunoDemo[] = [
  { id: "1", nome: "João", avatar: "🧒", escola: "Recanto Feliz", endereco: "Rua das Flores, 120", status: "aguardando" },
  { id: "2", nome: "Maria", avatar: "👧", escola: "Saber Mais", endereco: "Av. Brasil, 1450", status: "aguardando" },
  { id: "3", nome: "Felipe", avatar: "👦", escola: "Recanto Feliz", endereco: "Rua Pedro Álvares, 88", status: "aguardando" },
  { id: "4", nome: "Sofia", avatar: "👧", escola: "Saber Mais", endereco: "Rua Bela Vista, 17", status: "aguardando" },
];

function DemoPage() {
  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="bg-[image:var(--gradient-hero)] px-4 py-6 text-primary-foreground">
        <div className="mx-auto max-w-md">
          <Badge className="mb-2 bg-accent text-accent-foreground">Demonstração sem cadastro</Badge>
          <h1 className="text-2xl font-extrabold leading-tight">
            Experimente o Tati Van Escolar 🚐
          </h1>
          <p className="mt-1 text-sm opacity-90">
            Toque nos botões e veja como é o dia a dia com o app: rota com GPS, recibo na hora e
            cobrança educada no WhatsApp.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-md px-4 py-4">
        <Tabs defaultValue="rota">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="rota" className="text-xs font-bold">
              <Bus className="mr-1 h-4 w-4" /> Rota e GPS
            </TabsTrigger>
            <TabsTrigger value="financeiro" className="text-xs font-bold">
              <Wallet className="mr-1 h-4 w-4" /> Financeiro
            </TabsTrigger>
          </TabsList>

          <TabsContent value="rota" className="mt-4">
            <AbaRota />
          </TabsContent>
          <TabsContent value="financeiro" className="mt-4">
            <AbaFinanceiro />
          </TabsContent>
        </Tabs>
      </main>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t bg-card/95 p-3 backdrop-blur">
        <a href={CTA_URL} target="_blank" rel="noreferrer" className="mx-auto block max-w-md">
          <Button className="h-12 w-full text-sm font-extrabold shadow-[var(--shadow-soft)]">
            <Rocket className="mr-2 h-5 w-5" /> Gostou? Ativar 10 Dias Grátis no WhatsApp
          </Button>
        </a>
      </div>
    </div>
  );
}

/* ---------------------------- Aba 1: Rota e GPS ---------------------------- */

function AbaRota() {
  const [alunos, setAlunos] = useState<AlunoDemo[]>(ALUNOS_INICIAIS);
  const [mapaAberto, setMapaAberto] = useState(false);

  const embarcados = alunos.filter((a) => a.status === "embarcado").length;
  const marcados = alunos.filter((a) => a.status !== "aguardando").length;

  function marcar(id: string, status: AlunoDemo["status"]) {
    setAlunos((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
  }

  return (
    <div className="space-y-3">
      <Badge variant="secondary" className="font-bold">Plano Premium</Badge>

      <Card className="border-primary/20">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Users className="h-4 w-4 text-primary" /> Checklist da Ida — Manhã
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="text-xs text-muted-foreground">
            {marcados} de {alunos.length} alunos conferidos • {embarcados} na van
          </div>
          {alunos.map((a) => (
            <div key={a.id} className="rounded-xl border p-3">
              <div className="flex items-center gap-2">
                <span className="text-xl">{a.avatar}</span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-bold">{a.nome}</div>
                  <div className="truncate text-xs text-muted-foreground">
                    {a.endereco} • {a.escola}
                  </div>
                </div>
                <StatusPill status={a.status} />
              </div>
              <div className="mt-2 grid grid-cols-3 gap-2">
                <Button size="sm" variant={a.status === "embarcado" ? "default" : "outline"} onClick={() => marcar(a.id, "embarcado")}>
                  Embarcou
                </Button>
                <Button size="sm" variant={a.status === "entregue" ? "default" : "outline"} onClick={() => marcar(a.id, "entregue")}>
                  Na escola
                </Button>
                <Button size="sm" variant={a.status === "ausente" ? "destructive" : "outline"} onClick={() => marcar(a.id, "ausente")}>
                  Faltou
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Button className="h-12 w-full font-bold" variant="secondary" onClick={() => setMapaAberto(true)}>
        <MapPin className="mr-2 h-4 w-4" /> Visão do Pai — ver a van no mapa
      </Button>

      <MapaSimulado open={mapaAberto} onOpenChange={setMapaAberto} />
    </div>
  );
}

function StatusPill({ status }: { status: AlunoDemo["status"] }) {
  const map: Record<AlunoDemo["status"], { t: string; c: string }> = {
    aguardando: { t: "Aguardando", c: "bg-muted text-muted-foreground" },
    embarcado: { t: "Na van", c: "bg-primary text-primary-foreground" },
    entregue: { t: "Na escola", c: "bg-success text-success-foreground" },
    ausente: { t: "Faltou", c: "bg-destructive text-destructive-foreground" },
  };
  const s = map[status];
  return <span className={`rounded-full px-2 py-1 text-[10px] font-bold ${s.c}`}>{s.t}</span>;
}

/** Mapa fictício e leve (SVG animado) — sem Google Maps, carrega instantâneo. */
function MapaSimulado({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [t, setT] = useState(0);
  const raf = useRef<number | null>(null);

  useEffect(() => {
    if (!open) return;
    let inicio = performance.now();
    const loop = (now: number) => {
      const p = ((now - inicio) / 14000) % 1;
      setT(p);
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
    };
  }, [open]);

  // Trajeto: casa (30,230) -> curva -> escola (270,60)
  const pontos = useMemo(
    () => [
      { x: 30, y: 230 },
      { x: 90, y: 200 },
      { x: 120, y: 140 },
      { x: 190, y: 120 },
      { x: 230, y: 80 },
      { x: 270, y: 60 },
    ],
    [],
  );

  const pos = posicaoNaRota(pontos, t);
  const prox = posicaoNaRota(pontos, Math.min(t + 0.02, 1));
  const angulo = (Math.atan2(prox.y - pos.y, prox.x - pos.x) * 180) / Math.PI;

  const minutos = Math.max(1, Math.round((1 - t) * 12));
  const status =
    t < 0.15 ? "Saiu da casa do aluno" : t > 0.85 ? "Chegando na escola" : "A caminho da escola";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Visão do responsável 👨‍👩‍👧</DialogTitle>
          <DialogDescription>
            É isso que o pai ou a mãe vê no link, em tempo real, sem instalar nada.
          </DialogDescription>
        </DialogHeader>

        <div className="overflow-hidden rounded-xl border bg-secondary">
          <svg viewBox="0 0 300 260" className="h-56 w-full">
            <rect width="300" height="260" fill="var(--secondary)" />
            {[40, 100, 160, 220].map((y) => (
              <line key={y} x1="0" y1={y} x2="300" y2={y} stroke="var(--border)" strokeWidth="6" />
            ))}
            {[60, 150, 240].map((x) => (
              <line key={x} x1={x} y1="0" x2={x} y2="260" stroke="var(--border)" strokeWidth="6" />
            ))}
            <polyline
              points={pontos.map((p) => `${p.x},${p.y}`).join(" ")}
              fill="none"
              stroke="var(--primary)"
              strokeWidth="5"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.85"
            />
            <g transform={`translate(${pos.x},${pos.y}) rotate(${angulo})`}>
              <circle r="13" fill="var(--accent)" stroke="var(--primary)" strokeWidth="2" />
              <text x="-8" y="5" fontSize="14">🚐</text>
            </g>
            <text x="18" y="248" fontSize="20">🏠</text>
            <text x="258" y="52" fontSize="20">🏫</text>
          </svg>
        </div>

        <div className="rounded-xl border bg-card p-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[image:var(--gradient-sun)] text-lg">
              🧑‍✈️
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-bold">Tia Tati • Van Escolar</div>
              <div className="text-xs text-muted-foreground">{status}</div>
            </div>
            <div className="text-right">
              <div className="text-lg font-extrabold text-primary">{minutos} min</div>
              <div className="text-[10px] text-muted-foreground">previsão</div>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-1 rounded-lg bg-muted p-2">
              <Home className="h-3 w-3" /> Casa do aluno
            </div>
            <div className="flex items-center gap-1 rounded-lg bg-muted p-2">
              <School className="h-3 w-3" /> Escola de destino
            </div>
          </div>
        </div>

        <a href={CTA_URL} target="_blank" rel="noreferrer">
          <Button className="w-full font-bold">
            <Rocket className="mr-2 h-4 w-4" /> Quero isso na minha van
          </Button>
        </a>
      </DialogContent>
    </Dialog>
  );
}

function posicaoNaRota(pontos: { x: number; y: number }[], t: number) {
  const total = pontos.length - 1;
  const escala = Math.min(Math.max(t, 0), 0.999) * total;
  const i = Math.floor(escala);
  const f = escala - i;
  const a = pontos[i];
  const b = pontos[i + 1] ?? pontos[i];
  return { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f };
}

/* ------------------------ Aba 2: Financeiro e cobrança ---------------------- */

type MensalidadeDemo = {
  id: string;
  aluno: string;
  responsavel: string;
  avatar: string;
  valor: number;
  vencimento: string;
  status: "pago" | "atrasado" | "a_vencer";
};

const MENSALIDADES: MensalidadeDemo[] = [
  { id: "1", aluno: "João Silva", responsavel: "Mariana", avatar: "🧒", valor: 380, vencimento: "05/09/2026", status: "pago" },
  { id: "2", aluno: "Felipe Costa", responsavel: "Camila", avatar: "👦", valor: 420, vencimento: "05/09/2026", status: "atrasado" },
  { id: "3", aluno: "Sofia Oliveira", responsavel: "Daniel", avatar: "👧", valor: 380, vencimento: "15/09/2026", status: "a_vencer" },
];

function AbaFinanceiro() {
  const [lista, setLista] = useState(MENSALIDADES);
  const [recibo, setRecibo] = useState<MensalidadeDemo | null>(null);
  const [cobranca, setCobranca] = useState<MensalidadeDemo | null>(null);

  function darBaixa(m: MensalidadeDemo) {
    setLista((prev) => prev.map((x) => (x.id === m.id ? { ...x, status: "pago" } : x)));
    setRecibo({ ...m, status: "pago" });
  }

  return (
    <div className="space-y-3">
      <Badge variant="secondary" className="font-bold">Plano Básico</Badge>

      {lista.map((m) => (
        <Card key={m.id}>
          <CardContent className="space-y-3 p-3">
            <div className="flex items-center gap-2">
              <span className="text-xl">{m.avatar}</span>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-bold">{m.aluno}</div>
                <div className="text-xs text-muted-foreground">
                  Vence {m.vencimento} • R$ {formatBRL(m.valor)}
                </div>
              </div>
              <span
                className={`rounded-full px-2 py-1 text-[10px] font-bold ${
                  m.status === "pago"
                    ? "bg-success text-success-foreground"
                    : m.status === "atrasado"
                      ? "bg-destructive text-destructive-foreground"
                      : "bg-warning text-warning-foreground"
                }`}
              >
                {m.status === "pago" ? "Pago" : m.status === "atrasado" ? "Atrasado" : "A vencer"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {m.status === "pago" ? (
                <Button size="sm" variant="outline" onClick={() => setRecibo(m)}>
                  <Receipt className="mr-1 h-3 w-3" /> Ver recibo
                </Button>
              ) : (
                <Button size="sm" onClick={() => darBaixa(m)}>
                  <CheckCircle2 className="mr-1 h-3 w-3" /> Dar baixa
                </Button>
              )}
              <Button size="sm" variant="outline" onClick={() => setCobranca(m)} disabled={m.status === "pago"}>
                <MessageCircle className="mr-1 h-3 w-3" /> Lembrete
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}

      <p className="px-1 text-xs text-muted-foreground">
        💡 No app de verdade, o recibo sai em PDF ou imagem e vai direto para o WhatsApp do
        responsável.
      </p>

      <ReciboDemo mensalidade={recibo} onClose={() => setRecibo(null)} />
      <CobrancaDemo mensalidade={cobranca} onClose={() => setCobranca(null)} />
    </div>
  );
}

function ReciboDemo({ mensalidade, onClose }: { mensalidade: MensalidadeDemo | null; onClose: () => void }) {
  return (
    <Dialog open={!!mensalidade} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Recibo digital instantâneo 🧾</DialogTitle>
          <DialogDescription>Gerado na hora, pronto para enviar.</DialogDescription>
        </DialogHeader>
        {mensalidade && (
          <div className="rounded-xl border bg-card p-4 text-sm shadow-[var(--shadow-card)]">
            <div className="text-center">
              <div className="text-2xl">🚐</div>
              <div className="font-extrabold">Tati Van Escolar</div>
              <div className="text-xs text-muted-foreground">Recibo de pagamento</div>
            </div>
            <div className="mt-3 space-y-1">
              <Linha rotulo="Aluno" valor={mensalidade.aluno} />
              <Linha rotulo="Responsável" valor={mensalidade.responsavel} />
              <Linha rotulo="Referência" valor="Setembro/2026" />
              <Linha rotulo="Vencimento" valor={mensalidade.vencimento} />
              <Linha rotulo="Valor pago" valor={`R$ ${formatBRL(mensalidade.valor)}`} />
            </div>
            <div className="mt-3 rounded-lg bg-success/10 p-2 text-center text-xs font-bold text-success">
              ✅ Pagamento confirmado
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function Linha({ rotulo, valor }: { rotulo: string; valor: string }) {
  return (
    <div className="flex justify-between gap-2 border-b border-dashed py-1 text-xs last:border-0">
      <span className="text-muted-foreground">{rotulo}</span>
      <span className="font-bold">{valor}</span>
    </div>
  );
}

function CobrancaDemo({ mensalidade, onClose }: { mensalidade: MensalidadeDemo | null; onClose: () => void }) {
  const texto = mensalidade
    ? `Olá, ${mensalidade.responsavel}! 😊

Esperamos que esteja tudo bem com você.

Passamos para lembrar que a mensalidade do transporte escolar de ${mensalidade.aluno}, com vencimento em ${mensalidade.vencimento}, está em aberto, no valor de R$ ${formatBRL(mensalidade.valor)}.

Quando puder, pedimos a gentileza de realizar a regularização.

PIX: tativan@email.com

Caso o pagamento já tenha sido realizado, desconsidere esta mensagem.

Agradecemos a atenção! 💙`
    : "";

  return (
    <Dialog open={!!mensalidade} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[85vh] max-w-sm overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Lembrete de cobrança 💬</DialogTitle>
          <DialogDescription>
            A mensagem já sai pronta e educada — é só conferir e enviar.
          </DialogDescription>
        </DialogHeader>
        <div className="rounded-2xl bg-success/10 p-3 text-sm whitespace-pre-line">{texto}</div>
        <p className="text-xs text-muted-foreground">
          Nesta demonstração nada é enviado de verdade.
        </p>
      </DialogContent>
    </Dialog>
  );
}
