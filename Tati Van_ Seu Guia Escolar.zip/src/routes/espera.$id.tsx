import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { maskPhoneBR } from "@/lib/phone-mask";
import { PERIODO_OPCOES } from "@/components/lista-espera";
import { Bus, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/espera/$id")({
  head: () => ({
    meta: [
      { title: "Lista de espera da van — Tati Van Escolar" },
      { name: "description", content: "Deixe seus dados para entrar na lista de espera do transporte escolar. Avisamos assim que abrir vaga." },
      { property: "og:title", content: "Lista de espera da van — Tati Van Escolar" },
      { property: "og:description", content: "Deixe seus dados para entrar na lista de espera do transporte escolar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: ListaEsperaPublicaPage,
});

const emptyForm = {
  aluno_nome: "",
  responsavel_nome: "",
  responsavel_whatsapp: "",
  escola: "",
  periodo: "",
  rua: "",
  numero: "",
  bairro: "",
  observacoes: "",
};

function ListaEsperaPublicaPage() {
  const { id } = Route.useParams();
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [enviado, setEnviado] = useState(false);

  const set = (k: keyof typeof emptyForm, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const enviar = async () => {
    const obrigatorios: [keyof typeof emptyForm, string][] = [
      ["aluno_nome", "Nome do aluno"],
      ["responsavel_nome", "Nome do responsável"],
      ["responsavel_whatsapp", "WhatsApp do responsável"],
      ["escola", "Escola"],
      ["periodo", "Período"],
      ["rua", "Rua"],
      ["numero", "Número"],
      ["bairro", "Bairro"],
    ];
    const faltando = obrigatorios.find(([k]) => !String(form[k]).trim());
    if (faltando) {
      toast.error(`Preencha: ${faltando[1]}`);
      return;
    }

    setSaving(true);
    const { error } = await supabase.from("lista_espera").insert({
      user_id: id,
      aluno_nome: form.aluno_nome.trim().slice(0, 120),
      responsavel_nome: form.responsavel_nome.trim().slice(0, 120),
      responsavel_whatsapp: form.responsavel_whatsapp.trim().slice(0, 30),
      escola: form.escola.trim().slice(0, 120),
      periodo: form.periodo,
      endereco: [form.rua.trim(), form.bairro.trim()].filter(Boolean).join(", ").slice(0, 200),
      numero: form.numero.trim().slice(0, 20),
      observacoes: form.observacoes.trim().slice(0, 500),
    });
    setSaving(false);
    if (error) {
      toast.error("Não consegui enviar seus dados. Confira o link e tente novamente.");
      return;
    }
    setEnviado(true);
  };

  if (enviado) {
    return (
      <main className="mx-auto flex min-h-screen max-w-md items-center justify-center p-4">
        <Card className="w-full p-6 text-center">
          <CheckCircle2 className="mx-auto h-12 w-12 text-success" />
          <h1 className="mt-3 text-xl font-extrabold">Dados enviados com sucesso!</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Entraremos em contato assim que houver disponibilidade de vaga. 🚐✨
          </p>
        </Card>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-md space-y-4 p-4">
      <header className="flex items-center gap-3 rounded-2xl border bg-card p-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent">
          <Bus className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="text-lg font-extrabold leading-tight">Lista de espera da van</h1>
          <p className="text-xs text-muted-foreground">
            Preencha os dados abaixo. Avisamos assim que abrir uma vaga.
          </p>
        </div>
      </header>

      <Card className="space-y-4 p-4">
        <div className="space-y-1.5">
          <Label htmlFor="le-aluno">Nome do aluno *</Label>
          <Input id="le-aluno" value={form.aluno_nome} onChange={(e) => set("aluno_nome", e.target.value)} />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="le-resp">Nome do responsável *</Label>
          <Input id="le-resp" value={form.responsavel_nome} onChange={(e) => set("responsavel_nome", e.target.value)} />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="le-zap">WhatsApp do responsável *</Label>
          <Input
            id="le-zap"
            inputMode="numeric"
            placeholder="(11) 99999-9999"
            value={form.responsavel_whatsapp}
            onChange={(e) => set("responsavel_whatsapp", maskPhoneBR(e.target.value))}
          />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="le-escola">Escola *</Label>
          <Input id="le-escola" value={form.escola} onChange={(e) => set("escola", e.target.value)} />
        </div>

        <div className="space-y-1.5">
          <Label>Período *</Label>
          <Select value={form.periodo} onValueChange={(v) => set("periodo", v)}>
            <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
            <SelectContent>
              {PERIODO_OPCOES.map((p) => (
                <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-3 sm:grid-cols-[1fr_100px]">
          <div className="space-y-1.5">
            <Label htmlFor="le-rua">Rua *</Label>
            <Input id="le-rua" value={form.rua} onChange={(e) => set("rua", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="le-num">Número *</Label>
            <Input id="le-num" value={form.numero} onChange={(e) => set("numero", e.target.value)} />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="le-bairro">Bairro *</Label>
          <Input id="le-bairro" value={form.bairro} onChange={(e) => set("bairro", e.target.value)} />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="le-obs">Ponto de referência / observações da rota</Label>
          <Textarea
            id="le-obs"
            rows={3}
            value={form.observacoes}
            onChange={(e) => set("observacoes", e.target.value)}
            placeholder="Ex.: casa amarela em frente à padaria."
          />
        </div>

        <Button className="w-full font-bold" onClick={enviar} disabled={saving}>
          {saving ? "Enviando..." : "Enviar para a Lista de Espera"}
        </Button>
      </Card>
    </main>
  );
}
