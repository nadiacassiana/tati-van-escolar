import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Bus,
  CheckCircle2,
  Calendar,
  Wallet,
  Heart,
  ShieldCheck,
  Users,
  Bell,
  MessageCircle,
  Wrench,
  Fuel,
  FileText,
  Download,
  Cloud,
  Lock,
  Sparkles,
  ArrowRight,
  Building2,
  Notebook,
  UserCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useState } from "react";
import heroImg from "@/assets/hero-motorista.jpg";
import shotDashboard from "@/assets/screens/dashboard.png";
import shotAlunos from "@/assets/screens/alunos.png";
import shotResponsaveis from "@/assets/screens/responsaveis.png";
import shotFinanceiro from "@/assets/screens/financeiro.png";
import shotAgenda from "@/assets/screens/agenda.png";
import shotRecibos from "@/assets/screens/recibos.png";
import shotContratos from "@/assets/screens/contratos.png";
import shotChecklist from "@/assets/screens/checklist.png";
import shotManutencao from "@/assets/screens/manutencao.png";
import shotDocumentos from "@/assets/screens/documentos.png";
import { InstallHint } from "@/components/install-hint";


const screens = [
  { img: shotDashboard, title: "Dashboard Inteligente", desc: "Visualize rapidamente alunos, pagamentos, documentos e indicadores da sua van." },
  { img: shotAlunos, title: "Cadastro de Alunos", desc: "Gerencie todos os alunos em poucos cliques, com foto, horários e observações." },
  { img: shotResponsaveis, title: "Cadastro de Responsáveis", desc: "Contatos, PIX e vínculos com os alunos organizados em um só lugar." },
  { img: shotFinanceiro, title: "Financeiro", desc: "Controle mensalidades, recebimentos e despesas com clareza." },
  { img: shotAgenda, title: "Agenda", desc: "Organize toda a rotina diária do transporte escolar." },
  { img: shotRecibos, title: "Recibos", desc: "Gere recibos automaticamente e envie pelo WhatsApp." },
  { img: shotContratos, title: "Contratos", desc: "Mantenha contratos organizados, com PDF e assinatura." },
  { img: shotChecklist, title: "Checklist Diário", desc: "Nunca esqueça nenhum aluno — turnos manhã e tarde separados." },
  { img: shotManutencao, title: "Manutenção", desc: "Controle revisões, óleo, pneus e documentos da van." },
  { img: shotDocumentos, title: "Documentos", desc: "Acompanhe licenciamento, seguro, INMETRO e vencimentos." },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Tati Van Escolar — Assistente do motorista escolar" },
      {
        name: "description",
        content:
          "A assistente inteligente para motoristas de transporte escolar. Organize alunos, mensalidades, manutenção, combustível e documentos da van em um só lugar.",
      },
      { property: "og:title", content: "Tati Van Escolar" },
      {
        property: "og:description",
        content:
          "A assistente inteligente para motoristas de transporte escolar. Sua agenda de papel agora cabe no celular.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  const [openScreen, setOpenScreen] = useState<number | null>(null);
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-accent text-2xl shadow-sm">
              🚐
            </div>
            <div className="min-w-0">
              <div className="truncate text-base font-extrabold leading-none">
                Tati Van Escolar
              </div>
              <div className="mt-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">
                Assistente do motorista
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="#funcionalidades"
              className="hidden text-sm font-medium text-muted-foreground hover:text-foreground sm:inline"
            >
              Funcionalidades
            </a>
            <a
              href="#preco"
              className="hidden text-sm font-medium text-muted-foreground hover:text-foreground sm:inline"
            >
              Preço
            </a>
            <Link to="/auth">
              <Button variant="outline">Entrar</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section
        className="relative overflow-hidden"
        style={{ background: "var(--gradient-hero)" }}
      >
        {/* decorative blobs */}
        <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 right-0 h-96 w-96 rounded-full bg-accent/20 blur-3xl" />

        <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 lg:grid-cols-2 lg:py-28">
          <div className="text-primary-foreground">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 text-sm font-medium backdrop-blur">
              <span className="text-base">🚐</span>
              Tati Van Escolar
            </div>
            <p className="mb-3 text-base font-semibold text-accent">
              A assistente inteligente para motoristas de transporte escolar.
            </p>
            <h1 className="text-4xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
              Sua agenda de papel agora cabe no celular.
            </h1>
            <p className="mt-5 max-w-xl text-lg text-white/90">
              Organize alunos, mensalidades, manutenção da van, combustível,
              documentos, lembretes e toda a rotina do transporte escolar em um
              único lugar.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link to="/auth">
                <Button
                  size="lg"
                  className="bg-accent font-bold text-accent-foreground shadow-lg hover:bg-accent/90"
                >
                  🟡 Experimentar gratuitamente por 10 dias
                </Button>
              </Link>
              <a href="#funcionalidades">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/30 bg-white/10 font-semibold text-primary-foreground backdrop-blur hover:bg-white/20 hover:text-primary-foreground"
                >
                  Ver como funciona
                </Button>
              </a>
            </div>
            <p className="mt-5 inline-flex flex-wrap items-center gap-2 rounded-full bg-white/15 px-4 py-2 text-sm font-medium text-primary-foreground backdrop-blur">
              <span>🎉</span>
              <span>10 dias grátis</span>
              <span className="h-1 w-1 rounded-full bg-white/60" />
              <span>Depois apenas R$ 29,90/mês</span>
              <span className="h-1 w-1 rounded-full bg-white/60" />
              <span>Cancele quando quiser</span>
            </p>

            <InstallHint />

          </div>

          {/* Hero image */}
          <div className="relative">
            <div className="absolute inset-0 -m-4 rounded-[2rem] bg-white/10 blur-2xl" />
            <div
              className="relative overflow-hidden rounded-[2rem] border border-white/20 bg-white/5 p-2 backdrop-blur"
              style={{ boxShadow: "var(--shadow-soft)" }}
            >
              <img
                src={heroImg}
                alt="Motoristas de van escolar sorrindo ao lado de uma van moderna, com celular e notebook exibindo o painel da Tati Van Escolar com módulos de Alunos, Mensalidades, Manutenção, Financeiro, Checklist Diário e Lembretes."
                width={1024}
                height={1024}
                className="h-auto w-full rounded-[1.75rem]"
              />
            </div>
            {/* floating badge */}
            <div className="absolute -bottom-4 left-4 flex items-center gap-2 rounded-2xl border bg-card px-4 py-2.5 text-sm font-semibold shadow-lg sm:left-8">
              <CheckCircle2 className="h-4 w-4 text-success" />
              Saúde da van: 92%
            </div>
            <div className="absolute -top-4 right-4 hidden items-center gap-2 rounded-2xl border bg-card px-4 py-2.5 text-sm font-semibold shadow-lg sm:right-8 sm:flex">
              <Bell className="h-4 w-4 text-primary" />
              3 lembretes hoje
            </div>
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="border-b bg-background py-6">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-x-10 gap-y-3 px-6 text-sm font-medium text-muted-foreground">
          <span className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-primary" /> 100% seus dados
          </span>
          <span className="flex items-center gap-2">
            <Cloud className="h-4 w-4 text-primary" /> Backup automático
          </span>
          <span className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4 text-primary" /> Integrado ao
            WhatsApp
          </span>
          <span className="flex items-center gap-2">
            <Heart className="h-4 w-4 text-primary" /> Feito no Brasil
          </span>
        </div>
      </section>

      {/* Benefits */}
      <section id="funcionalidades" className="mx-auto max-w-6xl px-6 py-24">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-bold uppercase tracking-wider text-primary">
            Benefícios
          </span>
          <h2 className="mt-2 text-3xl font-extrabold sm:text-4xl">
            Organize sua rotina com tranquilidade
          </h2>
          <p className="mt-4 text-muted-foreground">
            Só o essencial — pensado para quem precisa de praticidade no
            dia a dia.
          </p>
        </div>
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[
            {
              icon: CheckCircle2,
              title: "Checklist diário",
              desc: "Marque cada criança no embarque e desembarque. Nunca mais esqueça ninguém na rota.",
            },
            {
              icon: Wallet,
              title: "Mensalidades em ordem",
              desc: "Veja quem pagou, quem está pendente e quem atrasou com apenas um olhar.",
            },
            {
              icon: Bus,
              title: "Saúde da van",
              desc: "Indicador completo de manutenção, documentos e combustível em uma única tela.",
            },
            {
              icon: Calendar,
              title: "Lembretes automáticos",
              desc: "Licenciamento, INMETRO, seguro e revisões com aviso antes do vencimento.",
            },
            {
              icon: MessageCircle,
              title: "Mensagens rápidas",
              desc: "Avise os pais em 2 toques pelo WhatsApp com mensagens prontas e personalizadas.",
            },
            {
              icon: ShieldCheck,
              title: "Seus dados são seus",
              desc: "Exporte tudo em PDF ou Excel quando quiser. Sem amarração, sem surpresa.",
            },
          ].map((f) => (
            <div
              key={f.title}
              className="group rounded-2xl border bg-card p-7 transition-all hover:-translate-y-1 hover:border-primary/30"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <div className="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <f.icon className="h-7 w-7" />
              </div>
              <h3 className="mb-2 text-lg font-extrabold">{f.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {f.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Para quem é */}
      <section className="bg-secondary/40 py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mx-auto max-w-2xl text-center">
            <span className="text-sm font-bold uppercase tracking-wider text-primary">
              Para quem é
            </span>
            <h2 className="mt-2 text-3xl font-extrabold sm:text-4xl">
              Feita para quem vive a rotina do transporte escolar
            </h2>
          </div>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                emoji: "🚐",
                title: "Motoristas de Van Escolar",
                desc: "Quem leva e busca as crianças todos os dias.",
              },
              {
                emoji: "👨‍👩‍👧",
                title: "Transportadores autônomos",
                desc: "Quem trabalha por conta própria e quer organização.",
              },
              {
                emoji: "🏫",
                title: "Pequenas empresas",
                desc: "Pequenas empresas de transporte escolar.",
              },
              {
                emoji: "📒",
                title: "Quem usa agenda de papel",
                desc: "Para quem quer trocar o caderno pelo celular.",
              },
            ].map((p) => (
              <div
                key={p.title}
                className="rounded-2xl border bg-card p-6 text-center"
                style={{ boxShadow: "var(--shadow-card)" }}
              >
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-accent text-3xl">
                  {p.emoji}
                </div>
                <h3 className="mb-1 text-base font-extrabold">{p.title}</h3>
                <p className="text-sm text-muted-foreground">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tudo o que organiza */}
      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-bold uppercase tracking-wider text-primary">
            Funcionalidades
          </span>
          <h2 className="mt-2 text-3xl font-extrabold sm:text-4xl">
            Tudo o que a Tati Van Escolar organiza
          </h2>
          <p className="mt-4 text-muted-foreground">
            Tudo o que você precisa para deixar a agenda de papel para trás.
          </p>
        </div>
        <div className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[
            "Cadastro de alunos",
            "Cadastro dos responsáveis",
            "Controle das mensalidades",
            "Controle financeiro",
            "Controle de combustível",
            "Manutenção preventiva",
            "Troca de óleo",
            "Tacógrafo",
            "Licenciamento",
            "INMETRO",
            "Corrente do motor",
            "Checklist diário dos alunos",
            "Histórico de atrasos",
            "Mensagens rápidas pelo WhatsApp",
            "Backup automático",
            "Exportação dos dados",
          ].map((item) => (
            <div
              key={item}
              className="flex items-center gap-3 rounded-xl border bg-card px-4 py-3.5"
            >
              <CheckCircle2 className="h-5 w-5 shrink-0 text-success" />
              <span className="text-sm font-medium">{item}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Por dentro do sistema */}
      <section id="por-dentro" className="bg-secondary/40 py-24">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mx-auto max-w-2xl text-center">
            <span className="text-sm font-bold uppercase tracking-wider text-primary">
              Demonstração
            </span>
            <h2 className="mt-2 text-3xl font-extrabold sm:text-4xl">
              Veja a Tati Van Escolar por dentro
            </h2>
            <p className="mt-4 text-muted-foreground">
              Conheça as principais telas do sistema e veja como é fácil administrar sua van escolar.
            </p>
          </div>

          <div className="mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {screens.map((s, i) => (
              <button
                key={s.title}
                type="button"
                onClick={() => setOpenScreen(i)}
                className="group text-left focus:outline-none"
              >
                {/* Notebook frame */}
                <div className="relative">
                  <div
                    className="overflow-hidden rounded-t-xl border border-b-0 bg-slate-900 p-2 pb-1 transition-all duration-300 group-hover:-translate-y-1"
                    style={{ boxShadow: "var(--shadow-card)" }}
                  >
                    <div className="mb-1.5 flex items-center gap-1.5 px-1">
                      <span className="h-2 w-2 rounded-full bg-red-400" />
                      <span className="h-2 w-2 rounded-full bg-yellow-400" />
                      <span className="h-2 w-2 rounded-full bg-green-400" />
                    </div>
                    <div className="overflow-hidden rounded-md bg-background">
                      <img
                        src={s.img}
                        alt={`Tela ${s.title} da Tati Van Escolar`}
                        loading="lazy"
                        className="aspect-[16/10] w-full object-cover object-top transition-transform duration-500 group-hover:scale-[1.03]"
                      />
                    </div>
                  </div>
                  {/* Notebook base */}
                  <div className="mx-auto h-2 w-[92%] rounded-b-xl bg-slate-800" />
                  <div className="mx-auto h-1 w-[70%] rounded-b-lg bg-slate-700/70" />
                </div>
                <div className="mt-5 px-1">
                  <h3 className="text-base font-extrabold">{s.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                    {s.desc}
                  </p>
                </div>
              </button>
            ))}
          </div>

          <div className="mt-14 flex justify-center">
            <Link to="/auth">
              <Button
                size="lg"
                className="bg-accent font-bold text-accent-foreground shadow-lg hover:bg-accent/90"
              >
                🟡 Experimentar gratuitamente por 10 dias
              </Button>
            </Link>
          </div>
        </div>

        <Dialog open={openScreen !== null} onOpenChange={(o) => !o && setOpenScreen(null)}>
          <DialogContent className="max-w-5xl border-0 bg-transparent p-0 shadow-none sm:rounded-none">
            {openScreen !== null && (
              <div className="overflow-hidden rounded-2xl bg-slate-900 p-3 shadow-2xl">
                <DialogTitle className="sr-only">{screens[openScreen].title}</DialogTitle>
                <DialogDescription className="sr-only">{screens[openScreen].desc}</DialogDescription>
                <div className="mb-2 flex items-center gap-1.5 px-1">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-yellow-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-green-400" />
                </div>
                <img
                  src={screens[openScreen].img}
                  alt={screens[openScreen].title}
                  className="w-full rounded-md bg-background"
                />
                <div className="px-2 pb-1 pt-3 text-primary-foreground">
                  <div className="text-lg font-extrabold">{screens[openScreen].title}</div>
                  <div className="text-sm text-white/80">{screens[openScreen].desc}</div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </section>



      {/* Como funciona */}
      <section
        className="relative overflow-hidden py-24 text-primary-foreground"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="mx-auto max-w-6xl px-6">
          <div className="mx-auto max-w-2xl text-center">
            <span className="text-sm font-bold uppercase tracking-wider text-accent">
              Como funciona
            </span>
            <h2 className="mt-2 text-3xl font-extrabold sm:text-4xl">
              Em 4 passos você está organizado
            </h2>
          </div>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                n: "1",
                icon: UserCircle2,
                title: "Crie sua conta",
                desc: "Cadastre-se em segundos, sem cartão de crédito.",
              },
              {
                n: "2",
                icon: Users,
                title: "Cadastre seus alunos",
                desc: "Adicione alunos, responsáveis e horários.",
              },
              {
                n: "3",
                icon: Notebook,
                title: "Organize sua rotina",
                desc: "Controle mensalidades, gastos e manutenção.",
              },
              {
                n: "4",
                icon: Bell,
                title: "Receba lembretes",
                desc: "Avisos automáticos de documentos e revisões.",
              },
            ].map((s) => (
              <div
                key={s.n}
                className="relative rounded-2xl border border-white/20 bg-white/10 p-6 backdrop-blur"
              >
                <div className="absolute -top-4 left-6 flex h-10 w-10 items-center justify-center rounded-full bg-accent text-base font-extrabold text-accent-foreground shadow-lg">
                  {s.n}
                </div>
                <s.icon className="mb-3 mt-3 h-8 w-8 text-accent" />
                <h3 className="mb-1 text-lg font-extrabold">{s.title}</h3>
                <p className="text-sm text-white/85">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Segurança */}
      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <span className="text-sm font-bold uppercase tracking-wider text-primary">
              Segurança e transparência
            </span>
            <h2 className="mt-2 text-3xl font-extrabold sm:text-4xl">
              Seus dados pertencem somente a você
            </h2>
            <p className="mt-4 text-muted-foreground">
              Caso um dia decida parar de utilizar o sistema, poderá exportar
              todas as suas informações antes do encerramento da conta. Total
              transparência, sem amarração.
            </p>
          </div>
          <div className="grid gap-4">
            {[
              {
                icon: Lock,
                title: "🔒 Seus dados são seus",
                desc: "Acesso protegido e somente você enxerga as suas informações.",
              },
              {
                icon: Cloud,
                title: "☁️ Backup completo",
                desc: "Backup automático em nuvem disponível a qualquer momento.",
              },
              {
                icon: Download,
                title: "📤 Exportação livre",
                desc: "Exporte todos os seus dados em PDF e Excel quando quiser.",
              },
            ].map((c) => (
              <div
                key={c.title}
                className="flex items-start gap-4 rounded-2xl border bg-card p-5"
                style={{ boxShadow: "var(--shadow-card)" }}
              >
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <c.icon className="h-6 w-6" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-extrabold">{c.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {c.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Preço */}
      <section id="preco" className="bg-secondary/40 py-24">
        <div className="mx-auto max-w-3xl px-6 text-center">
          <span className="text-sm font-bold uppercase tracking-wider text-primary">
            Preço
          </span>
          <h2 className="mt-2 text-3xl font-extrabold sm:text-4xl">
            Simples. Transparente. Sem surpresas.
          </h2>
          <p className="mt-4 text-muted-foreground">
            Não existem planos diferentes. Existe apenas uma assinatura — com
            tudo liberado.
          </p>

          <div
            className="mt-12 overflow-hidden rounded-3xl border bg-card text-left"
            style={{ boxShadow: "var(--shadow-soft)" }}
          >
            <div className="bg-accent px-8 py-4 text-center text-sm font-extrabold uppercase tracking-wider text-accent-foreground">
              🎁 Experimente gratuitamente durante 10 dias
            </div>
            <div className="p-8 sm:p-10">
              <div className="flex flex-col items-center text-center">
                <span className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                  Depois, apenas
                </span>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-6xl font-extrabold text-primary">
                    R$ 29,90
                  </span>
                  <span className="text-muted-foreground">/mês</span>
                </div>
                <p className="mt-3 max-w-xs text-sm font-medium text-muted-foreground">
                  🚐 Menos de R$ 1,00 por dia para organizar sua van escolar e oferecer mais tranquilidade aos pais.
                </p>
              </div>

              <ul className="mx-auto mt-8 grid max-w-md gap-3 sm:grid-cols-2">
                {[
                  "Todos os recursos liberados",
                  "Backup automático",
                  "Exportação em PDF e Excel",
                  "Atualizações constantes",
                  "Suporte dedicado",
                  "Alunos ilimitados",
                ].map((i) => (
                  <li
                    key={i}
                    className="flex items-center gap-2 text-sm font-medium"
                  >
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-success" />
                    {i}
                  </li>
                ))}
              </ul>

              <div className="mt-10 text-center">
                <Link to="/auth">
                  <Button
                    size="lg"
                    className="h-14 bg-primary px-8 text-base font-extrabold text-primary-foreground hover:bg-primary/90"
                  >
                    🚐 Começar gratuitamente
                    <ArrowRight className="ml-1 h-5 w-5" />
                  </Button>
                </Link>
                <p className="mt-3 text-xs text-muted-foreground">
                  Sem cartão de crédito para começar
                </p>
                <ul className="mx-auto mt-3 flex flex-wrap justify-center gap-x-4 gap-y-1 text-xs font-medium text-muted-foreground">
                  <li className="flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-success" /> 10 dias de teste grátis
                  </li>
                  <li className="flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-success" /> Sem fidelidade
                  </li>
                  <li className="flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-success" /> Cancele quando quiser
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Evolução */}
      <section className="mx-auto max-w-4xl px-6 py-20">
        <div className="rounded-3xl border bg-card p-10 text-center">
          <div className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-accent text-accent-foreground">
            <Sparkles className="h-7 w-7" />
          </div>
          <h2 className="text-2xl font-extrabold sm:text-3xl">
            Em constante evolução
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            A Tati Van Escolar está em constante evolução para facilitar ainda
            mais a rotina dos motoristas de transporte escolar. Novas
            funcionalidades serão adicionadas regularmente.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-secondary/30 py-12">
        <div className="mx-auto max-w-6xl px-6">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-xl">
                  🚐
                </div>
                <div>
                  <div className="text-sm font-extrabold leading-none">
                    Tati Van Escolar
                  </div>
                  <div className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                    Assistente do motorista
                  </div>
                </div>
              </div>
              <p className="mt-4 text-sm text-muted-foreground">
                A assistente inteligente para motoristas de transporte
                escolar.
              </p>
            </div>
            <FooterCol
              title="Produto"
              items={[
                { label: "Funcionalidades", href: "#funcionalidades" },
                { label: "Preço", href: "#preco" },
              ]}
            />
            <FooterCol
              title="Legal"
              items={[
                { label: "Política de Privacidade", href: "/privacidade" },
                { label: "Termos de Uso", href: "/termos-de-uso" },
              ]}
            />
            <FooterCol
              title="Ajuda"
              items={[
                { label: "Suporte", href: "/suporte" },
                { label: "Contato", href: "/contato" },
              ]}
            />
          </div>
          <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t pt-6 text-sm text-muted-foreground sm:flex-row">
            <span>© {new Date().getFullYear()} Tati Van Escolar</span>
            <span>💙 Feita com carinho para quem cuida das crianças.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FooterCol({
  title,
  items,
}: {
  title: string;
  items: { label: string; href: string }[];
}) {
  return (
    <div>
      <h4 className="mb-3 text-sm font-extrabold uppercase tracking-wider">
        {title}
      </h4>
      <ul className="space-y-2 text-sm">
        {items.map((i) => (
          <li key={i.label}>
            <a
              href={i.href}
              className="text-muted-foreground hover:text-foreground"
            >
              {i.label}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
