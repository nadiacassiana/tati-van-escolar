import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft, Mail, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/privacidade")({
  head: () => ({
    meta: [
      { title: "Política de Privacidade — Tati Van Escolar" },
      {
        name: "description",
        content:
          "Política de Privacidade da Tati Van Escolar em conformidade com a LGPD. Saiba como coletamos, usamos e protegemos seus dados.",
      },
      { property: "og:title", content: "Política de Privacidade — Tati Van Escolar" },
      {
        property: "og:description",
        content:
          "Como a Tati Van Escolar coleta, utiliza e protege as informações de motoristas, alunos e responsáveis.",
      },
    ],
  }),
  component: PrivacidadePage,
});

const CONTATO = "tatiassistentevirtualbr@gmail.com";

function PrivacidadePage() {
  const router = useRouter();

  const secoes: { id: string; titulo: string }[] = [
    { id: "apresentacao", titulo: "1. Apresentação" },
    { id: "coletamos", titulo: "2. Quais informações coletamos" },
    { id: "utilizamos", titulo: "3. Como utilizamos essas informações" },
    { id: "compartilhamento", titulo: "4. Compartilhamento de dados" },
    { id: "criancas", titulo: "5. Cuidado com dados de crianças" },
    { id: "seguranca", titulo: "6. Segurança das informações" },
    { id: "armazenamento", titulo: "7. Armazenamento dos dados" },
    { id: "cookies", titulo: "8. Cookies e tecnologias utilizadas" },
    { id: "direitos", titulo: "9. Direitos do usuário conforme a LGPD" },
    { id: "solicitacoes", titulo: "10. Como solicitar atualização, correção ou exclusão" },
    { id: "exclusao", titulo: "11. Exclusão da conta" },
    { id: "alteracoes", titulo: "12. Alterações nesta Política" },
    { id: "contato", titulo: "13. Contato" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header
        className="border-b"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-6 py-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-xl">
              🚐
            </div>
            <div className="text-primary-foreground">
              <div className="text-sm font-extrabold leading-none">Tati Van Escolar</div>
              <div className="mt-1 text-[10px] uppercase tracking-wider opacity-80">
                Assistente do motorista
              </div>
            </div>
          </Link>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => router.history.back()}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
        </div>
      </header>

      {/* Título */}
      <section className="border-b bg-secondary/30">
        <div className="mx-auto max-w-4xl px-6 py-10 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <ShieldCheck className="h-7 w-7" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
            Política de Privacidade
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Transparência é um compromisso da <strong>Tati Van Escolar</strong>.
            Aqui você entende exatamente quais dados tratamos, como cuidamos deles
            e quais são os seus direitos.
          </p>
        </div>
      </section>

      <div className="mx-auto grid max-w-5xl gap-8 px-6 py-10 lg:grid-cols-[240px_1fr]">
        {/* Sumário */}
        <aside className="hidden lg:block">
          <div className="sticky top-6 rounded-2xl border bg-card p-5 shadow-sm">
            <h2 className="mb-3 text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
              Sumário
            </h2>
            <ul className="space-y-2 text-sm">
              {secoes.map((s) => (
                <li key={s.id}>
                  <a
                    href={`#${s.id}`}
                    className="text-muted-foreground hover:text-primary"
                  >
                    {s.titulo}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        {/* Conteúdo */}
        <main className="max-w-none space-y-10 text-[15px] leading-relaxed text-foreground">
          <Secao id="apresentacao" titulo="1. Apresentação">
            <p>
              A <strong>Tati Van Escolar</strong> é uma plataforma do ecossistema{" "}
              <strong>Tati Assistente Virtual</strong>, desenvolvida e administrada
              por sua desenvolvedora, atualmente operada como <strong>pessoa física</strong>.
              A plataforma foi criada para auxiliar motoristas de transporte escolar
              na organização da rotina diária: alunos, responsáveis, financeiro,
              contratos, recibos, documentos, agenda, checklist e rastreamento
              temporário da rota.
            </p>
            <p className="mt-3">
              Esta Política de Privacidade explica, de forma clara e objetiva, como
              coletamos, utilizamos, armazenamos, compartilhamos e protegemos as
              informações tratadas na plataforma, em conformidade com a{" "}
              <strong>Lei Geral de Proteção de Dados (Lei nº 13.709/2018 — LGPD)</strong>.
            </p>
          </Secao>

          <Secao id="coletamos" titulo="2. Quais informações coletamos">
            <p>
              Coletamos apenas as informações necessárias para o funcionamento
              adequado da plataforma. Os dados são inseridos pelo próprio motorista
              usuário do sistema. São eles:
            </p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>
                <strong>Do motorista (titular da conta):</strong> nome completo,
                apelido, nome da empresa (quando informado), cidade, estado, e-mail,
                <strong> WhatsApp</strong> (com autorização expressa) e senha de acesso.
              </li>
              <li>
                <strong>Dos alunos:</strong> nome, foto (opcional), data de nascimento,
                endereço, escola, turno, horários e observações.
              </li>
              <li>
                <strong>Dos responsáveis:</strong> nome, telefone, endereço, chave PIX
                (quando informada) e vínculo com os alunos.
              </li>
              <li>
                <strong>Financeiro:</strong> mensalidades, pagamentos, recibos,
                despesas e histórico de movimentações.
              </li>
              <li>
                <strong>Documentos e manutenção:</strong> informações sobre CRLV,
                seguro, INMETRO, tacógrafo, revisões e demais dados operacionais da van.
              </li>
              <li>
                <strong>Contratos:</strong> dados necessários para geração e
                organização dos contratos de prestação de serviço.
              </li>
              <li>
                <strong>Agenda e checklist:</strong> compromissos, rotina diária,
                turnos e presença dos alunos.
              </li>
              <li>
                <strong>Rastreamento temporário:</strong> localização em tempo real
                da rota, apenas enquanto o motorista mantém a rota ativa. A
                localização <strong>não é armazenada de forma contínua</strong> e
                deixa de ser compartilhada assim que a rota é encerrada.
              </li>
              <li>
                <strong>Dados técnicos:</strong> informações mínimas de autenticação
                e uso (por exemplo, data do último acesso) para segurança da conta.
              </li>
            </ul>
          </Secao>

          <Secao id="utilizamos" titulo="3. Como utilizamos essas informações">
            <p>Utilizamos os dados exclusivamente para:</p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>Permitir o acesso do motorista à sua conta;</li>
              <li>Organizar alunos, responsáveis, financeiro e rotina do transporte;</li>
              <li>Gerar contratos, recibos e documentos operacionais;</li>
              <li>
                Enviar mensagens automáticas através de aplicativos do próprio
                motorista (ex.: WhatsApp), sempre a partir do dispositivo dele;
              </li>
              <li>
                Compartilhar o link temporário de rastreamento da rota com os
                responsáveis, quando o motorista optar por essa funcionalidade;
              </li>
              <li>Manter a segurança, o backup e a estabilidade da plataforma;</li>
              <li>
                <strong>Entrar em contato pelo WhatsApp</strong> informado pelo motorista,
                exclusivamente para assuntos relacionados à sua conta, suporte, novidades,
                atualizações da plataforma, lembretes importantes e comunicações sobre a
                assinatura — <strong>somente mediante autorização expressa</strong>
                registrada no momento do cadastro ou nas configurações do perfil. O
                consentimento pode ser revogado a qualquer momento em
                Configurações → Perfil, e o número <strong>nunca é compartilhado com
                outros usuários</strong>.
              </li>
              <li>Cumprir obrigações legais e responder a solicitações do titular.</li>
            </ul>
            <p className="mt-3">
              A <strong>Tati Van Escolar não vende, aluga ou comercializa</strong>{" "}
              nenhuma informação pessoal.
            </p>
          </Secao>

          <Secao id="compartilhamento" titulo="4. Compartilhamento de dados">
            <p>
              Os dados cadastrados na plataforma pertencem ao motorista usuário e
              são utilizados apenas dentro da sua própria conta. Não compartilhamos
              informações com terceiros, exceto quando:
            </p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>
                O próprio motorista compartilha (ex.: envio de recibo, contrato ou
                link de rastreamento para o responsável);
              </li>
              <li>
                Para provedores de infraestrutura em nuvem estritamente necessários
                à operação da plataforma (hospedagem, banco de dados e autenticação),
                sempre sob obrigação de confidencialidade;
              </li>
              <li>Para cumprimento de obrigação legal ou ordem de autoridade competente.</li>
            </ul>
          </Secao>

          <Secao id="criancas" titulo="5. Cuidado com dados de crianças">
            <p>
              A Tati Van Escolar trata informações relacionadas a crianças e
              adolescentes (alunos transportados). Esses dados são cadastrados{" "}
              <strong>exclusivamente pelo motorista</strong> responsável pelo
              transporte e são utilizados{" "}
              <strong>
                somente para a prestação do serviço de transporte escolar
              </strong>{" "}
              — organização de rotas, comunicação com os responsáveis, controle
              de embarque e desembarque e emissão de documentos.
            </p>
            <p className="mt-3">
              Seguimos boas práticas de proteção de dados, adotando o princípio da
              <strong> minimização</strong> (coletamos apenas o essencial) e do{" "}
              <strong>melhor interesse da criança</strong>, conforme previsto na LGPD.
              Não utilizamos dados de crianças para publicidade, perfilamento ou
              qualquer finalidade fora do escopo do serviço.
            </p>
          </Secao>

          <Secao id="seguranca" titulo="6. Segurança das informações">
            <p>
              Aplicamos medidas técnicas e organizacionais para proteger os dados
              contra acessos não autorizados, perdas, alterações ou divulgação
              indevida, incluindo:
            </p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>Comunicação criptografada (HTTPS/TLS);</li>
              <li>Autenticação com senha individual por motorista;</li>
              <li>
                Isolamento dos dados por conta (cada motorista acessa somente as
                próprias informações);
              </li>
              <li>Backups periódicos e monitoramento de segurança.</li>
            </ul>
            <p className="mt-3">
              Ainda que adotemos boas práticas, nenhum sistema é 100% imune a
              incidentes. Em caso de incidente relevante, o titular será
              informado conforme a LGPD.
            </p>
          </Secao>

          <Secao id="armazenamento" titulo="7. Armazenamento dos dados">
            <p>
              Os dados são armazenados em servidores de nuvem confiáveis, com
              proteção adequada. As informações permanecem armazenadas enquanto a
              conta do motorista estiver ativa e forem necessárias para as
              finalidades descritas nesta Política.
            </p>
            <p className="mt-3">
              A localização utilizada pelo rastreamento em tempo real é{" "}
              <strong>temporária</strong> e mantida apenas durante a rota ativa,
              sendo descartada ao final do compartilhamento.
            </p>
          </Secao>

          <Secao id="cookies" titulo="8. Cookies e tecnologias utilizadas">
            <p>
              Utilizamos apenas os cookies e armazenamentos locais necessários
              para o funcionamento da plataforma, como manter o motorista logado
              e lembrar preferências básicas (por exemplo, mensagens de
              boas-vindas). <strong>Não utilizamos cookies de publicidade</strong>{" "}
              nem rastreamento de terceiros para fins de marketing.
            </p>
          </Secao>

          <Secao id="direitos" titulo="9. Direitos do usuário conforme a LGPD">
            <p>Como titular de dados, você tem direito a:</p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>Confirmar a existência de tratamento dos seus dados;</li>
              <li>Acessar os dados tratados;</li>
              <li>Corrigir dados incompletos, inexatos ou desatualizados;</li>
              <li>Solicitar a anonimização, bloqueio ou eliminação de dados desnecessários;</li>
              <li>Solicitar a portabilidade dos dados, quando aplicável;</li>
              <li>Solicitar a eliminação dos dados tratados com o consentimento;</li>
              <li>Ser informado sobre com quem seus dados foram compartilhados;</li>
              <li>Revogar o consentimento, quando este for a base legal utilizada.</li>
            </ul>
          </Secao>

          <Secao
            id="solicitacoes"
            titulo="10. Como solicitar atualização, correção ou exclusão"
          >
            <p>
              Você pode, a qualquer momento, entrar em contato com a Tati
              Assistente Virtual para solicitar:
            </p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>Acesso aos seus dados;</li>
              <li>Atualização de informações;</li>
              <li>Correção de dados;</li>
              <li>Exclusão da conta;</li>
              <li>Exclusão definitiva dos dados;</li>
              <li>Esclarecimento de dúvidas relacionadas à privacidade.</li>
            </ul>
            <p className="mt-3">
              Basta enviar um e-mail para{" "}
              <a
                href={`mailto:${CONTATO}`}
                className="font-semibold text-primary hover:underline"
              >
                {CONTATO}
              </a>{" "}
              informando o pedido. Responderemos no menor prazo possível.
            </p>
          </Secao>

          <Secao id="exclusao" titulo="11. Exclusão da conta">
            <p>
              O motorista pode excluir a própria conta diretamente pela
              plataforma, em <strong>Configurações → Excluir conta e dados</strong>.
              A exclusão é <strong>permanente</strong> e remove todos os dados
              vinculados à conta: alunos, responsáveis, financeiro, gastos,
              documentos, contratos, recibos, agenda, mensagens, rotas e histórico.
            </p>
            <p className="mt-3">
              Caso prefira, também é possível solicitar a exclusão por e-mail,
              pelo canal informado no item 13.
            </p>
          </Secao>

          <Secao id="alteracoes" titulo="12. Alterações nesta Política de Privacidade">
            <p>
              Esta Política pode ser atualizada periodicamente para refletir
              melhorias na plataforma, mudanças legais ou novas funcionalidades.
              A versão mais recente estará sempre disponível nesta página, com a
              respectiva data de atualização.
            </p>
          </Secao>

          <Secao id="contato" titulo="13. Contato">
            <p>
              Para qualquer dúvida, solicitação ou assunto relacionado à
              privacidade e proteção de dados, entre em contato pelo canal
              oficial:
            </p>
            <a
              href={`mailto:${CONTATO}`}
              className="mt-4 inline-flex items-center gap-2 rounded-xl border bg-secondary/40 px-4 py-3 text-sm font-semibold text-primary hover:bg-secondary"
            >
              <Mail className="h-4 w-4" />
              {CONTATO}
            </a>
          </Secao>

          <div className="rounded-2xl border bg-secondary/30 p-6 text-sm text-muted-foreground">
            <div>
              <strong>Versão 1.0</strong>
            </div>
            <div className="mt-1">Última atualização: 01 de julho de 2026</div>
            <div className="mt-1">
              Plataforma desenvolvida e administrada pela{" "}
              <strong>Tati Assistente Virtual</strong>, atualmente operada por sua
              desenvolvedora como pessoa física.
            </div>
          </div>

          <div className="flex justify-center pt-2">
            <Button
              variant="outline"
              onClick={() => router.history.back()}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar à página anterior
            </Button>
          </div>
        </main>
      </div>
    </div>
  );
}

function Secao({
  id,
  titulo,
  children,
}: {
  id: string;
  titulo: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24">
      <h2 className="mb-3 text-xl font-extrabold tracking-tight text-foreground sm:text-2xl">
        {titulo}
      </h2>
      <div className="text-muted-foreground [&_strong]:text-foreground">
        {children}
      </div>
    </section>
  );
}
