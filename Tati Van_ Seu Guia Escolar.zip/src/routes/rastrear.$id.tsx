import { createFileRoute, ClientOnly } from "@tanstack/react-router";
import { Suspense, lazy, useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { turnoLabel, type ParadaStatus, type Sentido, type Turno } from "@/lib/rota-ativa";
import { geocodificarRota, type GeoRota } from "@/lib/mapa.functions";
import type { LatLng } from "@/components/rastreio-mapa";
import { RefreshCw, Bus, Navigation, Bell } from "lucide-react";

const RastreioMapa = lazy(() => import("@/components/rastreio-mapa"));

type StatusRota = {
  encontrada: boolean;
  estado?: "ativa" | "encerrada" | "revogada" | "expirada";
  turno?: Turno;
  sentido?: Sentido;
  motorista_nome?: string | null;
  encerrada_em?: string | null;
  expira_em?: string | null;
  servidor_agora?: string | null;
  ultima_lat?: number | null;
  ultima_lng?: number | null;
  ultima_atualizacao?: string | null;
  total_pendentes?: number;
  total_concluidas?: number;
  tem_paradas?: boolean;
  minha?: {
    nome: string;
    status: ParadaStatus;
    restantes: number;
    proxima: boolean;
    embarcado_em: string | null;
    desembarcado_em: string | null;
    endereco_casa?: string | null;
    escola_nome?: string | null;
    endereco_escola?: string | null;
  } | null;
};

export const Route = createFileRoute("/rastrear/$id")({
  validateSearch: (search: Record<string, unknown>) => ({
    p: typeof search.p === "string" ? search.p : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Rastrear van em tempo real — Tati Van Escolar" },
      { name: "description", content: "Acompanhe em tempo real a localização da van escolar." },
      { name: "robots", content: "noindex,nofollow" },
      { property: "og:title", content: "Rastrear van em tempo real — Tati Van Escolar" },
      { property: "og:description", content: "Acompanhe em tempo real a localização da van escolar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RastrearPage,
});

// ---------- Geo helpers ----------
function distanciaM(a: LatLng, b: LatLng): number {
  const R = 6371000;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

function bearing(de: LatLng, para: LatLng): number {
  const φ1 = (de.lat * Math.PI) / 180;
  const φ2 = (para.lat * Math.PI) / 180;
  const Δλ = ((para.lng - de.lng) * Math.PI) / 180;
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}

// ---------- Status dinâmico ----------
type Tom = "verde" | "amarelo" | "azul" | "cinza";

function statusDinamico(
  s: StatusRota,
  geo: GeoRota | null,
  van: LatLng | null,
): { texto: string; tom: Tom } {
  const motorista = s.motorista_nome || "sua motorista";
  const volta = (s.sentido ?? (s.turno === "tarde" ? "volta" : "ida")) === "volta";
  const m = s.minha;

  if (s.estado === "encerrada") {
    if (volta && m) {
      return { texto: "✨ Aluno entregue com sucesso aos responsáveis. Rota finalizada!", tom: "verde" };
    }
    const escola = m?.escola_nome ? ` na escola ${m.escola_nome}` : " ao destino";
    return { texto: `🏫 A Van chegou${escola}. Alunos entregues com segurança!`, tom: "verde" };
  }

  const distCasa = van && geo?.casa ? distanciaM(van, geo.casa) : null;
  const distEscola = van && geo?.escola ? distanciaM(van, geo.escola) : null;

  if (m) {
    if (m.status === "ausente") {
      return {
        texto: `ℹ️ ${m.nome} foi marcado(a) como ausente nesta rota. A van seguirá para as próximas paradas.`,
        tom: "cinza",
      };
    }

    if (m.status === "desembarcado") {
      if (!volta) {
        return {
          texto: `🏫 ${m.nome} chegou na escola${m.escola_nome ? ` ${m.escola_nome}` : ""} com segurança. Rota da ida concluída para este aluno!`,
          tom: "verde",
        };
      }
      return {
        texto: `🏡 ${m.nome} foi entregue em casa com segurança. Rota da volta concluída para este aluno!`,
        tom: "verde",
      };
    }

    if (!volta) {
      // IDA: casa → escola
      if (m.status === "embarcado") {
        if (distEscola != null && distEscola < 100) {
          return {
            texto: `🏫 A Van chegou na escola${m.escola_nome ? ` ${m.escola_nome}` : ""}. Aluno entregue com segurança!`,
            tom: "verde",
          };
        }
        return { texto: `✅ ${m.nome} embarcado com sucesso! Seguindo viagem rumo à escola.`, tom: "verde" };
      }
      // Pendente (aguardando embarque)
      if (distCasa != null && distCasa < 50) {
        return { texto: `👋 A Van Chegou! Aguardando o embarque do(a) ${m.nome}.`, tom: "amarelo" };
      }
      if (distCasa != null && distCasa < 300) {
        return {
          texto: `🚨 A Van do(a) ${motorista} está se aproximando do seu endereço! Esteja a postos na porta.`,
          tom: "amarelo",
        };
      }
      if (m.proxima || m.restantes === 0) {
        return {
          texto: `🛵 A Van do(a) ${motorista} está a caminho do seu endereço! Aguarde o(a) ${m.nome} a postos.`,
          tom: "amarelo",
        };
      }
      return {
        texto: `🚌 A Van do(a) ${motorista} está em rota, embarcando alunos. Faltam ${m.restantes} parada${m.restantes === 1 ? "" : "s"} antes do seu endereço.`,
        tom: "azul",
      };
    }

    // VOLTA: escola → casa
    if (m.status === "embarcado") {
      if (distCasa != null && distCasa < 50) {
        return { texto: "🏡 Chegamos na sua porta! Pronto para desembarque.", tom: "amarelo" };
      }
      if (distCasa != null && distCasa < 300) {
        return {
          texto: `🚨 A Van do(a) ${motorista} logo estará no seu endereço! Esteja a postos para receber.`,
          tom: "amarelo",
        };
      }
      return {
        texto: `🚌 A Van do(a) ${motorista} saiu da escola e está desembarcando alunos na rota.`,
        tom: "azul",
      };
    }
    return {
      texto: `🚌 A Van do(a) ${motorista} está na rota da volta. Aguarde o embarque do(a) ${m.nome} na escola.`,
      tom: "azul",
    };
  }

  // Sem parada identificada (link geral): status genérico, sem nomes de alunos
  const concluidas = s.total_concluidas ?? 0;
  return {
    texto: volta
      ? `🚌 A Van do(a) ${motorista} saiu da escola e está desembarcando alunos na rota.`
      : concluidas > 0
        ? `🚌 A Van do(a) ${motorista} está em rota, embarcando alunos. ${concluidas} parada${concluidas === 1 ? "" : "s"} concluída${concluidas === 1 ? "" : "s"}.`
        : `🚌 A Van do(a) ${motorista} está em rota, embarcando alunos.`,
    tom: "verde",
  };
}

const tomClass: Record<Tom, string> = {
  verde: "border-success/40 bg-success/10 text-success",
  amarelo: "border-accent/50 bg-accent/15 text-accent-foreground",
  azul: "border-primary/40 bg-primary/10 text-primary",
  cinza: "border-muted bg-muted/40 text-muted-foreground",
};

// ---------- Avisos automáticos para o responsável ----------
type Aviso = { chave: string; titulo: string; corpo: string };

/** Momentos que merecem um aviso: van chegando na casa e van chegando na escola. */
function avisoAtual(s: StatusRota, geo: GeoRota | null, van: LatLng | null): Aviso | null {
  if (!van || s.estado !== "ativa") return null;
  const m = s.minha;
  if (!m || m.status === "ausente" || m.status === "desembarcado") return null;
  const motorista = s.motorista_nome || "a van";
  const volta = (s.sentido ?? (s.turno === "tarde" ? "volta" : "ida")) === "volta";
  const distCasa = geo?.casa ? distanciaM(van, geo.casa) : null;
  const distEscola = geo?.escola ? distanciaM(van, geo.escola) : null;

  if (!volta && m.status === "embarcado" && distEscola != null && distEscola < 100) {
    return {
      chave: "escola",
      titulo: "🏫 A van chegou na escola",
      corpo: `${m.nome} chegou${m.escola_nome ? ` na escola ${m.escola_nome}` : " na escola"} com segurança.`,
    };
  }
  const indoParaCasa = volta ? m.status === "embarcado" : m.status === "pendente";
  if (indoParaCasa && distCasa != null && distCasa < 300) {
    return distCasa < 50
      ? {
          chave: "casa-chegou",
          titulo: volta ? "🏡 A van chegou na sua porta" : "👋 A van chegou!",
          corpo: volta
            ? `${m.nome} está chegando em casa. Pode receber na porta.`
            : `A van está na porta aguardando o embarque do(a) ${m.nome}.`,
        }
      : {
          chave: "casa-perto",
          titulo: "🚨 A van está chegando",
          corpo: `A van do(a) ${motorista} está a menos de 300 metros da sua casa. Esteja a postos!`,
        };
  }
  return null;
}

function RastrearPage() {
  const { id } = Route.useParams();
  const { p } = Route.useSearch();
  const [rota, setRota] = useState<StatusRota | null>(null);
  const [loading, setLoading] = useState(true);
  const [geo, setGeo] = useState<GeoRota | null>(null);
  const anteriorRef = useRef<LatLng | null>(null);
  const [heading, setHeading] = useState(0);
  const [avisosOn, setAvisosOn] = useState(false);
  const ultimoAvisoRef = useRef<string | null>(null);
  const horaLocalDaResposta = useRef(Date.now());
  const [, setTick] = useState(0);


  // Relógio de 1s: garante que o link vire "expirado" no segundo exato do prazo.
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);

  // Polling do status da rota (5s)
  useEffect(() => {
    let alive = true;
    async function load() {
      const { data } = await supabase.rpc("get_rota_status", { _rota: id, _parada: (p ?? null) as unknown as string });
      if (!alive) return;
      const status = (data as unknown as StatusRota) || null;
      horaLocalDaResposta.current = Date.now();
      setRota((prev) => {
        if (
          status?.ultima_lat != null && status?.ultima_lng != null &&
          prev?.ultima_lat != null && prev?.ultima_lng != null &&
          (prev.ultima_lat !== status.ultima_lat || prev.ultima_lng !== status.ultima_lng)
        ) {
          anteriorRef.current = { lat: prev.ultima_lat, lng: prev.ultima_lng };
          const h = bearing(anteriorRef.current, { lat: status.ultima_lat, lng: status.ultima_lng });
          setHeading(h);
        }
        return status;
      });
      setLoading(false);
    }
    void load();
    const t = setInterval(() => { void load(); }, 5_000);
    return () => { alive = false; clearInterval(t); };
  }, [id, p]);

  // Geocodifica casa/escola uma única vez (endereços já vinculados à parada)
  useEffect(() => {
    const m = rota?.minha;
    if (!m || geo || (!m.endereco_casa && !m.endereco_escola)) return;
    let alive = true;
    geocodificarRota({ data: { rota: id, parada: p ?? null } })
      .then((g) => { if (alive) setGeo(g); })
      .catch(() => { /* mapa segue só com a van */ });
    return () => { alive = false; };
  }, [rota?.minha, geo, id, p]);

  const encontrada = !!rota?.encontrada;
  // Diferença entre o relógio do servidor e o do celular: evita link durar mais que o programado.
  const offsetRef = useRef(0);
  if (rota?.servidor_agora) {
    offsetRef.current = new Date(rota.servidor_agora).getTime() - horaLocalDaResposta.current;
  }
  const expirouAgora =
    !!rota?.expira_em && new Date(rota.expira_em).getTime() <= Date.now() + offsetRef.current;
  const estado: StatusRota["estado"] | undefined =
    rota?.estado === "ativa" && expirouAgora ? "expirada" : rota?.estado;
  const inativa = !encontrada || estado !== "ativa";
  const van: LatLng | null =
    rota?.ultima_lat != null && rota?.ultima_lng != null
      ? { lat: rota.ultima_lat, lng: rota.ultima_lng }
      : null;

  // Destino do traçado: casa se aguardando a parada do aluno; escola na ida pós-embarque; casa na volta
  const destino: LatLng | null = useMemo(() => {
    if (!geo) return null;
    const m = rota?.minha;
    const volta = (rota?.sentido ?? (rota?.turno === "tarde" ? "volta" : "ida")) === "volta";
    if (!m) return volta ? geo.casa ?? geo.escola : geo.escola ?? geo.casa;
    if (m.status === "pendente") return volta ? geo.escola ?? geo.casa : geo.casa ?? geo.escola;
    return volta ? geo.casa ?? geo.escola : geo.escola ?? geo.casa;
  }, [geo, rota?.minha, rota?.turno, rota?.sentido]);

  // Privacidade: a casa do aluno só aparece quando a van está indo até a residência dele
  const casaVisivel: LatLng | null = useMemo(() => {
    if (!geo?.casa || !destino) return null;
    return destino.lat === geo.casa.lat && destino.lng === geo.casa.lng ? geo.casa : null;
  }, [geo, destino]);

  const banner = rota && encontrada ? statusDinamico(rota, geo, van) : null;

  // Avisos automáticos: chegando na casa e chegada na escola
  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    setAvisosOn(Notification.permission === "granted");
  }, []);

  async function ativarAvisos() {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    const perm = Notification.permission === "granted" ? "granted" : await Notification.requestPermission();
    setAvisosOn(perm === "granted");
    if (perm === "granted") {
      new Notification("🔔 Avisos ativados", {
        body: "Você será avisado quando a van estiver chegando e quando chegar na escola.",
      });
    }
  }

  useEffect(() => {
    if (!avisosOn || !rota) return;
    const aviso = avisoAtual(rota, geo, van);
    if (!aviso) return;
    if (ultimoAvisoRef.current === aviso.chave) return;
    ultimoAvisoRef.current = aviso.chave;
    try {
      new Notification(aviso.titulo, { body: aviso.corpo, tag: `tati-${aviso.chave}`, icon: "/icon-192.png" });
      navigator.vibrate?.([200, 100, 200]);
    } catch {
      /* alguns navegadores bloqueiam notificações */
    }
  }, [avisosOn, rota, geo, van]);




  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background">
      <div className="mx-auto max-w-2xl p-4 sm:p-6 space-y-4">
        <div className="rounded-2xl bg-primary p-4 text-primary-foreground shadow-lg">
          <div className="flex items-center gap-3">
            <div className="rounded-full bg-white/20 p-2"><Bus className="h-6 w-6" /></div>
            <div>
              <div className="text-lg font-extrabold">Rastreio da van em tempo real</div>
              <div className="text-xs opacity-90">
                {rota?.motorista_nome ? `Motorista: ${rota.motorista_nome}` : "Tati Van Escolar"}
                {rota?.turno ? ` • Turno da ${turnoLabel[rota.turno]}` : ""}
                {rota?.sentido ? (rota.sentido === "volta" ? " • Volta: Escola → Casa" : " • Ida: Casa → Escola") : ""}
              </div>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="rounded-xl border bg-card p-6 text-center text-sm text-muted-foreground">Carregando...</div>
        ) : !encontrada ? (
          <div className="rounded-xl border bg-card p-6 text-center text-sm">
            Link de rastreio inválido ou expirado.
          </div>
        ) : inativa ? (
          <>
            {estado === "encerrada" && banner && (
              <div className={`rounded-2xl border-2 p-4 text-center text-sm font-bold ${tomClass[banner.tom]}`}>
                {banner.texto}
              </div>
            )}
            <div className="rounded-xl border border-muted bg-card p-6 text-center">
              <div className="text-lg font-bold mb-1">
                {estado === "revogada" ? "Link revogado 🚫" : estado === "expirada" ? "Link expirado ⌛" : "Rota encerrada 🛑"}
              </div>
              <div className="text-sm text-muted-foreground">
                {estado === "revogada"
                  ? "O motorista revogou este link. Peça um novo link, se necessário."
                  : estado === "expirada"
                  ? `Este link deixou de ficar disponível em ${new Date(rota!.expira_em!).toLocaleString("pt-BR")}.`
                  : `Esta rota foi finalizada em ${new Date(rota!.encerrada_em!).toLocaleString("pt-BR")}.`}
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Card flutuante de status */}
            <div className={`rounded-2xl border-2 p-4 shadow-md animate-fade-in ${tomClass[banner!.tom]}`}>
              <div className="text-center text-sm font-bold leading-relaxed">{banner!.texto}</div>
              <div className="mt-1 text-center text-xs opacity-75">
                Última atualização:{" "}
                {rota!.ultima_atualizacao
                  ? new Date(rota!.ultima_atualizacao).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })
                  : "aguardando GPS..."}
              </div>
            </div>

            {avisosOn ? (
              <div className="flex items-center justify-center gap-2 rounded-xl border border-success/40 bg-success/10 p-3 text-xs font-semibold text-success">
                <Bell className="h-4 w-4" /> Avisos ativados: você será notificado quando a van estiver chegando e ao chegar na escola.
              </div>
            ) : (
              <button
                type="button"
                onClick={() => void ativarAvisos()}
                className="flex w-full items-center justify-center gap-2 rounded-xl border bg-card p-3 text-sm font-semibold text-primary shadow-sm"
              >
                <Bell className="h-4 w-4" /> Receber avisos da van no celular
              </button>
            )}



            <div className="overflow-hidden rounded-2xl border bg-card shadow-md" style={{ aspectRatio: "4 / 5" }}>
              {van ? (
                <ClientOnly
                  fallback={
                    <div className="flex h-full items-center justify-center p-6 text-sm text-muted-foreground">
                      Carregando mapa...
                    </div>
                  }
                >
                  <Suspense
                    fallback={
                      <div className="flex h-full items-center justify-center p-6 text-sm text-muted-foreground">
                        Carregando mapa...
                      </div>
                    }
                  >
                    <RastreioMapa van={van} heading={heading} casa={casaVisivel} escola={geo?.escola ?? null} destino={destino} />
                  </Suspense>
                </ClientOnly>
              ) : (
                <div className="flex h-full items-center justify-center p-6 text-center text-sm text-muted-foreground">
                  Aguardando a primeira leitura do GPS do motorista...
                </div>
              )}
            </div>

            {van && (
              <a
                className="flex items-center justify-center gap-2 rounded-xl border bg-card p-3 text-sm font-semibold text-primary shadow-sm"
                href={`https://www.openstreetmap.org/?mlat=${van.lat}&mlon=${van.lng}#map=17/${van.lat}/${van.lng}`}
                target="_blank" rel="noopener noreferrer"
              >
                <Navigation className="h-4 w-4" /> Abrir no OpenStreetMap
              </a>
            )}

            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
              <RefreshCw className="h-3 w-3" /> Atualiza automaticamente a cada 5 segundos.
            </div>
          </>
        )}

        <div className="text-center text-xs text-muted-foreground">
          Feito com 💙 pela Tati Van Escolar
        </div>
      </div>
    </div>
  );
}
