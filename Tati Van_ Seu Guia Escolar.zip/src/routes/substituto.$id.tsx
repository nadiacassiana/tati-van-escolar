import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Bus, MapPin, Navigation, Phone, Printer, School, Clock, ArrowRight, Home } from "lucide-react";
import { turnoLabel } from "@/lib/rota-ativa";
import {
  carregarRotaSubstitutoPublica, osmUrl, wazeUrl,
  type ParadaSubstituto, type RotaSubstitutoPublica,
} from "@/lib/rota-substituto";

export const Route = createFileRoute("/substituto/$id")({
  head: () => ({
    meta: [
      { title: "Rota do motorista substituto — Tati Van Escolar" },
      { name: "description", content: "Sequência de paradas da rota escolar para o motorista substituto." },
      { name: "robots", content: "noindex,nofollow" },
      { property: "og:title", content: "Rota do motorista substituto — Tati Van Escolar" },
      { property: "og:description", content: "Sequência de paradas da rota escolar para o motorista substituto." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SubstitutoPage,
});

function ordinal(i: number): string {
  return `${i + 1}º`;
}

type EscolaDestino = { nome: string; endereco: string };

function NavButtons({ endereco, compact }: { endereco: string; compact?: boolean }) {
  return (
    <div className={`grid grid-cols-2 gap-2 print:hidden ${compact ? "" : "mt-3"}`}>
      <a
        href={wazeUrl(endereco)}
        target="_blank"
        rel="noopener noreferrer"
        className={`flex items-center justify-center gap-1.5 rounded-xl bg-primary font-bold text-primary-foreground ${compact ? "px-2 py-2 text-xs" : "px-3 py-2.5 text-sm"}`}
      >
        <Navigation className={compact ? "h-3.5 w-3.5" : "h-4 w-4"} /> Waze
      </a>
      <a
        href={osmUrl(endereco)}
        target="_blank"
        rel="noopener noreferrer"
        className={`flex items-center justify-center gap-1.5 rounded-xl border font-bold hover:bg-secondary ${compact ? "px-2 py-2 text-xs" : "px-3 py-2.5 text-sm"}`}
      >
        <MapPin className={compact ? "h-3.5 w-3.5" : "h-4 w-4"} /> OpenStreetMap
      </a>
    </div>
  );
}

function EscolaCard({ escola, rotulo }: { escola: EscolaDestino; rotulo: string }) {
  return (
    <div className="rounded-2xl border-2 border-primary/30 bg-primary/5 p-4">
      <div className="flex items-start gap-3">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
          <School className="h-4.5 w-4.5" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[11px] font-bold uppercase tracking-wide text-primary">{rotulo}</div>
          <div className="text-base font-bold leading-tight">{escola.nome}</div>
          {escola.endereco && (
            <div className="mt-1 flex items-start gap-1.5 text-sm text-muted-foreground">
              <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <span>{escola.endereco}</span>
            </div>
          )}
        </div>
      </div>
      {escola.endereco && <NavButtons endereco={escola.endereco} />}
    </div>
  );
}

function ParadaCard({ p, i, sentido }: { p: ParadaSubstituto; i: number; sentido: "ida" | "volta" }) {
  return (
    <li className="rounded-2xl border bg-card p-4">
      <div className="flex items-start gap-3">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent text-sm font-extrabold text-accent-foreground">
          {ordinal(i)}
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-base font-bold leading-tight">{p.nome}</div>
          {p.endereco && (
            <div className="mt-1 flex items-start gap-1.5 text-sm text-muted-foreground">
              <Home className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <span>{p.endereco}</span>
            </div>
          )}
          {(p.escola || p.periodo) && (
            <div className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
              <School className="h-3.5 w-3.5 shrink-0" />
              <span>{[p.escola, p.periodo].filter(Boolean).join(" • ")}</span>
            </div>
          )}
          {p.escola_endereco && (
            <div className="mt-0.5 flex items-start gap-1.5 text-xs text-muted-foreground">
              <MapPin className="mt-0.5 h-3 w-3 shrink-0" />
              <span>{p.escola_endereco}</span>
            </div>
          )}
          {p.telefone && (
            <a
              href={`tel:${p.telefone.replace(/\D/g, "")}`}
              className="mt-1 flex items-center gap-1.5 text-xs font-semibold text-primary"
            >
              <Phone className="h-3.5 w-3.5" />
              {p.responsavel ? `${p.responsavel} — ` : ""}{p.telefone}
            </a>
          )}
        </div>
      </div>
      {p.endereco && (
        <div className="mt-3">
          <div className="mb-1 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
            {sentido === "ida" ? "Navegar até a casa" : "Navegar até a casa (destino)"}
          </div>
          <NavButtons endereco={p.endereco} compact />
        </div>
      )}
      {p.escola_endereco && (
        <div className="mt-2">
          <div className="mb-1 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
            {sentido === "ida" ? "Navegar até a escola" : "Navegar até a escola (embarque)"}
          </div>
          <NavButtons endereco={p.escola_endereco} compact />
        </div>
      )}
    </li>
  );
}

function SubstitutoPage() {
  const { id } = Route.useParams();
  const [rota, setRota] = useState<RotaSubstitutoPublica | null>(null);
  const [loading, setLoading] = useState(true);
  const [sentido, setSentido] = useState<"ida" | "volta">("ida");

  useEffect(() => {
    (async () => {
      setRota(await carregarRotaSubstitutoPublica(id));
      setLoading(false);
    })();
  }, [id]);

  if (loading) {
    return <div className="p-8 text-center text-sm text-muted-foreground">Carregando rota...</div>;
  }

  if (!rota?.encontrada || rota.estado !== "ativa") {
    const msg =
      rota?.estado === "expirada"
        ? "Este link expirou (validade de 24 horas). Peça um novo à motorista titular."
        : rota?.estado === "revogada"
          ? "Este link foi desativado pela motorista titular."
          : "Rota não encontrada.";
    return (
      <div className="mx-auto max-w-md p-6">
        <div className="rounded-2xl border bg-card p-6 text-center">
          <Bus className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
          <p className="text-sm font-medium text-muted-foreground">{msg}</p>
        </div>
      </div>
    );
  }

  const paradasIda = rota.paradas ?? [];
  const paradas = sentido === "ida" ? paradasIda : [...paradasIda].reverse();
  const expira = rota.expira_em ? new Date(rota.expira_em) : null;

  // Escolas únicas da rota (com endereço, quando cadastrado)
  const escolasMap = new Map<string, EscolaDestino>();
  for (const p of paradasIda) {
    const nome = (p.escola || "").trim();
    if (!nome || escolasMap.has(nome)) continue;
    escolasMap.set(nome, { nome, endereco: (p.escola_endereco || "").trim() });
  }
  const escolas = [...escolasMap.values()];

  return (
    <div className="mx-auto max-w-lg space-y-4 p-4 pb-16">
      <header className="rounded-2xl bg-primary p-5 text-primary-foreground print:bg-white print:text-black">
        <h1 className="text-xl font-extrabold">
          🚐 Rota da {rota.turno ? turnoLabel[rota.turno] : ""}
        </h1>
        <p className="mt-1 text-sm opacity-90">
          {paradas.length} parada(s) na ordem definida
          {rota.titular_nome ? ` por ${rota.titular_nome}` : ""}.
        </p>
        {expira && (
          <p className="mt-2 flex items-center gap-1.5 text-xs opacity-90">
            <Clock className="h-3.5 w-3.5" />
            Acesso válido até {expira.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}
          </p>
        )}
      </header>

      {/* Alternância Ida / Volta */}
      <div className="grid grid-cols-2 gap-2 print:hidden">
        <button
          type="button"
          onClick={() => setSentido("ida")}
          className={`rounded-xl border px-3 py-3 text-sm font-bold transition-colors ${
            sentido === "ida" ? "bg-primary text-primary-foreground border-primary" : "bg-card hover:bg-secondary"
          }`}
        >
          Ida — Casa <ArrowRight className="inline h-3.5 w-3.5" /> Escola
        </button>
        <button
          type="button"
          onClick={() => setSentido("volta")}
          className={`rounded-xl border px-3 py-3 text-sm font-bold transition-colors ${
            sentido === "volta" ? "bg-primary text-primary-foreground border-primary" : "bg-card hover:bg-secondary"
          }`}
        >
          Volta — Escola <ArrowRight className="inline h-3.5 w-3.5" /> Casa
        </button>
      </div>

      <div className="print:hidden">
        <button
          type="button"
          onClick={() => window.print()}
          className="w-full rounded-xl border bg-card px-4 py-3 text-sm font-bold hover:bg-secondary"
        >
          <Printer className="mr-2 inline h-4 w-4" /> Exportar rota em PDF / Imprimir
        </button>
      </div>

      {/* Na VOLTA, o embarque nas escolas aparece no início da rota */}
      {sentido === "volta" && escolas.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-sm font-extrabold uppercase tracking-wide text-muted-foreground">
            🏫 Embarque — buscar na(s) escola(s)
          </h2>
          {escolas.map((e) => (
            <EscolaCard key={e.nome} escola={e} rotulo="Embarque aqui" />
          ))}
          <h2 className="pt-1 text-sm font-extrabold uppercase tracking-wide text-muted-foreground">
            🏠 Entregas — ordem das casas
          </h2>
        </div>
      )}

      <ol className="space-y-3">
        {paradas.map((p, i) => (
          <ParadaCard key={`${p.nome}-${i}`} p={p} i={i} sentido={sentido} />
        ))}
      </ol>

      {/* Na IDA, as escolas de destino aparecem ao final dos embarques residenciais */}
      {sentido === "ida" && escolas.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-sm font-extrabold uppercase tracking-wide text-muted-foreground">
            🏫 Destino final — escola(s) desta rota
          </h2>
          {escolas.map((e) => (
            <EscolaCard key={e.nome} escola={e} rotulo="Destino final" />
          ))}
        </div>
      )}

      <p className="text-center text-[11px] text-muted-foreground print:hidden">
        Este link mostra apenas informações operacionais da rota. Nenhum dado financeiro é exibido.
      </p>

      {/* Versão limpa para impressão / PDF (A4) */}
      <div id="print-area" className="hidden">
        <div style={{ fontFamily: "Arial, Helvetica, sans-serif", fontSize: 12, color: "#000" }}>
          <h1 style={{ fontSize: 18, margin: 0 }}>
            Rota da {rota.turno ? turnoLabel[rota.turno] : ""} — {sentido === "ida" ? "Ida (Casa → Escola)" : "Volta (Escola → Casa)"}
          </h1>
          <p style={{ margin: "4px 0 12px", fontSize: 11 }}>
            {paradas.length} parada(s) na ordem definida
            {rota.titular_nome ? ` por ${rota.titular_nome}` : ""}.
            {expira ? ` Válido até ${expira.toLocaleString("pt-BR")}.` : ""}
          </p>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                {["#", "Aluno", "Endereço", "Responsável / Contato", "Escola"].map((h) => (
                  <th
                    key={h}
                    style={{
                      border: "1px solid #000", padding: "4px 6px", textAlign: "left",
                      fontSize: 11, background: "#eee",
                    }}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paradas.map((p, i) => (
                <tr key={`print-${p.nome}-${i}`}>
                  <td style={{ border: "1px solid #000", padding: "4px 6px" }}>{i + 1}</td>
                  <td style={{ border: "1px solid #000", padding: "4px 6px" }}>{p.nome}</td>
                  <td style={{ border: "1px solid #000", padding: "4px 6px" }}>{p.endereco}</td>
                  <td style={{ border: "1px solid #000", padding: "4px 6px" }}>
                    {[p.responsavel, p.telefone].filter(Boolean).join(" — ")}
                  </td>
                  <td style={{ border: "1px solid #000", padding: "4px 6px" }}>
                    {[p.escola, p.periodo].filter(Boolean).join(" • ")}
                    {p.escola_endereco ? <div style={{ fontSize: 10 }}>{p.escola_endereco}</div> : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {escolas.length > 0 && (
            <>
              <h2 style={{ fontSize: 14, margin: "16px 0 6px" }}>Escolas da rota</h2>
              <ul style={{ margin: 0, paddingLeft: 16 }}>
                {escolas.map((e) => (
                  <li key={`print-esc-${e.nome}`} style={{ marginBottom: 3 }}>
                    <strong>{e.nome}</strong>
                    {e.endereco ? ` — ${e.endereco}` : ""}
                  </li>
                ))}
              </ul>
            </>
          )}
          <p style={{ marginTop: 16, fontSize: 10 }}>
            Documento operacional. Nenhum dado financeiro é exibido.
          </p>
        </div>
      </div>
    </div>
  );
}

