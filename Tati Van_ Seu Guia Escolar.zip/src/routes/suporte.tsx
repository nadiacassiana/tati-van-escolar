import { SUPORTE_WHATSAPP, suporteWhatsAppLink } from "@/lib/suporte";
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft, Clock, Headphones, Mail, MessageCircle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/suporte")({
  head: () => ({
    meta: [
      { title: "Central de Suporte — Tati Van Escolar" },
      {
        name: "description",
        content:
          "Central de Suporte da Tati Van Escolar. Fale conosco pelo WhatsApp, e-mail ou consulte nossas perguntas frequentes.",
      },
      { property: "og:title", content: "Central de Suporte — Tati Van Escolar" },
      {
        property: "og:description",
        content:
          "Estamos prontos para ajudar você! Entre em contato pelo WhatsApp, e-mail ou encontre respostas rápidas no FAQ.",
      },
    ],
  }),
  component: SuportePage,
});

const WHATSAPP_NUMBER = SUPORTE_WHATSAPP;
const WHATSAPP_LINK = suporteWhatsAppLink();
const EMAIL = "tatiassistentevirtualbr@gmail.com";
const MAILTO_LINK = `mailto:${EMAIL}?subject=Suporte%20Tati%20Van%20Escolar`;

const FAQS = [
  {
    pergunta: "Como redefinir minha senha?",
    resposta:
      "Na tela de login, clique em \"Esqueci minha senha\" e informe seu e-mail cadastrado. Você receberá um link seguro para criar uma nova senha. Se não encontrar o e-mail, verifique sua caixa de spam ou lixo eletrônico.",
  },
  {
    pergunta: "Como alterar meus dados?",
    resposta:
      "Acesse a plataforma e vá até Configurações → Dados do motorista. Lá você pode atualizar seu nome completo, apelido, nome da empresa e outras informações. Lembre-se de salvar as alterações antes de sair da tela.",
  },
  {
    pergunta: "Como cancelar minha assinatura?",
    resposta:
      "Você pode cancelar a qualquer momento em Configurações → Assinatura. O acesso permanece ativo até o final do período pago. Durante o teste grátis de 10 dias, nenhum pagamento é exigido.",
  },
  {
    pergunta: "Como instalar a Tati Van Escolar como aplicativo?",
    resposta:
      "No Android, abra o site no Chrome, toque no menu (⋮) e selecione \"Adicionar à tela inicial\". No iPhone, use o Safari, toque no botão compartilhar e escolha \"Adicionar à Tela de Início\". Assim, a Tati fica como um app no celular.",
  },
  {
    pergunta: "Como atualizar meus dados de pagamento?",
    resposta:
      "Entre em Configurações → Assinatura e clique em \"Atualizar pagamento\". Você será redirecionado para o portal seguro de pagamento, onde poderá informar um novo cartão ou método de pagamento.",
  },
];

function SuportePage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header
        className="border-b"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-6 py-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-xl">
              🚐
            </div>
            <div className="text-primary-foreground">
              <div className="text-sm font-extrabold leading-none">Tati Van Escolar</div>
              <div className="mt-1 text-[10px] uppercase tracking-wider opacity-80">
                Assistente do motorista
              </div>
            </div>
          </Link>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => router.history.back()}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
        </div>
      </header>

      {/* Título */}
      <section className="border-b bg-secondary/30">
        <div className="mx-auto max-w-4xl px-6 py-10 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <Headphones className="h-7 w-7" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
            Central de Suporte
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Estamos prontos para ajudar você! Entre em contato sempre que precisar de
            suporte, tirar dúvidas ou solicitar ajuda com a plataforma.
          </p>
        </div>
      </section>

      <main className="mx-auto max-w-4xl px-6 py-10">
        {/* Canais de atendimento */}
        <section className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {/* WhatsApp */}
          <div
            className="rounded-2xl border bg-card p-6"
            style={{ boxShadow: "var(--shadow-card)" }}
          >
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
              <Phone className="h-6 w-6" />
            </div>
            <h2 className="mb-1 flex items-center gap-2 text-base font-extrabold">
              <MessageCircle className="h-4 w-4 text-green-600" />
              WhatsApp Business
            </h2>
            <p className="mb-4 text-sm text-muted-foreground">+55 (11) 96460-0186</p>
            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer">
              <Button className="w-full bg-green-600 font-bold text-white hover:bg-green-700">
                Conversar pelo WhatsApp
              </Button>
            </a>
          </div>

          {/* E-mail */}
          <div
            className="rounded-2xl border bg-card p-6"
            style={{ boxShadow: "var(--shadow-card)" }}
          >
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
              <Mail className="h-6 w-6" />
            </div>
            <h2 className="mb-1 text-base font-extrabold">E-mail</h2>
            <p className="mb-4 text-sm text-muted-foreground">{EMAIL}</p>
            <a href={MAILTO_LINK}>
              <Button variant="outline" className="w-full font-bold">
                Enviar e-mail
              </Button>
            </a>
          </div>

          {/* Horário */}
          <div
            className="rounded-2xl border bg-card p-6"
            style={{ boxShadow: "var(--shadow-card)" }}
          >
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-accent/20 text-accent-foreground">
              <Clock className="h-6 w-6" />
            </div>
            <h2 className="mb-1 text-base font-extrabold">Horário de atendimento</h2>
            <p className="mb-1 text-sm font-medium">Segunda a sexta-feira</p>
            <p className="mb-4 text-sm font-semibold">09:00 às 18:00</p>
            <p className="text-xs text-muted-foreground">
              Responderemos o mais rápido possível durante nosso horário de atendimento.
            </p>
          </div>
        </section>

        {/* FAQ */}
        <section className="mt-12">
          <div className="mb-6 text-center">
            <h2 className="text-2xl font-extrabold">Perguntas Frequentes</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Clique em cada pergunta para ver a resposta.
            </p>
          </div>
          <Accordion type="single" collapsible className="rounded-2xl border bg-card">
            {FAQS.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border-b last:border-b-0"
              >
                <AccordionTrigger className="px-6 py-4 text-left text-sm font-semibold hover:no-underline">
                  {faq.pergunta}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-sm leading-relaxed text-muted-foreground">
                  {faq.resposta}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>
      </main>

      {/* Rodapé */}
      <footer className="border-t bg-secondary/30">
        <div className="mx-auto max-w-4xl px-6 py-10 text-center">
          <div className="mb-4 flex items-center justify-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-xl">
              🚐
            </div>
            <div className="text-left">
              <div className="text-sm font-extrabold leading-none">Tati Assistente Virtual</div>
              <div className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                Ecossistema Tati Van Escolar
              </div>
            </div>
          </div>
          <p className="mx-auto max-w-xl text-sm text-muted-foreground">
            “Cuidando da tecnologia para que você cuide do transporte escolar com mais
            tranquilidade.”
          </p>
          <div className="mt-6">
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Voltar para a página inicial
              </Button>
            </Link>
          </div>
          <div className="mt-8 text-xs text-muted-foreground">
            © {new Date().getFullYear()} Tati Assistente Virtual. Todos os direitos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
}
