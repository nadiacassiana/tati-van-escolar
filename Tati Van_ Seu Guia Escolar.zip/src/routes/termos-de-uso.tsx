import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { ArrowLeft, FileText, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/termos-de-uso")({
  head: () => ({
    meta: [
      { title: "Termos de Uso — Tati Van Escolar" },
      {
        name: "description",
        content:
          "Termos de Uso da Tati Van Escolar. Regras para utilização da plataforma de gestão para motoristas de transporte escolar.",
      },
      { property: "og:title", content: "Termos de Uso — Tati Van Escolar" },
      {
        property: "og:description",
        content:
          "Termos de Uso da Tati Van Escolar. Regras para utilização da plataforma de gestão para motoristas de transporte escolar.",
      },
    ],
  }),
  component: TermosDeUsoPage,
});

const CONTATO = "tatiassistentevirtualbr@gmail.com";

function TermosDeUsoPage() {
  const router = useRouter();

  const secoes: { id: string; titulo: string }[] = [
    { id: "apresentacao", titulo: "1. Apresentação" },
    { id: "aceitacao", titulo: "2. Aceitação dos Termos" },
    { id: "objetivo", titulo: "3. Objetivo da Plataforma" },
    { id: "cadastro", titulo: "4. Cadastro do Usuário" },
    { id: "responsabilidades-usuario", titulo: "5. Responsabilidades do Usuário" },
    { id: "responsabilidades-tati", titulo: "6. Responsabilidades da Tati Van Escolar" },
    { id: "disponibilidade", titulo: "7. Disponibilidade do Sistema" },
    { id: "seguranca", titulo: "8. Segurança da Conta e da Senha" },
    { id: "pagamento", titulo: "9. Pagamento da Assinatura" },
    { id: "teste", titulo: "10. Período de Teste Gratuito" },
    { id: "cancelamento", titulo: "11. Cancelamento da Assinatura" },
    { id: "exclusao", titulo: "12. Exclusão da Conta" },
    { id: "propriedade", titulo: "13. Propriedade Intelectual" },
    { id: "limitacao", titulo: "14. Limitação de Responsabilidade" },
    { id: "alteracoes", titulo: "15. Alterações destes Termos de Uso" },
    { id: "legislacao", titulo: "16. Legislação Aplicável" },
    { id: "contato", titulo: "17. Contato" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header
        className="border-b"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-4 px-6 py-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent text-xl">
              🚐
            </div>
            <div className="text-primary-foreground">
              <div className="text-sm font-extrabold leading-none">Tati Van Escolar</div>
              <div className="mt-1 text-[10px] uppercase tracking-wider opacity-80">
                Assistente do motorista
              </div>
            </div>
          </Link>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => router.history.back()}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
        </div>
      </header>

      {/* Título */}
      <section className="border-b bg-secondary/30">
        <div className="mx-auto max-w-4xl px-6 py-10 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <FileText className="h-7 w-7" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
            Termos de Uso
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Regras para utilização da <strong>Tati Van Escolar</strong>.
            Leia com atenção para aproveitar a plataforma com segurança e tranquilidade.
          </p>
        </div>
      </section>

      <div className="mx-auto grid max-w-5xl gap-8 px-6 py-10 lg:grid-cols-[240px_1fr]">
        {/* Sumário */}
        <aside className="hidden lg:block">
          <div className="sticky top-6 rounded-2xl border bg-card p-5 shadow-sm">
            <h2 className="mb-3 text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
              Sumário
            </h2>
            <ul className="space-y-2 text-sm">
              {secoes.map((s) => (
                <li key={s.id}>
                  <a
                    href={`#${s.id}`}
                    className="text-muted-foreground hover:text-primary"
                  >
                    {s.titulo}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        {/* Conteúdo */}
        <main className="max-w-none space-y-10 text-[15px] leading-relaxed text-foreground">
          <div className="rounded-2xl border bg-primary/5 p-6 text-foreground">
            <p className="text-base leading-relaxed">
              Bem-vindo (a) à <strong>Tati Van Escolar</strong>! Estes Termos de Uso
              estabelecem as regras para utilização da plataforma, garantindo uma
              experiência segura, transparente e confiável para todos os usuários.
              Recomendamos a leitura completa deste documento antes de utilizar nossos
              serviços.
            </p>
          </div>

          <Secao id="apresentacao" titulo="1. Apresentação">
            <p>
              A <strong>Tati Van Escolar</strong> é uma plataforma do ecossistema{" "}
              <strong>Tati Assistente Virtual</strong>, desenvolvida e administrada
              por sua desenvolvedora, atualmente operada como <strong>pessoa física</strong>.
              O sistema foi criado para auxiliar motoristas de transporte escolar na
              organização da rotina diária, oferecendo funcionalidades como cadastro de
              alunos e responsáveis, controle financeiro, emissão de recibos e contratos,
              gestão de documentos, agenda, checklist diário, manutenção da van e
              rastreamento temporário da rota.
            </p>
            <p className="mt-3">
              Estes Termos de Uso regulam o relacionamento entre a plataforma e o usuário
              (motorista), estabelecendo direitos, responsabilidades e condições para o
              uso dos serviços.
            </p>
          </Secao>

          <Secao id="aceitacao" titulo="2. Aceitação dos Termos">
            <p>
              Ao criar uma conta, acessar ou utilizar a <strong>Tati Van Escolar</strong>,
              o usuário declara que leu, compreendeu e concorda integralmente com estes
              Termos de Uso e com a{" "}
              <Link
                to="/privacidade"
                className="font-semibold text-primary hover:underline"
              >
                Política de Privacidade
              </Link>
              .
            </p>
            <p className="mt-3">
              Caso não concorde com qualquer disposição deste documento, o usuário não
              deverá utilizar a plataforma. O uso continuado dos serviços após eventuais
              alterações nos Termos significa a aceitação das novas condições.
            </p>
          </Secao>

          <Secao id="objetivo" titulo="3. Objetivo da Plataforma">
            <p>
              A <strong>Tati Van Escolar</strong> tem como objetivo facilitar a gestão
              do transporte escolar, oferecendo ferramentas para:
            </p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>Cadastrar e organizar alunos e responsáveis;</li>
              <li>Controlar mensalidades, recebimentos, despesas e recibos;</li>
              <li>Gerenciar contratos de prestação de serviço;</li>
              <li>Acompanhar documentos, manutenção e vencimentos da van;</li>
              <li>Organizar a agenda e a rotina diária com checklist por turno;</li>
              <li>Enviar mensagens e compartilhar o rastreamento temporário da rota;</li>
              <li>Monitorar a saúde geral da van e da operação.</li>
            </ul>
            <p className="mt-3">
              A plataforma é um software de gestão. Ela não substitui obrigações legais,
              contratuais ou regulatórias do motorista, nem assume a responsabilidade pelo
              transporte em si.
            </p>
          </Secao>

          <Secao id="cadastro" titulo="4. Cadastro do Usuário">
            <p>
              Para utilizar a plataforma, o motorista deve criar uma conta informando
              dados verdadeiros, como nome, e-mail e senha. O usuário é responsável pela
              veracidade e atualização dos dados cadastrados.
            </p>
            <p className="mt-3">
              É vedado criar contas com informações falsas, usar dados de terceiros sem
              autorização ou praticar qualquer atividade ilícita por meio da plataforma.
              A Tati Van Escolar se reserva o direito de suspender ou excluir contas que
              violem estas regras.
            </p>
          </Secao>

          <Secao id="responsabilidades-usuario" titulo="5. Responsabilidades do Usuário">
            <p>O usuário se compromete a:</p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>
                Utilizar a plataforma de forma ética, legal e de acordo com estes Termos;
              </li>
              <li>
                Manter sua senha em segurança e não compartilhar o acesso à sua conta;
              </li>
              <li>
                Cadastrar informações verdadeiras sobre alunos, responsáveis e operações;
              </li>
              <li>
                Respeitar a privacidade dos dados de crianças e adolescentes, utilizando
                as informações apenas para fins relacionados ao transporte escolar;
              </li>
              <li>
                Obter, quando necessário, o consentimento dos responsáveis legais para o
                tratamento de dados dos alunos menores de idade;
              </li>
              <li>
                Cumprir as leis de trânsito, as normas de transporte escolar e as
                obrigações contratuais assumidas com os responsáveis;
              </li>
              <li>
                Não utilizar a plataforma para assédio, discriminação, spam ou qualquer
                prática abusiva.
              </li>
            </ul>
            <p className="mt-3">
              O motorista é o único responsável pelas informações que insere na
              plataforma e pelas decisões tomadas com base nessas informações.
            </p>
          </Secao>

          <Secao id="responsabilidades-tati" titulo="6. Responsabilidades da Tati Van Escolar">
            <p>A Tati Van Escolar se compromete a:</p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>Manter a plataforma disponível e funcionando da melhor forma possível;</li>
              <li>
                Proteger os dados do usuário com medidas técnicas e organizacionais de
                segurança, conforme descrito na Política de Privacidade;
              </li>
              <li>
                Isolar as informações de cada conta, garantindo que um motorista não
                acesse dados de outro;
              </li>
              <li>
                Oferecer suporte pelo canal oficial para dúvidas e problemas relacionados
                ao funcionamento da plataforma;
              </li>
              <li>
                Melhorar continuamente a plataforma e corrigir falhas quando identificadas.
              </li>
            </ul>
            <p className="mt-3">
              A Tati Van Escolar não se responsabiliza pelo conteúdo inserido pelo usuário,
              pelos contratos firmados fora da plataforma, nem pelas condutas do motorista
              no trânsito ou no relacionamento com responsáveis e alunos.
            </p>
          </Secao>

          <Secao id="disponibilidade" titulo="7. Disponibilidade do Sistema">
            <p>
              Buscamos manter a plataforma acessível 24 horas por dia, 7 dias por semana.
              No entanto, podem ocorrer interrupções por motivos de manutenção, atualização,
              falhas técnicas ou fatores externos (como instabilidade de internet ou provedores
              de nuvem).
            </p>
            <p className="mt-3">
              Nesses casos, trabalharemos para restabelecer o serviço o mais rápido possível.
              Eventuais interrupções não geram direito a indenização ou ressarcimento, salvo
              quando expressamente previsto em lei.
            </p>
          </Secao>

          <Secao id="seguranca" titulo="8. Segurança da Conta e da Senha">
            <p>
              O acesso à conta é protegido por e-mail e senha. O usuário é responsável por
              manter sua senha em sigilo e por todas as atividades realizadas em sua conta.
            </p>
            <p className="mt-3">
              Em caso de suspeita de acesso não autorizado, o usuário deve alterar sua senha
              imediatamente e entrar em contato com o suporte. A Tati Van Escolar não se
              responsabiliza por prejuízos decorrentes do uso indevido da conta por parte
              do usuário ou de terceiros que tenham obtido a senha.
            </p>
          </Secao>

          <Secao id="pagamento" titulo="9. Pagamento da Assinatura">
            <p>
              Após o período de teste gratuito, o uso da plataforma requer a assinatura no
              valor de <strong>R$ 29,90 por mês</strong>. O pagamento é de responsabilidade
              do usuário e deve ser realizado conforme as condições disponibilizadas na
              plataforma.
            </p>
            <p className="mt-3">
              A falta de pagamento ou atraso pode resultar na <strong>suspensão do acesso</strong>
              aos serviços até a regularização. Durante a suspensão, os dados permanecem
              armazenados por um período razoável, conforme descrito na Política de Privacidade.
            </p>
          </Secao>

          <Secao id="teste" titulo="10. Período de Teste Gratuito">
            <p>
              Todo novo usuário tem direito a <strong>10 dias de teste gratuito</strong>
              para conhecer e utilizar a plataforma sem custo. Durante esse período, é
              possível acessar as funcionalidades disponíveis e avaliar se o sistema atende
              às necessidades.
            </p>
            <p className="mt-3">
              Ao final dos 10 dias, caso o usuário deseje continuar utilizando a plataforma,
              deverá ativar a assinatura mensal de R$ 29,90. Caso não queira continuar, pode
              cancelar a qualquer momento, conforme descrito no item seguinte.
            </p>
          </Secao>

          <Secao id="cancelamento" titulo="11. Cancelamento da Assinatura">
            <p>
              O usuário pode cancelar sua assinatura a <strong>qualquer momento</strong>,
              sem necessidade de justificativa ou multa. O cancelamento pode ser feito
              diretamente na plataforma ou solicitado pelo canal oficial de contato.
            </p>
            <p className="mt-3">
              Após o cancelamento, o acesso aos serviços pagos será suspenso ao final do
              período já pago. Os dados do usuário permanecem armazenados por um prazo
              compatível com as obrigações legais e com a Política de Privacidade, podendo
              ser excluídos definitivamente mediante solicitação.
            </p>
          </Secao>

          <Secao id="exclusao" titulo="12. Exclusão da Conta">
            <p>
              O usuário pode excluir sua conta e todos os dados cadastrados a qualquer
              momento, diretamente na plataforma em{" "}
              <strong>Configurações → Excluir conta e dados</strong>, ou por meio de
              solicitação ao canal oficial de contato.
            </p>
            <p className="mt-3">
              A exclusão é <strong>permanente</strong> e remove todos os dados vinculados
              à conta, incluindo alunos, responsáveis, financeiro, gastos, documentos,
              contratos, recibos, agenda, mensagens, rotas e histórico. Após confirmada, a
              ação não pode ser desfeita.
            </p>
          </Secao>

          <Secao id="propriedade" titulo="13. Propriedade Intelectual">
            <p>
              Todos os direitos de propriedade intelectual relacionados à plataforma
              (marca, nome, design, layout, código, funcionalidades, textos e imagens)
              pertencem à <strong>Tati Assistente Virtual</strong> e são protegidos pela
              legislação brasileira.
            </p>
            <p className="mt-3">
              O usuário recebe uma licença de uso limitada, pessoal e intransferível para
              utilizar a plataforma durante a vigência de sua conta. É vedado copiar,
              modificar, distribuir, vender, fazer engenharia reversa ou utilizar partes da
              plataforma para fins não autorizados.
            </p>
          </Secao>

          <Secao id="limitacao" titulo="14. Limitação de Responsabilidade">
            <p>
              A Tati Van Escolar é um software de gestão e não participa diretamente do
              transporte escolar. Portanto, não se responsabiliza por:
            </p>
            <ul className="mt-3 list-disc space-y-1 pl-6">
              <li>
                Acidentes, atrasos, falhas de comunicação ou problemas ocorridos durante o
                transporte dos alunos;
              </li>
              <li>
                Decisões tomadas pelo motorista com base nas informações da plataforma;
              </li>
              <li>
                Danos causados por uso inadequado da plataforma ou por informações
                incorretas inseridas pelo usuário;
              </li>
              <li>
                Indisponibilidade temporária da plataforma por motivos técnicos ou de
                força maior;
              </li>
              <li>
                Perda de dados decorrente de falhas no dispositivo do usuário ou de falta
                de backup local realizado pelo próprio usuário.
              </li>
            </ul>
            <p className="mt-3">
              Na medida permitida pela legislação aplicável, a responsabilidade da
              plataforma fica limitada ao valor pago pelo usuário no período em que o
              evento ocorreu.
            </p>
          </Secao>

          <Secao id="alteracoes" titulo="15. Alterações destes Termos de Uso">
            <p>
              A Tati Van Escolar pode atualizar estes Termos de Uso a qualquer momento,
              especialmente para refletir melhorias na plataforma, mudanças legais ou novas
              funcionalidades. A versão mais recente estará sempre disponível nesta página,
              com a respectiva data de atualização.
            </p>
            <p className="mt-3">
              O uso continuado da plataforma após a publicação das alterações significa a
              aceitação das novas condições. Recomendamos que o usuário consulte esta página
              periodicamente.
            </p>
          </Secao>

          <Secao id="legislacao" titulo="16. Legislação Aplicável">
            <p>
              Estes Termos de Uso são regidos pelas leis da República Federativa do Brasil,
              em especial pela Lei Geral de Proteção de Dados (Lei nº 13.709/2018 — LGPD),
              pelo Marco Civil da Internet (Lei nº 12.965/2014) e pelo Código de Defesa do
              Consumidor (Lei nº 8.078/1990), quando aplicável.
            </p>
            <p className="mt-3">
              Para dirimir quaisquer dúvidas ou controvérsias, as partes elegem o foro da
              comarca do domicílio do usuário, salvo quando outro foro for legalmente
              determinado.
            </p>
          </Secao>

          <Secao id="contato" titulo="17. Contato">
            <p>
              Para dúvidas, sugestões, solicitações ou qualquer assunto relacionado a estes
              Termos de Uso, entre em contato pelo canal oficial:
            </p>
            <a
              href={`mailto:${CONTATO}`}
              className="mt-4 inline-flex items-center gap-2 rounded-xl border bg-secondary/40 px-4 py-3 text-sm font-semibold text-primary hover:bg-secondary"
            >
              <Mail className="h-4 w-4" />
              {CONTATO}
            </a>
          </Secao>

          <div className="rounded-2xl border bg-secondary/30 p-6 text-sm text-muted-foreground">
            <div>
              <strong>Versão 1.0</strong>
            </div>
            <div className="mt-1">Última atualização: 01 de julho de 2026</div>
            <div className="mt-1">
              Plataforma desenvolvida e administrada pela{" "}
              <strong>Tati Assistente Virtual</strong>, atualmente operada por sua
              desenvolvedora como pessoa física.
            </div>
          </div>

          <div className="flex justify-center pt-2">
            <Button
              variant="outline"
              onClick={() => router.history.back()}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar à página anterior
            </Button>
          </div>
        </main>
      </div>
    </div>
  );
}

function Secao({
  id,
  titulo,
  children,
}: {
  id: string;
  titulo: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24">
      <h2 className="mb-3 text-xl font-extrabold tracking-tight text-foreground sm:text-2xl">
        {titulo}
      </h2>
      <div className="text-muted-foreground [&_strong]:text-foreground">
        {children}
      </div>
    </section>
  );
}
