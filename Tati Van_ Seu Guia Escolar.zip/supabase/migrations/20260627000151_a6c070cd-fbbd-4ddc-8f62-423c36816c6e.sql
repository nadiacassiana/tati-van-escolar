CREATE TABLE IF NOT EXISTS public.alunos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  escola TEXT NOT NULL DEFAULT '—',
  turma TEXT NOT NULL DEFAULT '',
  endereco TEXT NOT NULL DEFAULT '—',
  responsavel TEXT NOT NULL DEFAULT '—',
  telefone TEXT NOT NULL DEFAULT '—',
  whatsapp TEXT NOT NULL DEFAULT '',
  mensalidade NUMERIC(10,2) NOT NULL DEFAULT 0,
  vencimento INTEGER NOT NULL DEFAULT 5,
  horario_ida TEXT NOT NULL DEFAULT '—',
  horario_volta TEXT NOT NULL DEFAULT '—',
  aniversario TEXT NOT NULL DEFAULT '',
  observacoes TEXT NOT NULL DEFAULT '',
  pode_buscar TEXT NOT NULL DEFAULT '',
  nao_pode_buscar TEXT NOT NULL DEFAULT '',
  restricoes TEXT NOT NULL DEFAULT '',
  avatar TEXT NOT NULL DEFAULT '🧒',
  status_mensalidade TEXT NOT NULL DEFAULT 'pendente' CHECK (status_mensalidade IN ('pago', 'pendente', 'atrasado')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.alunos TO authenticated;
GRANT ALL ON public.alunos TO service_role;

ALTER TABLE public.alunos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Motoristas podem ver seus alunos" ON public.alunos;
CREATE POLICY "Motoristas podem ver seus alunos"
ON public.alunos
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Motoristas podem cadastrar seus alunos" ON public.alunos;
CREATE POLICY "Motoristas podem cadastrar seus alunos"
ON public.alunos
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Motoristas podem editar seus alunos" ON public.alunos;
CREATE POLICY "Motoristas podem editar seus alunos"
ON public.alunos
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Motoristas podem apagar seus alunos" ON public.alunos;
CREATE POLICY "Motoristas podem apagar seus alunos"
ON public.alunos
FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS update_alunos_updated_at ON public.alunos;
CREATE TRIGGER update_alunos_updated_at
BEFORE UPDATE ON public.alunos
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX IF NOT EXISTS alunos_user_id_created_at_idx ON public.alunos (user_id, created_at DESC);