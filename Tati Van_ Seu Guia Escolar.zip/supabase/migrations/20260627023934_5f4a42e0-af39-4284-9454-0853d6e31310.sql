
-- Responsáveis
CREATE TABLE public.responsaveis (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  nome text NOT NULL,
  telefone text NOT NULL DEFAULT '',
  whatsapp text NOT NULL DEFAULT '',
  pix text NOT NULL DEFAULT '',
  endereco text NOT NULL DEFAULT '',
  observacoes text NOT NULL DEFAULT '',
  alunos_ids uuid[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.responsaveis TO authenticated;
GRANT ALL ON public.responsaveis TO service_role;
ALTER TABLE public.responsaveis ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own responsaveis select" ON public.responsaveis FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own responsaveis insert" ON public.responsaveis FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own responsaveis update" ON public.responsaveis FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own responsaveis delete" ON public.responsaveis FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER update_responsaveis_updated_at BEFORE UPDATE ON public.responsaveis FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Gastos
CREATE TABLE public.gastos (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  data date NOT NULL DEFAULT CURRENT_DATE,
  categoria text NOT NULL DEFAULT 'Outros',
  valor numeric NOT NULL DEFAULT 0,
  descricao text NOT NULL DEFAULT '',
  km integer,
  observacoes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.gastos TO authenticated;
GRANT ALL ON public.gastos TO service_role;
ALTER TABLE public.gastos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own gastos select" ON public.gastos FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own gastos insert" ON public.gastos FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own gastos update" ON public.gastos FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own gastos delete" ON public.gastos FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER update_gastos_updated_at BEFORE UPDATE ON public.gastos FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Documentos da van
CREATE TABLE public.documentos (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  nome text NOT NULL,
  numero text NOT NULL DEFAULT '',
  vencimento date,
  observacoes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.documentos TO authenticated;
GRANT ALL ON public.documentos TO service_role;
ALTER TABLE public.documentos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own documentos select" ON public.documentos FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own documentos insert" ON public.documentos FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own documentos update" ON public.documentos FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own documentos delete" ON public.documentos FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER update_documentos_updated_at BEFORE UPDATE ON public.documentos FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Pagamentos (dar baixa em mensalidades)
CREATE TABLE public.pagamentos (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  aluno_id uuid NOT NULL REFERENCES public.alunos(id) ON DELETE CASCADE,
  mes_referencia text NOT NULL,
  valor numeric NOT NULL DEFAULT 0,
  metodo text NOT NULL DEFAULT 'dinheiro',
  data_pagamento date NOT NULL DEFAULT CURRENT_DATE,
  observacoes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pagamentos TO authenticated;
GRANT ALL ON public.pagamentos TO service_role;
ALTER TABLE public.pagamentos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own pagamentos select" ON public.pagamentos FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own pagamentos insert" ON public.pagamentos FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own pagamentos update" ON public.pagamentos FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own pagamentos delete" ON public.pagamentos FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER update_pagamentos_updated_at BEFORE UPDATE ON public.pagamentos FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX idx_pagamentos_aluno_mes ON public.pagamentos(aluno_id, mes_referencia);
