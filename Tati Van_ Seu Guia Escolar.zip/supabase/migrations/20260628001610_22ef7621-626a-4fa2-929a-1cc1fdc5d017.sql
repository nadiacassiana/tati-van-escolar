
CREATE TABLE public.mensagens (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  nome text NOT NULL,
  emoji text NOT NULL DEFAULT '💬',
  texto text NOT NULL,
  favorito boolean NOT NULL DEFAULT false,
  ordem integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mensagens TO authenticated;
GRANT ALL ON public.mensagens TO service_role;
ALTER TABLE public.mensagens ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own mensagens" ON public.mensagens FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER update_mensagens_updated_at BEFORE UPDATE ON public.mensagens FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX mensagens_user_ordem_idx ON public.mensagens (user_id, favorito DESC, ordem ASC, created_at ASC);

CREATE TABLE public.mensagens_historico (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mensagem_nome text NOT NULL DEFAULT '',
  emoji text NOT NULL DEFAULT '💬',
  texto text NOT NULL,
  destinatario text NOT NULL DEFAULT '',
  telefone text NOT NULL DEFAULT '',
  responsavel_id uuid,
  aluno_id uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.mensagens_historico TO authenticated;
GRANT ALL ON public.mensagens_historico TO service_role;
ALTER TABLE public.mensagens_historico ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own historico" ON public.mensagens_historico FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX mensagens_historico_user_created_idx ON public.mensagens_historico (user_id, created_at DESC);
