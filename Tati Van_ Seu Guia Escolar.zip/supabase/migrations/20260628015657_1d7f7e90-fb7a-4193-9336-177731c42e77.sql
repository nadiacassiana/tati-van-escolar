
ALTER TABLE public.responsaveis
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS pessoas_autorizadas text,
  ADD COLUMN IF NOT EXISTS telefone_emergencia text;

ALTER TABLE public.contratos
  ADD COLUMN IF NOT EXISTS email_responsavel text,
  ADD COLUMN IF NOT EXISTS horario_ida text,
  ADD COLUMN IF NOT EXISTS horario_volta text,
  ADD COLUMN IF NOT EXISTS forma_pagamento text,
  ADD COLUMN IF NOT EXISTS pix_motorista text,
  ADD COLUMN IF NOT EXISTS pessoas_autorizadas text,
  ADD COLUMN IF NOT EXISTS telefone_emergencia text,
  ADD COLUMN IF NOT EXISTS observacoes_importantes text,
  ADD COLUMN IF NOT EXISTS enviado_whatsapp_em timestamptz,
  ADD COLUMN IF NOT EXISTS enviado_email_em timestamptz,
  ADD COLUMN IF NOT EXISTS assinado_em timestamptz,
  ADD COLUMN IF NOT EXISTS arquivado_em timestamptz,
  ADD COLUMN IF NOT EXISTS historico jsonb NOT NULL DEFAULT '[]'::jsonb;
