
ALTER TABLE public.documentos
  ADD COLUMN IF NOT EXISTS vistoria_checklist jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS vistoria_concluida_em timestamptz,
  ADD COLUMN IF NOT EXISTS vistoria_parabens_exibido boolean NOT NULL DEFAULT false;
