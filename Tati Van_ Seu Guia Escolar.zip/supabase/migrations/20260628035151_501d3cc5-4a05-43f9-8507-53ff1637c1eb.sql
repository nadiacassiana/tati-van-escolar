
CREATE TABLE public.saude_van_snapshots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  mes_referencia TEXT NOT NULL,
  score INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, mes_referencia)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.saude_van_snapshots TO authenticated;
GRANT ALL ON public.saude_van_snapshots TO service_role;

ALTER TABLE public.saude_van_snapshots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own saude snapshots"
ON public.saude_van_snapshots FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER update_saude_van_snapshots_updated_at
BEFORE UPDATE ON public.saude_van_snapshots
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
