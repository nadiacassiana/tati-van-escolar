
ALTER TABLE public.mensagens ADD COLUMN IF NOT EXISTS categoria text NOT NULL DEFAULT 'Geral';
ALTER TABLE public.mensagens_historico ADD COLUMN IF NOT EXISTS canal text NOT NULL DEFAULT 'whatsapp';
ALTER TABLE public.mensagens_historico ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'enviado';
