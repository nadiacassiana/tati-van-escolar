
CREATE TABLE public.recibos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  numero TEXT NOT NULL,
  pagamento_id UUID,
  aluno_id UUID,
  aluno_nome TEXT NOT NULL,
  escola TEXT,
  turma TEXT,
  periodo TEXT,
  responsavel_nome TEXT,
  responsavel_cpf TEXT,
  responsavel_telefone TEXT,
  responsavel_whatsapp TEXT,
  responsavel_email TEXT,
  mes_referencia TEXT NOT NULL,
  valor NUMERIC NOT NULL DEFAULT 0,
  data_vencimento DATE,
  data_pagamento DATE NOT NULL DEFAULT CURRENT_DATE,
  metodo TEXT,
  observacoes TEXT,
  favorito BOOLEAN NOT NULL DEFAULT false,
  envios JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.recibos TO authenticated;
GRANT ALL ON public.recibos TO service_role;

ALTER TABLE public.recibos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own recibos" ON public.recibos
  FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE INDEX recibos_user_created_idx ON public.recibos (user_id, created_at DESC);
CREATE UNIQUE INDEX recibos_user_numero_idx ON public.recibos (user_id, numero);

CREATE OR REPLACE FUNCTION public.set_recibo_numero()
RETURNS TRIGGER AS $$
DECLARE
  next_n INT;
BEGIN
  IF NEW.numero IS NULL OR NEW.numero = '' THEN
    SELECT COALESCE(MAX(NULLIF(regexp_replace(numero, '\D', '', 'g'), '')::INT), 0) + 1
      INTO next_n
      FROM public.recibos
      WHERE user_id = NEW.user_id;
    NEW.numero := 'REC-' || LPAD(next_n::TEXT, 6, '0');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER recibos_set_numero
  BEFORE INSERT ON public.recibos
  FOR EACH ROW EXECUTE FUNCTION public.set_recibo_numero();

CREATE TRIGGER recibos_updated_at
  BEFORE UPDATE ON public.recibos
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
