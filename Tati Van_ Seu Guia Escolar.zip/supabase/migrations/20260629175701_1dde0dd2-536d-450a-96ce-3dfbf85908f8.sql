DROP POLICY IF EXISTS "Users manage own recibos" ON public.recibos;
CREATE POLICY "Users manage own recibos" ON public.recibos FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
REVOKE ALL ON public.recibos FROM anon;