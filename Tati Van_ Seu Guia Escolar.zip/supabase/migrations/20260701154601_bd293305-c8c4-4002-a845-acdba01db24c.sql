
CREATE TABLE public.rotas_ativas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  turno TEXT NOT NULL CHECK (turno IN ('manha','tarde')),
  motorista_nome TEXT,
  iniciada_em TIMESTAMPTZ NOT NULL DEFAULT now(),
  encerrada_em TIMESTAMPTZ,
  ultima_lat DOUBLE PRECISION,
  ultima_lng DOUBLE PRECISION,
  ultima_atualizacao TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.rotas_ativas TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.rotas_ativas TO authenticated;
GRANT ALL ON public.rotas_ativas TO service_role;

ALTER TABLE public.rotas_ativas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owner pode gerenciar suas rotas"
  ON public.rotas_ativas FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Qualquer um pode ver rota pelo id (link público)"
  ON public.rotas_ativas FOR SELECT
  TO anon
  USING (true);

CREATE TRIGGER update_rotas_ativas_updated_at
  BEFORE UPDATE ON public.rotas_ativas
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX rotas_ativas_user_turno_idx
  ON public.rotas_ativas (user_id, turno, encerrada_em);
