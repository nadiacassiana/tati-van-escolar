
-- Remove policy pública que permitia listar todas as rotas
DROP POLICY IF EXISTS "Qualquer um pode ver rota pelo id (link público)" ON public.rotas_ativas;

-- Função security definer que expõe apenas a rota específica solicitada pelo id do link
CREATE OR REPLACE FUNCTION public.get_rota_publica(_id uuid)
RETURNS TABLE (
  id uuid,
  turno text,
  motorista_nome text,
  iniciada_em timestamptz,
  encerrada_em timestamptz,
  ultima_lat double precision,
  ultima_lng double precision,
  ultima_atualizacao timestamptz
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT r.id, r.turno, r.motorista_nome, r.iniciada_em, r.encerrada_em,
         r.ultima_lat, r.ultima_lng, r.ultima_atualizacao
  FROM public.rotas_ativas r
  WHERE r.id = _id
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public.get_rota_publica(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_rota_publica(uuid) TO anon, authenticated;
