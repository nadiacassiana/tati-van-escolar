
ALTER TABLE public.rotas_ativas
  ADD COLUMN IF NOT EXISTS expira_em timestamptz,
  ADD COLUMN IF NOT EXISTS revogada_em timestamptz;

DROP FUNCTION IF EXISTS public.get_rota_publica(uuid);

CREATE FUNCTION public.get_rota_publica(_id uuid)
 RETURNS TABLE(
   id uuid, turno text, motorista_nome text,
   iniciada_em timestamptz, encerrada_em timestamptz,
   expira_em timestamptz, revogada_em timestamptz,
   ultima_lat double precision, ultima_lng double precision,
   ultima_atualizacao timestamptz
 )
 LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  SELECT r.id, r.turno, r.motorista_nome,
         r.iniciada_em, r.encerrada_em,
         r.expira_em, r.revogada_em,
         r.ultima_lat, r.ultima_lng, r.ultima_atualizacao
  FROM public.rotas_ativas r
  WHERE r.id = _id
  LIMIT 1;
$function$;
