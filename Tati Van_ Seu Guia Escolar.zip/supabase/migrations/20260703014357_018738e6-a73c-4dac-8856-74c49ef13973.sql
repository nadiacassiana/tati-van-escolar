
CREATE POLICY "admin read all alunos" ON public.alunos
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "admin read all responsaveis" ON public.responsaveis
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "admin read all contratos" ON public.contratos
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "admin read all recibos" ON public.recibos
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "admin read all rotas_ativas" ON public.rotas_ativas
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
