
CREATE TABLE public.deleted_accounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  nome TEXT,
  email TEXT,
  whatsapp TEXT,
  cidade TEXT,
  estado TEXT,
  cadastro_em TIMESTAMPTZ,
  excluido_em TIMESTAMPTZ NOT NULL DEFAULT now(),
  dias_permanencia INT,
  status_no_momento TEXT,
  motivo TEXT,
  motivo_texto TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.deleted_accounts TO authenticated;
GRANT ALL ON public.deleted_accounts TO service_role;

ALTER TABLE public.deleted_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins podem ler histórico de exclusões"
  ON public.deleted_accounts
  FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_deleted_accounts_excluido_em ON public.deleted_accounts (excluido_em DESC);
