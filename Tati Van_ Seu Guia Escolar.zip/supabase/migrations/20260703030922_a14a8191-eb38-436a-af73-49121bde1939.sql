
CREATE TABLE public.retention_surveys (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  motivos TEXT[] NOT NULL DEFAULT '{}',
  comentario TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.retention_surveys TO authenticated;
GRANT ALL ON public.retention_surveys TO service_role;

ALTER TABLE public.retention_surveys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Motorista lê sua própria resposta"
  ON public.retention_surveys FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Motorista insere sua própria resposta"
  ON public.retention_surveys FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX idx_retention_surveys_created_at ON public.retention_surveys (created_at DESC);
