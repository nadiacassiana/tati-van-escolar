ALTER TABLE public.alunos ADD COLUMN IF NOT EXISTS arquivado_em timestamptz;
ALTER TABLE public.responsaveis ADD COLUMN IF NOT EXISTS arquivado_em timestamptz;
CREATE INDEX IF NOT EXISTS idx_alunos_arquivado_em ON public.alunos (arquivado_em);
CREATE INDEX IF NOT EXISTS idx_responsaveis_arquivado_em ON public.responsaveis (arquivado_em);