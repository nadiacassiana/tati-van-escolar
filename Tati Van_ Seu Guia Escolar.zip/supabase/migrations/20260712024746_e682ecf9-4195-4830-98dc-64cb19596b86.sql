
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS trial_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS trial_days_bonus integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS blocked_at timestamptz;
