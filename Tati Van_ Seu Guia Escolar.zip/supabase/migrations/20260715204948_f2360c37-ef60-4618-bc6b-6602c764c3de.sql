
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS asaas_customer_id text,
  ADD COLUMN IF NOT EXISTS asaas_subscription_id text,
  ADD COLUMN IF NOT EXISTS asaas_next_due_date date,
  ADD COLUMN IF NOT EXISTS subscription_status text NOT NULL DEFAULT 'trial',
  ADD COLUMN IF NOT EXISTS subscription_started_at timestamptz,
  ADD COLUMN IF NOT EXISTS subscription_ends_at timestamptz,
  ADD COLUMN IF NOT EXISTS trial_ends_at timestamptz,
  ADD COLUMN IF NOT EXISTS plan_price numeric(10,2) NOT NULL DEFAULT 29.90,
  ADD COLUMN IF NOT EXISTS payment_method text;

-- Backfill trial_ends_at para quem ainda não tem
UPDATE public.profiles
   SET trial_ends_at = COALESCE(trial_started_at, created_at) + interval '10 days'
 WHERE trial_ends_at IS NULL;
