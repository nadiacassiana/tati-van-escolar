ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS logo text;

UPDATE public.profiles p
SET logo = u.raw_user_meta_data->>'logo'
FROM auth.users u
WHERE u.id = p.user_id
  AND COALESCE(u.raw_user_meta_data->>'logo', '') <> ''
  AND COALESCE(p.logo, '') = '';

UPDATE auth.users
SET raw_user_meta_data = raw_user_meta_data - 'logo'
WHERE raw_user_meta_data ? 'logo';