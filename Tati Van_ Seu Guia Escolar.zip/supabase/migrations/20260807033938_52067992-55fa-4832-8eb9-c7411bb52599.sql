CREATE TABLE public.garantias_vaga (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  aluno_id uuid REFERENCES public.alunos(id) ON DELETE SET NULL,
  aluno_nome text NOT NULL DEFAULT '',
  responsavel_nome text NOT NULL DEFAULT '',
  responsavel_whatsapp text NOT NULL DEFAULT '',
  escola text NOT NULL DEFAULT '',
  ano_referencia integer NOT NULL,
  tipo text NOT NULL DEFAULT 'rematricula',
  tipo_outro text NOT NULL DEFAULT '',
  cobrar boolean NOT NULL DEFAULT false,
  valor numeric NOT NULL DEFAULT 0,
  abater boolean NOT NULL DEFAULT false,
  abater_em text NOT NULL DEFAULT '',
  abater_outro text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pendente',
  observacoes text NOT NULL DEFAULT '',
  enviado_em timestamptz,
  confirmado_em timestamptz,
  recusado_em timestamptz,
  historico jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.garantias_vaga TO authenticated;
GRANT ALL ON public.garantias_vaga TO service_role;

ALTER TABLE public.garantias_vaga ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Motorista gerencia suas garantias de vaga"
ON public.garantias_vaga FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE UNIQUE INDEX garantias_vaga_aluno_ano_unico
ON public.garantias_vaga (user_id, aluno_id, ano_referencia)
WHERE aluno_id IS NOT NULL;

CREATE TRIGGER update_garantias_vaga_updated_at
BEFORE UPDATE ON public.garantias_vaga
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();