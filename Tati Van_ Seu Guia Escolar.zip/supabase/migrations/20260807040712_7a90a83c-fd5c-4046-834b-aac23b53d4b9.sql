CREATE TABLE public.lancamentos_financeiros (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  aluno_id uuid REFERENCES public.alunos(id) ON DELETE SET NULL,
  aluno_nome text NOT NULL DEFAULT '',
  tipo text NOT NULL DEFAULT 'outros',
  descricao text NOT NULL DEFAULT '',
  valor numeric NOT NULL DEFAULT 0,
  saldo_restante numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'a_receber',
  competencia text,
  ano_referencia integer,
  garantia_id uuid REFERENCES public.garantias_vaga(id) ON DELETE SET NULL,
  origem text NOT NULL DEFAULT '',
  regra_abatimento text,
  data_recebimento date,
  historico jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.lancamentos_financeiros TO authenticated;
GRANT ALL ON public.lancamentos_financeiros TO service_role;

ALTER TABLE public.lancamentos_financeiros ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Motoristas gerenciam seus lancamentos"
ON public.lancamentos_financeiros FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE UNIQUE INDEX lancamentos_sem_duplicidade
ON public.lancamentos_financeiros (
  user_id, aluno_id, tipo,
  COALESCE(competencia, ''),
  COALESCE(ano_referencia, 0)
);

CREATE INDEX lancamentos_user_idx ON public.lancamentos_financeiros (user_id, tipo, status);

CREATE TRIGGER update_lancamentos_updated_at
BEFORE UPDATE ON public.lancamentos_financeiros
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();