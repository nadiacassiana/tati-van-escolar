ALTER TABLE public.alunos
  ADD COLUMN IF NOT EXISTS tipo_cobranca text NOT NULL DEFAULT 'mensal';

ALTER TABLE public.alunos
  ADD CONSTRAINT alunos_tipo_cobranca_check CHECK (tipo_cobranca IN ('mensal','anual'));