UPDATE auth.users
SET raw_user_meta_data = (raw_user_meta_data - 'logo' - 'logotipo' - 'foto' - 'avatar_base64')
WHERE raw_user_meta_data ? 'logo'
   OR raw_user_meta_data ? 'logotipo'
   OR raw_user_meta_data ? 'foto'
   OR raw_user_meta_data ? 'avatar_base64'
   OR length(raw_user_meta_data::text) > 8000;