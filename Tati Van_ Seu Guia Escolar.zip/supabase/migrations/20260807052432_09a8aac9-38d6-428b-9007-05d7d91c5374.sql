ALTER TABLE public.alunos DROP CONSTRAINT IF EXISTS alunos_tipo_cobranca_check;
UPDATE public.alunos SET tipo_cobranca = 'anual_parcelado' WHERE tipo_cobranca = 'anual';
ALTER TABLE public.alunos ADD CONSTRAINT alunos_tipo_cobranca_check CHECK (tipo_cobranca = ANY (ARRAY['mensal'::text, 'anual_vista'::text, 'anual_parcelado'::text]));