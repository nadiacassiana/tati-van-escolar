ALTER TABLE public.contratos
  ADD COLUMN IF NOT EXISTS assinatura_motorista jsonb,
  ADD COLUMN IF NOT EXISTS assinatura_responsavel jsonb;

ALTER TABLE public.garantias_vaga
  ADD COLUMN IF NOT EXISTS assinatura_motorista jsonb,
  ADD COLUMN IF NOT EXISTS assinatura_responsavel jsonb;

CREATE OR REPLACE FUNCTION public.get_documento_assinatura(_tipo text, _id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  doc jsonb;
  owner uuid;
  marca jsonb;
BEGIN
  IF _tipo = 'contrato' THEN
    SELECT c.user_id,
           jsonb_build_object(
             'tipo', 'contrato',
             'id', c.id,
             'aluno_nome', c.aluno_nome,
             'responsavel', c.responsavel,
             'escola', c.escola,
             'endereco', c.endereco,
             'telefone', c.telefone,
             'mensalidade', c.mensalidade,
             'dia_vencimento', c.dia_vencimento,
             'data_inicio', c.data_inicio,
             'data_termino', c.data_termino,
             'turno', c.turno,
             'horario_ida', c.horario_ida,
             'horario_volta', c.horario_volta,
             'forma_pagamento', c.forma_pagamento,
             'pessoas_autorizadas', c.pessoas_autorizadas,
             'observacoes_importantes', c.observacoes_importantes,
             'observacoes', c.observacoes,
             'assinatura_motorista', c.assinatura_motorista,
             'assinatura_responsavel', c.assinatura_responsavel
           )
      INTO owner, doc
      FROM public.contratos c
     WHERE c.id = _id;
  ELSIF _tipo = 'garantia' THEN
    SELECT g.user_id,
           jsonb_build_object(
             'tipo', 'garantia',
             'id', g.id,
             'aluno_nome', g.aluno_nome,
             'escola', g.escola,
             'responsavel_nome', g.responsavel_nome,
             'ano_referencia', g.ano_referencia,
             'tipo_garantia', g.tipo,
             'tipo_outro', g.tipo_outro,
             'cobrar', g.cobrar,
             'valor', g.valor,
             'abater', g.abater,
             'abater_em', g.abater_em,
             'abater_outro', g.abater_outro,
             'observacoes', g.observacoes,
             'status', g.status,
             'assinatura_motorista', g.assinatura_motorista,
             'assinatura_responsavel', g.assinatura_responsavel
           )
      INTO owner, doc
      FROM public.garantias_vaga g
     WHERE g.id = _id;
  ELSE
    RETURN NULL;
  END IF;

  IF doc IS NULL THEN
    RETURN NULL;
  END IF;

  SELECT jsonb_build_object(
           'nome', COALESCE(
             NULLIF(u.raw_user_meta_data->>'empresa', ''),
             NULLIF(u.raw_user_meta_data->>'nome_completo', ''),
             NULLIF(p.nome, ''),
             'Transporte Escolar'
           ),
           'logo', p.logo,
           'apelido', NULLIF(u.raw_user_meta_data->>'apelido', ''),
           'nome_completo', COALESCE(NULLIF(u.raw_user_meta_data->>'nome_completo', ''), NULLIF(p.nome, ''))
         )
    INTO marca
    FROM auth.users u
    LEFT JOIN public.profiles p ON p.user_id = u.id
   WHERE u.id = owner;

  RETURN doc || jsonb_build_object('marca', COALESCE(marca, '{}'::jsonb));
END;
$$;

CREATE OR REPLACE FUNCTION public.assinar_documento_responsavel(
  _tipo text,
  _id uuid,
  _nome text,
  _imagem text
)
RETURNS jsonb
LANGUAGE plpgsql
VOLATILE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  ja_assinado boolean;
  motorista_ok boolean;
  assinatura jsonb;
BEGIN
  IF _nome IS NULL OR length(btrim(_nome)) < 3 THEN
    RETURN jsonb_build_object('ok', false, 'erro', 'nome_invalido');
  END IF;
  IF _imagem IS NULL OR _imagem NOT LIKE 'data:image/png;base64,%' OR length(_imagem) > 400000 THEN
    RETURN jsonb_build_object('ok', false, 'erro', 'imagem_invalida');
  END IF;

  assinatura := jsonb_build_object(
    'imagem', _imagem,
    'nome', btrim(_nome),
    'papel', 'responsavel',
    'em', to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
  );

  IF _tipo = 'contrato' THEN
    SELECT c.assinatura_responsavel IS NOT NULL, c.assinatura_motorista IS NOT NULL
      INTO ja_assinado, motorista_ok
      FROM public.contratos c WHERE c.id = _id;
    IF ja_assinado IS NULL THEN RETURN jsonb_build_object('ok', false, 'erro', 'nao_encontrado'); END IF;
    IF NOT motorista_ok THEN RETURN jsonb_build_object('ok', false, 'erro', 'aguardando_motorista'); END IF;
    IF ja_assinado THEN RETURN jsonb_build_object('ok', false, 'erro', 'ja_assinado'); END IF;
    UPDATE public.contratos
       SET assinatura_responsavel = assinatura,
           assinado_em = now()
     WHERE id = _id;
    RETURN jsonb_build_object('ok', true);
  ELSIF _tipo = 'garantia' THEN
    SELECT g.assinatura_responsavel IS NOT NULL, g.assinatura_motorista IS NOT NULL
      INTO ja_assinado, motorista_ok
      FROM public.garantias_vaga g WHERE g.id = _id;
    IF ja_assinado IS NULL THEN RETURN jsonb_build_object('ok', false, 'erro', 'nao_encontrado'); END IF;
    IF NOT motorista_ok THEN RETURN jsonb_build_object('ok', false, 'erro', 'aguardando_motorista'); END IF;
    IF ja_assinado THEN RETURN jsonb_build_object('ok', false, 'erro', 'ja_assinado'); END IF;
    UPDATE public.garantias_vaga
       SET assinatura_responsavel = assinatura,
           confirmacao_nome = btrim(_nome),
           status = 'confirmado',
           confirmado_em = now(),
           recusado_em = NULL
     WHERE id = _id;
    RETURN jsonb_build_object('ok', true);
  END IF;

  RETURN jsonb_build_object('ok', false, 'erro', 'tipo_invalido');
END;
$$;

REVOKE ALL ON FUNCTION public.get_documento_assinatura(text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_documento_assinatura(text, uuid) TO anon, authenticated, service_role;
REVOKE ALL ON FUNCTION public.assinar_documento_responsavel(text, uuid, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.assinar_documento_responsavel(text, uuid, text, text) TO anon, authenticated, service_role;