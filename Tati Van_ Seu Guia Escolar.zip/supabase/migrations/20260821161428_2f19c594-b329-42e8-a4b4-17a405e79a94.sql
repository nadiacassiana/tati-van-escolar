CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_whats text := NULLIF(NEW.raw_user_meta_data->>'whatsapp', '');
  v_consent boolean := COALESCE((NEW.raw_user_meta_data->>'whatsapp_consent')::boolean, false);
BEGIN
  INSERT INTO public.profiles (
    user_id, nome, email, whatsapp, whatsapp_consent, whatsapp_consent_at,
    plan_status, subscription_status, trial_started_at, trial_ends_at
  )
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'nome', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.email,
    v_whats,
    v_consent,
    CASE WHEN v_consent THEN now() ELSE NULL END,
    'trial',
    'trial',
    now(),
    now() + interval '10 days'
  )
  ON CONFLICT (user_id) DO UPDATE
    SET email = COALESCE(EXCLUDED.email, public.profiles.email),
        trial_started_at = COALESCE(public.profiles.trial_started_at, EXCLUDED.trial_started_at),
        trial_ends_at = COALESCE(public.profiles.trial_ends_at, EXCLUDED.trial_ends_at);

  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'motorista')
  ON CONFLICT (user_id, role) DO NOTHING;

  IF NEW.email_confirmed_at IS NOT NULL
     AND lower(NEW.email) = 'tatiassistentevirtualbr@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;

  RETURN NEW;
END;
$function$;