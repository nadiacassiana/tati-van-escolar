CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

SELECT cron.unschedule('aniversarios-diario') WHERE EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'aniversarios-diario');

SELECT cron.schedule(
  'aniversarios-diario',
  '0 11 * * *',
  $$
  SELECT net.http_post(
    url := 'https://project--e7ce0ced-e067-413e-a028-c7e4bfea712c.lovable.app/api/public/notificacoes-cron',
    headers := '{"Content-Type": "application/json", "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxteXdzdnhjYmd4d2lsYmJrZmxoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI1MDQ0NzIsImV4cCI6MjA5ODA4MDQ3Mn0.Q4ZrsP0xX7Y6FK1X2PzCfFZUO5lDKAHeiPNm2aPrz5U"}'::jsonb,
    body := '{"origem": "cron"}'::jsonb
  );
  $$
);