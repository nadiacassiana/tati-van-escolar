CREATE OR REPLACE FUNCTION public.get_documento_assinatura(_tipo text, _id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  doc jsonb;
  owner uuid;
  marca jsonb;
BEGIN
  IF _tipo = 'contrato' THEN
    SELECT c.user_id,
           jsonb_build_object(
             'tipo', 'contrato',
             'id', c.id,
             'aluno_nome', c.aluno_nome,
             'responsavel', c.responsavel,
             'escola', c.escola,
             'endereco', c.endereco,
             'telefone', c.telefone,
             'email_responsavel', c.email_responsavel,
             'telefone_emergencia', c.telefone_emergencia,
             'pix_motorista', c.pix_motorista,
             'mensalidade', c.mensalidade,
             'dia_vencimento', c.dia_vencimento,
             'data_inicio', c.data_inicio,
             'data_termino', c.data_termino,
             'turno', c.turno,
             'horario_ida', c.horario_ida,
             'horario_volta', c.horario_volta,
             'forma_pagamento', c.forma_pagamento,
             'pessoas_autorizadas', c.pessoas_autorizadas,
             'observacoes_importantes', c.observacoes_importantes,
             'observacoes', c.observacoes,
             'assinatura_motorista', c.assinatura_motorista,
             'assinatura_responsavel', c.assinatura_responsavel
           )
      INTO owner, doc
      FROM public.contratos c
     WHERE c.id = _id;
  ELSIF _tipo = 'garantia' THEN
    SELECT g.user_id,
           jsonb_build_object(
             'tipo', 'garantia',
             'id', g.id,
             'aluno_nome', g.aluno_nome,
             'escola', g.escola,
             'responsavel_nome', g.responsavel_nome,
             'ano_referencia', g.ano_referencia,
             'tipo_garantia', g.tipo,
             'tipo_outro', g.tipo_outro,
             'cobrar', g.cobrar,
             'valor', g.valor,
             'abater', g.abater,
             'abater_em', g.abater_em,
             'abater_outro', g.abater_outro,
             'prazo_resposta', g.prazo_resposta,
             'confirmado_em', g.confirmado_em,
             'observacoes', g.observacoes,
             'status', g.status,
             'assinatura_motorista', g.assinatura_motorista,
             'assinatura_responsavel', g.assinatura_responsavel
           )
      INTO owner, doc
      FROM public.garantias_vaga g
     WHERE g.id = _id;
  ELSE
    RETURN NULL;
  END IF;

  IF doc IS NULL THEN
    RETURN NULL;
  END IF;

  SELECT jsonb_build_object(
           'nome', COALESCE(
             NULLIF(u.raw_user_meta_data->>'empresa', ''),
             NULLIF(u.raw_user_meta_data->>'nome_completo', ''),
             NULLIF(p.nome, ''),
             'Transporte Escolar'
           ),
           'logo', p.logo,
           'apelido', NULLIF(u.raw_user_meta_data->>'apelido', ''),
           'nome_completo', COALESCE(NULLIF(u.raw_user_meta_data->>'nome_completo', ''), NULLIF(p.nome, ''))
         )
    INTO marca
    FROM auth.users u
    LEFT JOIN public.profiles p ON p.user_id = u.id
   WHERE u.id = owner;

  RETURN doc || jsonb_build_object('marca', COALESCE(marca, '{}'::jsonb));
END;
$$;

REVOKE ALL ON FUNCTION public.get_documento_assinatura(text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_documento_assinatura(text, uuid) TO anon, authenticated, service_role;