CREATE TABLE public.notificacoes_agendadas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipo text NOT NULL DEFAULT 'teste',
  titulo text NOT NULL,
  corpo text NOT NULL,
  url text,
  agendada_para timestamptz NOT NULL,
  enviada_em timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_notificacoes_agendadas_pendentes ON public.notificacoes_agendadas (agendada_para) WHERE enviada_em IS NULL;
GRANT SELECT, INSERT, DELETE ON public.notificacoes_agendadas TO authenticated;
GRANT ALL ON public.notificacoes_agendadas TO service_role;
ALTER TABLE public.notificacoes_agendadas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Motorista vê seus agendamentos" ON public.notificacoes_agendadas FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Motorista cria seus agendamentos" ON public.notificacoes_agendadas FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Motorista apaga seus agendamentos" ON public.notificacoes_agendadas FOR DELETE TO authenticated USING (auth.uid() = user_id);