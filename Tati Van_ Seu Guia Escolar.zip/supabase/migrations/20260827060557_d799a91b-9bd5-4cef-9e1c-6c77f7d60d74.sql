CREATE TABLE public.lista_espera (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  aluno_nome text NOT NULL,
  responsavel_nome text NOT NULL,
  responsavel_whatsapp text NOT NULL,
  escola text NOT NULL DEFAULT '',
  periodo text NOT NULL DEFAULT '',
  endereco text NOT NULL DEFAULT '',
  numero text NOT NULL DEFAULT '',
  observacoes text NOT NULL DEFAULT '',
  convertido_em timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.lista_espera TO authenticated;
GRANT ALL ON public.lista_espera TO service_role;

ALTER TABLE public.lista_espera ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Motorista gerencia sua lista de espera"
ON public.lista_espera FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER update_lista_espera_updated_at
BEFORE UPDATE ON public.lista_espera
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

ALTER TABLE public.garantias_vaga ADD COLUMN IF NOT EXISTS mensalidade_prevista numeric NOT NULL DEFAULT 0;