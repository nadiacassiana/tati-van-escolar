ALTER TABLE public.alunos ADD COLUMN IF NOT EXISTS turno TEXT;
ALTER TABLE public.alunos DROP CONSTRAINT IF EXISTS alunos_turno_check;
ALTER TABLE public.alunos ADD CONSTRAINT alunos_turno_check CHECK (turno IS NULL OR turno IN ('manha','tarde','integral'));

ALTER TABLE public.rotas_ativas DROP CONSTRAINT IF EXISTS rotas_ativas_turno_check;
ALTER TABLE public.rotas_ativas ADD CONSTRAINT rotas_ativas_turno_check CHECK (turno IN ('manha','tarde','integral'));

CREATE TABLE IF NOT EXISTS public.rota_paradas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  rota_id UUID NOT NULL REFERENCES public.rotas_ativas(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  aluno_id UUID,
  aluno_nome TEXT NOT NULL,
  ordem INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','embarcado','ausente')),
  embarcado_em TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.rota_paradas TO authenticated;
GRANT ALL ON public.rota_paradas TO service_role;

ALTER TABLE public.rota_paradas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Motorista gerencia suas paradas"
ON public.rota_paradas FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS rota_paradas_rota_ordem_idx ON public.rota_paradas (rota_id, ordem);
CREATE UNIQUE INDEX IF NOT EXISTS rota_paradas_rota_aluno_idx ON public.rota_paradas (rota_id, aluno_id) WHERE aluno_id IS NOT NULL;

CREATE TRIGGER update_rota_paradas_updated_at
BEFORE UPDATE ON public.rota_paradas
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.get_rota_status(_rota uuid, _parada uuid DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  r public.rotas_ativas%ROWTYPE;
  p public.rota_paradas%ROWTYPE;
  estado text;
  restantes int := 0;
  prox_ordem int;
  total_pendentes int := 0;
BEGIN
  SELECT * INTO r FROM public.rotas_ativas WHERE id = _rota;
  IF r.id IS NULL THEN
    RETURN jsonb_build_object('encontrada', false);
  END IF;

  IF r.encerrada_em IS NOT NULL THEN estado := 'encerrada';
  ELSIF r.revogada_em IS NOT NULL THEN estado := 'revogada';
  ELSIF r.expira_em IS NOT NULL AND r.expira_em <= now() THEN estado := 'expirada';
  ELSE estado := 'ativa';
  END IF;

  SELECT count(*) INTO total_pendentes
    FROM public.rota_paradas WHERE rota_id = _rota AND status = 'pendente';

  SELECT min(ordem) INTO prox_ordem
    FROM public.rota_paradas WHERE rota_id = _rota AND status = 'pendente';

  IF _parada IS NOT NULL THEN
    SELECT * INTO p FROM public.rota_paradas WHERE id = _parada AND rota_id = _rota;
  END IF;

  IF p.id IS NOT NULL THEN
    SELECT count(*) INTO restantes
      FROM public.rota_paradas
     WHERE rota_id = _rota AND status = 'pendente' AND ordem < p.ordem;
  END IF;

  RETURN jsonb_build_object(
    'encontrada', true,
    'estado', estado,
    'turno', r.turno,
    'motorista_nome', r.motorista_nome,
    'encerrada_em', r.encerrada_em,
    'expira_em', r.expira_em,
    'ultima_lat', r.ultima_lat,
    'ultima_lng', r.ultima_lng,
    'ultima_atualizacao', r.ultima_atualizacao,
    'total_pendentes', total_pendentes,
    'tem_paradas', (prox_ordem IS NOT NULL OR total_pendentes > 0),
    'minha', CASE WHEN p.id IS NULL THEN NULL ELSE jsonb_build_object(
        'nome', p.aluno_nome,
        'status', p.status,
        'restantes', restantes,
        'proxima', (p.status = 'pendente' AND prox_ordem IS NOT NULL AND p.ordem = prox_ordem),
        'embarcado_em', p.embarcado_em
      ) END
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_rota_status(uuid, uuid) TO anon, authenticated;