CREATE TABLE public.pre_cadastros (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  aluno_nome text NOT NULL,
  data_nascimento date,
  escola text NOT NULL DEFAULT '',
  serie text NOT NULL DEFAULT '',
  rua text NOT NULL DEFAULT '',
  numero text NOT NULL DEFAULT '',
  bairro text NOT NULL DEFAULT '',
  referencia text NOT NULL DEFAULT '',
  responsavel_nome text NOT NULL DEFAULT '',
  responsavel_whatsapp text NOT NULL DEFAULT '',
  responsavel_cpf text,
  responsavel_email text,
  telefone_emergencia text,
  pessoas_autorizadas text,
  status text NOT NULL DEFAULT 'pendente',
  aluno_id uuid REFERENCES public.alunos(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT INSERT ON public.pre_cadastros TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pre_cadastros TO authenticated;
GRANT ALL ON public.pre_cadastros TO service_role;

ALTER TABLE public.pre_cadastros ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Qualquer um pode enviar ficha"
ON public.pre_cadastros FOR INSERT TO anon, authenticated
WITH CHECK (status = 'pendente');

CREATE POLICY "Motorista ve suas fichas"
ON public.pre_cadastros FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Motorista atualiza suas fichas"
ON public.pre_cadastros FOR UPDATE TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Motorista exclui suas fichas"
ON public.pre_cadastros FOR DELETE TO authenticated
USING (auth.uid() = user_id);

CREATE INDEX idx_pre_cadastros_user_status ON public.pre_cadastros (user_id, status, created_at DESC);

CREATE TRIGGER update_pre_cadastros_updated_at
BEFORE UPDATE ON public.pre_cadastros
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();