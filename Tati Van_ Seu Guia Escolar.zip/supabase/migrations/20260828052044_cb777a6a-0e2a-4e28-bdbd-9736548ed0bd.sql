ALTER TABLE public.alunos ADD COLUMN IF NOT EXISTS ordem_rota integer;

CREATE TABLE public.rotas_substituto (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  turno text NOT NULL,
  titular_nome text,
  paradas jsonb NOT NULL DEFAULT '[]'::jsonb,
  expira_em timestamp with time zone NOT NULL DEFAULT (now() + interval '24 hours'),
  revogada_em timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.rotas_substituto TO authenticated;
GRANT ALL ON public.rotas_substituto TO service_role;

ALTER TABLE public.rotas_substituto ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Motorista gerencia seus links de substituto"
ON public.rotas_substituto FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER update_rotas_substituto_updated_at
BEFORE UPDATE ON public.rotas_substituto
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.get_rota_substituto(_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  r public.rotas_substituto%ROWTYPE;
BEGIN
  SELECT * INTO r FROM public.rotas_substituto WHERE id = _id;
  IF r.id IS NULL THEN
    RETURN jsonb_build_object('encontrada', false);
  END IF;
  IF r.revogada_em IS NOT NULL THEN
    RETURN jsonb_build_object('encontrada', true, 'estado', 'revogada');
  END IF;
  IF r.expira_em <= now() THEN
    RETURN jsonb_build_object('encontrada', true, 'estado', 'expirada');
  END IF;
  RETURN jsonb_build_object(
    'encontrada', true,
    'estado', 'ativa',
    'turno', r.turno,
    'titular_nome', r.titular_nome,
    'expira_em', r.expira_em,
    'criada_em', r.created_at,
    'paradas', r.paradas
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_rota_substituto(uuid) TO anon, authenticated;