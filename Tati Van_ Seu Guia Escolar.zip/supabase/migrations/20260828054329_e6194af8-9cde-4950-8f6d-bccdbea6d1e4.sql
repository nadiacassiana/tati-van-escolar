ALTER TABLE public.alunos
  ADD COLUMN IF NOT EXISTS multa_atraso numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS multa_tipo text NOT NULL DEFAULT 'percentual',
  ADD COLUMN IF NOT EXISTS juros_dia numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS juros_tipo text NOT NULL DEFAULT 'percentual';

ALTER TABLE public.contratos
  ADD COLUMN IF NOT EXISTS multa_atraso numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS multa_tipo text NOT NULL DEFAULT 'percentual',
  ADD COLUMN IF NOT EXISTS juros_dia numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS juros_tipo text NOT NULL DEFAULT 'percentual',
  ADD COLUMN IF NOT EXISTS clausulas_adicionais text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS clausulas_custom jsonb;