ALTER TABLE public.pre_cadastros ADD COLUMN IF NOT EXISTS autoriza_imagem boolean;
ALTER TABLE public.alunos ADD COLUMN IF NOT EXISTS autoriza_imagem boolean;
ALTER TABLE public.contratos ADD COLUMN IF NOT EXISTS autoriza_imagem boolean;