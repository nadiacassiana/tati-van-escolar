DROP FUNCTION IF EXISTS public.get_rota_status(uuid, uuid);
CREATE FUNCTION public.get_rota_status(_rota uuid, _parada uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  r public.rotas_ativas%ROWTYPE;
  p public.rota_paradas%ROWTYPE;
  estado text;
  restantes int := 0;
  prox_ordem int;
  total_pendentes int := 0;
  total_concluidas int := 0;
BEGIN
  SELECT * INTO r FROM public.rotas_ativas WHERE id = _rota;
  IF r.id IS NULL THEN
    RETURN jsonb_build_object('encontrada', false);
  END IF;

  IF r.encerrada_em IS NOT NULL THEN estado := 'encerrada';
  ELSIF r.revogada_em IS NOT NULL THEN estado := 'revogada';
  ELSIF r.expira_em IS NOT NULL AND r.expira_em <= now() THEN estado := 'expirada';
  ELSE estado := 'ativa';
  END IF;

  SELECT count(*) INTO total_pendentes
    FROM public.rota_paradas WHERE rota_id = _rota AND status = 'pendente';

  SELECT count(*) INTO total_concluidas
    FROM public.rota_paradas WHERE rota_id = _rota AND status = 'embarcado';

  SELECT min(ordem) INTO prox_ordem
    FROM public.rota_paradas WHERE rota_id = _rota AND status = 'pendente';

  IF _parada IS NOT NULL THEN
    SELECT * INTO p FROM public.rota_paradas WHERE id = _parada AND rota_id = _rota;
  END IF;

  IF p.id IS NOT NULL THEN
    SELECT count(*) INTO restantes
      FROM public.rota_paradas
     WHERE rota_id = _rota AND status = 'pendente' AND ordem < p.ordem;
  END IF;

  RETURN jsonb_build_object(
    'encontrada', true,
    'estado', estado,
    'turno', r.turno,
    'motorista_nome', r.motorista_nome,
    'encerrada_em', r.encerrada_em,
    'expira_em', r.expira_em,
    'ultima_lat', r.ultima_lat,
    'ultima_lng', r.ultima_lng,
    'ultima_atualizacao', r.ultima_atualizacao,
    'total_pendentes', total_pendentes,
    'total_concluidas', total_concluidas,
    'tem_paradas', (prox_ordem IS NOT NULL OR total_pendentes > 0),
    'minha', CASE WHEN p.id IS NULL THEN NULL ELSE jsonb_build_object(
        'nome', split_part(p.aluno_nome, ' ', 1),
        'status', p.status,
        'restantes', restantes,
        'proxima', (p.status = 'pendente' AND prox_ordem IS NOT NULL AND p.ordem = prox_ordem),
        'embarcado_em', p.embarcado_em
      ) END
  );
END;
$$;