GRANT INSERT ON public.lista_espera TO anon;
CREATE POLICY "Qualquer um pode entrar na lista de espera"
ON public.lista_espera
FOR INSERT
TO anon, authenticated
WITH CHECK (convertido_em IS NULL);