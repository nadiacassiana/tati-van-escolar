ALTER TABLE public.alunos ADD COLUMN IF NOT EXISTS estado text NOT NULL DEFAULT '';
ALTER TABLE public.pre_cadastros ADD COLUMN IF NOT EXISTS cidade text NOT NULL DEFAULT '';
ALTER TABLE public.pre_cadastros ADD COLUMN IF NOT EXISTS estado text NOT NULL DEFAULT '';
ALTER TABLE public.pre_cadastros ADD COLUMN IF NOT EXISTS cep text NOT NULL DEFAULT '';