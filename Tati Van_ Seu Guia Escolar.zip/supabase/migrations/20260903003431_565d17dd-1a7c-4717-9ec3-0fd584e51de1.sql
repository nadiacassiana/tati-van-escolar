CREATE OR REPLACE FUNCTION public.get_escolas_publicas(_user_id uuid)
RETURNS TABLE(nome text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT e.nome
  FROM public.escolas e
  WHERE e.user_id = _user_id
  ORDER BY e.nome ASC
$$;

GRANT EXECUTE ON FUNCTION public.get_escolas_publicas(uuid) TO anon, authenticated;