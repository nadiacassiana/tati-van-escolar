ALTER TABLE public.rotas_ativas
  ADD COLUMN IF NOT EXISTS sentido text NOT NULL DEFAULT 'ida';

DO $$ BEGIN
  ALTER TABLE public.rotas_ativas
    ADD CONSTRAINT rotas_ativas_sentido_check CHECK (sentido IN ('ida','volta'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE OR REPLACE FUNCTION public.get_rota_status(_rota uuid, _parada uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  r public.rotas_ativas%ROWTYPE;
  p public.rota_paradas%ROWTYPE;
  estado text;
  restantes int := 0;
  prox_ordem int;
  total_pendentes int := 0;
  total_concluidas int := 0;
  a public.alunos%ROWTYPE;
  end_casa text;
  end_escola text;
BEGIN
  SELECT * INTO r FROM public.rotas_ativas WHERE id = _rota;
  IF r.id IS NULL THEN
    RETURN jsonb_build_object('encontrada', false);
  END IF;

  IF r.encerrada_em IS NOT NULL THEN estado := 'encerrada';
  ELSIF r.revogada_em IS NOT NULL THEN estado := 'revogada';
  ELSIF r.expira_em IS NOT NULL AND r.expira_em <= now() THEN estado := 'expirada';
  ELSE estado := 'ativa';
  END IF;

  SELECT count(*) INTO total_pendentes
    FROM public.rota_paradas WHERE rota_id = _rota AND status = 'pendente';

  SELECT count(*) INTO total_concluidas
    FROM public.rota_paradas WHERE rota_id = _rota AND status = 'embarcado';

  SELECT min(ordem) INTO prox_ordem
    FROM public.rota_paradas WHERE rota_id = _rota AND status = 'pendente';

  IF _parada IS NOT NULL THEN
    SELECT * INTO p FROM public.rota_paradas WHERE id = _parada AND rota_id = _rota;
  END IF;

  IF p.id IS NOT NULL THEN
    SELECT count(*) INTO restantes
      FROM public.rota_paradas
     WHERE rota_id = _rota AND status = 'pendente' AND ordem < p.ordem;

    IF p.aluno_id IS NOT NULL THEN
      SELECT * INTO a FROM public.alunos WHERE id = p.aluno_id;
      IF a.id IS NOT NULL THEN
        end_casa := NULLIF(btrim(
          CASE WHEN btrim(COALESCE(a.rua, '')) <> '' THEN
            concat_ws(', ', NULLIF(btrim(a.rua), ''), NULLIF(btrim(a.numero), ''))
            || CASE WHEN btrim(COALESCE(a.bairro, '')) <> '' THEN ' - ' || btrim(a.bairro) ELSE '' END
            || CASE WHEN btrim(COALESCE(a.cidade, '')) <> '' THEN ', ' || btrim(a.cidade) ELSE '' END
            || CASE WHEN btrim(COALESCE(a.cep, '')) <> '' THEN ', ' || btrim(a.cep) ELSE '' END
          ELSE COALESCE(a.endereco, '') END
        ), '');

        SELECT NULLIF(btrim(
                 CASE WHEN btrim(COALESCE(e.rua, '')) <> '' THEN
                   concat_ws(', ', NULLIF(btrim(e.rua), ''), NULLIF(btrim(e.numero), ''))
                   || CASE WHEN btrim(COALESCE(e.bairro, '')) <> '' THEN ' - ' || btrim(e.bairro) ELSE '' END
                   || CASE WHEN btrim(COALESCE(e.cidade, '')) <> '' THEN ', ' || btrim(e.cidade) ELSE '' END
                   || CASE WHEN btrim(COALESCE(e.cep, '')) <> '' THEN ', ' || btrim(e.cep) ELSE '' END
                 ELSE COALESCE(e.endereco, '') END
               ), '')
          INTO end_escola
          FROM public.escolas e
         WHERE e.user_id = a.user_id AND lower(btrim(e.nome)) = lower(btrim(a.escola))
         LIMIT 1;
      END IF;
    END IF;
  END IF;

  RETURN jsonb_build_object(
    'encontrada', true,
    'estado', estado,
    'turno', r.turno,
    'sentido', COALESCE(r.sentido, 'ida'),
    'motorista_nome', r.motorista_nome,
    'encerrada_em', r.encerrada_em,
    'expira_em', r.expira_em,
    'ultima_lat', r.ultima_lat,
    'ultima_lng', r.ultima_lng,
    'ultima_atualizacao', r.ultima_atualizacao,
    'total_pendentes', total_pendentes,
    'total_concluidas', total_concluidas,
    'tem_paradas', (prox_ordem IS NOT NULL OR total_pendentes > 0),
    'minha', CASE WHEN p.id IS NULL THEN NULL ELSE jsonb_build_object(
        'nome', split_part(p.aluno_nome, ' ', 1),
        'status', p.status,
        'restantes', restantes,
        'proxima', (p.status = 'pendente' AND prox_ordem IS NOT NULL AND p.ordem = prox_ordem),
        'embarcado_em', p.embarcado_em,
        'endereco_casa', end_casa,
        'escola_nome', NULLIF(btrim(COALESCE(a.escola, '')), ''),
        'endereco_escola', end_escola
      ) END
  );
END;
$function$;