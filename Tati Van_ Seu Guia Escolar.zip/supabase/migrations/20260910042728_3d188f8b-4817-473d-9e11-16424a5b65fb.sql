
-- 1) Limite absoluto de 4 horas e encerramento forçado no servidor
CREATE OR REPLACE FUNCTION public.rotas_ativas_hard_limit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  limite timestamptz;
BEGIN
  -- prazo obrigatório: no máximo 4h após o início
  limite := COALESCE(NEW.iniciada_em, now()) + interval '4 hours';
  IF NEW.expira_em IS NULL OR NEW.expira_em > limite THEN
    NEW.expira_em := limite;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    -- rota já encerrada/revogada/expirada: congela a localização
    IF OLD.encerrada_em IS NOT NULL
       OR OLD.revogada_em IS NOT NULL
       OR (OLD.expira_em IS NOT NULL AND OLD.expira_em <= now()) THEN
      NEW.ultima_lat := OLD.ultima_lat;
      NEW.ultima_lng := OLD.ultima_lng;
      NEW.ultima_atualizacao := OLD.ultima_atualizacao;
      NEW.encerrada_em := COALESCE(OLD.encerrada_em, LEAST(now(), COALESCE(OLD.expira_em, now())));
    END IF;
  END IF;

  -- auto-kill: prazo atingido => encerra
  IF NEW.encerrada_em IS NULL AND NEW.expira_em IS NOT NULL AND NEW.expira_em <= now() THEN
    NEW.encerrada_em := now();
    NEW.ultima_lat := NULL;
    NEW.ultima_lng := NULL;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_rotas_ativas_hard_limit ON public.rotas_ativas;
CREATE TRIGGER trg_rotas_ativas_hard_limit
BEFORE INSERT OR UPDATE ON public.rotas_ativas
FOR EACH ROW EXECUTE FUNCTION public.rotas_ativas_hard_limit();

-- 2) Encerra imediatamente qualquer rota já vencida ou aberta há mais de 4h
UPDATE public.rotas_ativas
SET encerrada_em = now(), ultima_lat = NULL, ultima_lng = NULL
WHERE encerrada_em IS NULL
  AND (
    (expira_em IS NOT NULL AND expira_em <= now())
    OR iniciada_em <= now() - interval '4 hours'
  );
